#ifndef COLIBRI_TIER_H
#define COLIBRI_TIER_H

#include <stdint.h>

/* ─── Fine-tuned constants for 4-agent MoE on 16 GB / Intel HD620 ─── */

/* Heat decay: preserve history for small committees.
 * 0.9 per heartbeat gives ~5 minute half-life instead of 30s. */
#define TIER_DECAY_NUM    9
#define TIER_DECAY_DENOM 10

/* Minimum heat floor: a recently-accessed expert remains
 * distinguishable from a never-accessed one. */
#define TIER_MIN_HEAT     1

/* Recency window: 64 ticks @ 30s = ~32 minutes. */
#define TIER_RECENT_WINDOW 64

/* Swap hysteresis: keep 25% + 4-frequency margin. */
#define TIER_SWAP_HYSTERESIS_NUM   5  /* 1.25x */
#define TIER_SWAP_HYSTERESIS_DENOM 4
#define TIER_SWAP_FREQ_MARGIN      4

/* RAM thresholds for 16 GB / Intel HD620 potato tier. */
#define TIER_RAM_BUDGET_MB     10240  /* 10 GB */
#define TIER_EVICTION_RAM_PCT  65      /* early eviction */
#define TIER_HARD_HALT_RAM_PCT 70     /* absolute halt */

/* Max hot experts for integrated-GPU inference. */
#define TIER_MAX_HOT 2

/* Pick one RAM/VRAM hot-store slot to replace from recent routing heat.
 * The fixed margin handles tiny samples; the 25% margin prevents ping-pong. */
static int tier_pick_swap(const uint32_t *heat, int nexpert,
                          const int *pinned, int npin,
                          int *slot, int *eid, long *gain){
    if(!heat || !pinned || npin<1 || nexpert<1) return 0;
    int cold=0;
    for(int z=1;z<npin;z++) if(heat[pinned[z]]<heat[pinned[cold]]) cold=z;
    int hot=-1; uint32_t fh=0;
    for(int e=0;e<nexpert;e++){
        int resident=0;
        for(int z=0;z<npin;z++) if(pinned[z]==e){ resident=1; break; }
        if(!resident && heat[e]>fh){ fh=heat[e]; hot=e; }
    }
    if(hot<0) return 0;
    uint32_t fc=heat[pinned[cold]];
    if(fh<=fc+(fc>>2)+4) return 0;
    *slot=cold; *eid=hot; *gain=(long)fh-(long)fc;
    return 1;
}

/* LFRU: frequency is the primary signal; recency breaks close calls. A recent
 * access contributes at most 255 points while one frequency count is worth
 * 256, so a merely recent expert cannot displace a genuinely hotter one. */
static uint64_t tier_lfru_score(uint32_t heat, uint32_t last, uint32_t clock){
    uint32_t age=clock-last, recent=age<TIER_RECENT_WINDOW?TIER_RECENT_WINDOW-age:0;
    return ((uint64_t)heat<<8)|recent;
}

static int tier_pick_lfru(const uint32_t *heat, const uint32_t *last, uint32_t clock,
                          int nexpert, const int *pinned, int npin,
                          int *slot, int *eid, long *gain){
    if(!heat||!last||!pinned||npin<1||nexpert<1) return 0;
    int cold=0;
    for(int z=1;z<npin;z++)
        if(tier_lfru_score(heat[pinned[z]],last[pinned[z]],clock)<
           tier_lfru_score(heat[pinned[cold]],last[pinned[cold]],clock)) cold=z;
    int hot=-1; uint64_t hs=0;
    for(int e=0;e<nexpert;e++){
        int resident=0; for(int z=0;z<npin;z++) if(pinned[z]==e){resident=1;break;}
        uint64_t score=tier_lfru_score(heat[e],last[e],clock);
        if(!resident&&(hot<0||score>hs)){ hot=e; hs=score; }
    }
    if(hot<0) return 0;
    uint64_t cs=tier_lfru_score(heat[pinned[cold]],last[pinned[cold]],clock);
    /* Retain the existing 25%+4-frequency hysteresis in score units. */
    if(hs<=cs+(cs>>2)+(4u<<8)) return 0;
    *slot=cold; *eid=hot; *gain=(long)((hs-cs)>>8); return 1;
}

static void tier_decay(uint32_t *heat, int nexpert){
    for(int e=0;e<nexpert;e++){
        uint32_t v = heat[e];
        v = (v * TIER_DECAY_NUM) / TIER_DECAY_DENOM;
        if(v < TIER_MIN_HEAT && heat[e] > 0) v = TIER_MIN_HEAT;
        heat[e] = v;
    }
}

#endif
