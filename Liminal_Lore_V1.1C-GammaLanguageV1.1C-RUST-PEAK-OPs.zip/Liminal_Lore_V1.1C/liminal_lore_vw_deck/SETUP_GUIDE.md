# Liminal Lore — Setup & Extension Guide

> **Liminal Lore** (formerly Liminal Link) is a self-hosted, agentic game development
> suite with multi-agent orchestration, local LLM inference, and pipeline automation.
> This guide covers initial setup, configuration, and extending the toolchain.

---

## Table of Contents

1. [Quick Start](#quick-start)
2. [Configuration System](#configuration-system)
3. [LLM Provider Setup](#llm-provider-setup)
4. [Extending with Custom Providers](#extending-with-custom-providers)
5. [Hooking into Your Own Toolchain](#hooking-into-your-own-toolchain)
6. [Architecture Reference](#architecture-reference)

---

## Quick Start

### Prerequisites

- **Python 3.10+** (for config system, FUBBU sidecar, VW Nexus)
- **Node.js 18+** (for Electron Deck UI and Hermes Bridge)
- **Ollama** (for local LLM inference) — [ollama.com](https://ollama.com)
- **Git** (for cloning and version control)

### 1. Clone the Repository

```powershell
git clone https://github.com/your-org/voidwalkers.git
cd voidwalkers
```

### 2. Run the Setup Wizard

```powershell
cd Modern_X64\tools\liminal_link_vw_deck
python -m config.setup_wizard
```

The wizard will:
- Detect your project root
- Generate a `.env` template file
- Generate a `liminal_lore.yaml` config file
- Prompt you for your preferred LLM provider
- Validate the configuration

### 3. Configure Your Credentials

Edit the generated `.env` file:

```ini
# Project root (required)
PROJECT_ROOT=C:\path\to\your\project

# LLM provider (choose one)
LIMINAL_LORE_ACTIVE_PROVIDER=ollama
LIMINAL_LORE_ACTIVE_MODEL=qwen2.5-coder:7b

# Ollama (local, no API key needed)
OLLAMA_BASE_URL=http://127.0.0.1:11434

# Or use OpenAI-compatible API:
# LLM_BASE_URL=http://127.0.0.1:1234/v1
# LLM_API_KEY=your-key-here

# Or OpenRouter:
# OPENROUTER_API_KEY=sk-or-...
```

### 4. Install Ollama Models

```powershell
ollama pull qwen2.5-coder:7b
# Optional: larger model for heavy analysis
ollama pull deepseek-coder:6.7b
```

### 5. Validate Configuration

```powershell
python -m config.setup_wizard --check
```

### 6. Start Liminal Lore

```powershell
# Start the Hermes Bridge (Node.js)
cd electron
npm install
npm start
```

---

## Configuration System

### Layered Resolution

Configuration is resolved in priority order:

| Priority | Source | Purpose |
|----------|--------|---------|
| 1 (highest) | Environment variables | Runtime overrides, secrets |
| 2 | `.env` file | User credentials, local settings |
| 3 | `liminal_lore.yaml` | User preferences, provider config |
| 4 (lowest) | Built-in defaults | Safe fallbacks, no secrets |

### Key Principle: **No secrets in config files**

API keys are **never** stored in `liminal_lore.yaml` or any JSON config file.
They are always read from environment variables at runtime.

The config file stores the **name** of the env var to read, not the value:

```yaml
providers:
  openai_compatible:
    api_key_env: "LLM_API_KEY"  # ← Name of env var, not the key itself
```

### Config Files

| File | Location | Purpose |
|------|----------|---------|
| `.env` | Project root | API keys, credentials, env-specific overrides |
| `liminal_lore.yaml` | Project root | Provider config, UI settings, hardware tier |
| `vw_deck.config.json` | `tools/liminal_link_vw_deck/` | Deck UI config (uses `${project_root}` vars) |
| `liminal_settings.json` | `tools/liminal_link_vw_deck/` | FS service settings |

### Environment Variables Reference

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `PROJECT_ROOT` | Yes | — | Absolute path to project root |
| `LIMINAL_LORE_ACTIVE_PROVIDER` | No | `ollama` | Active LLM provider |
| `LIMINAL_LORE_ACTIVE_MODEL` | No | Provider default | Model name |
| `OLLAMA_BASE_URL` | No | `http://127.0.0.1:11434` | Ollama endpoint |
| `LLM_BASE_URL` | If using OpenAI-compat | — | OpenAI-compatible API URL |
| `LLM_API_KEY` | If using OpenAI-compat | — | API key |
| `OPENROUTER_API_KEY` | If using OpenRouter | — | OpenRouter API key |
| `CUSTOM_LLM_BASE_URL` | If using custom | — | Custom LLM endpoint |
| `CUSTOM_LLM_API_KEY` | If using custom | — | Custom API key |
| `NEXUS_API_KEY` | No | — | Nexus API key (if auth enabled) |
| `LIMINAL_LORE_NEXUS_URL` | No | `http://127.0.0.1:8651` | Nexus URL |
| `LIMINAL_LORE_BRIDGE_PORT` | No | `8643` | Bridge server port |
| `LIMINAL_LORE_THEME` | No | `void` | UI theme (void, ice, ember) |
| `LIMINAL_LORE_HARDWARE_TIER` | No | `mid_range` | Hardware profile |

---

## LLM Provider Setup

### Option A: Local Ollama (Recommended for self-hosting)

1. Install Ollama: [ollama.com](https://ollama.com)
2. Pull models:
   ```powershell
   ollama pull qwen2.5-coder:7b
   ollama pull deepseek-coder:6.7b
   ```
3. Configure `.env`:
   ```ini
   LIMINAL_LORE_ACTIVE_PROVIDER=ollama
   OLLAMA_BASE_URL=http://127.0.0.1:11434
   LIMINAL_LORE_ACTIVE_MODEL=qwen2.5-coder:7b
   ```

### Option B: vLLM Server

1. Install vLLM: `pip install vllm`
2. Start server:
   ```powershell
   python -m vllm.entrypoints.openai.api_server --model your-model --port 1234
   ```
3. Configure `.env`:
   ```ini
   LIMINAL_LORE_ACTIVE_PROVIDER=openai_compatible
   LLM_BASE_URL=http://127.0.0.1:1234/v1
   LIMINAL_LORE_ACTIVE_MODEL=your-model
   ```

### Option C: LM Studio

1. Download LM Studio: [lmstudio.ai](https://lmstudio.ai)
2. Load a model and start the local server
3. Configure `.env`:
   ```ini
   LIMINAL_LORE_ACTIVE_PROVIDER=openai_compatible
   LLM_BASE_URL=http://127.0.0.1:1234/v1
   LIMINAL_LORE_ACTIVE_MODEL=loaded-model-name
   ```

### Option D: OpenRouter (Cloud)

1. Get an API key: [openrouter.ai](https://openrouter.ai)
2. Configure `.env`:
   ```ini
   LIMINAL_LORE_ACTIVE_PROVIDER=openrouter
   OPENROUTER_API_KEY=sk-or-...
   LIMINAL_LORE_ACTIVE_MODEL=anthropic/claude-3.5-sonnet
   ```

---

## Extending with Custom Providers

### Adding a New Provider

1. **Add to `liminal_lore.yaml`** under `providers`:

```yaml
providers:
  my_custom_provider:
    enabled: true
    base_url_env: "MY_PROVIDER_URL"
    api_key_env: "MY_PROVIDER_KEY"
    default_base_url: "https://api.my-provider.com/v1"
    default_model: "my-model-v1"
```

2. **Add env vars to `.env`**:

```ini
MY_PROVIDER_URL=https://api.my-provider.com/v1
MY_PROVIDER_KEY=your-key-here
```

3. **Set as active provider**:

```ini
LIMINAL_LORE_ACTIVE_PROVIDER=my_custom_provider
```

The `LLMProvider` class auto-detects the API format:
- If URL contains `11434` → Ollama native API
- If URL contains `openrouter` → OpenRouter format
- Otherwise → OpenAI-compatible format

### Forcing a Specific API Format

If your provider uses a non-standard format, you can extend
`provider_abstraction.py`:

```python
# In provider_abstraction.py, add to _resolve_provider():
if pconfig["id"] == "my_custom_provider":
    provider_type = "my_custom_format"
```

Then implement a `_call_my_custom_format()` method on the `LLMProvider` class.

---

## Hooking into Your Own Toolchain

### Registering Custom Tools

Add tools to `vw_deck.config.json` under `tool_registry`:

```json
{
  "id": "my_tool",
  "name": "My Custom Tool",
  "category": "Custom",
  "command": "python my_script.py",
  "args": "--agent",
  "cwd": "${project_root}/my_tools",
  "icon": "🔧"
}
```

### Connecting to VW Nexus

Liminal Lore integrates with VW Nexus for multi-agent orchestration:

1. Start Nexus:
   ```powershell
   cd Modern_X64\tools
   python -m vw_nexus
   ```

2. Configure `.env`:
   ```ini
   LIMINAL_LORE_NEXUS_URL=http://127.0.0.1:8651
   ```

3. Agents registered with Nexus can claim tasks, query RAG, and coordinate.

### Using the FUBBU Sidecar

FUBBU is a self-hosted multi-agent orchestration sidecar that runs
Router-Worker-Verifier loops using local models:

```powershell
cd Modern_X64\tools\fubbu
python -m fubbu test-connection
python -m fubbu start
```

See `tools/fubbu/README.md` for full FUBBU documentation.

### Custom RAG Corpora

The RAG system supports multiple knowledge bases:

```powershell
cd Modern_X64\tools
python -m vw_rag ingest --corpus my_docs --path ./my_docs
```

Query from agents:
```
POST http://127.0.0.1:8651/rag
{"query": "your search", "corpus": "my_docs", "max_chunks": 10}
```

---

## Architecture Reference

```
┌─────────────────────────────────────────────────────────────────┐
│                     Liminal Lore Suite                          │
│                                                                 │
│  ┌──────────────┐   ┌──────────────┐   ┌──────────────────┐    │
│  │  Electron    │   │  Hermes      │   │  VW Nexus        │    │
│  │  Deck UI     │←→ │  Bridge      │←→ │  (orchestration) │    │
│  │  (Chat/Deck) │   │  (:8643)     │   │  (:8651)         │    │
│  └──────────────┘   └──────┬───────┘   └────────┬─────────┘    │
│                            │                     │              │
│  ┌─────────────────────────┼─────────────────────┼──────┐      │
│  │     Config System       │                     │      │      │
│  │  (.env → YAML → defs)   │                     │      │      │
│  │  Provider Abstraction   │                     │      │      │
│  └─────────────────────────┘                     │      │      │
│                                                  │      │      │
│  ┌───────────────────────────────────────────────┘      │      │
│  │  FUBBU Sidecar (Router→Worker→Verifier)              │      │
│  │  Local models via Ollama/vLLM                       │      │
│  └──────────────────────────────────────────────────────┘      │
│                                                                 │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐               │
│  │  Ollama    │  │  vLLM      │  │  OpenRouter│               │
│  │  (:11434)  │  │  (:1234)   │  │  (cloud)   │               │
│  └────────────┘  └────────────┘  └────────────┘               │
└─────────────────────────────────────────────────────────────────┘
```

### Module Structure

```
tools/liminal_link_vw_deck/
├── config/
│   ├── __init__.py            # Package exports
│   ├── config_loader.py       # Layered config loader (.env → YAML → defaults)
│   ├── provider_abstraction.py # Dynamic LLM provider client
│   └── setup_wizard.py        # Interactive setup & template generation
├── electron/
│   ├── main.js                # Electron main process
│   ├── hermes-bridge.js       # HTTP bridge server
│   └── package.json           # Node.js dependencies
├── vw_deck.config.json        # Deck UI config (uses ${project_root} vars)
├── liminal_settings.json      # FS service settings
├── VoidWalkers_Chat_GUI.html  # Main UI
└── hermes-bridge.js           # Root-level bridge (for non-Electron mode)
```

### Security Model

- **Credentials**: Only in `.env`, never in config files or source
- **File access**: Allowlist-based, configurable via `${project_root}` prefix
- **Exec safety**: Blocked patterns (rm -rf, format, etc.)
- **Denied paths**: `.ssh`, `.git/hooks`, `secrets.*`, `keys.*`
- **VPN**: Disabled by default for public release

---

## Troubleshooting

### "Provider not reachable"

1. Check if Ollama is running: `ollama serve`
2. Check `OLLAMA_BASE_URL` in `.env`
3. Run: `python -m config.setup_wizard --check`

### "No model specified"

Set `LIMINAL_LORE_ACTIVE_MODEL` in `.env` or `active_model` in `liminal_lore.yaml`.

### "Nexus not running"

Nexus is optional. If you need multi-agent orchestration:
```powershell
cd Modern_X64\tools
python -m vw_nexus
```

### "Config file not found"

Run the setup wizard to generate template files:
```powershell
python -m config.setup_wizard --generate
```

---

## Caveman Token Compression (V100C)

Caveman is a token compression skill that injects a terse "caveman speak" prompt into LLM requests, reducing output tokens by ~65% without losing technical accuracy. Code blocks, commands, and error strings stay byte-for-byte exact.

### How It Works

1. `caveman_middleware.js` intercepts chat requests in `hermes-bridge.js`
2. A caveman skill prompt (from `caveman_levels/*.txt`) is appended to the system message
3. The LLM responds in compressed terse style
4. Telemetry tracks token savings per response

### Compression Levels

| Level | Description |
|-------|-------------|
| `off` | No compression — passthrough |
| `lite` | No filler/hedging. Keep articles + full sentences. Professional but tight |
| `full` | Drop articles, fragments OK, short synonyms. Classic caveman |
| `ultra` | Strip conjunctions, one word when enough. Maximum terseness |
| `wenyan` | Classical Chinese (文言文). 80-90% character reduction |

### Configuration

In `.env`:
```
CAVEMAN_ENABLED=true
CAVEMAN_LEVEL=full
```

In `liminal_lore.yaml`:
```yaml
caveman:
  enabled: true
  level: full
  track_savings: true
  compress_context: false
  exclude_roles: ["tool", "function"]
  min_prompt_tokens: 50
```

### Runtime Toggle (No Restart)

```bash
# Check current settings
curl http://127.0.0.1:8643/caveman

# Change level
curl -X POST http://127.0.0.1:8643/caveman \
  -H "Content-Type: application/json" \
  -d '{"level": "ultra"}'

# Disable
curl -X POST http://127.0.0.1:8643/caveman \
  -H "Content-Type: application/json" \
  -d '{"enabled": false}'

# View savings stats
curl http://127.0.0.1:8643/caveman/stats
```

### Coordination with Other Services

- **TurboQuant**: Compressed output = slower KV cache growth. `predict_kv_cache_size()` accepts `caveman_enabled` parameter for accurate prediction.
- **Colibri**: Throughput is normalized — `access()` accepts `caveman_compressed` flag so LFRU scores reflect true productivity, not raw compressed token counts.
- **Gigatoken**: When available, exact token counting replaces heuristic estimation in savings tracking.

### Health Check

Caveman is included in the `/health/all` endpoint:
```bash
curl http://127.0.0.1:8643/health/all
```
