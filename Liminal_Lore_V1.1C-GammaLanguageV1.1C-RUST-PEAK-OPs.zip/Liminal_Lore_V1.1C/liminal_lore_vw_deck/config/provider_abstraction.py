"""Liminal Lore — Dynamic LLM Provider Abstraction.

Abstracts the LLM backend so users can dynamically switch between:
  - Local Ollama endpoints
  - vLLM servers
  - OpenAI-compatible APIs (e.g., LM Studio, text-generation-webui)
  - OpenRouter
  - Any custom OpenAI-compatible base URL

All credentials are read from environment variables at runtime.
No API keys are stored in config files or source code.
"""

from __future__ import annotations

import json
import time
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from typing import Any, Dict, Generator, List, Optional

from .config_loader import ConfigLoader


@dataclass
class ProviderInfo:
    """Resolved provider information."""
    id: str
    base_url: str
    api_key: str
    model: str
    enabled: bool
    provider_type: str  # ollama, openai_compatible, openrouter, custom

    @property
    def has_auth(self) -> bool:
        return bool(self.api_key)

    @property
    def is_local(self) -> bool:
        return "127.0.0.1" in self.base_url or "localhost" in self.base_url


class LLMProvider:
    """Unified LLM provider client.

    Routes requests to the appropriate backend based on provider type:
      - ollama: POST /api/generate (Ollama native API)
      - openai_compatible: POST /v1/chat/completions (OpenAI API format)
      - openrouter: POST /api/v1/chat/completions (OpenRouter)
      - custom: POST {base_url}/chat/completions (user-defined)

    All providers support:
      - generate(prompt, system) → single response
      - generate_stream(prompt, system) → streaming response (generator)
      - list_models() → available models
      - health_check() → connectivity test
    """

    def __init__(self, config_loader: ConfigLoader, provider_id: Optional[str] = None):
        self.config = config_loader
        self._provider_id = provider_id
        self._info: Optional[ProviderInfo] = None

    @property
    def info(self) -> ProviderInfo:
        if self._info is None:
            self._info = self._resolve_provider(self._provider_id)
        return self._info

    def _resolve_provider(self, provider_id: Optional[str]) -> ProviderInfo:
        """Resolve provider config from ConfigLoader."""
        pconfig = self.config.get_provider_config(provider_id)
        provider_type = pconfig["id"]

        # Determine provider type
        if pconfig["id"] == "ollama":
            provider_type = "ollama"
        elif pconfig["id"] == "openrouter":
            provider_type = "openrouter"
        elif pconfig["id"] == "openai_compatible":
            provider_type = "openai_compatible"
        elif pconfig["id"] == "custom":
            provider_type = "custom"
        else:
            # Auto-detect from base URL
            if "ollama" in pconfig["base_url"] or "11434" in pconfig["base_url"]:
                provider_type = "ollama"
            elif "openrouter" in pconfig["base_url"]:
                provider_type = "openrouter"
            else:
                provider_type = "openai_compatible"

        return ProviderInfo(
            id=pconfig["id"],
            base_url=pconfig["base_url"],
            api_key=pconfig["api_key"],
            model=pconfig["model"],
            enabled=pconfig["enabled"],
            provider_type=provider_type,
        )

    def switch_provider(self, provider_id: str, model: Optional[str] = None) -> None:
        """Switch to a different provider at runtime."""
        self._provider_id = provider_id
        self._info = self._resolve_provider(provider_id)
        if model:
            self._info.model = model

    # ── Ollama API ────────────────────────────────────────────

    def _call_ollama(self, prompt: str, system: str = "",
                     temperature: float = 0.7, max_tokens: int = 2048,
                     stream: bool = False, timeout: int = 120) -> Dict[str, Any]:
        """Call Ollama /api/generate."""
        payload = json.dumps({
            "model": self.info.model,
            "prompt": prompt,
            "system": system,
            "stream": stream,
            "options": {
                "temperature": temperature,
                "num_predict": max_tokens,
            },
        }).encode("utf-8")

        url = f"{self.info.base_url}/api/generate"
        headers = {"Content-Type": "application/json"}

        start = time.time()
        req = urllib.request.Request(url, data=payload, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if stream:
                return {"ok": True, "stream": True, "response": resp}
            result = json.loads(resp.read().decode("utf-8"))
        latency_ms = (time.time() - start) * 1000

        return {
            "ok": True,
            "output": result.get("response", ""),
            "tokens_in": result.get("prompt_eval_count", 0),
            "tokens_out": result.get("eval_count", 0),
            "latency_ms": latency_ms,
            "model": result.get("model", self.info.model),
            "provider": self.info.id,
        }

    # ── OpenAI-compatible API ─────────────────────────────────

    def _call_openai_compatible(self, prompt: str, system: str = "",
                                temperature: float = 0.7, max_tokens: int = 2048,
                                stream: bool = False, timeout: int = 120) -> Dict[str, Any]:
        """Call OpenAI-compatible /v1/chat/completions."""
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        payload = json.dumps({
            "model": self.info.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream,
        }).encode("utf-8")

        # Build URL
        base = self.info.base_url.rstrip("/")
        if self.info.provider_type == "openrouter":
            url = f"{base}/chat/completions"
        else:
            url = f"{base}/v1/chat/completions"

        headers = {"Content-Type": "application/json"}
        if self.info.has_auth:
            headers["Authorization"] = f"Bearer {self.info.api_key}"

        start = time.time()
        req = urllib.request.Request(url, data=payload, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if stream:
                return {"ok": True, "stream": True, "response": resp}
            result = json.loads(resp.read().decode("utf-8"))
        latency_ms = (time.time() - start) * 1000

        # Parse OpenAI response format
        choice = result.get("choices", [{}])[0]
        usage = result.get("usage", {})

        return {
            "ok": True,
            "output": choice.get("message", {}).get("content", ""),
            "tokens_in": usage.get("prompt_tokens", 0),
            "tokens_out": usage.get("completion_tokens", 0),
            "latency_ms": latency_ms,
            "model": result.get("model", self.info.model),
            "provider": self.info.id,
        }

    # ── Token Counting ───────────────────────────────────────

    def count_tokens(self, text: str) -> int:
        """Count tokens using the active model's tokenizer."""
        try:
            from shared.token_counter import get_token_counter
            return get_token_counter(self.info.model).count(text)
        except Exception:
            return len(text) // 4

    def get_context_window(self) -> int:
        """Get the context window size for the active model."""
        try:
            from shared.token_counter import get_token_counter
            return get_token_counter(self.info.model).get_context_window()
        except Exception:
            return 8192

    def fits_in_context(self, prompt: str, system: str = "",
                        max_output: int = 2048) -> bool:
        """Check if prompt + system + max_output fits in context window."""
        try:
            from shared.token_counter import get_token_counter
            tc = get_token_counter(self.info.model)
            return tc.fits_in_context(prompt, system, max_output)
        except Exception:
            return True

    def budget_for_context(self, prompt: str, system: str = "",
                           max_output: int = 2048) -> int:
        """Return available token budget for RAG injection."""
        try:
            from shared.token_counter import get_token_counter
            tc = get_token_counter(self.info.model)
            return tc.budget_for_rag(prompt, system, max_output)
        except Exception:
            return 4096

    # ── Unified Generate ──────────────────────────────────────

    def generate(self, prompt: str, system: str = "",
                 temperature: float = 0.7, max_tokens: int = 2048,
                 timeout: int = 120) -> Dict[str, Any]:
        """Generate a completion using the active provider.

        Returns dict with: ok, output, tokens_in, tokens_out, latency_ms, model, provider,
                          prompt_tokens_local
        """
        if not self.info.enabled:
            return {"ok": False, "error": f"Provider '{self.info.id}' is not enabled"}
        if not self.info.base_url:
            return {"ok": False, "error": f"Provider '{self.info.id}' has no base_url configured"}
        if not self.info.model:
            return {"ok": False, "error": "No model specified. Set active_model in config or env."}

        try:
            if self.info.provider_type == "ollama":
                result = self._call_ollama(prompt, system, temperature, max_tokens, False, timeout)
            else:
                result = self._call_openai_compatible(prompt, system, temperature, max_tokens, False, timeout)
            if result.get("ok"):
                try:
                    from shared.token_counter import get_token_counter
                    result["prompt_tokens_local"] = get_token_counter(self.info.model).count(prompt)
                except Exception:
                    pass
            return result
        except urllib.error.URLError as e:
            return {"ok": False, "error": f"Connection failed: {e}", "provider": self.info.id}
        except Exception as e:
            return {"ok": False, "error": str(e), "provider": self.info.id}

    def generate_stream(self, prompt: str, system: str = "",
                        temperature: float = 0.7, max_tokens: int = 2048,
                        timeout: int = 120) -> Generator[str, None, None]:
        """Stream a completion token-by-token.

        Yields string chunks as they arrive.
        """
        if not self.info.enabled or not self.info.base_url or not self.info.model:
            yield f"[Error: Provider not properly configured]"
            return

        try:
            if self.info.provider_type == "ollama":
                result = self._call_ollama(prompt, system, temperature, max_tokens, True, timeout)
                if result.get("stream"):
                    with result["response"] as resp:
                        for line in resp:
                            line = line.decode("utf-8").strip()
                            if line:
                                chunk = json.loads(line)
                                text = chunk.get("response", "")
                                if text:
                                    yield text
            else:
                result = self._call_openai_compatible(prompt, system, temperature, max_tokens, True, timeout)
                if result.get("stream"):
                    with result["response"] as resp:
                        for line in resp:
                            line = line.decode("utf-8").strip()
                            if line.startswith("data: "):
                                data = line[6:]
                                if data == "[DONE]":
                                    break
                                chunk = json.loads(data)
                                delta = chunk.get("choices", [{}])[0].get("delta", {}).get("content", "")
                                if delta:
                                    yield delta
        except Exception as e:
            yield f"[Error: {e}]"

    # ── Model Listing ─────────────────────────────────────────

    def list_models(self, timeout: int = 10) -> Dict[str, Any]:
        """List available models on the active provider."""
        if not self.info.base_url:
            return {"ok": False, "error": "No base_url configured", "models": []}

        try:
            if self.info.provider_type == "ollama":
                url = f"{self.info.base_url}/api/tags"
            else:
                base = self.info.base_url.rstrip("/")
                url = f"{base}/v1/models" if "openrouter" not in self.info.base_url else f"{base}/models"

            headers = {}
            if self.info.has_auth:
                headers["Authorization"] = f"Bearer {self.info.api_key}"

            req = urllib.request.Request(url, headers=headers, method="GET")
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                result = json.loads(resp.read().decode("utf-8"))

            if self.info.provider_type == "ollama":
                models = [m.get("name", "") for m in result.get("models", [])]
            else:
                models = [m.get("id", "") for m in result.get("data", [])]

            return {"ok": True, "models": models, "provider": self.info.id}
        except Exception as e:
            return {"ok": False, "error": str(e), "models": []}

    # ── Health Check ──────────────────────────────────────────

    def health_check(self, timeout: int = 5) -> Dict[str, Any]:
        """Check if the provider endpoint is reachable."""
        if not self.info.base_url:
            return {"ok": False, "reachable": False, "error": "No base_url configured"}

        try:
            if self.info.provider_type == "ollama":
                url = f"{self.info.base_url}/api/tags"
            else:
                base = self.info.base_url.rstrip("/")
                url = f"{base}/v1/models" if "openrouter" not in self.info.base_url else f"{base}/models"

            headers = {}
            if self.info.has_auth:
                headers["Authorization"] = f"Bearer {self.info.api_key}"

            req = urllib.request.Request(url, headers=headers, method="GET")
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return {"ok": True, "reachable": True, "provider": self.info.id,
                        "base_url": self.info.base_url}
        except Exception as e:
            return {"ok": False, "reachable": False, "error": str(e),
                    "provider": self.info.id, "base_url": self.info.base_url}

    # ── Status ────────────────────────────────────────────────

    def status(self) -> Dict[str, Any]:
        """Get provider status summary."""
        return {
            "provider_id": self.info.id,
            "provider_type": self.info.provider_type,
            "base_url": self.info.base_url,
            "model": self.info.model,
            "enabled": self.info.enabled,
            "is_local": self.info.is_local,
            "has_auth": self.info.has_auth,
            "context_window": self.get_context_window(),
            "tokenizer": "gigatoken" if self.count_tokens("test") != 1 else "heuristic",
        }
