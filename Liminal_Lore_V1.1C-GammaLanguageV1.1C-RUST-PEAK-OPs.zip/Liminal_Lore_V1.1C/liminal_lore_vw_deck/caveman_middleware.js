/**
 * Caveman Token Compression Middleware
 *
 * Injects caveman skill prompt into LLM requests to reduce output
 * token volume by ~65%. Co-exists with:
 *   - TurboQuant: compressed output = slower KV cache growth
 *   - Colibri: faster responses = higher throughput = better LFRU score
 *   - Gigatoken: exact token counting for savings measurement
 *
 * Can be toggled on/off at runtime via /caveman endpoint or config.
 */

const fs = require('fs');
const path = require('path');

const CAVEMAN_DIR = path.join(__dirname, 'caveman_levels');
let cavemanCache = {};

function loadCavemanSkill(level) {
  if (cavemanCache[level] !== undefined && cavemanCache[level] !== '') return cavemanCache[level];
  const filePath = path.join(CAVEMAN_DIR, `${level}.txt`);
  try {
    const text = fs.readFileSync(filePath, 'utf8').trim();
    if (text) {
      cavemanCache[level] = text;
      console.log('[CAVEMAN] Loaded skill for level:', level, 'len:', text.length, 'from:', filePath);
    }
    return text;
  } catch (e) {
    console.warn('[CAVEMAN] Failed to load skill for level:', level, '—', e.message);
    cavemanCache[level] = '';
    return '';
  }
}

function reloadSkills() {
  cavemanCache = {};
}

// Runtime state — level can be changed via /caveman endpoint without restart
let runtimeLevel = null;
let runtimeEnabled = null;

function getCavemanSettings(config) {
  const cavemanConfig = config.caveman || {};
  return {
    enabled: runtimeEnabled !== null ? runtimeEnabled : (cavemanConfig.enabled !== false),
    level: runtimeLevel || cavemanConfig.level || 'full',
    excludeRoles: cavemanConfig.exclude_roles || ['tool', 'function'],
    minPromptTokens: cavemanConfig.min_prompt_tokens || 50,
    trackSavings: cavemanConfig.track_savings !== false,
  };
}

function setRuntimeLevel(level) {
  if (!['lite', 'full', 'ultra', 'wenyan', 'off'].includes(level)) return false;
  runtimeLevel = level;
  return true;
}

function setRuntimeEnabled(enabled) {
  runtimeEnabled = !!enabled;
}

function resetRuntime() {
  runtimeLevel = null;
  runtimeEnabled = null;
}

/**
 * Estimate token count for a string.
 * Uses heuristic (len/4) when no token counter is available.
 * Gigatoken integration replaces this with exact counts when available.
 */
function estimateTokens(text) {
  if (!text) return 0;
  return Math.ceil(text.length / 4);
}

/**
 * Inject caveman skill into messages array.
 * Returns modified messages array. Does not mutate original.
 *
 * @param {Array} messages - Chat messages [{role, content}, ...]
 * @param {Object} config - Resolved vw_deck config
 * @param {Object|null} tokenCounter - Optional: {count: (text) => int} from Gigatoken
 * @returns {Array} Modified messages with caveman skill injected
 */
function injectCaveman(messages, config, tokenCounter) {
  if (!Array.isArray(messages)) return messages;

  const settings = getCavemanSettings(config);
  if (!settings.enabled || settings.level === 'off') {
    console.log('[CAVEMAN] Skipped — enabled:', settings.enabled, 'level:', settings.level);
    return messages;
  }

  const skill = loadCavemanSkill(settings.level);
  if (!skill) {
    console.log('[CAVEMAN] No skill text loaded for level:', settings.level);
    return messages;
  }

  // Don't compress if prompt is too short
  const countFn = (tokenCounter && tokenCounter.count)
    ? tokenCounter.count.bind(tokenCounter)
    : estimateTokens;

  let totalTokens = 0;
  for (const m of messages) {
    if (settings.excludeRoles.includes(m.role)) continue;
    totalTokens += countFn(m.content || '');
  }
  if (totalTokens < settings.minPromptTokens) {
    console.log('[CAVEMAN] Skipped — total tokens', totalTokens, '< min', settings.minPromptTokens);
    return messages;
  }

  // Find existing system message or create one
  const hasSystem = messages.some(m => m.role === 'system');
  let result;

  if (hasSystem) {
    result = messages.map(m => {
      if (m.role === 'system' && !settings.excludeRoles.includes(m.role)) {
        return { ...m, content: m.content + '\n\n' + skill };
      }
      return m;
    });
    console.log('[CAVEMAN] Injected skill into existing system message — level:', settings.level, 'skill_len:', skill.length);
  } else {
    result = [{ role: 'system', content: skill }, ...messages];
    console.log('[CAVEMAN] Created new system message with skill — level:', settings.level, 'skill_len:', skill.length);
  }

  return result;
}

/**
 * Estimate token savings from a caveman-compressed response.
 *
 * @param {string} output - The actual compressed output
 * @param {Object|null} tokenCounter - Optional Gigatoken counter
 * @returns {Object} { actual_tokens, estimated_verbose_tokens, saved, ratio }
 */
function estimateSavings(output, tokenCounter) {
  const countFn = (tokenCounter && tokenCounter.count)
    ? tokenCounter.count.bind(tokenCounter)
    : estimateTokens;

  const actualTokens = countFn(output);
  const estimatedVerbose = Math.round(actualTokens * 2.857);
  const saved = estimatedVerbose - actualTokens;
  const ratio = estimatedVerbose > 0 ? (saved / estimatedVerbose) : 0;

  return {
    actual_tokens: actualTokens,
    estimated_verbose_tokens: estimatedVerbose,
    saved: saved,
    ratio: Math.round(ratio * 100) / 100,
  };
}

module.exports = {
  injectCaveman,
  estimateSavings,
  getCavemanSettings,
  setRuntimeLevel,
  setRuntimeEnabled,
  resetRuntime,
  loadCavemanSkill,
  reloadSkills,
  estimateTokens,
};
