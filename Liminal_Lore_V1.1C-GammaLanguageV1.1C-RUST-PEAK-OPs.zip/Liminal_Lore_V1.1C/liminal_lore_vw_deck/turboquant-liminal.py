#!/usr/bin/env python3
"""TurboQuant Liminal Hook — KV-cache scaling when SYSRAM > 65%%."""
import sys, os, json, time, threading, argparse, psutil

TQ_ROOT = r"C:\Users\XFO777\turboquant"
if TQ_ROOT not in sys.path:
    sys.path.insert(0, TQ_ROOT)

TEMP_DIR = r"C:\LuxAura\VoidWalkers_Project\Modern_X64\study\temp"
STATUS_FILE = os.path.join(TEMP_DIR, "tq_status.txt")
QUEUE_FILE  = os.path.join(TEMP_DIR, "tq_queue.json")

THRESHOLD_RAM = 65.0   # %
THRESHOLD_PF  = 50.0   # %
HALT_RAM      = 70.0   # %
MAX_STATUS_BYTES = 4096

active_caches = {}
_scaling = False

# ─── Helpers ───
def ensure_dir(p):
    d = os.path.dirname(p)
    if d and not os.path.exists(d):
        os.makedirs(d, exist_ok=True)

def write_status(payload: dict):
    ensure_dir(STATUS_FILE)
    raw = json.dumps(payload, separators=(',', ':'))
    raw = raw[:MAX_STATUS_BYTES]
    with open(STATUS_FILE, 'w', encoding='utf-8') as f:
        f.write(raw)
    return os.path.exists(STATUS_FILE)

def queue_task(task: dict):
    ensure_dir(QUEUE_FILE)
    q = []
    if os.path.exists(QUEUE_FILE):
        try:
            with open(QUEUE_FILE, 'r', encoding='utf-8') as f:
                q = json.load(f)
        except Exception:
            pass
    q.append(task)
    with open(QUEUE_FILE, 'w', encoding='utf-8') as f:
        json.dump(q[-128:], f, separators=(',', ':'))

# ─── TurboQuant Scaling ───
def get_memory_snapshot():
    ram = psutil.virtual_memory()
    pf = psutil.swap_memory()
    return {
        'ram_pct': ram.percent,
        'ram_used_gb': round((ram.total - ram.available) / (1024**3), 2),
        'ram_total_gb': round(ram.total / (1024**3), 2),
        'pf_pct': round(pf.percent, 1) if pf.total else 0.0,
        'pf_used_gb': round(pf.used / (1024**3), 2) if pf.total else 0.0,
    }

def scale_kv_caches(target_bits: int = 2):
    """Down-scale all registered KV caches to target bit-width."""
    global _scaling
    if _scaling:
        return {'ok': False, 'reason': 'already_scaling'}
    _scaling = True
    freed_estimate = 0
    try:
        # Lazy-import torch / turboquant only when needed
        try:
            import torch
            from turboquant.kv_cache import TurboQuantKVCache
        except ImportError as imp:
            return {'ok': False, 'error': f"PyTorch / TurboQuant not installed: {imp}. Run: pip install torch"}

        for name, cache in list(active_caches.items()):
            if not isinstance(cache, TurboQuantKVCache):
                continue
            # Reduce buffer size to force quantization of buffered tokens
            old_buf = cache.buffer_size
            if old_buf > 0 and cache.key_buffer is not None:
                # Flush buffer into quantized store
                cache.append(cache.key_buffer, cache.value_buffer)
                cache.key_buffer = None
                cache.value_buffer = None
                # Rough footprint estimate: buf * heads * dim * 2 (k+v) * 2 (fp16)
                freed_estimate += old_buf * cache.head_dim * 2 * 2
            # Note: true bit-width reduction requires cache rebuild;
            # this flushes buffers to quantized state, reclaiming ~30-50%% footprint.

        return {
            'ok': True,
            'action': 'scale',
            'target_bits': target_bits,
            'freed_estimate_mb': round(freed_estimate / (1024 * 1024), 2),
            'caches': len(active_caches),
        }
    except Exception as e:
        return {'ok': False, 'error': str(e)}
    finally:
        _scaling = False

def register_cache(name: str, cache):
    active_caches[name] = cache

def unregister_cache(name: str):
    active_caches.pop(name, None)

# ─── KV Cache Prediction ───

# Bytes per token per model for KV cache (2 * layers * kv_heads * head_dim * 2 bytes fp16)
_KV_BYTES_PER_TOKEN = {
    'qwen2.5-coder:7b': 57344,      # 28 layers, 4 KV heads, 128 head_dim
    'deepseek-coder:6.7b': 49152,   # 32 layers, 3 KV heads, 128 head_dim
    'llama3.1:8b': 65536,           # 32 layers, 8 KV heads, 128 head_dim
    'mistral:7b': 65536,
}


def predict_kv_cache_size(token_count, model='qwen2.5-coder:7b', caveman_enabled=False):
    """Predict KV cache memory usage in MB for a given token count.
    
    When caveman_enabled, output tokens are ~65% shorter, so KV cache
    grows slower. We apply a 0.35x multiplier to the output portion
    of the KV cache (input tokens are unaffected — only output is compressed).
    """
    bytes_per_token = _KV_BYTES_PER_TOKEN.get(model, 57344)
    effective_tokens = token_count
    if caveman_enabled:
        # Rough heuristic: ~40% of tokens are output (prompt is 60%)
        # Output tokens compressed to ~35% of original volume
        input_tokens = int(token_count * 0.6)
        output_tokens = int(token_count * 0.4 * 0.35)
        effective_tokens = input_tokens + output_tokens
    return (effective_tokens * bytes_per_token) / (1024 * 1024)


# ─── Monitor Loop ───
def monitor_tick():
    mem = get_memory_snapshot()
    mode = 'normal'
    action = None

    if mem['ram_pct'] > THRESHOLD_RAM:
        bits = 2 if mem['ram_pct'] > 75 else 3
        result = scale_kv_caches(bits)
        mode = 'scale'
        action = result
    elif mem['pf_pct'] > THRESHOLD_PF:
        queue_task({
            't': time.time(),
            'trigger': 'pagefile',
            'value': mem['pf_pct'],
            'action': 'queued',
            'reason': 'pagefile > 50%%'
        })
        mode = 'queue'

    if mem['ram_pct'] > HALT_RAM:
        mode = 'halt'

    write_status({
        'time': time.strftime('%H:%M:%S'),
        'ram_pct': mem['ram_pct'],
        'ram_used_gb': mem['ram_used_gb'],
        'pf_pct': mem['pf_pct'],
        'pf_used_gb': mem['pf_used_gb'],
        'mode': mode,
        'action': action,
    })
    return mem, mode

def monitor_loop(interval: float = 5.0):
    while True:
        monitor_tick()
        time.sleep(interval)

# ─── HTTP Service ───
def start_http(port: int = 8646):
    from http.server import HTTPServer, BaseHTTPRequestHandler
    class H(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path == '/tq/status':
                body = b'{}'
                if os.path.exists(STATUS_FILE):
                    with open(STATUS_FILE, 'rb') as f:
                        body = f.read()
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(body)
            elif self.path.startswith('/tq/predict'):
                from urllib.parse import urlparse, parse_qs
                qs = parse_qs(urlparse(self.path).query)
                tokens = int(qs.get('tokens', ['4096'])[0])
                model = qs.get('model', ['qwen2.5-coder:7b'])[0]
                caveman = qs.get('caveman', ['false'])[0].lower() in ('true', '1', 'yes')
                mb = predict_kv_cache_size(tokens, model, caveman_enabled=caveman)
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({
                    'tokens': tokens, 'model': model,
                    'caveman_enabled': caveman,
                    'predicted_kv_mb': round(mb, 2),
                }).encode())
            elif self.path == '/vpn-health':
                import urllib.request
                try:
                    with urllib.request.urlopen('https://checkip.amazonaws.com', timeout=5) as r:
                        exit_ip = r.read().decode().strip()
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({'status': 'connected', 'exit_ip': exit_ip}).encode())
                except Exception as e:
                    self.send_response(503)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({'status': 'disconnected', 'error': str(e)}).encode())
            else:
                self.send_response(404); self.end_headers()

        def do_POST(self):
            if self.path == '/tq/scale':
                r = scale_kv_caches(2)
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(r).encode())
            elif self.path == '/tq/flush':
                active_caches.clear()
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(b'{"ok":true}')
            elif self.path == '/tq/queue':
                length = int(self.headers.get('Content-Length', 0))
                body = self.rfile.read(length).decode() if length else '{}'
                try:
                    task = json.loads(body)
                    queue_task(task)
                    self.send_response(200)
                except Exception:
                    self.send_response(400)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(b'{"ok":true}')
            else:
                self.send_response(404); self.end_headers()

        def log_message(self, fmt, *args):
            pass

    srv = HTTPServer(('127.0.0.1', port), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv

# ─── CLI ───
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--scale', type=int, default=None, help='Force scale to N bits')
    ap.add_argument('--monitor', action='store_true', help='Start monitor loop')
    ap.add_argument('--service', action='store_true', help='Start HTTP service')
    ap.add_argument('--port', type=int, default=8646)
    args = ap.parse_args()

    if args.scale is not None:
        r = scale_kv_caches(args.scale)
        print(json.dumps(r))
    elif args.monitor:
        if args.service:
            start_http(args.port)
        monitor_loop()
    elif args.service:
        import sys
        print(f'[TQ] Python: {sys.executable}')
        try:
            import torch
            print(f'[TQ] PyTorch {torch.__version__} OK')
        except ImportError:
            print('[TQ] PyTorch NOT installed — scale commands will fail gracefully')
        start_http(args.port)
        print(f'[TQ] HTTP on 127.0.0.1:{args.port}')
        threading.Event().wait()
    else:
        # One-shot status + auto-scale if needed
        mem, mode = monitor_tick()
        print(json.dumps({'mem': mem, 'mode': mode}))
