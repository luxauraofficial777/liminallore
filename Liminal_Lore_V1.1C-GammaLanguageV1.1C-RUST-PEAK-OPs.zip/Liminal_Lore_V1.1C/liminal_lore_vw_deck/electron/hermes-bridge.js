const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const PORT = 8643;
const LOCAL_HARNESS_URL = process.env.LOCAL_HARNESS_URL || 'http://127.0.0.1:8647';
const OLLAMA_URL = process.env.OLLAMA_URL || LOCAL_HARNESS_URL;
const OPENROUTER_KEY = process.env.OPENROUTER_API_KEY || '';

/* ─── CONFIG ─── */
let config = {};
let workspaces = {};
let activeWorkspaceId = 'vw_hd';

function resolveConfig(rawConfig) {
  const projectRoot = rawConfig.project_root || path.dirname(path.dirname(__dirname));
  function resolveStr(s) {
    if (typeof s !== 'string') return s;
    return s.replace(/\$\{project_root\}/g, projectRoot);
  }
  function deepResolve(obj) {
    if (typeof obj === 'string') return resolveStr(obj);
    if (Array.isArray(obj)) return obj.map(deepResolve);
    if (obj && typeof obj === 'object') {
      const out = {};
      for (const k of Object.keys(obj)) out[k] = deepResolve(obj[k]);
      return out;
    }
    return obj;
  }
  return deepResolve(rawConfig);
}

function loadWorkspaces() {
  const wsPath = path.join(__dirname, 'workspaces.json');
  try {
    const raw = fs.readFileSync(wsPath, 'utf8');
    workspaces = JSON.parse(raw);
    activeWorkspaceId = workspaces.active_workspace || 'vw_hd';
    log('Workspaces loaded:', (workspaces.workspaces || []).length, 'projects');
  } catch (e) {
    log('Workspaces load failed:', e.message);
    workspaces = { workspaces: [] };
  }
}

function loadActiveConfig() {
  const ws = (workspaces.workspaces || []).find(w => w.id === activeWorkspaceId);
  const configPath = ws ? path.join(ws.project_root, ws.config_file) : path.join(__dirname, 'vw_deck.config.json');
  try {
    const raw = fs.readFileSync(configPath, 'utf8');
    config = resolveConfig(JSON.parse(raw));
    log('Config loaded:', configPath, '| project:', config.project_name || 'unnamed');
  } catch (e) {
    log('Config load failed:', e.message, '- using defaults');
    config = { project_root: path.dirname(path.dirname(__dirname)) };
  }
}

loadWorkspaces();
loadActiveConfig();

/* ─── TELEMETRY STATE ─── */
let telemetryCache = null;
let telemetryTimer = null;
let requestCounters = {
  chat_requests: 0,
  committee_triggers: 0,
  pipeline_switches: 0,
  total_pulses: 0,
  llm_invocations: 0,
  per_model: {}, // {model: {count, total_latency_ms}}
};
let telemetryLogPath = null;

function getTelemetryLogPath() {
  if (telemetryLogPath) return telemetryLogPath;
  try {
    const agentDir = path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'logs');
    fs.mkdirSync(agentDir, { recursive: true });
    telemetryLogPath = path.join(agentDir, 'nexus_telemetry.log');
    return telemetryLogPath;
  } catch (e) {
    return path.join(__dirname, 'nexus_telemetry.log');
  }
}

function logTelemetry(snapshot) {
  try {
    const logPath = getTelemetryLogPath();
    fs.appendFileSync(logPath, JSON.stringify(snapshot) + '\n');
  } catch (e) { /* ignore */ }
}

function fetchJson(url, timeoutMs = 3000) {
  return new Promise((resolve) => {
    const parsed = new URL(url);
    const client = parsed.protocol === 'https:' ? https : http;
    const req = client.request({
      hostname: parsed.hostname,
      port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
      path: parsed.pathname + parsed.search,
      method: 'GET',
      timeout: timeoutMs,
    }, (res) => {
      let body = '';
      res.on('data', c => body += c);
      res.on('end', () => {
        if (res.statusCode === 200) {
          try { resolve({ ok: true, data: JSON.parse(body) }); }
          catch { resolve({ ok: false, error: 'JSON parse failed' }); }
        } else {
          resolve({ ok: false, error: `HTTP ${res.statusCode}` });
        }
      });
    });
    req.on('error', () => resolve({ ok: false, error: 'connection refused' }));
    req.on('timeout', () => { req.destroy(); resolve({ ok: false, error: 'timeout' }); });
    req.end();
  });
}

async function collectTelemetry() {
  const ts = new Date().toISOString();

  // Parallel-fetch all services
  const [nexusRes, tqRes, ollamaRes, harnessRes, koboldRes] = await Promise.all([
    fetchJson('http://127.0.0.1:8651/status'),
    fetchJson('http://127.0.0.1:8646/tq/status'),
    fetchJson('http://127.0.0.1:11434/api/tags'),
    fetchJson('http://127.0.0.1:8647/api/tags'),
    fetchJson('http://127.0.0.1:5001/v1/models'),
  ]);

  // Read heartbeat resonance
  let heartbeat = { alive: false };
  try {
    const resonancePath = path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'logs', 'resonance.json');
    if (fs.existsSync(resonancePath)) {
      heartbeat = { alive: true, ...JSON.parse(fs.readFileSync(resonancePath, 'utf8')) };
    }
  } catch (e) { /* ignore */ }

  // Read committee status
  let committee = { members: 0, sessions: 0, mode: 'lazy_sync', last_variance: 0 };
  try {
    const manifestPath = path.join(__dirname, 'committee_manifest.json');
    if (fs.existsSync(manifestPath)) {
      const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
      committee.members = (manifest.committee_members || []).length;
      committee.mode = (manifest.consensus_config || {}).mode || 'lazy_sync';
    }
    const transcriptPath = path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'logs', 'committee_transcript.json');
    if (fs.existsSync(transcriptPath)) {
      const transcript = JSON.parse(fs.readFileSync(transcriptPath, 'utf8'));
      committee.sessions = (transcript.sessions || []).length;
      const lastSession = (transcript.sessions || []).pop();
      if (lastSession && lastSession.variance !== undefined) {
        committee.last_variance = lastSession.variance;
      }
    }
  } catch (e) { /* ignore */ }

  // Tier + pipeline
  const tier = getHardwareTier();
  let pipeline = { active: 'unknown', label: 'Unknown', category: 'unknown' };
  try {
    const manifestPath = path.join(__dirname, 'pipeline_manifest.json');
    if (fs.existsSync(manifestPath)) {
      const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
      const active = manifest.active_pipeline || 'dx11';
      const p = (manifest.pipelines || {})[active] || {};
      pipeline = { active, label: p.label || active, category: p.category || 'modern' };
    }
  } catch (e) { /* ignore */ }

  // Compute alerts
  const alerts = [];
  if (tqRes.ok) {
    const tq = tqRes.data;
    if (tq.ram_pct >= 70 || tq.mode === 'halt') {
      alerts.push({ level: 'red', source: 'turboquant', message: `KV-Cache Overflow: RAM at ${tq.ram_pct}% — mode: ${tq.mode}` });
    } else if (tq.ram_pct >= 65 || tq.mode === 'scale') {
      alerts.push({ level: 'amber', source: 'turboquant', message: `KV-Cache Pressure: RAM at ${tq.ram_pct}% — scaling active` });
    }
  }
  if (heartbeat.alive) {
    if (heartbeat.notes && heartbeat.notes.includes('ARRHYTHMIA')) {
      alerts.push({ level: 'red', source: 'heartbeat', message: `Nexus Arrhythmia: ${heartbeat.notes}` });
    }
    if (heartbeat.ram_pressure > 0.85) {
      alerts.push({ level: 'red', source: 'heartbeat', message: `RAM pressure ${(heartbeat.ram_pressure * 100).toFixed(0)}% — critical` });
    }
  }
  if (!ollamaRes.ok) {
    alerts.push({ level: 'red', source: 'ollama', message: 'Ollama service offline — LLM inference unavailable' });
  }
  if (!nexusRes.ok) {
    alerts.push({ level: 'amber', source: 'nexus', message: 'VW Nexus server not responding on :8651' });
  }

  const snapshot = {
    timestamp: ts,
    nexus: nexusRes.ok ? { alive: true, ...nexusRes.data } : { alive: false, error: nexusRes.error },
    turboquant: tqRes.ok ? { alive: true, ...tqRes.data } : { alive: false, error: tqRes.error },
    heartbeat: heartbeat,
    ollama: ollamaRes.ok ? {
      alive: true,
      models: (ollamaRes.data.models || []).map(m => m.name),
    } : { alive: false, error: ollamaRes.error },
    harness: harnessRes.ok ? {
      alive: true,
      models: (harnessRes.data.models || []).map(m => ({ name: m.name, backend: m.backend, alive: m.backend_alive })),
    } : { alive: false, error: harnessRes.error },
    koboldcpp: koboldRes.ok ? {
      alive: true,
      models: (koboldRes.data.data || []).map(m => m.id),
    } : { alive: false, error: koboldRes.error },
    committee: committee,
    tier: { current: tier.name, label: tier.label || tier.name, max_concurrent: tier.max_concurrent_experts, tq_strategy: tier.turboquant_strategy, kv_bits: tier.turboquant_kv_bits },
    pipeline: pipeline,
    counters: { ...requestCounters },
    alerts: alerts,
  };

  telemetryCache = snapshot;
  logTelemetry(snapshot);
  return snapshot;
}

function startTelemetryPolling() {
  if (telemetryTimer) clearInterval(telemetryTimer);
  collectTelemetry(); // initial fetch
  telemetryTimer = setInterval(() => { collectTelemetry().catch(() => {}); }, 5000);
  log('Telemetry polling started (5s interval)');
}

function stopTelemetryPolling() {
  if (telemetryTimer) { clearInterval(telemetryTimer); telemetryTimer = null; }
  log('Telemetry polling stopped');
}

/* ─── NEXUS PULSE (Auto-Refresh Toggle) ─── */
let nexusRefreshInterval = null;
let nexusModels = []; // Cached model list from harness

function getHardwareTier() {
  const ht = config.hardware_tier || {};
  const tierName = ht.current || 'potato';
  const profile = (ht.profiles || {})[tierName] || {};
  return { name: tierName, ...profile };
}

function getAgentOverrides(agentName) {
  const ht = config.hardware_tier || {};
  const overrides = ht.agent_overrides || {};
  const agentCfg = overrides[agentName];
  if (!agentCfg || !agentCfg.enabled) return null;
  return agentCfg;
}

function resolveAgentConfig(agentName) {
  const tier = getHardwareTier();
  const override = getAgentOverrides(agentName);
  if (!override) return { tier: tier.name, overridden: false, ...tier };

  // Merge: override values that are non-null take precedence over tier defaults
  const merged = { ...tier };
  for (const [key, val] of Object.entries(override)) {
    if (val !== null && val !== undefined && key !== 'enabled') {
      merged[key] = val;
    }
  }
  return { tier: tier.name, overridden: true, ...merged };
}

function getNexusSettings() {
  const tier = getHardwareTier();
  const base = config.nexus_settings || { auto_refresh_enabled: false, refresh_interval_ms: 30000, pulse_mode: 'manual' };
  // Tier overrides: if tier has a refresh strategy, use its interval
  if (tier.refresh_strategy === 'manual') {
    return { ...base, auto_refresh_enabled: false, pulse_mode: 'manual' };
  } else if (tier.refresh_strategy === 'auto' && tier.refresh_interval_ms) {
    return { ...base, auto_refresh_enabled: true, refresh_interval_ms: tier.refresh_interval_ms, pulse_mode: 'auto' };
  }
  return base;
}

function refreshNexusModels() {
  const harnessPort = parseInt(new URL(OLLAMA_URL).port || '8647');
  const harnessHost = new URL(OLLAMA_URL).hostname || '127.0.0.1';
  const probe = http.request({ hostname: harnessHost, port: harnessPort, path: '/api/tags', method: 'GET', timeout: 5000 }, (apiRes) => {
    let body = '';
    apiRes.on('data', c => body += c);
    apiRes.on('end', () => {
      if (apiRes.statusCode === 200) {
        try {
          const parsed = JSON.parse(body);
          nexusModels = (parsed.models || []).map(m => ({ name: m.name, backend: m.backend, alive: m.backend_alive }));
          log('Nexus Pulse: refreshed', nexusModels.length, 'models');
        } catch { log('Nexus Pulse: parse error'); }
      }
    });
  });
  probe.on('error', (err) => log('Nexus Pulse: error', err.message));
  probe.on('timeout', () => { probe.destroy(); log('Nexus Pulse: timeout'); });
  probe.end();
}

function toggleNexusRefresh(isEnabled) {
  const settings = getNexusSettings();
  if (isEnabled) {
    const interval = settings.refresh_interval_ms || 30000;
    if (nexusRefreshInterval) clearInterval(nexusRefreshInterval);
    nexusRefreshInterval = setInterval(refreshNexusModels, interval);
    refreshNexusModels(); // Immediate first poll
    log('Nexus Pulse: ON (interval:', interval + 'ms)');
  } else {
    if (nexusRefreshInterval) {
      clearInterval(nexusRefreshInterval);
      nexusRefreshInterval = null;
    }
    log('Nexus Pulse: OFF (Professional Mode)');
  }
}

// Initialize pulse state from config
toggleNexusRefresh(getNexusSettings().auto_refresh_enabled);

/* ─── PRE-VERIFICATION HANDSHAKE ─── */
const NEXUS_ERROR_LOG = path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'logs', 'nexus_error.log');
const MONK_MODELFILES = {
  'lux-architect': path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'Modelfiles', 'lux-architect.modelfile'),
  'nex': path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'Modelfiles', 'nex.modelfile'),
  'nexx': path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'Modelfiles', 'nexx.modelfile'),
  'n3x': path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'Modelfiles', 'n3x.modelfile'),
};
const OLLAMA_BIN_PATH = path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'bin', 'ollama.exe');

let verifiedModels = {}; // { "model-name": { status: "active"|"recovery"|"unavailable", last_check, latency_ms, error } }

function nexusLogError(model, error) {
  const ts = new Date().toISOString();
  const entry = `[${ts}] MODEL=${model} ERROR=${error}\n`;
  try {
    const dir = path.dirname(NEXUS_ERROR_LOG);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.appendFileSync(NEXUS_ERROR_LOG, entry);
  } catch (e) { /* best effort */ }
}

function probeModel(modelName, backendHost, backendPort) {
  return new Promise((resolve) => {
    const start = Date.now();
    const probe = http.request({
      hostname: backendHost,
      port: backendPort,
      path: '/api/tags',
      method: 'GET',
      timeout: 4000,
    }, (apiRes) => {
      let body = '';
      apiRes.on('data', c => body += c);
      apiRes.on('end', () => {
        const latency = Date.now() - start;
        if (apiRes.statusCode !== 200) {
          resolve({ status: 'unavailable', latency_ms: latency, error: `HTTP ${apiRes.statusCode}` });
          return;
        }
        try {
          const parsed = JSON.parse(body);
          const models = parsed.models || [];
          const found = models.some(m => m.name === modelName || m.name === modelName + ':latest' || m.name.startsWith(modelName));
          if (found) {
            resolve({ status: 'active', latency_ms: latency, error: null });
          } else {
            resolve({ status: 'recovery', latency_ms: latency, error: 'Model not found in backend registry' });
          }
        } catch {
          resolve({ status: 'recovery', latency_ms: latency, error: 'Backend returned non-JSON' });
        }
      });
    });
    probe.on('error', (err) => {
      resolve({ status: 'unavailable', latency_ms: Date.now() - start, error: err.message });
    });
    probe.on('timeout', () => {
      probe.destroy();
      resolve({ status: 'unavailable', latency_ms: Date.now() - start, error: 'Probe timed out' });
    });
    probe.end();
  });
}

async function verifyAllModels() {
  // Get model list from harness
  const harnessPort = parseInt(new URL(OLLAMA_URL).port || '8647');
  const harnessHost = new URL(OLLAMA_URL).hostname || '127.0.0.1';

  // First get the model list
  const models = await new Promise((resolve) => {
    const probe = http.request({ hostname: harnessHost, port: harnessPort, path: '/api/tags', method: 'GET', timeout: 5000 }, (apiRes) => {
      let body = '';
      apiRes.on('data', c => body += c);
      apiRes.on('end', () => {
        if (apiRes.statusCode === 200) {
          try { resolve(JSON.parse(body).models || []); } catch { resolve([]); }
        } else { resolve([]); }
      });
    });
    probe.on('error', () => resolve([]));
    probe.on('timeout', () => { probe.destroy(); resolve([]); });
    probe.end();
  });

  // Probe each model against its declared backend
  const results = {};
  for (const m of models) {
    const baseName = m.name.replace(':latest', '');
    const backend = m.backend || 'ollama';
    let backendHost = '127.0.0.1';
    let backendPort = 11434;
    if (backend === 'koboldcpp') backendPort = 5001;

    const result = await probeModel(m.name, backendHost, backendPort);
    results[m.name] = {
      ...result,
      backend,
      base_name: baseName,
      last_check: new Date().toISOString(),
    };

    // Log errors
    if (result.status !== 'active') {
      nexusLogError(m.name, result.error);
    }

    verifiedModels[m.name] = results[m.name];
  }

  return results;
}

function repairMonk(modelName) {
  const baseName = modelName.replace(':latest', '').replace('ollama:', '').replace('kobold:', '');
  const modelfilePath = MONK_MODELFILES[baseName];
  if (!modelfilePath) {
    return { ok: false, error: `No Modelfile mapping for monk: ${baseName}` };
  }
  if (!fs.existsSync(modelfilePath)) {
    return { ok: false, error: `Modelfile not found: ${modelfilePath}` };
  }
  if (!fs.existsSync(OLLAMA_BIN_PATH)) {
    return { ok: false, error: `Ollama binary not found: ${OLLAMA_BIN_PATH}` };
  }

  return new Promise((resolve) => {
    const args = ['create', baseName, '-f', modelfilePath];
    log('Repair: re-creating monk', baseName, 'from', modelfilePath);
    const proc = spawn(OLLAMA_BIN_PATH, args, { cwd: path.dirname(OLLAMA_BIN_PATH) });
    let output = '';
    proc.stdout.on('data', (d) => { output += d.toString(); });
    proc.stderr.on('data', (d) => { output += d.toString(); });
    proc.on('close', (code) => {
      if (code === 0) {
        log('Repair: monk', baseName, 're-created successfully');
        resolve({ ok: true, model: baseName, output: output.slice(-500) });
      } else {
        log('Repair: monk', baseName, 'FAILED (exit', code + ')');
        nexusLogError(baseName, `Repair failed (exit ${code}): ${output.slice(0, 200)}`);
        resolve({ ok: false, model: baseName, error: `Exit code ${code}`, output: output.slice(-500) });
      }
    });
    proc.on('error', (err) => {
      resolve({ ok: false, model: baseName, error: err.message });
    });
  });
}

/* ─── DYNAMIC RESOLVER (Pointer-Based Model Routing) ─── */
const NEXUS_PATH_LOG = path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'logs', 'nexus_path_resolution.log');

// Discovery methods per provider type
const DISCOVERY_METHODS = {
  'ollama': { endpoint: '/api/tags', method: 'GET', parser: 'ollama-tags' },
  'koboldcpp': { endpoint: '/v1/models', method: 'GET', parser: 'openai-models' },
  'hermes': { endpoint: '/v1/models', method: 'GET', parser: 'openai-models' },
  'openrouter': { endpoint: '/v1/models', method: 'GET', parser: 'openai-models' },
};

// Provider endpoints from config (populated at load time)
let providerEndpoints = {};

function loadProviderEndpoints() {
  providerEndpoints = {
    'ollama': { host: '127.0.0.1', port: 11434, url: OLLAMA_URL.includes(':8647') ? 'http://127.0.0.1:11434' : OLLAMA_URL },
    'koboldcpp': { host: '127.0.0.1', port: 5001, url: 'http://127.0.0.1:5001' },
    'hermes': { host: null, port: null, url: null }, // Cloud, resolved at runtime
    'openrouter': { host: 'openrouter.ai', port: 443, url: 'https://openrouter.ai/api/v1' },
  };
}

// Runtime pointer map: model_id → { provider, uri, last_resolved, status }
let modelPointers = {};

function nexusLogPath(modelId, oldUri, newUri, reason) {
  const ts = new Date().toISOString();
  const entry = `[${ts}] MODEL=${modelId} OLD=${oldUri} NEW=${newUri} REASON=${reason}\n`;
  try {
    const dir = path.dirname(NEXUS_PATH_LOG);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.appendFileSync(NEXUS_PATH_LOG, entry);
  } catch (e) { /* best effort */ }
}

// Normalization: convert any provider's model list into NexusModelManifest
function normalizeOllamaTags(body, providerUrl) {
  const data = JSON.parse(body);
  return (data.models || []).map(m => ({
    id: m.name,
    name: m.name.replace(':latest', ''),
    provider: 'ollama',
    uri: `${providerUrl}/api/generate`,
    chat_uri: `${providerUrl}/api/chat`,
    size: m.size || 0,
    modified: m.modified_at || '',
    digest: m.digest || '',
  }));
}

function normalizeOpenAIModels(body, provider, providerUrl) {
  const data = JSON.parse(body);
  return (data.data || []).map(m => ({
    id: m.id,
    name: m.id,
    provider,
    uri: `${providerUrl}/chat/completions`,
    chat_uri: `${providerUrl}/chat/completions`,
    size: 0,
    modified: '',
    digest: '',
  }));
}

function normalizeHarnessTags(body, providerUrl) {
  const data = JSON.parse(body);
  return (data.models || []).map(m => ({
    id: m.name,
    name: m.name.replace(':latest', ''),
    provider: m.backend || 'ollama',
    uri: `${providerUrl}/api/generate`,
    chat_uri: `${providerUrl}/api/chat`,
    size: 0,
    modified: '',
    digest: '',
    backend: m.backend || 'ollama',
    backend_alive: m.backend_alive || false,
  }));
}

// Discovery: query a provider and return normalized manifest
function discoverProvider(providerId, endpoint) {
  return new Promise((resolve) => {
    const method = DISCOVERY_METHODS[providerId] || DISCOVERY_METHODS['ollama'];
    let url;
    let isHttps = false;

    if (providerId === 'ollama' && endpoint.url.includes(':8647')) {
      // Use harness for Ollama discovery
      url = `${endpoint.url}/api/tags`;
    } else if (endpoint.url) {
      url = `${endpoint.url}${method.endpoint}`;
      isHttps = endpoint.url.startsWith('https://');
    } else {
      resolve({ provider: providerId, models: [], error: 'No endpoint URL configured' });
      return;
    }

    const parsed = new URL(url);
    const client = parsed.protocol === 'https:' ? https : http;
    const req = client.request({
      hostname: parsed.hostname,
      port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
      path: parsed.pathname + parsed.search,
      method: method.method,
      timeout: 5000,
    }, (apiRes) => {
      let body = '';
      apiRes.on('data', c => body += c);
      apiRes.on('end', () => {
        if (apiRes.statusCode !== 200) {
          resolve({ provider: providerId, models: [], error: `HTTP ${apiRes.statusCode}` });
          return;
        }
        try {
          let manifest;
          if (providerId === 'ollama' && endpoint.url.includes(':8647')) {
            manifest = normalizeHarnessTags(body, endpoint.url);
          } else if (method.parser === 'ollama-tags') {
            manifest = normalizeOllamaTags(body, endpoint.url);
          } else {
            manifest = normalizeOpenAIModels(body, providerId, endpoint.url);
          }
          resolve({ provider: providerId, models: manifest, error: null });
        } catch (e) {
          resolve({ provider: providerId, models: [], error: `Parse error: ${e.message}` });
        }
      });
    });
    req.on('error', (err) => resolve({ provider: providerId, models: [], error: err.message }));
    req.on('timeout', () => { req.destroy(); resolve({ provider: providerId, models: [], error: 'Discovery timed out' }); });
    req.end();
  });
}

// Cross-provider audit: discover all providers, update pointer map
async function resolveAllProviders() {
  loadProviderEndpoints();
  const allProviders = Object.keys(providerEndpoints);
  const manifests = {};

  for (const pid of allProviders) {
    const ep = providerEndpoints[pid];
    if (!ep.url && pid !== 'hermes') continue; // Skip unconfigured
    if (pid === 'hermes') {
      // Hermes requires auth — skip discovery if no key
      continue;
    }
    const result = await discoverProvider(pid, ep);
    manifests[pid] = result;
  }

  // Update pointer map with drift detection
  const updates = [];
  for (const [pid, result] of Object.entries(manifests)) {
    if (result.error) {
      log(`Resolver: ${pid} discovery failed — ${result.error}`);
      continue;
    }
    for (const model of result.models) {
      const existing = modelPointers[model.id];
      if (existing && existing.uri !== model.uri) {
        // Pointer drift detected!
        nexusLogPath(model.id, existing.uri, model.uri, 'provider-drift');
        updates.push({ model: model.id, old: existing.uri, new: model.uri, reason: 'provider-drift' });
        log(`Resolver: pointer drift for ${model.id}: ${existing.uri} → ${model.uri}`);
      } else if (!existing) {
        updates.push({ model: model.id, old: null, new: model.uri, reason: 'new-discovery' });
        log(`Resolver: new model discovered: ${model.id} at ${model.uri}`);
      }
      modelPointers[model.id] = {
        provider: model.provider,
        uri: model.uri,
        chat_uri: model.chat_uri,
        name: model.name,
        last_resolved: new Date().toISOString(),
        status: 'resolved',
        backend: model.backend,
        digest: model.digest,
      };
    }
  }

  // Mark models that were previously known but no longer discovered
  for (const [id, ptr] of Object.entries(modelPointers)) {
    let stillFound = false;
    for (const result of Object.values(manifests)) {
      if (result.models && result.models.some(m => m.id === id)) {
        stillFound = true;
        break;
      }
    }
    if (!stillFound && ptr.status === 'resolved') {
      modelPointers[id].status = 'pending-resolution';
      nexusLogPath(id, ptr.uri, 'UNKNOWN', 'model-vanished');
      log(`Resolver: model ${id} no longer discoverable — marked pending-resolution`);
    }
  }

  return {
    resolved_at: new Date().toISOString(),
    providers: Object.fromEntries(
      Object.entries(manifests).map(([k, v]) => [k, { model_count: v.models.length, error: v.error }])
    ),
    pointer_updates: updates,
    total_models: Object.keys(modelPointers).length,
    resolved_count: Object.values(modelPointers).filter(p => p.status === 'resolved').length,
    pending_count: Object.values(modelPointers).filter(p => p.status === 'pending-resolution').length,
  };
}

// Resolve a single model's pointer (for on-demand routing)
function resolveModelPointer(modelId) {
  const ptr = modelPointers[modelId] || modelPointers[modelId + ':latest'];
  if (!ptr) return null;
  if (ptr.status !== 'resolved') return null;
  return ptr;
}

/* ─── UTILITIES ─── */
function log(...args) {
  const ts = new Date().toISOString().replace('T', ' ').slice(0, 19);
  console.log(`[${ts}]`, ...args);
}

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'content-type, x-provider, x-api-key, x-hermes-session-id, x-hermes-session-key, x-devin-org');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS, GET');
}

function streamJSON(res, obj) {
  res.write(`data: ${JSON.stringify(obj)}\n\n`);
}

function streamDone(res) {
  res.write('data: [DONE]\n\n');
  res.end();
}

function errorResponse(res, code, msg) {
  res.writeHead(code, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: msg }));
}

/* ─── RAG CONTEXT INJECTION ─── */
const STUDY_CONTEXT_MAX_BYTES = 200000;
const STUDY_CONTEXT_CORE_FILES = [
  '000_VOID_WALKERS_TECHNICAL_MANIFEST.md',
  '001_VOID_WALKERS_LIBRARY_INDEX.md',
  '002_VOID_WALKERS_ASSET_SCHEMA_DATABASE.md',
  'june/238_CASCADE_Library_Synchronization_Schema_Jun25_2026.md',
  'june/238_GLM_Agent_Synchronization_Prompts_Jun25_2026.md',
];

function getStudyDir() {
  return (config.paths && config.paths.study_dir) ? config.paths.study_dir : path.join(__dirname, '..', '..', 'study');
}

function readStudyFile(relPath) {
  try {
    const full = path.join(getStudyDir(), relPath);
    if (!fileAccessGate(full).ok) return null;
    const content = fs.readFileSync(full, 'utf8');
    return { rel: relPath, content };
  } catch (e) {
    return null;
  }
}

function getRecentStudyFiles(count = 5) {
  try {
    const dir = getStudyDir();
    const files = [];
    function walk(base, relPrefix) {
      const entries = fs.readdirSync(base, { withFileTypes: true });
      for (const e of entries) {
        const rel = relPrefix ? `${relPrefix}/${e.name}` : e.name;
        const full = path.join(base, e.name);
        if (!fileAccessGate(full).ok) continue;
        if (e.isDirectory()) { walk(full, rel); continue; }
        const st = fs.statSync(full);
        files.push({ rel, modified: st.mtime.getTime(), size: st.size });
      }
    }
    walk(dir, '');
    files.sort((a, b) => b.modified - a.modified);
    return files.slice(0, count);
  } catch (e) {
    return [];
  }
}

function buildStudyContext() {
  const parts = [];
  parts.push('VOID WALKERS CANONICAL STUDY CONTEXT');
  for (const rel of STUDY_CONTEXT_CORE_FILES) {
    const file = readStudyFile(rel);
    if (!file) continue;
    const head = file.content.slice(0, 50000);
    parts.push(`--- ${file.rel} ---\n${head}`);
  }
  const recent = getRecentStudyFiles(5);
  if (recent.length) {
    parts.push('--- MOST RECENT STUDY UPDATES ---');
    for (const f of recent) {
      const file = readStudyFile(f.rel);
      if (!file) continue;
      const head = file.content.slice(0, 20000);
      parts.push(`--- ${f.rel} ---\n${head}`);
    }
  }
  let context = parts.join('\n\n');
  if (context.length > STUDY_CONTEXT_MAX_BYTES) {
    context = context.slice(0, STUDY_CONTEXT_MAX_BYTES) + '\n\n[STUDY CONTEXT TRUNCATED]';
  }
  return context;
}

function injectContextIntoPrompt(prompt) {
  const ctx = buildStudyContext();
  if (!ctx) return prompt;
  return `[${ctx}]\n\n=== USER PROMPT ===\n${prompt}`;
}

function injectContextIntoMessages(messages) {
  const ctx = buildStudyContext();
  if (!ctx || !Array.isArray(messages)) return messages;
  return [{ role: 'system', content: ctx }, ...messages];
}

/* ─── FILE ACCESS GATE ─── */
function fileAccessGate(filePath) {
  const fa = config.file_access;
  if (!fa || !fa.enabled) return { ok: true };
  if (!filePath) return { ok: true };

  // Force absolute resolution and normalize
  let resolved;
  try {
    resolved = path.resolve(filePath);
  } catch (e) {
    return { ok: false, reason: 'Path resolution failed: ' + e.message };
  }
  // Convert to forward slashes and lowercase for robust comparison
  const normalized = resolved.replace(/\\/g, '/').toLowerCase();

  // Path traversal trap: reject .. sequences AFTER normalization
  if (normalized.includes('..')) {
    return { ok: false, reason: 'Path traversal detected' };
  }

  // Denied patterns (regex) against full resolved path
  for (const pat of fa.denied_patterns || []) {
    try {
      const re = new RegExp(pat, 'i');
      if (re.test(normalized)) return { ok: false, reason: 'Path matches denied pattern: ' + pat };
    } catch { /* invalid regex, skip */ }
  }

  // Allowlist mode: resolved path must start with an allowed prefix
  if (fa.mode === 'allowlist') {
    for (const prefix of fa.allowed_prefixes || []) {
      const p = path.resolve(prefix).replace(/\\/g, '/').toLowerCase();
      // Ensure prefix ends with / for exact folder matching if it's not a root
      const pFolder = p.endsWith('/') ? p : p + '/';
      if (normalized === p || normalized.startsWith(pFolder)) return { ok: true };
    }
    return { ok: false, reason: 'Path outside allowed directories: ' + filePath };
  }
  return { ok: true };
}

/* ─── AUTH: browser X-API-Key first, then Hermes file ─── */
function getNousAuth(reqHeaders) {
  // 1. Browser override
  const browserKey = reqHeaders['x-api-key'];
  if (browserKey && browserKey.length > 5) {
    log('Using browser-provided API key (length:', browserKey.length, ')');
    return { token: browserKey, baseUrl: 'https://inference-api.nousresearch.com/v1' };
  }
  if (browserKey) log('Browser key too short, ignoring');

  // 2. Hermes shared credentials
  const authPath = path.join(process.env.LOCALAPPDATA || process.env.APPDATA, 'hermes', 'shared', 'nous_auth.json');
  try {
    const raw = fs.readFileSync(authPath, 'utf8');
    const data = JSON.parse(raw);
    const now = Date.now();
    const expires = new Date(data.expires_at || 0).getTime();
    if (expires && expires <= now) {
      log('WARNING: Hermes token EXPIRED at', data.expires_at, '- paste a fresh key in the browser UI');
    } else {
      log('Using Hermes Nous credentials from', authPath, 'expires:', data.expires_at || 'unknown');
    }
    return {
      token: data.access_token,
      baseUrl: data.inference_base_url || 'https://inference-api.nousresearch.com/v1',
    };
  } catch (e) {
    log('Failed to read Hermes Nous auth:', e.message);
    return null;
  }
}

/* ─── GENERIC SSE PROXY ─── */
function proxySSE(targetUrl, headers, body, res) {
  const parsed = new URL(targetUrl);
  const isHttps = parsed.protocol === 'https:';
  const client = isHttps ? https : http;
  const options = {
    hostname: parsed.hostname,
    port: parsed.port || (isHttps ? 443 : 80),
    path: parsed.pathname + parsed.search,
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...headers },
  };

  const req = client.request(options, (apiRes) => {
    if (apiRes.statusCode !== 200) {
      let errBody = '';
      apiRes.on('data', (chunk) => errBody += chunk);
      apiRes.on('end', () => {
        log('Proxy error', apiRes.statusCode, ':', errBody.slice(0, 500));
        streamJSON(res, { choices: [{ delta: { content: `[API ERROR ${apiRes.statusCode}: ${errBody.slice(0, 200)}]` } }] });
        streamDone(res);
      });
      return;
    }
    apiRes.on('data', (chunk) => res.write(chunk));
    apiRes.on('end', () => res.end());
  });

  req.on('error', (err) => {
    log('Proxy error:', err.message);
    streamJSON(res, { choices: [{ delta: { content: `[PROXY ERROR: ${err.message}]` } }] });
    streamDone(res);
  });

  req.write(JSON.stringify(body));
  req.end();
}

/* ─── NOUS / HERMES ─── */
function handleNous(body, res, reqHeaders) {
  const auth = getNousAuth(reqHeaders);
  if (!auth) {
    streamJSON(res, { choices: [{ delta: { content: '[AUTH ERROR: Nous key missing. Paste your API key in the web UI or run: hermes auth add nous]' } }] });
    streamDone(res);
    return;
  }

  const payload = {
    model: body.model || 'nousresearch/hermes-4-70b',
    messages: body.messages,
    stream: true,
    temperature: body.temperature ?? 0.7,
  };

  log('Proxying to Nous API:', auth.baseUrl, 'model:', payload.model);
  proxySSE(`${auth.baseUrl}/chat/completions`, { Authorization: `Bearer ${auth.token}` }, payload, res);
}

/* ─── OLLAMA ─── */
function handleOllama(body, res) {
  // Ollama expects messages[].content as a string, not an array (OpenAI vision format).
  // Convert array content parts to Ollama's native format: string content + images[] array.
  const ollamaMessages = (body.messages || []).map(m => {
    if (typeof m.content === 'string') return m;
    if (Array.isArray(m.content)) {
      let text = '';
      const images = [];
      for (const part of m.content) {
        if (part.type === 'text') text += part.text || '';
        else if (part.type === 'image_url' && part.image_url?.url) {
          const match = part.image_url.url.match(/^data:[^;]+;base64,(.+)$/);
          if (match) images.push(match[1]);
        }
      }
      const msg = { role: m.role, content: text };
      if (images.length > 0) msg.images = images;
      return msg;
    }
    return { role: m.role, content: String(m.content || '') };
  });
  const payload = { model: body.model || 'lux-architect', messages: ollamaMessages, stream: true };
  // Route directly to Ollama (11434), not the harness (8647) which is for model discovery only
  const ollamaDirectUrl = (providerEndpoints && providerEndpoints.ollama && providerEndpoints.ollama.url)
    ? providerEndpoints.ollama.url
    : (OLLAMA_URL.includes(':8647') ? 'http://127.0.0.1:11434' : OLLAMA_URL);
  const parsed = new URL(`${ollamaDirectUrl}/api/chat`);
  const client = parsed.protocol === 'https:' ? https : http;

  log('Proxying to Ollama:', parsed.href, 'model:', payload.model);

  // Send an initial keep-alive comment to prevent proxy timeout during model load
  res.write(': keep-alive\n\n');

  // Heartbeat every 10s to keep the connection alive while Ollama loads the model
  const heartbeat = setInterval(() => {
    try { res.write(': heartbeat\n\n'); } catch (_) {}
  }, 10000);

  const req = client.request({
    hostname: parsed.hostname,
    port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
    path: parsed.pathname + parsed.search,
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    timeout: 180000, // 3 minutes — large models like lux-architect need time to load into RAM
  }, (apiRes) => {
    if (apiRes.statusCode !== 200) {
      let errBody = '';
      apiRes.on('data', (chunk) => errBody += chunk.toString());
      apiRes.on('end', () => {
        clearInterval(heartbeat);
        log('Ollama HTTP error:', apiRes.statusCode, errBody.slice(0, 300));
        streamJSON(res, { choices: [{ delta: { content: `[OLLAMA HTTP ${apiRes.statusCode}: ${errBody.slice(0, 200)}]` } }] });
        streamDone(res);
      });
      return;
    }
    let buffer = '';
    apiRes.on('data', (chunk) => {
      buffer += chunk.toString();
      const lines = buffer.split('\n');
      buffer = lines.pop();
      for (const line of lines) {
        if (!line.trim()) continue;
        try {
          const obj = JSON.parse(line);
          const txt = obj.message?.content || '';
          if (txt) streamJSON(res, { choices: [{ delta: { content: txt } }] });
        } catch (_) {}
      }
    });
    apiRes.on('end', () => {
      clearInterval(heartbeat);
      streamDone(res);
    });
  });

  req.on('error', (err) => {
    clearInterval(heartbeat);
    log('Ollama error:', err.message);
    streamJSON(res, { choices: [{ delta: { content: `[OLLAMA ERROR: ${err.message}. Ensure Ollama Desktop is running on port 11434.]` } }] });
    streamDone(res);
  });

  req.on('timeout', () => {
    clearInterval(heartbeat);
    log('Ollama timeout (180s) — model may still be loading. Check: ollama ps');
    req.destroy();
    streamJSON(res, { choices: [{ delta: { content: '[OLLAMA ERROR: Connection timeout after 180s. The model may still be loading into memory. Run `ollama ps` to check status, then retry.]' } }] });
    streamDone(res);
  });

  req.write(JSON.stringify(payload));
  req.end();
}

/* ─── OPENROUTER ─── */
function handleOpenRouter(body, res) {
  if (!OPENROUTER_KEY) {
    streamJSON(res, { choices: [{ delta: { content: '[AUTH ERROR: OPENROUTER_API_KEY env var not set]' } }] });
    streamDone(res);
    return;
  }

  const payload = {
    model: body.model || 'moonshotai/kimi-k2.6',
    messages: body.messages,
    stream: true,
    temperature: body.temperature ?? 0.7,
  };

  log('Proxying to OpenRouter, model:', payload.model);
  proxySSE('https://openrouter.ai/api/v1/chat/completions', {
    Authorization: `Bearer ${OPENROUTER_KEY}`,
    'HTTP-Referer': 'http://localhost:8642',
    'X-Title': 'VoidWalkers Neural Link',
  }, payload, res);
}

const HTML_PATH = './VoidWalkers_Suite.html';

/* ─── SERVER ─── */
const server = http.createServer((req, res) => {
  cors(res);
  if (req.method === 'OPTIONS') { res.writeHead(200); res.end(); return; }
  if (req.url === '/health') { res.writeHead(200); res.end('ok'); return; }

  if (req.url === '/health/all' && req.method === 'GET') {
    const services = [
      { name: 'bridge', port: PORT, path: '/health' },
      { name: 'fs_service', port: 8644, path: '/health' },
      { name: 'liminal_lore', port: 8645, path: '/health' },
      { name: 'turboquant', port: 8646, path: '/health' },
      { name: 'runpod_bridge', port: 8647, path: '/health' },
    ];
    const results = {};
    let pending = services.length;
    function done() {
      pending--;
      if (pending === 0) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true, services: results, timestamp: new Date().toISOString() }));
      }
    }
    for (const svc of services) {
      const proxyReq = http.request({ hostname: '127.0.0.1', port: svc.port, path: svc.path, method: 'GET', timeout: 2000 }, (proxyRes) => {
        results[svc.name] = { status: proxyRes.statusCode, ok: proxyRes.statusCode >= 200 && proxyRes.statusCode < 300 };
        done();
      });
      proxyReq.on('error', () => { results[svc.name] = { status: 0, ok: false, error: 'unreachable' }; done(); });
      proxyReq.on('timeout', () => { proxyReq.destroy(); results[svc.name] = { status: 0, ok: false, error: 'timeout' }; done(); });
      proxyReq.end();
    }
    return;
  }

  // Serve the HTML UI from same origin to avoid CORS
  if (req.url === '/' || req.url === '/index.html') {
    try {
      const html = fs.readFileSync(HTML_PATH, 'utf8');
      res.writeHead(200, {
        'Content-Type': 'text/html',
        'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0',
      });
      res.end(html);
      return;
    } catch (e) {
      res.writeHead(500);
      res.end('HTML not found: ' + e.message);
      return;
    }
  }

  // Proxy TurboQuant service (port 8646)
  if (req.url.startsWith('/tq/')) {
    let data = '';
    req.on('data', c => data += c);
    req.on('end', () => {
      const proxyReq = http.request({
        hostname: '127.0.0.1', port: 8646, path: req.url, method: req.method,
        headers: { 'Content-Type': 'application/json' },
      }, (proxyRes) => {
        res.writeHead(proxyRes.statusCode, { 'Content-Type': proxyRes.headers['content-type'] || 'application/json' });
        proxyRes.pipe(res);
      });
      proxyReq.on('error', () => {
        res.writeHead(503, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: 'TurboQuant service not running on port 8646. Run: python study/turboquant-liminal.py --service' }));
      });
      if (data) proxyReq.write(data);
      proxyReq.end();
    });
    return;
  }

  // Proxy Liminal Lore service (port 8645)
  if (req.url.startsWith('/liminal/')) {
    let data = '';
    req.on('data', c => data += c);
    req.on('end', () => {
      const proxyReq = http.request({
        hostname: '127.0.0.1', port: 8645, path: req.url.replace('/liminal', ''), method: req.method,
        headers: { 'Content-Type': 'application/json' },
      }, (proxyRes) => {
        res.writeHead(proxyRes.statusCode, { 'Content-Type': proxyRes.headers['content-type'] || 'application/json' });
        proxyRes.pipe(res);
      });
      proxyReq.on('error', () => {
        res.writeHead(503, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: 'Liminal Lore not running on port 8645. Run: python liminal-lore.py' }));
      });
      if (data) proxyReq.write(data);
      proxyReq.end();
    });
    return;
  }

  // Proxy Runpod Bridge service (port 8647)
  if (req.url.startsWith('/runpod/')) {
    let data = '';
    req.on('data', c => data += c);
    req.on('end', () => {
      const proxyReq = http.request({
        hostname: '127.0.0.1', port: 8647, path: req.url, method: req.method,
        headers: { 'Content-Type': 'application/json' },
      }, (proxyRes) => {
        res.writeHead(proxyRes.statusCode, { 'Content-Type': proxyRes.headers['content-type'] || 'application/json' });
        proxyRes.pipe(res);
      });
      proxyReq.on('error', () => {
        res.writeHead(503, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: 'Runpod Bridge not running on port 8647. Run: python study/runpod-bridge.py --service' }));
      });
      if (data) proxyReq.write(data);
      proxyReq.end();
    });
    return;
  }

  // Proxy file ops to FS Service (port 8644) — with file access gate
  const fsEndpoints = ['/read-file', '/read-file-binary', '/write-file', '/list-dir', '/stat', '/search', '/exec', '/delete', '/study/index', '/study/search', '/settings', '/roots'];
  const studyGet = (req.url === '/study/index' && req.method === 'GET') || (req.url === '/study/search' && req.method === 'POST');
  const settingsGet = (req.url === '/settings' || req.url === '/roots') && req.method === 'GET';
  if (fsEndpoints.includes(req.url) && (req.method === 'POST' || studyGet || settingsGet)) {
    let data = '';
    req.on('data', c => data += c);
    req.on('end', () => {
      // File access gate: check path before proxying
      try {
        const body = JSON.parse(data);
        const pathsToCheck = [];
        if (body.path) pathsToCheck.push(body.path);
        if (body.src) pathsToCheck.push(body.src);
        if (body.dst) pathsToCheck.push(body.dst);
        if (body.dir) pathsToCheck.push(body.dir);
        if (body.command) {
          // For /exec, we can't easily parse all paths from the command, but we can at least gate the working dir
          if (body.cwd) pathsToCheck.push(body.cwd);
        }
        for (const p of pathsToCheck) {
          const gate = fileAccessGate(p);
          if (!gate.ok) {
            log('PROXY BLOCKED:', req.url, p, gate.reason);
            res.writeHead(403, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ ok: false, error: gate.reason, path: p }));
            return;
          }
        }
      } catch { /* body not JSON or no path field, pass through */ }
      
      log('PROXY REQUEST:', req.url, `to 127.0.0.1:8644`);
      const proxyReq = http.request({
        hostname: '127.0.0.1', port: 8644, path: req.url, method: req.method,
        headers: { 'Content-Type': 'application/json' },
      }, (proxyRes) => {
        log('PROXY RESPONSE:', req.url, `status: ${proxyRes.statusCode}`);
        res.writeHead(proxyRes.statusCode, { 'Content-Type': proxyRes.headers['content-type'] || 'application/json' });
        proxyRes.pipe(res);
      });
      proxyReq.on('error', (err) => {
        log('PROXY ERROR:', req.url, err.message);
        res.writeHead(503, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: 'FS Service not running on port 8644. Run: node voidwalkers-fs-service.js' }));
      });
      proxyReq.write(data);
      proxyReq.end();
    });
    return;
  }

  // Serve deck config to the portal
  if (req.url === '/config' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(config));
    return;
  }

  // ─── NEXUS PULSE ENDPOINTS ───

  // GET /nexus/pulse — current pulse state + cached models
  if (req.url === '/nexus/pulse' && req.method === 'GET') {
    const settings = getNexusSettings();
    const tier = getHardwareTier();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      ok: true,
      auto_refresh_enabled: settings.auto_refresh_enabled,
      refresh_interval_ms: settings.refresh_interval_ms,
      pulse_mode: settings.pulse_mode,
      is_running: nexusRefreshInterval !== null,
      cached_models: nexusModels,
      model_count: nexusModels.length,
      hardware_tier: tier.name,
      tier_label: tier.label,
      max_concurrent_experts: tier.max_concurrent_experts,
      turboquant_strategy: tier.turboquant_strategy,
      turboquant_flush_threshold_pct: tier.turboquant_flush_threshold_pct,
      gpu_offload_flag: tier.gpu_offload_flag,
      cpu_only: tier.cpu_only,
    }));
    return;
  }

  // GET /nexus/tier — return active hardware tier profile
  if (req.url === '/nexus/tier' && req.method === 'GET') {
    const tier = getHardwareTier();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      ok: true,
      tier: tier.name,
      label: tier.label,
      max_concurrent_experts: tier.max_concurrent_experts,
      turboquant_strategy: tier.turboquant_strategy,
      turboquant_kv_bits: tier.turboquant_kv_bits,
      turboquant_flush_threshold_pct: tier.turboquant_flush_threshold_pct,
      refresh_strategy: tier.refresh_strategy,
      refresh_interval_ms: tier.refresh_interval_ms,
      nexus_heartbeat_interval_s: tier.nexus_heartbeat_interval_s,
      model_resolution_interval_s: tier.model_resolution_interval_s,
      gpu_offload_layers: tier.gpu_offload_layers,
      gpu_offload_flag: tier.gpu_offload_flag,
      cpu_only: tier.cpu_only,
      hbe_streaming: tier.hbe_streaming,
      expert_pinning: tier.expert_pinning,
    }));
    return;
  }

  // GET /nexus/agents/config — resolved config for all agents (tier + overrides merged)
  if (req.url === '/nexus/agents/config' && req.method === 'GET') {
    const ht = config.hardware_tier || {};
    const overrides = ht.agent_overrides || {};
    const agentNames = Object.keys(overrides);
    const result = {};
    for (const name of agentNames) {
      result[name] = resolveAgentConfig(name);
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true, tier: getHardwareTier().name, agents: result }));
    return;
  }

  // GET /nexus/agents/config?name=X — resolved config for a single agent
  if (req.url.startsWith('/nexus/agents/config?') && req.method === 'GET') {
    const urlObj = new URL(req.url, `http://127.0.0.1:${PORT}`);
    const agentName = urlObj.searchParams.get('name');
    if (!agentName) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: 'Missing name parameter' }));
      return;
    }
    const resolved = resolveAgentConfig(agentName);
    if (!resolved) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: `Unknown agent: ${agentName}` }));
      return;
    }
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true, agent: agentName, ...resolved }));
    return;
  }

  // POST /nexus/agents/config — update per-agent override (partial merge)
  if (req.url === '/nexus/agents/config' && req.method === 'POST') {
    let data = '';
    req.on('data', c => data += c);
    req.on('end', () => {
      try {
        const body = JSON.parse(data);
        const agentName = body.agent || body.name;
        if (!agentName) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: 'Missing agent name' }));
          return;
        }
        if (!config.hardware_tier) config.hardware_tier = {};
        if (!config.hardware_tier.agent_overrides) config.hardware_tier.agent_overrides = {};
        if (!config.hardware_tier.agent_overrides[agentName]) {
          config.hardware_tier.agent_overrides[agentName] = { enabled: false };
        }
        // Merge body fields into existing override (partial update)
        for (const [key, val] of Object.entries(body)) {
          if (key !== 'agent' && key !== 'name') {
            config.hardware_tier.agent_overrides[agentName][key] = val;
          }
        }
        // Persist to config file
        try {
          const configPath = path.join(__dirname, 'vw_deck.config.json');
          fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
          log(`Agent override updated: ${agentName}`);
        } catch (e) { log('Agent override save failed:', e.message); }
        const resolved = resolveAgentConfig(agentName);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true, agent: agentName, resolved }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
    });
    return;
  }

  // POST /nexus/tier/set — switch active tier
  if (req.url === '/nexus/tier/set' && req.method === 'POST') {
    let data = '';
    req.on('data', c => data += c);
    req.on('end', () => {
      try {
        const body = JSON.parse(data);
        const tierName = body.tier;
        if (!tierName || !['potato', 'mid_range', 'high_end', 'custom'].includes(tierName)) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: 'Invalid tier. Use: potato, mid_range, high_end, custom' }));
          return;
        }
        if (!config.hardware_tier) config.hardware_tier = {};
        config.hardware_tier.current = tierName;
        config.hardware_tier.auto_detect = false;
        // Sync nexus_settings
        const profile = config.hardware_tier.profiles[tierName];
        if (profile) {
          config.nexus_settings.auto_refresh_enabled = profile.refresh_strategy === 'auto';
          config.nexus_settings.refresh_interval_ms = profile.refresh_interval_ms || 30000;
          config.nexus_settings.pulse_mode = profile.refresh_strategy;
        }
        try {
          const configPath = path.join(__dirname, 'vw_deck.config.json');
          fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
          log(`Tier switched to: ${tierName}`);
        } catch (e) { log('Tier switch save failed:', e.message); }
        // Re-initialize pulse with new tier settings
        const settings = getNexusSettings();
        toggleNexusRefresh(settings.auto_refresh_enabled);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true, tier: tierName, label: profile ? profile.label : tierName, pulse: settings.pulse_mode }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
    });
    return;
  }

  // ─── COMMITTEE CONSENSUS PROTOCOL ENDPOINTS ───

  // GET /nexus/committee/manifest — return the committee manifest
  if (req.url === '/nexus/committee/manifest' && req.method === 'GET') {
    const manifestPath = path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'committee_manifest.json');
    try {
      const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true, ...manifest }));
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: 'Manifest not found: ' + e.message }));
    }
    return;
  }

  // GET /nexus/committee/transcript — return the committee transcript
  if (req.url === '/nexus/committee/transcript' && req.method === 'GET') {
    const transcriptPath = path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'logs', 'committee_transcript.json');
    try {
      const transcript = JSON.parse(fs.readFileSync(transcriptPath, 'utf-8'));
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true, ...transcript }));
    } catch (e) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true, sessions: [], current_session: null, error: 'No transcript yet' }));
    }
    return;
  }

  // GET /nexus/committee/transcript/latest — return only the most recent session
  if (req.url === '/nexus/committee/transcript/latest' && req.method === 'GET') {
    const transcriptPath = path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'logs', 'committee_transcript.json');
    try {
      const transcript = JSON.parse(fs.readFileSync(transcriptPath, 'utf-8'));
      const sessions = transcript.sessions || [];
      const latest = sessions.length > 0 ? sessions[sessions.length - 1] : null;
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true, session: latest }));
    } catch (e) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: 'No transcript yet' }));
    }
    return;
  }

  // POST /nexus/committee/trigger — trigger a committee deliberation
  if (req.url === '/nexus/committee/trigger' && req.method === 'POST') {
    let data = '';
    req.on('data', c => data += c);
    req.on('end', () => {
      try {
        const body = JSON.parse(data);
        const query = body.query || body.prompt;
        if (!query) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: 'Missing query parameter' }));
          return;
        }
        log(`Committee: triggering deliberation — "${query.slice(0, 80)}..."`);
        requestCounters.committee_triggers++;
        // Spawn moe_router.py --committee as subprocess
        const routerPath = path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'moe_router.py');
        const proc = spawn('python', [routerPath, '--committee', query], {
          cwd: path.dirname(routerPath),
          env: { ...process.env },
          windowless: true,
        });
        let stdout = '';
        let stderr = '';
        proc.stdout.on('data', (c) => { stdout += c.toString(); });
        proc.stderr.on('data', (c) => { stderr += c.toString(); });
        proc.on('close', (code) => {
          if (code === 0) {
            // Read the transcript for the latest session
            const transcriptPath = path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'logs', 'committee_transcript.json');
            try {
              const transcript = JSON.parse(fs.readFileSync(transcriptPath, 'utf-8'));
              const sessions = transcript.sessions || [];
              const latest = sessions.length > 0 ? sessions[sessions.length - 1] : null;
              log(`Committee: deliberation complete — session: ${latest ? latest.session_id : 'unknown'}`);
              res.writeHead(200, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({
                ok: true,
                session: latest,
                stdout: stdout.slice(-2000),
              }));
            } catch (e2) {
              log('Committee: transcript read failed:', e2.message);
              res.writeHead(200, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ ok: true, stdout: stdout.slice(-2000), warning: 'Transcript not readable' }));
            }
          } else {
            log(`Committee: deliberation failed (exit ${code})`);
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ ok: false, error: `Exit code ${code}`, stderr: stderr.slice(-1000), stdout: stdout.slice(-1000) }));
          }
        });
        proc.on('error', (err) => {
          log('Committee: spawn error:', err.message);
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: 'Failed to start committee: ' + err.message }));
        });
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
    });
    return;
  }

  // GET /nexus/committee/status — quick committee status (member count, last session)
  if (req.url === '/nexus/committee/status' && req.method === 'GET') {
    const manifestPath = path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'committee_manifest.json');
    const transcriptPath = path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'logs', 'committee_transcript.json');
    const tier = getHardwareTier();
    let memberCount = 0;
    let lastSession = null;
    let totalSessions = 0;
    try {
      const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
      memberCount = (manifest.committee_members || []).length;
    } catch {}
    try {
      const transcript = JSON.parse(fs.readFileSync(transcriptPath, 'utf-8'));
      const sessions = transcript.sessions || [];
      totalSessions = sessions.length;
      lastSession = sessions.length > 0 ? sessions[sessions.length - 1] : null;
    } catch {}
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      ok: true,
      members: memberCount,
      total_sessions: totalSessions,
      last_session: lastSession,
      committee_mode: tier.committee_mode || 'lazy_sync',
      committee_parallel: tier.committee_parallel || false,
    }));
    return;
  }

  // ─── PIPELINE REGISTRY ENDPOINTS ───

  // GET /nexus/pipeline/list — list all pipelines from manifest
  if (req.url === '/nexus/pipeline/list' && req.method === 'GET') {
    const manifestPath = path.join(__dirname, 'pipeline_manifest.json');
    try {
      const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
      const tier = getHardwareTier();
      const tierName = tier.name;
      const pipelines = {};
      for (const [key, p] of Object.entries(manifest.pipelines || {})) {
        const compat = (p.tier_compatibility || []).includes(tierName);
        const sdkOk = !p.sdk_required || (p.sdk_paths || []).every(sp => {
          if (sp.startsWith('$')) { const ev = sp.split('/')[0].slice(1); return !!process.env[ev]; }
          if (sp.startsWith('/')) { try { return fs.existsSync(sp); } catch { return false; } }
          return true;
        });
        pipelines[key] = {
          label: p.label, api_type: p.api_type, category: p.category,
          platform: p.platform, tier_compatible: compat, sdk_ok: sdkOk,
          advanced: p.advanced || false, timing_mode: p.timing_mode,
          region_mode: p.region_mode, shader_model: p.shader_model,
        };
      }
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true, active: manifest.active_pipeline, tier: tierName, pipelines }));
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: e.message }));
    }
    return;
  }

  // GET /nexus/pipeline/active — return active pipeline config
  if (req.url === '/nexus/pipeline/active' && req.method === 'GET') {
    const manifestPath = path.join(__dirname, 'pipeline_manifest.json');
    try {
      const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
      const active = manifest.active_pipeline || 'dx11';
      const pipeline = (manifest.pipelines || {})[active];
      const reg = config.pipeline_registry || {};
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        ok: true, active, pipeline,
        region_mode: reg.region_mode || 'NTSC',
        timing_mode: reg.timing_mode || '60Hz',
        dev_kit_target: reg.dev_kit_target,
      }));
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: e.message }));
    }
    return;
  }

  // POST /nexus/pipeline/switch — switch active pipeline (with validation)
  if (req.url === '/nexus/pipeline/switch' && req.method === 'POST') {
    let data = '';
    req.on('data', c => data += c);
    req.on('end', () => {
      try {
        const body = JSON.parse(data);
        const pipelineKey = body.pipeline;
        const force = body.force === true;
        if (!pipelineKey) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: 'Missing pipeline parameter' }));
          return;
        }
        const manifestPath = path.join(__dirname, 'pipeline_manifest.json');
        const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
        const pipeline = (manifest.pipelines || {})[pipelineKey];
        if (!pipeline) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: `Unknown pipeline: ${pipelineKey}` }));
          return;
        }
        const tier = getHardwareTier();
        const tierName = tier.name;
        // Validate tier compatibility
        const compat = (pipeline.tier_compatibility || []).includes(tierName);
        if (!compat && !force) {
          const rules = (manifest.validation_rules || {}).tier_enforcement || {};
          const fallback = (rules[tierName] || {}).fallback || 'dx11';
          log(`Pipeline switch BLOCKED: ${pipelineKey} not compatible with tier ${tierName}`);
          res.writeHead(403, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({
            ok: false, blocked: true, error: `Pipeline '${pipelineKey}' is not compatible with tier '${tierName}'`,
            fallback, tier: tierName,
          }));
          return;
        }
        // Validate SDK presence
        if (pipeline.sdk_required && !force) {
          const sdkRules = (manifest.validation_rules || {}).sdk_verification || {};
          const sdkCheck = sdkRules[pipelineKey];
          if (sdkCheck) {
            const missing = (sdkCheck.env_vars || []).filter(ev => !process.env[ev]);
            if (missing.length > 0) {
              log(`Pipeline switch BLOCKED: ${pipelineKey} — missing SDK env vars: ${missing.join(', ')}`);
              res.writeHead(403, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({
                ok: false, blocked: true, error: sdkCheck.block_message || `Missing SDK: ${missing.join(', ')}`,
                missing_env_vars: missing,
              }));
              return;
            }
          }
        }
        // Perform switch
        const oldPipeline = manifest.active_pipeline;
        manifest.active_pipeline = pipelineKey;
        fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));
        // Update config
        if (!config.pipeline_registry) config.pipeline_registry = {};
        config.pipeline_registry.active_pipeline = pipelineKey;
        config.pipeline_registry.region_mode = pipeline.region_mode || 'NTSC';
        config.pipeline_registry.timing_mode = pipeline.timing_mode || '60Hz';
        config.pipeline_registry.overscan_compensation = pipeline.overscan_compensation || false;
        config.pipeline_registry.dev_kit_target = (pipeline.category === 'console') ? pipeline.platform : null;
        config.pipeline_registry.compiler_flags_override = pipeline.compiler_flags || null;
        config.pipeline_registry.linker_settings_override = pipeline.linker_settings || null;
        try {
          fs.writeFileSync(path.join(__dirname, 'vw_deck.config.json'), JSON.stringify(config, null, 2));
        } catch (e) { log('Pipeline config save failed:', e.message); }
        // Log transition
        const logPath = path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'logs', 'pipeline_transition.log');
        try {
          fs.mkdirSync(path.dirname(logPath), { recursive: true });
          const logEntry = JSON.stringify({
            timestamp: new Date().toISOString(), from: oldPipeline, to: pipelineKey,
            tier: tierName, status: 'switched', reason: force ? 'forced' : 'validated',
          }) + '\n';
          fs.appendFileSync(logPath, logEntry);
        } catch (e) { /* ignore log errors */ }
        log(`Pipeline switched: ${oldPipeline} → ${pipelineKey} (tier: ${tierName})`);
        requestCounters.pipeline_switches++;
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          ok: true, from: oldPipeline, to: pipelineKey, pipeline,
          tier: tierName, advanced: pipeline.advanced || false,
          compiler_flags: pipeline.compiler_flags,
          linker_settings: pipeline.linker_settings,
        }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
    });
    return;
  }

  // GET /nexus/pipeline/validate — validate current pipeline against tier
  if (req.url === '/nexus/pipeline/validate' && req.method === 'GET') {
    const manifestPath = path.join(__dirname, 'pipeline_manifest.json');
    try {
      const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
      const active = manifest.active_pipeline || 'dx11';
      const pipeline = (manifest.pipelines || {})[active];
      const tier = getHardwareTier();
      const tierName = tier.name;
      const compat = (pipeline.tier_compatibility || []).includes(tierName);
      const sdkOk = !pipeline.sdk_required || (() => {
        const sdkRules = (manifest.validation_rules || {}).sdk_verification || {};
        const sdkCheck = sdkRules[active];
        if (!sdkCheck) return true;
        return (sdkCheck.env_vars || []).every(ev => !!process.env[ev]);
      })();
      const issues = [];
      if (!compat) issues.push(`Pipeline '${active}' not compatible with tier '${tierName}'`);
      if (!sdkOk) issues.push(`SDK requirements not met for pipeline '${active}'`);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        ok: true, pipeline: active, tier: tierName,
        tier_compatible: compat, sdk_ok: sdkOk,
        issues, valid: issues.length === 0,
      }));
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: e.message }));
    }
    return;
  }

  // GET /nexus/pipeline/log — return pipeline transition log
  if (req.url === '/nexus/pipeline/log' && req.method === 'GET') {
    const logPath = path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'logs', 'pipeline_transition.log');
    try {
      const raw = fs.readFileSync(logPath, 'utf-8');
      const lines = raw.trim().split('\n').filter(l => l.trim());
      const entries = lines.map(l => JSON.parse(l));
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true, entries, count: entries.length }));
    } catch (e) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true, entries: [], count: 0 }));
    }
    return;
  }

  // ─── TELEMETRY ENDPOINTS ───

  // GET /nexus/telemetry — aggregated service health snapshot
  if (req.url === '/nexus/telemetry' && req.method === 'GET') {
    if (telemetryCache) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(telemetryCache));
    } else {
      (async () => {
        try {
          const snapshot = await collectTelemetry();
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify(snapshot));
        } catch (e) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: e.message }));
        }
      })();
    }
    return;
  }

  // GET /nexus/hbe-stats — HBE efficiency metrics
  if (req.url === '/nexus/hbe-stats' && req.method === 'GET') {
    let recentPulses = [];
    try {
      const hbPath = path.join(__dirname, '..', '..', '..', 'AGENT', 'distilled_agents', 'logs', 'heartbeat.jsonl');
      if (fs.existsSync(hbPath)) {
        const lines = fs.readFileSync(hbPath, 'utf-8').trim().split('\n').filter(l => l.trim());
        recentPulses = lines.slice(-20).map(l => JSON.parse(l));
      }
    } catch (e) { /* ignore */ }

    const totalPulses = requestCounters.total_pulses + recentPulses.length;
    const llmInvocations = requestCounters.llm_invocations;
    const deterministicBypass = Math.max(0, totalPulses - llmInvocations);
    const efficiencyRate = totalPulses > 0
      ? ((deterministicBypass / totalPulses) * 100).toFixed(1) + '%'
      : '100.0%';

    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      ok: true,
      total_pulses: totalPulses,
      llm_invocations: llmInvocations,
      deterministic_bypass: deterministicBypass,
      efficiency_rate: efficiencyRate,
      trigger_frequency_per_min: recentPulses.length > 1
        ? (recentPulses.length / Math.max(1, (Date.now() - new Date(recentPulses[0].timestamp).getTime()) / 60000)).toFixed(2)
        : 0,
      task_queue_depth: telemetryCache?.nexus?.tasks?.pending || 0,
      chat_requests: requestCounters.chat_requests,
      committee_triggers: requestCounters.committee_triggers,
      pipeline_switches: requestCounters.pipeline_switches,
      per_model: requestCounters.per_model,
      recent_pulses: recentPulses,
    }));
    return;
  }

  // POST /nexus/telemetry/refresh — force fresh telemetry collection
  if (req.url === '/nexus/telemetry/refresh' && req.method === 'POST') {
    (async () => {
      try {
        const snapshot = await collectTelemetry();
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true, ...snapshot }));
      } catch (e) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
    })();
    return;
  }

  // POST /nexus/pulse/toggle — enable/disable auto-refresh
  if (req.url === '/nexus/pulse/toggle' && req.method === 'POST') {
    let data = '';
    req.on('data', c => data += c);
    req.on('end', () => {
      try {
        const body = JSON.parse(data);
        const enable = body.enabled === true;
        toggleNexusRefresh(enable);
        // Persist to config
        if (!config.nexus_settings) config.nexus_settings = {};
        config.nexus_settings.auto_refresh_enabled = enable;
        config.nexus_settings.pulse_mode = enable ? 'auto' : 'manual';
        // Write back to config file
        try {
          const configPath = path.join(__dirname, 'vw_deck.config.json');
          fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
          log('Nexus Pulse: config persisted (auto_refresh=' + enable + ')');
        } catch (e) { log('Nexus Pulse: config save failed:', e.message); }
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true, auto_refresh_enabled: enable, pulse_mode: enable ? 'auto' : 'manual' }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
    });
    return;
  }

  // POST /nexus/sync — manual one-shot model refresh
  if (req.url === '/nexus/sync' && req.method === 'POST') {
    const harnessPort = parseInt(new URL(OLLAMA_URL).port || '8647');
    const harnessHost = new URL(OLLAMA_URL).hostname || '127.0.0.1';
    const probe = http.request({ hostname: harnessHost, port: harnessPort, path: '/api/tags', method: 'GET', timeout: 5000 }, (apiRes) => {
      let body = '';
      apiRes.on('data', c => body += c);
      apiRes.on('end', () => {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        if (apiRes.statusCode === 200) {
          try {
            const parsed = JSON.parse(body);
            nexusModels = (parsed.models || []).map(m => ({ name: m.name, backend: m.backend, alive: m.backend_alive }));
            log('Nexus Sync: manual refresh —', nexusModels.length, 'models');
            res.end(JSON.stringify({ ok: true, models: nexusModels, count: nexusModels.length, synced_at: new Date().toISOString() }));
          } catch {
            res.end(JSON.stringify({ ok: true, note: 'Harness returned non-JSON', synced_at: new Date().toISOString() }));
          }
        } else {
          res.end(JSON.stringify({ ok: false, status: apiRes.statusCode, error: body.slice(0, 300) }));
        }
      });
    });
    probe.on('error', (err) => {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: err.message + '. Start harness: python local_provider_harness.py' }));
    });
    probe.on('timeout', () => { probe.destroy(); res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ ok: false, error: 'Harness probe timed out' })); });
    probe.end();
    return;
  }

  // ─── PRE-VERIFICATION HANDSHAKE ENDPOINTS ───

  // GET /nexus/verify — probe all models, return per-model status
  if (req.url === '/nexus/verify' && req.method === 'GET') {
    (async () => {
      log('Pre-Verification: probing all models...');
      const results = await verifyAllModels();
      const summary = {
        ok: true,
        verified_at: new Date().toISOString(),
        models: results,
        active_count: Object.values(results).filter(r => r.status === 'active').length,
        recovery_count: Object.values(results).filter(r => r.status === 'recovery').length,
        unavailable_count: Object.values(results).filter(r => r.status === 'unavailable').length,
        total: Object.keys(results).length,
      };
      log('Pre-Verification:', summary.active_count, 'active,', summary.recovery_count, 'recovery,', summary.unavailable_count, 'unavailable');
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(summary));
    })();
    return;
  }

  // GET /nexus/verify/cached — return last cached verification (no probe)
  if (req.url === '/nexus/verify/cached' && req.method === 'GET') {
    const cached = {
      ok: true,
      models: verifiedModels,
      active_count: Object.values(verifiedModels).filter(r => r.status === 'active').length,
      recovery_count: Object.values(verifiedModels).filter(r => r.status === 'recovery').length,
      unavailable_count: Object.values(verifiedModels).filter(r => r.status === 'unavailable').length,
      total: Object.keys(verifiedModels).length,
    };
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(cached));
    return;
  }

  // POST /nexus/repair — re-create a monk from its Modelfile
  if (req.url === '/nexus/repair' && req.method === 'POST') {
    let data = '';
    req.on('data', c => data += c);
    req.on('end', async () => {
      try {
        const body = JSON.parse(data);
        const model = body.model || body.name;
        if (!model) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: 'Missing model name' }));
          return;
        }
        log('Repair request for monk:', model);
        const result = await repairMonk(model);
        res.writeHead(result.ok ? 200 : 500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
    });
    return;
  }

  // ─── DYNAMIC RESOLVER ENDPOINTS ───

  // GET /nexus/resolve — cross-provider audit, discover all models, update pointers
  if (req.url === '/nexus/resolve' && req.method === 'GET') {
    (async () => {
      log('Dynamic Resolver: starting cross-provider audit...');
      const result = await resolveAllProviders();
      log('Dynamic Resolver: complete —', result.resolved_count, 'resolved,', result.pending_count, 'pending,', result.pointer_updates.length, 'updates');
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true, ...result, pointers: modelPointers }));
    })();
    return;
  }

  // GET /nexus/pointers — return cached pointer map (no probe)
  if (req.url === '/nexus/pointers' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      ok: true,
      total_models: Object.keys(modelPointers).length,
      resolved_count: Object.values(modelPointers).filter(p => p.status === 'resolved').length,
      pending_count: Object.values(modelPointers).filter(p => p.status === 'pending-resolution').length,
      pointers: modelPointers,
    }));
    return;
  }

  // GET /nexus/resolve/model?id=<model> — resolve a single model pointer
  if (req.url.startsWith('/nexus/resolve/model?') && req.method === 'GET') {
    const urlObj = new URL(req.url, `http://127.0.0.1:${PORT}`);
    const modelId = urlObj.searchParams.get('id');
    if (!modelId) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: 'Missing id parameter' }));
      return;
    }
    const ptr = resolveModelPointer(modelId);
    if (ptr) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true, model: modelId, pointer: ptr }));
    } else {
      const cached = modelPointers[modelId] || modelPointers[modelId + ':latest'];
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        ok: false,
        model: modelId,
        status: cached ? cached.status : 'unknown',
        error: cached ? `Status: ${cached.status}` : 'Model not in pointer map',
      }));
    }
    return;
  }

  // RAG diagnostic: expose injected context
  if (req.url === '/rag/context' && req.method === 'GET') {
    try {
      const ctx = buildStudyContext();
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true, bytes: ctx.length, context: ctx }));
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: e.message }));
    }
    return;
  }

  // Workspace management endpoints
  if (req.url === '/workspaces' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      active: activeWorkspaceId,
      workspaces: workspaces.workspaces || []
    }));
    return;
  }
  if (req.url === '/workspace/switch' && req.method === 'POST') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => {
      try {
        const data = JSON.parse(body);
        const wsId = data.workspaceId;
        const ws = (workspaces.workspaces || []).find(w => w.id === wsId);
        if (!ws) {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: 'Workspace not found: ' + wsId }));
          return;
        }
        activeWorkspaceId = wsId;
        workspaces.active_workspace = wsId;
        // Save active workspace to disk
        try {
          const wsPath = path.join(__dirname, 'workspaces.json');
          fs.writeFileSync(wsPath, JSON.stringify(workspaces, null, 2));
        } catch (e) {
          log('Failed to save workspaces:', e.message);
        }
        loadActiveConfig();
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true, workspace: ws, config: config }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
    });
    return;
  }

  // Serve backdrop images (configurable paths from vw_deck.config.json)
  const backdropMatch = req.url.match(/^\/backdrop\/(.+)$/);
  if (backdropMatch) {
    const imageName = backdropMatch[1];
    if (!/^[a-zA-Z0-9_\-]+\.png$/.test(imageName)) {
      res.writeHead(403); res.end('Forbidden'); return;
    }
    const searchPaths = config.backdrops?.search_paths || [
      'C:\\LuxAura\\VoidWalkers_Project\\Modern_X64\\assets\\game_assets\\ui\\ui_hud\\ui_vista_backdrops',
      'C:\\LuxAura\\VoidWalkers_Project\\Modern_X64\\assets\\game_assets\\ui\\backdrops\\screens',
      'C:\\LuxAura\\VoidWalkers_Project\\Modern_X64\\assets\\game_assets\\vfx_suite_v1\\arena_battle',
    ];
    let found = false;
    for (const base of searchPaths) {
      const imagePath = path.resolve(base, imageName);
      try {
        const data = fs.readFileSync(imagePath);
        res.writeHead(200, { 'Content-Type': 'image/png', 'Cache-Control': 'public, max-age=3600' });
        res.end(data);
        found = true;
        break;
      } catch { /* try next */ }
    }
    if (!found) { res.writeHead(404); res.end('Image not found'); }
    return;
  }

  // Tool execution endpoint (registered tools from config)
  if (req.url === '/tool-exec' && req.method === 'POST') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => {
      try {
        const data = JSON.parse(body);
        const toolId = data.toolId;
        const registry = config.tool_registry || [];
        const tool = registry.find(t => t.id === toolId);
        if (!tool) {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: 'Tool not found: ' + toolId }));
          return;
        }
        // Security: check blocked patterns
        const blocked = config.security?.blocked_patterns || [];
        const fullCmd = (tool.command + ' ' + (tool.args || '')).toLowerCase();
        for (const pat of blocked) {
          if (fullCmd.includes(pat.toLowerCase())) {
            res.writeHead(403, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ ok: false, error: 'Blocked pattern detected: ' + pat }));
            return;
          }
        }
        log('Tool exec:', tool.name, '|', tool.command, tool.args || '');
        const child = spawn(tool.command, (tool.args || '').split(/\s+/).filter(Boolean), {
          cwd: tool.cwd || config.project_root,
          shell: true,
          windowsHide: true,
        });
        let stdout = '';
        let stderr = '';
        child.stdout.on('data', (d) => { stdout += d.toString(); });
        child.stderr.on('data', (d) => { stderr += d.toString(); });
        child.on('close', (code) => {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: code === 0, code, stdout: stdout.slice(-8000), stderr: stderr.slice(-2000) }));
        });
        child.on('error', (err) => {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: err.message }));
        });
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
    });
    return;
  }

  // Tool execution — SSE streaming (live output for long builds)
  if (req.url === '/tool-exec-stream' && req.method === 'POST') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => {
      try {
        const data = JSON.parse(body);
        const toolId = data.toolId;
        const registry = config.tool_registry || [];
        const tool = registry.find(t => t.id === toolId);
        if (!tool) {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: 'Tool not found: ' + toolId }));
          return;
        }
        const blocked = config.security?.blocked_patterns || [];
        const fullCmd = (tool.command + ' ' + (tool.args || '')).toLowerCase();
        for (const pat of blocked) {
          if (fullCmd.includes(pat.toLowerCase())) {
            res.writeHead(403, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ ok: false, error: 'Blocked pattern detected: ' + pat }));
            return;
          }
        }
        log('Tool stream:', tool.name, '|', tool.command, tool.args || '');
        res.writeHead(200, {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive',
        });

        const TOOL_TIMEOUT_MS = data.timeout || 300000; // 5 min default
        let heartbeatTimer = null;
        let isEnded = false;

        function safeEnd() {
          if (isEnded) return;
          isEnded = true;
          if (heartbeatTimer) clearInterval(heartbeatTimer);
          res.end();
        }

        // Keep-alive heartbeat every 15s to prevent proxy timeouts
        heartbeatTimer = setInterval(() => {
          if (!isEnded) {
            res.write(`data: ${JSON.stringify({ type: 'heartbeat', ts: Date.now() })}\n\n`);
          }
        }, 15000);

        const child = spawn(tool.command, (tool.args || '').split(/\s+/).filter(Boolean), {
          cwd: tool.cwd || config.project_root,
          shell: true,
          windowsHide: true,
        });

        const killTimer = setTimeout(() => {
          if (!isEnded && child && !child.killed) {
            log('Tool stream timeout. Killing:', tool.name);
            child.kill('SIGTERM');
            res.write(`data: ${JSON.stringify({ type: 'error', message: 'Tool execution timed out after ' + TOOL_TIMEOUT_MS + 'ms' })}\n\n`);
            res.write(`data: ${JSON.stringify({ type: 'done', code: -1 })}\n\n`);
            safeEnd();
          }
        }, TOOL_TIMEOUT_MS);

        child.stdout.on('data', (d) => {
          if (isEnded) return;
          const lines = d.toString().split('\n').filter(l => l.length > 0);
          for (const line of lines) {
            try { res.write(`data: ${JSON.stringify({ type: 'stdout', line })}\n\n`); } catch (_) {}
          }
        });

        child.stderr.on('data', (d) => {
          if (isEnded) return;
          const lines = d.toString().split('\n').filter(l => l.length > 0);
          for (const line of lines) {
            try { res.write(`data: ${JSON.stringify({ type: 'stderr', line })}\n\n`); } catch (_) {}
          }
        });

        child.on('close', (code, signal) => {
          clearTimeout(killTimer);
          if (isEnded) return;
          try {
            res.write(`data: ${JSON.stringify({ type: 'done', code: code ?? -1, signal })}\n\n`);
          } catch (_) {}
          safeEnd();
        });

        child.on('error', (err) => {
          clearTimeout(killTimer);
          if (isEnded) return;
          try {
            res.write(`data: ${JSON.stringify({ type: 'error', message: err.message })}\n\n`);
            res.write(`data: ${JSON.stringify({ type: 'done', code: -1 })}\n\n`);
          } catch (_) {}
          safeEnd();
        });

        // Client disconnect: kill child immediately to prevent orphan processes
        res.on('close', () => {
          clearTimeout(killTimer);
          if (child && !child.killed) {
            try { child.kill('SIGKILL'); } catch (_) {}
          }
          safeEnd();
        });
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
    });
    return;
  }

  // Devin proxy endpoints
  if (req.url === '/devin/spawn' && req.method === 'POST') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => {
      try {
        const data = JSON.parse(body);
        const { apiKey, orgId, prompt } = data;
        if (!apiKey || !orgId || !prompt) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: 'Missing apiKey, orgId, or prompt' }));
          return;
        }
        const augmentedPrompt = injectContextIntoPrompt(prompt);
        if (augmentedPrompt.length > 500000) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: 'Augmented prompt exceeds 500KB limit. Reduce attachments or study context.' }));
          return;
        }
        const hasImages = prompt.includes('data:image');
        log('Devin spawn:', orgId.slice(0, 16) + '...', 'prompt chars:', augmentedPrompt.length, hasImages ? '(with images)' : '');
        const client = https;
        const proxyReq = client.request({
          hostname: 'api.devin.ai',
          path: `/v3/organizations/${orgId}/sessions`,
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`,
          },
        }, (apiRes) => {
          let respBody = '';
          apiRes.on('data', chunk => respBody += chunk);
          apiRes.on('end', () => {
            res.writeHead(apiRes.statusCode, { 'Content-Type': 'application/json' });
            res.end(respBody);
          });
        });
        proxyReq.on('error', (err) => {
          res.writeHead(502, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: err.message }));
        });
        proxyReq.write(JSON.stringify({ prompt: augmentedPrompt }));
        proxyReq.end();
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
    });
    return;
  }

  if (req.url === '/devin/poll' && req.method === 'POST') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => {
      try {
        const data = JSON.parse(body);
        const { apiKey, orgId, sessionId } = data;
        if (!apiKey || !orgId || !sessionId) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: 'Missing apiKey, orgId, or sessionId' }));
          return;
        }
        const client = https;
        const proxyReq = client.request({
          hostname: 'api.devin.ai',
          path: `/v3/organizations/${orgId}/sessions/${sessionId}/messages`,
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
          },
        }, (apiRes) => {
          let respBody = '';
          apiRes.on('data', chunk => respBody += chunk);
          apiRes.on('end', () => {
            res.writeHead(apiRes.statusCode, { 'Content-Type': 'application/json' });
            res.end(respBody);
          });
        });
        proxyReq.on('error', (err) => {
          res.writeHead(502, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: err.message }));
        });
        proxyReq.end();
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
    });
    return;
  }

  if (req.url === '/vpn' && req.method === 'GET') {
    const proxy = http.request({ hostname: '127.0.0.1', port: 8645, path: '/health', method: 'GET' }, (apiRes) => {
      let body = '';
      apiRes.on('data', chunk => body += chunk);
      apiRes.on('end', () => {
        res.writeHead(apiRes.statusCode, { 'Content-Type': 'application/json' });
        res.end(body);
      });
    });
    proxy.on('error', (err) => {
      res.writeHead(503, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: 'VPN monitor unreachable: ' + err.message }));
    });
    proxy.end();
    return;
  }

  // Provider diagnostics: Nous/Hermes key check
  if (req.url === '/providers/nous/status' && req.method === 'GET') {
    const auth = getNousAuth(req.headers);
    if (!auth) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: 'No Nous API key configured. Paste key in UI or run: hermes auth add nous' }));
      return;
    }
    // Lightweight models list probe
    const probe = https.request({
      hostname: 'inference-api.nousresearch.com',
      path: '/v1/models',
      method: 'GET',
      headers: { Authorization: `Bearer ${auth.token}` },
      timeout: 8000,
    }, (apiRes) => {
      let body = '';
      apiRes.on('data', c => body += c);
      apiRes.on('end', () => {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        if (apiRes.statusCode === 200) {
          try {
            const models = JSON.parse(body);
            res.end(JSON.stringify({ ok: true, token_present: true, token_prefix: auth.token.slice(0, 8), models_count: models.data?.length || 0 }));
          } catch {
            res.end(JSON.stringify({ ok: true, token_present: true, token_prefix: auth.token.slice(0, 8), note: 'Models list returned non-JSON' }));
          }
        } else {
          res.end(JSON.stringify({ ok: false, token_present: true, token_prefix: auth.token.slice(0, 8), status: apiRes.statusCode, error: body.slice(0, 300) }));
        }
      });
    });
    probe.on('error', (err) => {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, token_present: true, token_prefix: auth.token.slice(0, 8), error: err.message }));
    });
    probe.on('timeout', () => { probe.destroy(); res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ ok: false, error: 'Nous probe timed out' })); });
    probe.end();
    return;
  }

  // Provider diagnostics: Devin/Cognition key + org check
  if (req.url === '/providers/devin/status' && req.method === 'POST') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => {
      try {
        const data = JSON.parse(body);
        const apiKey = data.apiKey || '';
        const orgId = data.orgId || '';
        if (!apiKey || !orgId) {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: 'Missing apiKey or orgId' }));
          return;
        }
        const probe = https.request({
          hostname: 'api.devin.ai',
          path: `/v3/organizations/${orgId}/sessions`,
          method: 'GET',
          headers: { Authorization: `Bearer ${apiKey}` },
          timeout: 8000,
        }, (apiRes) => {
          let respBody = '';
          apiRes.on('data', c => respBody += c);
          apiRes.on('end', () => {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            if (apiRes.statusCode === 200) {
              try {
                const sessions = JSON.parse(respBody);
                res.end(JSON.stringify({ ok: true, token_prefix: apiKey.slice(0, 8), org_id: orgId, sessions_count: sessions.data?.length || sessions.length || 0 }));
              } catch {
                res.end(JSON.stringify({ ok: true, token_prefix: apiKey.slice(0, 8), org_id: orgId, note: 'Sessions list returned non-JSON' }));
              }
            } else {
              res.end(JSON.stringify({ ok: false, token_prefix: apiKey.slice(0, 8), org_id: orgId, status: apiRes.statusCode, error: respBody.slice(0, 300) }));
            }
          });
        });
        probe.on('error', (err) => {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: err.message }));
        });
        probe.on('timeout', () => { probe.destroy(); res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ ok: false, error: 'Devin probe timed out' })); });
        probe.end();
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
    });
    return;
  }

  // Provider diagnostics: Local LLM harness (Ollama + KoboldCpp)
  if (req.url === '/providers/ollama/status' && req.method === 'GET') {
    const harnessPort = parseInt(new URL(OLLAMA_URL).port || '8647');
    const harnessHost = new URL(OLLAMA_URL).hostname || '127.0.0.1';
    const probe = http.request({ hostname: harnessHost, port: harnessPort, path: '/api/tags', method: 'GET', timeout: 5000 }, (apiRes) => {
      let body = '';
      apiRes.on('data', c => body += c);
      apiRes.on('end', () => {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        if (apiRes.statusCode === 200) {
          try {
            const parsed = JSON.parse(body);
            const models = (parsed.models || []).map(m => m.name || m);
            const backends = {};
            for (const m of (parsed.models || [])) {
              const b = m.backend || 'ollama';
              if (!backends[b]) backends[b] = [];
              backends[b].push(m.name || m);
            }
            res.end(JSON.stringify({ ok: true, reachable: true, models_count: models.length, models: models.slice(0, 50), backends, harness: true }));
          } catch {
            res.end(JSON.stringify({ ok: true, reachable: true, note: 'Harness returned non-JSON', harness: true }));
          }
        } else {
          res.end(JSON.stringify({ ok: false, reachable: true, status: apiRes.statusCode, error: body.slice(0, 300) }));
        }
      });
    });
    probe.on('error', (err) => {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, reachable: false, error: err.message + '. Start harness: python local_provider_harness.py' }));
    });
    probe.on('timeout', () => { probe.destroy(); res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ ok: false, reachable: false, error: 'Harness probe timed out. Start: python local_provider_harness.py' })); });
    probe.end();
    return;
  }

  // Provider diagnostics: OpenRouter key present
  if (req.url === '/providers/openrouter/status' && req.method === 'GET') {
    const key = OPENROUTER_KEY;
    if (!key) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: 'OPENROUTER_API_KEY env var not set' }));
      return;
    }
    const probe = https.request({
      hostname: 'openrouter.ai',
      path: '/api/v1/auth/key',
      method: 'GET',
      headers: { Authorization: `Bearer ${key}` },
      timeout: 8000,
    }, (apiRes) => {
      let body = '';
      apiRes.on('data', c => body += c);
      apiRes.on('end', () => {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        if (apiRes.statusCode === 200) {
          try {
            const data = JSON.parse(body);
            res.end(JSON.stringify({ ok: true, key_present: true, token_prefix: key.slice(0, 8), label: data.data?.label || 'unknown' }));
          } catch {
            res.end(JSON.stringify({ ok: true, key_present: true, token_prefix: key.slice(0, 8), note: 'Key probe returned non-JSON' }));
          }
        } else {
          res.end(JSON.stringify({ ok: false, key_present: true, token_prefix: key.slice(0, 8), status: apiRes.statusCode, error: body.slice(0, 300) }));
        }
      });
    });
    probe.on('error', (err) => {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, key_present: true, error: err.message }));
    });
    probe.on('timeout', () => { probe.destroy(); res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ ok: false, key_present: true, error: 'OpenRouter probe timed out' })); });
    probe.end();
    return;
  }

  // Provider diagnostics: Gemini Core CLI
  if (req.url === '/providers/gemini/status' && req.method === 'GET') {
    const { exec } = require('child_process');
    exec('gemini --version', { timeout: 5000 }, (err, stdout) => {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      if (err) {
        res.end(JSON.stringify({ ok: false, installed: false, error: err.message }));
      } else {
        res.end(JSON.stringify({ ok: true, installed: true, version: stdout.trim().slice(0, 100) }));
      }
    });
    return;
  }

  // Combined provider list
  if (req.url === '/providers' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      providers: [
        { id: 'hermes', name: 'HERMES (Nous Portal)', type: 'cloud', auth: 'api_key' },
        { id: 'gemini', name: 'GEMINI CORE (Local CLI)', type: 'local', auth: 'cli' },
        { id: 'devin', name: 'DEVIN (Cognition Labs)', type: 'cloud', auth: 'api_key+org' },
        { id: 'ollama', name: 'OLLAMA (Temple Monks)', type: 'local', auth: 'none', models: ['lux-architect', 'nex', 'nexx', 'n3x'] },
        { id: 'openrouter', name: 'OPENROUTER (Cloud)', type: 'cloud', auth: 'api_key' },
      ],
      models: {
        hermes: [
          'nousresearch/hermes-4-405b',
          'nousresearch/hermes-4-405b-thinking',
          'nousresearch/hermes-4-70b',
          'nousresearch/hermes-4-70b-thinking',
          'nousresearch/deephermes-3-mistral-24b-preview',
          'nousresearch/deephermes-3-llama-3-8b-preview',
          'nousresearch/hermes-3-llama-3.1-70b',
          'nousresearch/hermes-3-llama-3.1-405b',
          'nousresearch/hermes-3-llama-3.1-405b:free',
          'moonshotai/kimi-k2.7-code',
          'moonshotai/kimi-k2.6',
          'moonshotai/kimi-k2.5',
          'moonshotai/kimi-k2',
          'moonshotai/kimi-k2-thinking',
          'z-ai/glm-5.2',
          'z-ai/glm-5.1',
          'z-ai/glm-5',
          'z-ai/glm-4.7',
          'z-ai/glm-4.7-flash',
          'z-ai/glm-4.6',
          'z-ai/glm-4.5',
          'google/gemini-2.5-pro',
          'google/gemini-2.5-flash',
          'google/gemini-2.5-flash-preview',
          'anthropic/claude-sonnet-5',
          'anthropic/claude-3.5-sonnet',
          'openai/gpt-5.6-sol',
          'openai/gpt-5.6-terra',
          'openai/gpt-5.6-luna',
          'openai/gpt-4o',
          'x-ai/grok-4.5',
          'deepseek/deepseek-chat',
          'deepseek/deepseek-chat-v3.1',
          'tencent/hy3',
          'tencent/hy3:free',
        ],
        openrouter: [
          'moonshotai/kimi-k2.7-code',
          'moonshotai/kimi-k2.6',
          'moonshotai/kimi-k2.5',
          'moonshotai/kimi-k2',
          'moonshotai/kimi-k2-thinking',
          'z-ai/glm-5.2',
          'z-ai/glm-5.1',
          'z-ai/glm-5',
          'z-ai/glm-4.7',
          'z-ai/glm-4.7-flash',
          'z-ai/glm-4.6',
          'z-ai/glm-4.5',
          'google/gemini-2.5-pro',
          'google/gemini-2.5-flash',
          'google/gemini-2.5-flash-preview',
          'google/gemini-2.0-flash',
          'google/gemini-2.0-flash-lite',
          'google/gemini-2.0-pro',
          'google/gemini-1.5-pro',
          'google/gemini-1.5-flash',
          'google/gemini-3.0-flash',
          'google/gemini-3.1-flash',
          'google/gemini-3.1-flash-lite',
          'anthropic/claude-sonnet-5',
          'anthropic/claude-fable-5',
          'anthropic/claude-3.5-sonnet',
          'anthropic/claude-3-haiku',
          'openai/gpt-5.6-sol',
          'openai/gpt-5.6-sol-pro',
          'openai/gpt-5.6-terra',
          'openai/gpt-5.6-terra-pro',
          'openai/gpt-5.6-luna',
          'openai/gpt-5.6-luna-pro',
          'openai/gpt-4o',
          'openai/gpt-4o-mini',
          'x-ai/grok-4.5',
          'deepseek/deepseek-chat',
          'deepseek/deepseek-chat-v3.1',
          'tencent/hy3',
          'tencent/hy3:free',
          'nousresearch/hermes-4-405b',
          'nousresearch/hermes-4-70b',
          'nousresearch/deephermes-3-mistral-24b-preview',
          'nousresearch/hermes-3-llama-3.1-70b',
          'nousresearch/hermes-3-llama-3.1-405b',
          'nousresearch/hermes-3-llama-3.1-405b:free',
          'meta-llama/llama-3.1-70b-instruct',
          'mistralai/mistral-large',
          'qwen/qwen-2.5-72b-instruct',
          'openrouter/auto',
          'openrouter/fusion',
        ],
        cloud: [
          'moonshotai/kimi-k2.6',
          'moonshotai/kimi-k2.5',
          'moonshotai/kimi-k2',
          'z-ai/glm-5.2',
          'google/gemini-2.5-pro',
          'google/gemini-2.5-flash',
          'google/gemini-2.5-flash-preview',
          'anthropic/claude-3.5-sonnet',
          'openai/gpt-4o',
          'deepseek/deepseek-chat',
        ],
        gemini: ['gemini-cli-local'],
        ollama: [
          'lux-architect',
          'nex',
          'nexx',
          'n3x',
        ],
      }
    }));
    return;
  }

  if (req.url !== '/v1/chat/completions') { errorResponse(res, 404, 'not found'); return; }

  let data = '';
  req.on('data', c => data += c);
  req.on('end', async () => {
    // Write headers ONCE here, never in handlers
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });

    try {
      const body = JSON.parse(data);
      const noRag = req.headers['x-no-rag'] === '1' || body.no_rag === true;
      if (!noRag && Array.isArray(body.messages)) {
        body.messages = injectContextIntoMessages(body.messages);
      }
      const provider = req.headers['x-provider'] || body.provider || 'hermes';
      log('Request provider:', provider, 'model:', body.model || '(default)', 'messages:', body.messages ? body.messages.length : 0, noRag ? '(RAG disabled)' : '(RAG active)');

      // Track request counters
      requestCounters.chat_requests++;
      requestCounters.llm_invocations++;
      const modelName = body.model || 'default';
      if (!requestCounters.per_model[modelName]) requestCounters.per_model[modelName] = { count: 0, total_latency_ms: 0 };
      requestCounters.per_model[modelName].count++;
      const _reqStart = Date.now();
      res.on('finish', () => {
        requestCounters.per_model[modelName].total_latency_ms += Date.now() - _reqStart;
      });

      if (provider === 'ollama') handleOllama(body, res);
      else if (provider === 'openrouter') handleOpenRouter(body, res);
      else if (provider === 'devin') {
        streamJSON(res, { choices: [{ delta: { content: '[BRIDGE ERROR: Devin provider must be used via the Task panel, not /v1/chat/completions]' } }] });
        streamDone(res);
      }
      else handleNous(body, res, req.headers);
    } catch (e) {
      log('Handler error:', e.message);
      streamJSON(res, { choices: [{ delta: { content: `[BRIDGE ERROR: ${e.message}]` } }] });
      streamDone(res);
    }
  });
});

server.listen(PORT, '127.0.0.1', () => {
  log('VoidWalkers bridge on http://127.0.0.1:' + PORT);
  log('Open your browser to: http://127.0.0.1:' + PORT);
  startTelemetryPolling();
});
