// ═══════════════════════════════════════════════════════════════
//  A2A_Gamma.h — Combined GammaLanguage v1.1C Header
//  Single-file inline implementation for Liminal Lore Deck integration
//  Merges: A2AST.h + A2ALexer.h + A2AEvaluator.h (GPU stubbed)
//  v1.1C: Rust FFI, Zero-Copy Memory Offsets, PSXMatrix DMA, CyberGrime CP0
// ═══════════════════════════════════════════════════════════════
#pragma once
#include <cstdint>
#include <array>
#include <string_view>
#include <string>
#include <cstring>
#include <cstddef>
#include <cctype>
#include <atomic>

namespace A2A {

// ─── Fault Codes ───
enum class FaultCode : uint8_t {
    NONE                    = 0x00,
    SCHEMA_DRIFT            = 0xE0,
    MEMORY_LIMIT_EXCEEDED   = 0xE1,
    INSTRUCTION_BUDGET      = 0xE2,
    VECTOR_SIMILARITY_LOW   = 0xE3
};

// ─── Opcodes (v1.1C) ───
enum class Opcode : uint8_t {
    NOP                 = 0x00,
    STATE_DECL          = 0x01,
    INVARIANT_GUARD     = 0x02,
    COLIBRI_PIN         = 0x03,
    COLIBRI_UNPIN       = 0x04,
    COLIBRI_SWAP        = 0x05,
    COLIBRI_HEARTBEAT   = 0x06,
    ASSIGN_SCALAR       = 0x0A,
    ASSIGN_STRING       = 0x0B,
    VECTOR_LOAD         = 0x10,
    VECTOR_QUERY        = 0x11,
    COSINE_SIM          = 0x12,
    CAVEMAN_SHRINK      = 0x20,
    GIGATOKEN_PACK      = 0x30,
    MCP_CALL            = 0x40,
    MATCH_BEGIN         = 0x50,
    MATCH_BRANCH        = 0x51,
    EMIT_SIGNAL         = 0xFE,
    ABORT_TRANSITION    = 0xFF,
    TARGET_DECL         = 0x07,
    TARGET_DEFINE       = 0x08,
    SKILL_EQUIP         = 0x09,
    SKILL_UNLOAD        = 0x0C,
    PROFILE_SWAP        = 0x0D,
    HIVE_SELECT         = 0x15,
    ZHARK_QUERY         = 0x16,
    FUBBU_SYNC          = 0x17,
    LOCK_ACQUIRE        = 0x60,
    LOCK_RELEASE        = 0x61,
    BARRIER_WAIT        = 0x62,
    SYNC_WAIT           = 0x63,
    ON_ERROR_BLOCK      = 0x70,
    SHIFT_TARGET        = 0x71,
    RETRY               = 0x72,
    NATIVE_BRIDGE       = 0x80,
    QVEC_LOAD           = 0x18,
    VEC_DELTA           = 0x19,
    PREDICT_BLOCK       = 0x73,
    SPEC_COMMIT         = 0x74,
    SPEC_ROLLBACK       = 0x75,
    HW_INTERRUPT        = 0x90,
    EVICT_SLIDING       = 0x31,
    // v1.1C: Rust FFI Opcodes
    RUST_OFFSET_LOAD    = 0xA0,
    RUST_FFI_CALL       = 0xA1,
    ALIGN_BOUND         = 0xA2,
    CP0_REG_MAP         = 0xA3,
    PSX_DMA_DISPATCH    = 0xA4
};

enum class CavemanLevel : uint8_t { LITE = 0, FULL = 1, ULTRA = 2, WENYAN = 3 };
enum class HWIntChannel : uint8_t { NONE = 0x00, VBLANK = 0x01, DMA_CH1 = 0x02, AUDIO_SWAP = 0x03, RENDER_DONE = 0x04 };

// ─── v1.1C: Rust FFI Types ───
enum class RustReprType : uint8_t {
    REPR_C           = 0x0,
    REPR_PACKED      = 0x1,
    REPR_ALIGN       = 0x2,
    REPR_TRANSPARENT = 0x3
};

enum RustOffsetFlag : uint8_t {
    RUST_READ_ONLY   = 0x1,
    RUST_VOLATILE    = 0x2,
    RUST_UNSAFE_PTR  = 0x4,
    RUST_DMA_MAPPED  = 0x8
};

// ─── v1.1C: Rust FFI Export Struct (96 bytes on x64, alignas(16)) ───
// Fixed: DataPtr uses uint64_t for fixed-width parity with Rust repr(C)
struct alignas(16) RustFFIExport {
    uint64_t DataPtr{0};        // 8 bytes fixed-width (was const void*)
    uint32_t DataSize{0};       // 4 bytes
    uint32_t ElementSize{0};    // 4 bytes
    RustReprType Repr{RustReprType::REPR_C}; // 1 byte
    uint8_t Flags{0};           // 1 byte
    uint8_t _pad[2]{0, 0};      // 2 bytes
    uint32_t OffsetAddr{0};     // 4 bytes
    char StructName[32]{};      // 32 bytes
    char FieldName[32]{};       // 32 bytes
};
static_assert(sizeof(RustFFIExport) == 96, "RustFFIExport must be 96 bytes on x64");

// ─── v1.1C: PEAK Subsystem FFI Dispatch Table ───
struct RustFFIDispatchTable {
    void (*Peak1_ExportBytecode)(const void*, uint32_t){nullptr};
    float (*Peak2_QVecSimd)(const uint8_t*, const uint8_t*, uint32_t){nullptr};
    void (*Peak3_SpecScopeEnter)(void*){nullptr};
    void (*Peak3_SpecScopeExit)(void*, bool){nullptr};
    void (*Peak4_HwIntDispatch)(uint8_t){nullptr};
    uint32_t (*Peak5_RingIterNext)(const void*, uint32_t, uint32_t){nullptr};
};

// ─── v1.1C: CyberGrime CP0 Register Map (32 bytes) ───
struct CyberGrimeCP0Map {
    uint32_t CP0_Status{0};    // CP0 reg 12
    uint32_t CP0_Cause{0};     // CP0 reg 13
    uint32_t CP0_EPC{0};       // CP0 reg 14
    uint32_t CP0_BadVAddr{0};  // CP0 reg 8
    uint32_t CP0_Count{0};     // CP0 reg 9
    uint32_t CP0_Compare{0};   // CP0 reg 11
    uint32_t CP0_EntryHi{0};   // CP0 reg 10
    uint32_t CP0_Index{0};     // CP0 reg 0
};

// ─── v1.1C: PSXMatrix Hardware Register Map (40 bytes) ───
// Fixed: DMA channel addresses aligned to PSX hardware spec (0x1F801080 + ch*0x10)
struct PSXHwRegMap {
    uint32_t DMA_CH1_MADR{0x1F801090}; // CH1 = MDEC out (was 0x1F8010A0)
    uint32_t DMA_CH1_BCR{0x1F801094};
    uint32_t DMA_CH1_CHCR{0x1F801098};
    uint32_t DMA_CH2_MADR{0x1F8010A0}; // CH2 = GPU (was 0x1F8010B0)
    uint32_t DMA_CH2_BCR{0x1F8010A4};
    uint32_t DMA_CH2_CHCR{0x1F8010A8};
    uint32_t GPU_GP0{0x1F801810};
    uint32_t GPU_GP1{0x1F801814};
    uint32_t I_STAT{0x1F801070};
    uint32_t I_MASK{0x1F801074};
};

// ─── PEAK-3: Speculative Buffer ───
struct SpeculativeBuffer {
    bool Active{false};
    bool Committed{false};
    uint32_t StartPC{0};
    uint32_t SavedRetryCount{0};
    uint8_t SavedTargetIndex{0};
    std::array<uint64_t, 4> SavedLck{};
    std::array<float, 8> SavedSig{};
};

// ─── Register Bank (8 banks, v1.1A-Robust+) ───
// v1.1C-fix: Added spinlock for thread-safe access in multi-threaded hypervisor
struct alignas(64) RegisterBank {
    // Thread synchronization — lightweight spinlock for concurrent access
    std::atomic_flag Spinlock = ATOMIC_FLAG_INIT;

    void lock() noexcept {
        while (Spinlock.test_and_set(std::memory_order_acquire)) {
            // spin
        }
    }
    void unlock() noexcept {
        Spinlock.clear(std::memory_order_release);
    }

    std::array<int64_t, 16> Reg{};
    std::array<uint64_t, 8> Hw{};
    std::array<uint64_t, 4> Skl{};
    std::array<std::array<uint16_t, 1536>, 8> Vec{};
    std::array<std::array<uint8_t, 1536>, 8> QVec{};
    std::array<float, 8> Sig{};
    std::array<std::array<char, 2048>, 4> Ctx{};
    std::array<uint64_t, 4> Lck{};
    uint8_t ActiveExpertIndex{0};
    float TurboQuantRamUtil{0.0f};
    uint8_t ActiveTargetIndex{0};
    uint8_t RetryCount{0};
    uint8_t MaxRetries{2};
    HWIntChannel PendingInt{HWIntChannel::NONE};
    uint32_t FrameCount{0};
    uint16_t EvictSpan{2048};
    uint16_t EvictStride{512};
    uint16_t CtxWritePos[4]{0, 0, 0, 0};
    SpeculativeBuffer SpecBuf;
    // v1.1C: Rust FFI fields
    RustFFIDispatchTable FFIDispatch;
    CyberGrimeCP0Map CP0Map;
    PSXHwRegMap PSXRegs;
    uint32_t AlignBound{16};
    RustFFIExport FFIExports[4]{};
};

// ─── AST Node (256-byte cache-line aligned) ───
struct alignas(64) ASTNode {
    Opcode op{Opcode::NOP};
    uint8_t target_reg{0};
    uint8_t src_reg_a{0};
    uint8_t src_reg_b{0};
    CavemanLevel caveman_lvl{CavemanLevel::FULL};
    float scalar_imm{0.0f};
    int64_t int_imm{0};
    char payload_str[228]{};

    void SetPayload(std::string_view sv) {
        size_t len = (sv.length() < sizeof(payload_str) - 1) ? sv.length() : (sizeof(payload_str) - 1);
        std::memcpy(payload_str, sv.data(), len);
        payload_str[len] = '\0';
    }
};
static_assert(sizeof(ASTNode) == 256, "ASTNode must be 256 bytes");

// ─── AST Arena ───
template <size_t MaxCapacity = 256>
struct ASTArena {
    std::array<ASTNode, MaxCapacity> Nodes{};
    size_t Count{0};
    bool Push(const ASTNode& node) {
        if (Count >= MaxCapacity) return false;
        Nodes[Count++] = node;
        return true;
    }
    void Clear() { Count = 0; }
};

// ─── PEAK-1: A2A-B Bytecode ───
struct A2AB_Instruction {
    uint32_t packed;
    constexpr A2AB_Instruction() : packed(0) {}
    constexpr A2AB_Instruction(uint8_t op, uint8_t tgt, uint8_t srcA, uint8_t srcB,
                                uint8_t flags, uint8_t imm)
        : packed((uint32_t(op) << 24) | (uint32_t(tgt) << 20) |
                 (uint32_t(srcA) << 16) | (uint32_t(srcB) << 12) |
                 (uint32_t(flags) << 8) | uint32_t(imm)) {}
    constexpr uint8_t GetOpcode()    const { return (packed >> 24) & 0xFF; }
    constexpr uint8_t TargetReg()    const { return (packed >> 20) & 0x0F; }
    constexpr uint8_t SrcRegA()      const { return (packed >> 16) & 0x0F; }
    constexpr uint8_t SrcRegB()      const { return (packed >> 12) & 0x0F; }
    constexpr uint8_t Flags()        const { return (packed >> 8)  & 0x0F; }
    constexpr uint8_t Immediate()    const { return  packed        & 0xFF; }
};
static_assert(sizeof(A2AB_Instruction) == 4, "A2AB instruction must be 4 bytes");

template <size_t MaxCapacity = 512>
struct BytecodeArena {
    std::array<A2AB_Instruction, MaxCapacity> Instrs{};
    size_t Count{0};
    bool Emit(const A2AB_Instruction& instr) {
        if (Count >= MaxCapacity) return false;
        Instrs[Count++] = instr;
        return true;
    }
    void Clear() { Count = 0; }
};

struct BytecodeCompiler {
    template <size_t N>
    static size_t Compile(const ASTArena<N>& ast, BytecodeArena<512>& bc) {
        bc.Clear();
        for (size_t i = 0; i < ast.Count; ++i) {
            const ASTNode& node = ast.Nodes[i];
            uint8_t flags = static_cast<uint8_t>(node.caveman_lvl) & 0x0F;
            A2AB_Instruction instr(
                static_cast<uint8_t>(node.op),
                node.target_reg & 0x0F,
                node.src_reg_a & 0x0F,
                node.src_reg_b & 0x0F,
                flags, 0
            );
            if (!bc.Emit(instr)) break;
        }
        return bc.Count;
    }
};

// ═══════════════════════════════════════════════════════════════
//  Lexer (inline implementation)
// ═══════════════════════════════════════════════════════════════
class Lexer {
public:
    explicit Lexer(std::string_view stream) : m_stream(stream), m_cursor(0) {}

    template <size_t N>
    bool ParseIntoArena(ASTArena<N>& arena) {
        arena.Clear();
        while (m_cursor < m_stream.length()) {
            SkipWhitespaceAndComments();
            if (m_cursor >= m_stream.length()) break;

            char sigil = m_stream[m_cursor];
            ASTNode node{};

            if (sigil == '!') {
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                if (line.find("SHIFT_TARGET") != std::string_view::npos)
                    node.op = Opcode::SHIFT_TARGET;
                else
                    node.op = Opcode::STATE_DECL;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '@') {
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                if (line.find("ON_ERROR") != std::string_view::npos) {
                    node.op = Opcode::ON_ERROR_BLOCK;
                    while (m_cursor < m_stream.length() && m_stream[m_cursor] != '}') m_cursor++;
                    if (m_cursor < m_stream.length()) m_cursor++;
                } else if (line.find("PREDICT") != std::string_view::npos) {
                    node.op = Opcode::PREDICT_BLOCK;
                } else if (line.find("ALIGN_BOUND") != std::string_view::npos) {
                    node.op = Opcode::ALIGN_BOUND;
                } else {
                    node.op = Opcode::INVARIANT_GUARD;
                }
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '&') {
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                if (line.find("RUST_OFFSET") != std::string_view::npos) {
                    node.op = Opcode::RUST_OFFSET_LOAD;
                    if (line.find("READ_ONLY") != std::string_view::npos) node.target_reg |= RustOffsetFlag::RUST_READ_ONLY;
                    if (line.find("VOLATILE") != std::string_view::npos) node.target_reg |= RustOffsetFlag::RUST_VOLATILE;
                    if (line.find("UNSAFE") != std::string_view::npos) node.target_reg |= RustOffsetFlag::RUST_UNSAFE_PTR;
                    if (line.find("DMA_MAPPED") != std::string_view::npos) node.target_reg |= RustOffsetFlag::RUST_DMA_MAPPED;
                } else if (line.find("UNPIN") != std::string_view::npos) node.op = Opcode::COLIBRI_UNPIN;
                else if (line.find("SWAP") != std::string_view::npos) node.op = Opcode::COLIBRI_SWAP;
                else if (line.find("HEARTBEAT") != std::string_view::npos) node.op = Opcode::COLIBRI_HEARTBEAT;
                else node.op = Opcode::COLIBRI_PIN;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '|') {
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                if (line.find("TARGET_DEFINE") != std::string_view::npos) node.op = Opcode::TARGET_DEFINE;
                else node.op = Opcode::TARGET_DECL;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '+') {
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                node.op = Opcode::SKILL_EQUIP;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '-') {
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                node.op = Opcode::SKILL_UNLOAD;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '*') {
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                node.op = Opcode::PROFILE_SWAP;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '~') {
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                node.op = Opcode::MCP_CALL;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '^') {
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                if (line.find("EVICT_SLIDING") != std::string_view::npos) node.op = Opcode::EVICT_SLIDING;
                else node.op = Opcode::GIGATOKEN_PACK;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '%') {
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                if (line.find("HW_INT") != std::string_view::npos) {
                    node.op = Opcode::HW_INTERRUPT;
                    if (line.find("VBLANK") != std::string_view::npos)
                        node.target_reg = static_cast<uint8_t>(HWIntChannel::VBLANK);
                    else if (line.find("DMA") != std::string_view::npos)
                        node.target_reg = static_cast<uint8_t>(HWIntChannel::DMA_CH1);
                    else if (line.find("AUDIO") != std::string_view::npos)
                        node.target_reg = static_cast<uint8_t>(HWIntChannel::AUDIO_SWAP);
                    else if (line.find("RENDER") != std::string_view::npos)
                        node.target_reg = static_cast<uint8_t>(HWIntChannel::RENDER_DONE);
                } else {
                    node.op = Opcode::EMIT_SIGNAL;
                }
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '?') {
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                node.op = Opcode::ZHARK_QUERY;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == 0xBF) { // ¿
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                node.op = Opcode::FUBBU_SYNC;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '#') {
                m_cursor++;
                std::string_view word = ReadWord();
                if (word.find("HIVE") != std::string_view::npos) {
                    node.op = Opcode::HIVE_SELECT;
                    std::string_view rest = ReadUntil('\n');
                    node.SetPayload(rest);
                } else if (word.find("QVEC") != std::string_view::npos) {
                    node.op = Opcode::QVEC_LOAD;
                    std::string_view rest = ReadUntil('\n');
                    node.SetPayload(rest);
                } else if (word.find("VEC_DELTA") != std::string_view::npos) {
                    node.op = Opcode::VEC_DELTA;
                    std::string_view rest = ReadUntil('\n');
                    node.SetPayload(rest);
                } else {
                    node.op = Opcode::VECTOR_LOAD;
                    node.SetPayload(word);
                }
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '=') {
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                if (line.find("UNLOCK") != std::string_view::npos) node.op = Opcode::LOCK_RELEASE;
                else if (line.find("BARRIER") != std::string_view::npos) node.op = Opcode::BARRIER_WAIT;
                else if (line.find("SYNC") != std::string_view::npos) node.op = Opcode::SYNC_WAIT;
                else node.op = Opcode::LOCK_ACQUIRE;
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '<') {
                m_cursor++;
                std::string_view line = ReadUntil('\n');
                if (line.find("NATIVE_BRIDGE") != std::string_view::npos) {
                    node.op = Opcode::NATIVE_BRIDGE;
                    while (m_cursor < m_stream.length()) {
                        if (m_stream[m_cursor] == '<' &&
                            m_cursor + 1 < m_stream.length() &&
                            m_stream.substr(m_cursor, 16).find("/NATIVE_BRIDGE") != std::string_view::npos) {
                            m_cursor += 16;
                            break;
                        }
                        m_cursor++;
                    }
                }
                node.SetPayload(line);
                if (!arena.Push(node)) return false;
            }
            else if (sigil == '$') {
                m_cursor++;
                std::string_view word = ReadWord();
                if (word.find("EXEC") != std::string_view::npos) {
                    // Parse execution block contents
                    while (m_cursor < m_stream.length() && m_stream[m_cursor] != '}') {
                        SkipWhitespaceAndComments();
                        if (m_cursor >= m_stream.length() || m_stream[m_cursor] == '}') break;
                        char c = m_stream[m_cursor];
                        ASTNode exec_node{};

                        if (c == '#' || c == '%' || c == '~' || c == '^' || c == '?' || c == '=' || c == '@') {
                            // Re-parse sigil inside EXEC block
                            exec_node.op = Opcode::ASSIGN_SCALAR;
                            std::string_view line = ReadUntil(';');
                            exec_node.SetPayload(line);
                            if (line.find("COSINE_SIM") != std::string_view::npos) exec_node.op = Opcode::COSINE_SIM;
                            else if (line.find("QUERY_VECTOR_DB") != std::string_view::npos) exec_node.op = Opcode::VECTOR_QUERY;
                            else if (line.find("LOAD_EMBEDDING") != std::string_view::npos) exec_node.op = Opcode::VECTOR_LOAD;
                            else if (line.find("CAVEMAN_SHRINK") != std::string_view::npos) exec_node.op = Opcode::CAVEMAN_SHRINK;
                            else if (line.find("GIGATOKEN_PACK") != std::string_view::npos) exec_node.op = Opcode::GIGATOKEN_PACK;
                            else if (line.find("QUANTIZE") != std::string_view::npos) exec_node.op = Opcode::QVEC_LOAD;
                            else if (line.find("VEC_DELTA") != std::string_view::npos) exec_node.op = Opcode::VEC_DELTA;
                            else if (line.find("EVICT_SLIDING") != std::string_view::npos) exec_node.op = Opcode::EVICT_SLIDING;
                            else if (line.find("HW_INT") != std::string_view::npos) exec_node.op = Opcode::HW_INTERRUPT;
                            else if (line.find("ZHARK") != std::string_view::npos) exec_node.op = Opcode::ZHARK_QUERY;
                            else if (line.find("FUBBU") != std::string_view::npos) exec_node.op = Opcode::FUBBU_SYNC;
                            else if (line.find("MCP") != std::string_view::npos) exec_node.op = Opcode::MCP_CALL;
                            else if (line.find("EMIT_SIGNAL") != std::string_view::npos) exec_node.op = Opcode::EMIT_SIGNAL;
                            else if (line.find("ABORT") != std::string_view::npos) exec_node.op = Opcode::ABORT_TRANSITION;
                            else if (line.find("MATCH") != std::string_view::npos) exec_node.op = Opcode::MATCH_BEGIN;
                            else if (line.find("RUST_FFI_CALL") != std::string_view::npos) exec_node.op = Opcode::RUST_FFI_CALL;
                            else if (line.find("CP0_REG_MAP") != std::string_view::npos) exec_node.op = Opcode::CP0_REG_MAP;
                            else if (line.find("PSX_DMA_DISPATCH") != std::string_view::npos) exec_node.op = Opcode::PSX_DMA_DISPATCH;
                            else if (line.find("RUST_OFFSET") != std::string_view::npos) exec_node.op = Opcode::RUST_OFFSET_LOAD;
                            else if (line.find("ALIGN_BOUND") != std::string_view::npos) exec_node.op = Opcode::ALIGN_BOUND;
                            if (!arena.Push(exec_node)) return false;
                        } else if (c == 'M' || c == 'R' || c == 'S' || c == 'C' || c == 'E' || c == 'A') {
                            std::string_view word2 = ReadWord();
                            std::string_view rest = ReadUntil(';');
                            if (word2.find("MATCH") != std::string_view::npos) exec_node.op = Opcode::MATCH_BEGIN;
                            else if (word2.find("REG") != std::string_view::npos) exec_node.op = Opcode::ASSIGN_SCALAR;
                            else if (word2.find("CTX") != std::string_view::npos) exec_node.op = Opcode::ASSIGN_STRING;
                            else if (word2.find("CAVEMAN") != std::string_view::npos) exec_node.op = Opcode::CAVEMAN_SHRINK;
                            else if (word2.find("COSINE") != std::string_view::npos) exec_node.op = Opcode::COSINE_SIM;
                            else if (word2.find("EMIT") != std::string_view::npos) exec_node.op = Opcode::EMIT_SIGNAL;
                            else if (word2.find("ABORT") != std::string_view::npos) exec_node.op = Opcode::ABORT_TRANSITION;
                            else if (word2.find("SPEC_COMMIT") != std::string_view::npos) exec_node.op = Opcode::SPEC_COMMIT;
                            else if (word2.find("SPEC_ROLLBACK") != std::string_view::npos) exec_node.op = Opcode::SPEC_ROLLBACK;
                            else if (word2.find("RETRY") != std::string_view::npos) exec_node.op = Opcode::RETRY;
                            else { m_cursor++; continue; }
                            exec_node.SetPayload(rest);
                            if (!arena.Push(exec_node)) return false;
                        } else {
                            m_cursor++;
                        }
                    }
                    if (m_cursor < m_stream.length() && m_stream[m_cursor] == '}') m_cursor++;
                }
            }
            else {
                m_cursor++;
            }
        }
        return true;
    }

private:
    void SkipWhitespaceAndComments() {
        while (m_cursor < m_stream.length()) {
            char c = m_stream[m_cursor];
            if (std::isspace(static_cast<unsigned char>(c))) {
                m_cursor++;
            } else if (c == '/' && m_cursor + 1 < m_stream.length() && m_stream[m_cursor + 1] == '/') {
                while (m_cursor < m_stream.length() && m_stream[m_cursor] != '\n') m_cursor++;
            } else {
                break;
            }
        }
    }

    std::string_view ReadUntil(char delimiter) {
        size_t start = m_cursor;
        while (m_cursor < m_stream.length() && m_stream[m_cursor] != delimiter) m_cursor++;
        std::string_view res = m_stream.substr(start, m_cursor - start);
        if (m_cursor < m_stream.length() && m_stream[m_cursor] == delimiter) m_cursor++;
        return res;
    }

    std::string_view ReadWord() {
        SkipWhitespaceAndComments();
        size_t start = m_cursor;
        while (m_cursor < m_stream.length()) {
            char c = m_stream[m_cursor];
            if (std::isalnum(static_cast<unsigned char>(c)) || c == '_' || c == '.' || c == '-' || c == '[' || c == ']' || c == ':') {
                m_cursor++;
            } else {
                break;
            }
        }
        return m_stream.substr(start, m_cursor - start);
    }

    std::string_view m_stream;
    size_t m_cursor{0};
};

// ═══════════════════════════════════════════════════════════════
//  Evaluator (inline implementation, GPU stubbed)
// ═══════════════════════════════════════════════════════════════
struct ExecutionResult {
    bool Success{true};
    FaultCode Fault{FaultCode::NONE};
    uint8_t ExitCode{0};
    std::string Message{"OK"};
    uint32_t InvariantsChecked{0};
    uint32_t InstructionsExecuted{0};
};

class Evaluator {
public:
    explicit Evaluator(uint32_t max_cycles = 1000) : m_max_cycles(max_cycles) {}

    template <size_t N>
    ExecutionResult Execute(const ASTArena<N>& arena, RegisterBank& registers) {
        ExecutionResult res{};

        for (size_t i = 0; i < arena.Count; ++i) {
            if (res.InstructionsExecuted >= m_max_cycles) {
                res.Success = false;
                res.Fault = FaultCode::INSTRUCTION_BUDGET;
                res.ExitCode = static_cast<uint8_t>(FaultCode::INSTRUCTION_BUDGET);
                res.Message = "Instruction cycle budget limit exceeded";
                return res;
            }

            const ASTNode& node = arena.Nodes[i];

            switch (node.op) {
                case Opcode::STATE_DECL:
                    res.InstructionsExecuted++;
                    break;

                case Opcode::TARGET_DECL:
                    registers.ActiveTargetIndex = 1;
                    res.InstructionsExecuted++;
                    break;

                case Opcode::INVARIANT_GUARD:
                    res.InvariantsChecked++;
                    res.InstructionsExecuted++;
                    break;

                case Opcode::SKILL_EQUIP:
                    if (registers.ActiveExpertIndex < 3)
                        registers.ActiveExpertIndex++;
                    res.InstructionsExecuted++;
                    break;

                case Opcode::SKILL_UNLOAD:
                    if (registers.ActiveExpertIndex > 0)
                        registers.ActiveExpertIndex--;
                    res.InstructionsExecuted++;
                    break;

                case Opcode::CAVEMAN_SHRINK:
                    res.InstructionsExecuted++;
                    break;

                case Opcode::GIGATOKEN_PACK:
                    res.InstructionsExecuted++;
                    break;

                case Opcode::MCP_CALL:
                    res.InstructionsExecuted++;
                    break;

                case Opcode::COSINE_SIM: {
                    float sim = 0.0f;
                    for (int d = 0; d < 1536; ++d) {
                        float a = static_cast<float>(registers.Vec[node.src_reg_a][d]);
                        float b = static_cast<float>(registers.Vec[node.src_reg_b][d]);
                        sim += a * b;
                    }
                    registers.Reg[node.target_reg] = static_cast<int64_t>(sim * 1000.0f);
                    res.InstructionsExecuted++;
                    break;
                }

                case Opcode::LOCK_ACQUIRE:
                    if (registers.Lck[node.target_reg & 0x03] == 0)
                        registers.Lck[node.target_reg & 0x03] = 1;
                    res.InstructionsExecuted++;
                    break;

                case Opcode::LOCK_RELEASE:
                    registers.Lck[node.target_reg & 0x03] = 0;
                    res.InstructionsExecuted++;
                    break;

                case Opcode::QVEC_LOAD: {
                    // Quantize FP16 vector to 8-bit
                    uint8_t qidx = node.target_reg & 0x07;
                    uint8_t vidx = node.src_reg_a & 0x07;
                    for (int d = 0; d < 1536; ++d) {
                        uint16_t fp16 = registers.Vec[vidx][d];
                        registers.QVec[qidx][d] = static_cast<uint8_t>(fp16 >> 8);
                    }
                    res.InstructionsExecuted++;
                    break;
                }

                case Opcode::VEC_DELTA: {
                    uint8_t qa = node.src_reg_a & 0x07;
                    uint8_t qb = node.src_reg_b & 0x07;
                    uint8_t qt = node.target_reg & 0x07;
                    for (int d = 0; d < 1536; ++d) {
                        int16_t delta = static_cast<int16_t>(registers.QVec[qa][d]) -
                                        static_cast<int16_t>(registers.QVec[qb][d]);
                        registers.QVec[qt][d] = static_cast<uint8_t>(delta & 0xFF);
                    }
                    res.InstructionsExecuted++;
                    break;
                }

                case Opcode::PREDICT_BLOCK:
                    if (!registers.SpecBuf.Active) {
                        registers.SpecBuf.Active = true;
                        registers.SpecBuf.Committed = false;
                        registers.SpecBuf.StartPC = static_cast<uint32_t>(i);
                        registers.SpecBuf.SavedRetryCount = registers.RetryCount;
                        registers.SpecBuf.SavedTargetIndex = registers.ActiveTargetIndex;
                        registers.SpecBuf.SavedLck = registers.Lck;
                        registers.SpecBuf.SavedSig = registers.Sig;
                    }
                    res.InstructionsExecuted++;
                    break;

                case Opcode::SPEC_COMMIT:
                    if (registers.SpecBuf.Active) {
                        registers.SpecBuf.Active = false;
                        registers.SpecBuf.Committed = true;
                    }
                    res.InstructionsExecuted++;
                    break;

                case Opcode::SPEC_ROLLBACK:
                    if (registers.SpecBuf.Active) {
                        registers.RetryCount = registers.SpecBuf.SavedRetryCount;
                        registers.ActiveTargetIndex = registers.SpecBuf.SavedTargetIndex;
                        registers.Lck = registers.SpecBuf.SavedLck;
                        registers.Sig = registers.SpecBuf.SavedSig;
                        registers.SpecBuf.Active = false;
                        registers.SpecBuf.Committed = false;
                    }
                    res.InstructionsExecuted++;
                    break;

                case Opcode::HW_INTERRUPT:
                    registers.PendingInt = static_cast<HWIntChannel>(node.target_reg);
                    registers.FrameCount++;
                    res.InstructionsExecuted++;
                    break;

                case Opcode::EVICT_SLIDING: {
                    // Parse SPAN and STRIDE from payload
                    std::string_view payload(node.payload_str);
                    size_t span_pos = payload.find("SPAN=");
                    if (span_pos != std::string_view::npos) {
                        registers.EvictSpan = static_cast<uint16_t>(std::atoi(payload.data() + span_pos + 5));
                    }
                    size_t stride_pos = payload.find("STRIDE=");
                    if (stride_pos != std::string_view::npos) {
                        registers.EvictStride = static_cast<uint16_t>(std::atoi(payload.data() + stride_pos + 7));
                    }
                    // Advance ring-buffer write positions
                    for (int c = 0; c < 4; ++c) {
                        registers.CtxWritePos[c] = (registers.CtxWritePos[c] + registers.EvictStride) % registers.EvictSpan;
                    }
                    res.InstructionsExecuted++;
                    break;
                }

                case Opcode::EMIT_SIGNAL:
                    res.InstructionsExecuted++;
                    break;

                case Opcode::RUST_OFFSET_LOAD: {
                    uint8_t idx = node.target_reg & 0x03;
                    std::string_view payload(node.payload_str);
                    size_t off_pos = payload.find("OFFSET=0x");
                    if (off_pos != std::string_view::npos) {
                        registers.FFIExports[idx].OffsetAddr =
                            static_cast<uint32_t>(std::strtoul(payload.data() + off_pos + 8, nullptr, 16));
                    }
                    size_t sz_pos = payload.find("SIZE=");
                    if (sz_pos != std::string_view::npos) {
                        registers.FFIExports[idx].DataSize =
                            static_cast<uint32_t>(std::atoi(payload.data() + sz_pos + 5));
                    }
                    if (payload.find("REPR_PACKED") != std::string_view::npos)
                        registers.FFIExports[idx].Repr = RustReprType::REPR_PACKED;
                    else if (payload.find("REPR_ALIGN") != std::string_view::npos)
                        registers.FFIExports[idx].Repr = RustReprType::REPR_ALIGN;
                    else if (payload.find("REPR_TRANSPARENT") != std::string_view::npos)
                        registers.FFIExports[idx].Repr = RustReprType::REPR_TRANSPARENT;
                    else
                        registers.FFIExports[idx].Repr = RustReprType::REPR_C;
                    res.InstructionsExecuted++;
                    break;
                }

                case Opcode::RUST_FFI_CALL: {
                    uint8_t peak_idx = node.target_reg & 0x07;
                    if (peak_idx == 1 && registers.FFIDispatch.Peak1_ExportBytecode)
                        registers.FFIDispatch.Peak1_ExportBytecode(nullptr, 0);
                    else if (peak_idx == 2 && registers.FFIDispatch.Peak2_QVecSimd)
                        registers.Reg[0] = static_cast<int64_t>(
                            registers.FFIDispatch.Peak2_QVecSimd(nullptr, nullptr, 0) * 1000);
                    else if (peak_idx == 3 && registers.FFIDispatch.Peak3_SpecScopeEnter)
                        registers.FFIDispatch.Peak3_SpecScopeEnter(nullptr);
                    else if (peak_idx == 4 && registers.FFIDispatch.Peak4_HwIntDispatch)
                        registers.FFIDispatch.Peak4_HwIntDispatch(static_cast<uint8_t>(registers.PendingInt));
                    else if (peak_idx == 5 && registers.FFIDispatch.Peak5_RingIterNext)
                        registers.Reg[0] = registers.FFIDispatch.Peak5_RingIterNext(nullptr, 0, 0);
                    res.InstructionsExecuted++;
                    break;
                }

                case Opcode::ALIGN_BOUND: {
                    std::string_view payload(node.payload_str);
                    size_t bound_pos = payload.find("BOUND=");
                    if (bound_pos != std::string_view::npos) {
                        registers.AlignBound = static_cast<uint32_t>(
                            std::atoi(payload.data() + bound_pos + 6));
                    }
                    res.InstructionsExecuted++;
                    break;
                }

                case Opcode::CP0_REG_MAP: {
                    std::string_view payload(node.payload_str);
                    if (payload.find("Status") != std::string_view::npos)
                        registers.CP0Map.CP0_Status = static_cast<uint32_t>(node.int_imm);
                    else if (payload.find("Cause") != std::string_view::npos)
                        registers.CP0Map.CP0_Cause = static_cast<uint32_t>(node.int_imm);
                    else if (payload.find("EPC") != std::string_view::npos)
                        registers.CP0Map.CP0_EPC = static_cast<uint32_t>(node.int_imm);
                    else if (payload.find("BadVAddr") != std::string_view::npos)
                        registers.CP0Map.CP0_BadVAddr = static_cast<uint32_t>(node.int_imm);
                    else if (payload.find("Count") != std::string_view::npos)
                        registers.CP0Map.CP0_Count = static_cast<uint32_t>(node.int_imm);
                    res.InstructionsExecuted++;
                    break;
                }

                case Opcode::PSX_DMA_DISPATCH: {
                    uint8_t ch = node.target_reg & 0x01;
                    if (ch == 0) {
                        registers.PSXRegs.DMA_CH1_MADR = static_cast<uint32_t>(node.int_imm);
                        if (registers.FFIDispatch.Peak4_HwIntDispatch)
                            registers.FFIDispatch.Peak4_HwIntDispatch(static_cast<uint8_t>(HWIntChannel::DMA_CH1));
                    } else {
                        registers.PSXRegs.DMA_CH2_MADR = static_cast<uint32_t>(node.int_imm);
                    }
                    res.InstructionsExecuted++;
                    break;
                }

                case Opcode::ABORT_TRANSITION:
                    res.Success = false;
                    res.Fault = FaultCode::SCHEMA_DRIFT;
                    res.Message = "ABORT_TRANSITION triggered";
                    return res;

                default:
                    res.InstructionsExecuted++;
                    break;
            }
        }
        return res;
    }

    // PEAK-1: Direct Threaded Code bytecode execution
    template <size_t N>
    ExecutionResult ExecuteBytecode(const BytecodeArena<N>& bc, RegisterBank& registers) {
        ExecutionResult res{};

        for (size_t i = 0; i < bc.Count; ++i) {
            if (res.InstructionsExecuted >= m_max_cycles) {
                res.Success = false;
                res.Fault = FaultCode::INSTRUCTION_BUDGET;
                res.Message = "Bytecode cycle budget exceeded";
                return res;
            }

            const A2AB_Instruction& instr = bc.Instrs[i];
            uint8_t op = instr.GetOpcode();

            switch (op) {
                case static_cast<uint8_t>(Opcode::STATE_DECL):
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::TARGET_DECL):
                    registers.ActiveTargetIndex = 1;
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::INVARIANT_GUARD):
                    res.InvariantsChecked++;
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::LOCK_ACQUIRE):
                    if (registers.Lck[instr.TargetReg() & 0x03] == 0)
                        registers.Lck[instr.TargetReg() & 0x03] = 1;
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::LOCK_RELEASE):
                    registers.Lck[instr.TargetReg() & 0x03] = 0;
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::QVEC_LOAD): {
                    uint8_t qidx = instr.TargetReg() & 0x07;
                    uint8_t vidx = instr.SrcRegA() & 0x07;
                    for (int d = 0; d < 1536; ++d) {
                        uint16_t fp16 = registers.Vec[vidx][d];
                        registers.QVec[qidx][d] = static_cast<uint8_t>(fp16 >> 8);
                    }
                    res.InstructionsExecuted++;
                    break;
                }

                case static_cast<uint8_t>(Opcode::HW_INTERRUPT):
                    registers.PendingInt = static_cast<HWIntChannel>(instr.TargetReg());
                    registers.FrameCount++;
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::EVICT_SLIDING):
                    for (int c = 0; c < 4; ++c) {
                        registers.CtxWritePos[c] = (registers.CtxWritePos[c] + registers.EvictStride) % registers.EvictSpan;
                    }
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::EMIT_SIGNAL):
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::RUST_OFFSET_LOAD):
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::RUST_FFI_CALL):
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::ALIGN_BOUND):
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::CP0_REG_MAP):
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::PSX_DMA_DISPATCH):
                    res.InstructionsExecuted++;
                    break;

                case static_cast<uint8_t>(Opcode::ABORT_TRANSITION):
                    res.Success = false;
                    res.Fault = FaultCode::SCHEMA_DRIFT;
                    res.Message = "Bytecode ABORT_TRANSITION";
                    return res;

                default:
                    res.InstructionsExecuted++;
                    break;
            }
        }
        return res;
    }

private:
    uint32_t m_max_cycles;
};

} // namespace A2A
