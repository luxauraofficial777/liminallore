"""ZHARK — CLI Entry Point.

Usage:
  python -m zhark run "Your research question here"
  python -m zhark run "Question" --max-iterations 100 --convergence 0.8
  python -m zhark status
  python -m zhark resume <cycle_id>
  python -m zhark cycles
  python -m zhark report <cycle_id>
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(
        description="ZHARK — Autonomous Long-Horizon Research & Strategy Engine"
    )
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # Run command
    run_parser = subparsers.add_parser("run", help="Run a research cycle")
    run_parser.add_argument("question", type=str, help="Research question to investigate")
    run_parser.add_argument("--max-iterations", type=int, default=50, help="Max investigation cycles")
    run_parser.add_argument("--convergence", type=float, default=0.75, help="Convergence threshold")
    run_parser.add_argument("--max-depth", type=int, default=5, help="Max hypothesis tree depth")
    run_parser.add_argument("--cycle-delay", type=float, default=5.0, help="Seconds between cycles")
    run_parser.add_argument("--db-path", type=str, default=None, help="SQLite state DB path")
    run_parser.add_argument("--output-dir", type=str, default=None, help="Output directory")

    # Status command
    subparsers.add_parser("status", help="Show current ZHARK status")

    # Resume command
    resume_parser = subparsers.add_parser("resume", help="Resume a previous cycle")
    resume_parser.add_argument("cycle_id", type=str, help="Cycle ID to resume")
    resume_parser.add_argument("--max-iterations", type=int, default=None)

    # List cycles
    subparsers.add_parser("cycles", help="List all research cycles")

    # Report command
    report_parser = subparsers.add_parser("report", help="Show report for a cycle")
    report_parser.add_argument("cycle_id", type=str, help="Cycle ID")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    # Import ZHARK components
    try:
        from .zhark_orchestrator import ZharkOrchestrator
        from .zhark_state import ZharkState
    except ImportError as e:
        print(f"ZHARK: Import error: {e}")
        print("ZHARK: Make sure you're running from the tools/ directory")
        sys.exit(1)

    # Try to load Liminal Lore config + provider if available
    llm_provider = None
    config_loader = None
    try:
        import importlib
        # Add liminal_lore_vw_deck to path
        tools_dir = Path(__file__).parent.parent
        deck_dir = tools_dir / "liminal_lore_vw_deck"
        if str(deck_dir) not in sys.path:
            sys.path.insert(0, str(deck_dir))
        from config import ConfigLoader, LLMProvider
        config_loader = ConfigLoader()
        llm_provider = LLMProvider(config_loader)
        print("ZHARK: Liminal Lore LLM provider loaded")
    except ImportError:
        print("ZHARK: Liminal Lore config not found — running without LLM (heuristic mode)")

    # Determine DB path
    project_root = os.environ.get("PROJECT_ROOT", str(Path(__file__).parent.parent.parent))
    db_path = args.db_path if hasattr(args, "db_path") and args.db_path else None
    if not db_path:
        db_path = str(Path(project_root) / "tools" / "zhark" / "data" / "zhark_state.db")

    output_dir = args.output_dir if hasattr(args, "output_dir") and args.output_dir else None

    if args.command == "run":
        orchestrator = ZharkOrchestrator(
            llm_provider=llm_provider,
            config_loader=config_loader,
            db_path=db_path,
            max_iterations=args.max_iterations,
            convergence_threshold=args.convergence,
            max_depth=args.max_depth,
            cycle_delay=args.cycle_delay,
            output_dir=output_dir,
        )

        # Progress callback
        def on_progress(event, data):
            print(f"  [{event}] {json.dumps(data, default=str)[:200]}")

        orchestrator.set_progress_callback(on_progress)

        report = orchestrator.run(args.question)
        print(f"\nZHARK: Report saved to {report.get('report_path', 'N/A')}")
        print(f"ZHARK: {len(report.get('strategy_options', []))} strategic options generated")

    elif args.command == "status":
        state = ZharkState(db_path)
        cycles = state.list_cycles(status="active")
        if cycles:
            print("Active cycles:")
            for c in cycles:
                print(f"  {c['cycle_id']}: {c['research_question'][:60]}")
                print(f"    Phase: {c['phase']}, Iteration: {c['iteration']}")
        else:
            print("No active cycles.")

    elif args.command == "resume":
        orchestrator = ZharkOrchestrator(
            llm_provider=llm_provider,
            config_loader=config_loader,
            db_path=db_path,
            output_dir=output_dir,
        )
        report = orchestrator.resume(args.cycle_id, max_iterations=args.max_iterations)
        print(f"\nZHARK: Resume complete. Report: {report.get('report_path', 'N/A')}")

    elif args.command == "cycles":
        state = ZharkState(db_path)
        cycles = state.list_cycles()
        if not cycles:
            print("No cycles found.")
        else:
            print(f"{'Cycle ID':<16} {'Status':<12} {'Phase':<16} {'Iter':<6} {'Question'}")
            print("-" * 80)
            for c in cycles:
                print(f"{c['cycle_id']:<16} {c['status']:<12} {c['phase']:<16} "
                      f"{c['iteration']:<6} {c['research_question'][:40]}")

    elif args.command == "report":
        state = ZharkState(db_path)
        cycle = state.get_cycle(args.cycle_id)
        if not cycle:
            print(f"Cycle {args.cycle_id} not found.")
            sys.exit(1)

        checkpoint = state.load_latest_checkpoint(args.cycle_id)
        if checkpoint and checkpoint.get("strategy"):
            strategy = checkpoint["strategy"]
            print(json.dumps(strategy, indent=2, default=str))
        else:
            print(f"No strategy output found for cycle {args.cycle_id}")
            print(f"Cycle status: {cycle['status']}, Phase: {cycle['phase']}")


if __name__ == "__main__":
    main()
