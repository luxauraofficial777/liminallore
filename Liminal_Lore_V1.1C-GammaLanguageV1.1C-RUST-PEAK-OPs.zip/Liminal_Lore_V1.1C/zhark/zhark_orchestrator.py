"""ZHARK — Autonomous Long-Horizon Research Orchestrator.

The main async loop that drives multi-hour investigation cycles. This is the
core of ZHARK's Virtual CSO capability — it runs autonomously, forming
hypotheses, gathering web data, resolving contradictions, mapping causal
relationships, and synthesizing executive-ready strategy.

Orchestration Loop (one cycle):
  1. HYPOTHESIS: Generate or select pending hypotheses from the graph
  2. GATHER: Web-search for evidence supporting/refuting each hypothesis
  3. ANALYZE: LLM extracts key claims, causal relationships from gathered data
  4. VERIFY: Verification buffer scores outputs for consistency and convergence
  5. CONTRADICT: Detect contradictions between hypotheses, flag for resolution
  6. REFINE: Generate sub-hypotheses or revise existing ones based on findings
  7. CAUSAL: Update causal map with newly discovered relationships
  8. SYNTHESIZE: Convert findings to strategic options (when convergence reached)

The loop continues until:
  - All root hypotheses reach SUPPORTED or REFUTED status
  - Max iterations reached
  - Convergence threshold met (avg confidence > threshold)
  - Human interrupt (Ctrl+C)

State is checkpointed to SQLite every cycle for resume capability.
"""

from __future__ import annotations

import json
import os
import signal
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Callable

# ─── GammaLanguage v1.1C Integration ───
import os as _os
import sys as _sys
_GAMMA_PATH = _os.path.join(_os.path.dirname(__file__), "..", "..", "..", "GammaLanguage", "python")
if _GAMMA_PATH not in _sys.path:
    _sys.path.insert(0, _os.path.abspath(_GAMMA_PATH))
try:
    from gamma_bridge import GammaBridge as _GammaBridge
    _gamma = _GammaBridge()
    _GAMMA_AVAILABLE = True
except Exception:
    _gamma = None
    _GAMMA_AVAILABLE = False

from .zhark_hypothesis_graph import HypothesisGraph, Hypothesis, Evidence, HypothesisStatus
from .zhark_causal_mapper import CausalMapper, CausalNode, CausalEdge, CausalType
from .zhark_strategy_synthesizer import StrategySynthesizer, StrategyOption
from .zhark_state import ZharkState, VerifyBuffer, CyclePhase
from .zhark_web_gatherer import WebGatherer, SearchResult


def _get_token_counter():
    """Lazy-load token counter (gigatoken with heuristic fallback)."""
    try:
        from shared.token_counter import get_token_counter
        return get_token_counter()
    except Exception:
        return None


def parse_zhark_directive(gamma_script: str) -> Optional[Dict[str, Any]]:
    """Parse a ?ZHARK sigil directive from a GammaLanguage v1.1C script.

    Extracts the research question and parameters from a Gamma script
    containing a ?ZHARK_QUERY directive. This enables GammaLanguage to
    dispatch research tasks directly to the ZHARK orchestrator.
    """
    if not gamma_script or not _GAMMA_AVAILABLE:
        return None
    try:
        compiled = _gamma.compile_gamma(gamma_script)
        research = compiled.get("research_directives", [])
        zhark_directives = [d for d in research if d.get("type") == "zhark"]
        if not zhark_directives:
            return None
        directive = zhark_directives[0]
        query_line = directive.get("query", "")
        # Extract research question from the ?ZHARK line
        # Format: ?ZHARK(research_question, max_iterations=..., convergence=...)
        import re
        match = re.match(r'.*ZHARK\s*\(?(.+?)(?:\)|$)', query_line)
        question = match.group(1).strip() if match else query_line
        # Extract optional parameters
        max_iter_match = re.search(r'max_iterations=(\d+)', query_line)
        max_iterations = int(max_iter_match.group(1)) if max_iter_match else None
        conv_match = re.search(r'convergence=([\d.]+)', query_line)
        convergence = float(conv_match.group(1)) if conv_match else None
        return {
            "research_question": question,
            "max_iterations": max_iterations,
            "convergence_threshold": convergence,
            "gamma_compiled": compiled,
        }
    except Exception:
        return None


class ZharkOrchestrator:
    """Main orchestrator for autonomous long-horizon research.

    Configuration via environment variables or constructor args:
      ZHARK_MAX_ITERATIONS — Max investigation cycles (default: 50)
      ZHARK_CONVERGENCE_THRESHOLD — Avg confidence to stop (default: 0.75)
      ZHARK_MAX_DEPTH — Max hypothesis tree depth (default: 5)
      ZHARK_CYCLE_DELAY — Seconds between cycles (default: 5)
      ZHARK_VERIFY_CANDIDATES — LLM candidates per verification (default: 3)
    """

    def __init__(
        self,
        llm_provider=None,
        config_loader=None,
        db_path: Optional[str] = None,
        max_iterations: int = 50,
        convergence_threshold: float = 0.75,
        max_depth: int = 5,
        cycle_delay: float = 5.0,
        verify_candidates: int = 3,
        output_dir: Optional[str] = None,
    ):
        # LLM provider (from Liminal Lore provider_abstraction)
        self._llm = llm_provider
        self._config = config_loader

        # Override from env vars if present
        self.max_iterations = int(os.environ.get("ZHARK_MAX_ITERATIONS", max_iterations))
        self.convergence_threshold = float(os.environ.get("ZHARK_CONVERGENCE_THRESHOLD", convergence_threshold))
        self.max_depth = int(os.environ.get("ZHARK_MAX_DEPTH", max_depth))
        self.cycle_delay = float(os.environ.get("ZHARK_CYCLE_DELAY", cycle_delay))
        self.verify_candidates = int(os.environ.get("ZHARK_VERIFY_CANDIDATES", verify_candidates))

        # State management
        if db_path:
            self.state = ZharkState(db_path)
        else:
            project_root = os.environ.get("PROJECT_ROOT", ".")
            self.state = ZharkState(Path(project_root) / "tools" / "zhark" / "data" / "zhark_state.db")

        self._tc = _get_token_counter()

        # GammaLanguage v1.1C: Caveman compress helper
        self._gamma_available = _GAMMA_AVAILABLE
        self._gamma = _gamma

        # Core components
        self.hypothesis_graph = HypothesisGraph()
        self.causal_mapper = CausalMapper()
        self.strategy_synthesizer = StrategySynthesizer(llm_provider=self._llm)
        self.verify_buffer = VerifyBuffer(
            max_candidates=self.verify_candidates,
            convergence_threshold=self.convergence_threshold,
        )
        self.web_gatherer = WebGatherer()

        # Output directory
        self.output_dir = Path(output_dir or (Path(os.environ.get("PROJECT_ROOT", ".")) / "tools" / "zhark" / "output"))
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Runtime state
        self._running = False
        self._stop_event = threading.Event()
        self._cycle_id: Optional[str] = None
        self._iteration = 0
        self._phase = CyclePhase.IDLE.value
        self._progress_callback: Optional[Callable] = None

    def set_progress_callback(self, callback: Callable) -> None:
        """Set a callback function called after each phase completion."""
        self._progress_callback = callback

    def _gamma_compress(self, text: str) -> str:
        """Apply GammaLanguage Caveman compression to text if available."""
        if self._gamma_available:
            try:
                return self._gamma.caveman_compress(text, level="full")
            except Exception:
                pass
        return text

    def _budget_prompt(self, prompt: str, system: str, max_output: int = 512) -> dict:
        """Calculate token budget for an LLM call."""
        if not self._tc:
            return {"fits": True, "prompt_tokens": 0, "output_budget": max_output, "rag_budget": 0}
        prompt_tokens = self._tc.count(prompt) + self._tc.count(system)
        context_window = self._tc.get_context_window()
        fits = prompt_tokens + max_output <= context_window
        rag_budget = max(0, context_window - prompt_tokens - max_output)
        return {"fits": fits, "prompt_tokens": prompt_tokens, "output_budget": max_output, "rag_budget": rag_budget}

    def _emit(self, event: str, data: Dict) -> None:
        """Log event to state and call progress callback."""
        if self._cycle_id:
            self.state.log_event(self._cycle_id, event, data)
        if self._progress_callback:
            try:
                self._progress_callback(event, data)
            except Exception:
                pass

    def run(
        self,
        research_question: str,
        max_iterations: Optional[int] = None,
        resume_cycle_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Run a complete autonomous research cycle.

        Args:
          research_question: The strategic question to investigate
          max_iterations: Override max iterations for this run
          resume_cycle_id: Resume from a previous cycle checkpoint

        Returns:
          Final report dict with strategy options, hypothesis graph, and causal map
        """
        max_iters = max_iterations or self.max_iterations

        # Resume or start new cycle
        if resume_cycle_id:
            checkpoint = self.state.load_latest_checkpoint(resume_cycle_id)
            if checkpoint:
                self._cycle_id = resume_cycle_id
                self._iteration = checkpoint.get("iteration", 0)
                if checkpoint.get("hypothesis_graph"):
                    self.hypothesis_graph.load(self.output_dir / f"hyp_checkpoint_{resume_cycle_id}.json")
                if checkpoint.get("causal_map"):
                    self.causal_mapper.load(self.output_dir / f"causal_checkpoint_{resume_cycle_id}.json")
                print(f"ZHARK: Resuming cycle {resume_cycle_id} at iteration {self._iteration}")
            else:
                print(f"ZHARK: No checkpoint found for {resume_cycle_id}, starting new cycle")
                self._cycle_id = self.state.start_cycle(research_question)
        else:
            self._cycle_id = self.state.start_cycle(research_question)

        self._running = True
        self._stop_event.clear()

        # Set up signal handlers (only in main thread — signal.signal raises ValueError in threads)
        if threading.current_thread() is threading.main_thread():
            signal.signal(signal.SIGINT, self._signal_handler)
            if hasattr(signal, "SIGTERM"):
                signal.signal(signal.SIGTERM, self._signal_handler)

        # Phase 1: Form initial hypotheses
        self._set_phase(CyclePhase.HYPOTHESIS)
        if self._iteration == 0:
            self._form_initial_hypotheses(research_question)
            self._emit("initial_hypotheses", self.hypothesis_graph.summary())

        # Main orchestration loop
        while self._running and not self._stop_event.is_set() and self._iteration < max_iters:
            self._iteration += 1
            print(f"\n{'='*60}")
            print(f"ZHARK: Cycle {self._iteration}/{max_iters}")
            print(f"{'='*60}")

            # Check convergence
            if self._check_convergence():
                print("ZHARK: Convergence threshold met. Synthesizing final strategy.")
                break

            # Get pending hypotheses
            pending = self.hypothesis_graph.get_pending(max_depth=self.max_depth)
            if not pending:
                print("ZHARK: No pending hypotheses remaining. Synthesizing strategy.")
                break

            # Process each pending hypothesis
            for hyp in pending[:3]:  # Process top 3 per cycle
                if self._stop_event.is_set():
                    break
                self._process_hypothesis(hyp, research_question)

            # Detect contradictions
            self._set_phase(CyclePhase.VERIFYING)
            contradictions = self.hypothesis_graph.detect_contradictions()
            if contradictions:
                self._emit("contradictions_detected", {"count": len(contradictions)})
                self._resolve_contradictions(contradictions)

            # Update causal map
            self._set_phase(CyclePhase.ANALYZING)
            self._update_causal_map()

            # Checkpoint
            self._checkpoint()
            self._emit("cycle_checkpoint", {"iteration": self._iteration})

            # Rate limit
            if self.cycle_delay > 0:
                self._stop_event.wait(self.cycle_delay)

        # Phase: Synthesize strategy
        self._set_phase(CyclePhase.SYNTHESIZING)
        options = self.strategy_synthesizer.synthesize(
            self.hypothesis_graph,
            self.causal_mapper,
            research_question,
        )
        self._emit("strategy_synthesized", {"option_count": len(options)})

        # Final checkpoint
        self._checkpoint(strategy=True)

        # Complete cycle
        self.state.complete_cycle(self._cycle_id)
        self._set_phase(CyclePhase.COMPLETE)

        # Generate final report
        report = self._generate_final_report(research_question, options)

        print(f"\nZHARK: Research cycle complete. {len(options)} strategic options generated.")
        print(f"ZHARK: Report saved to {self.output_dir}")

        self._running = False
        return report

    def _process_hypothesis(self, hyp: Hypothesis, research_question: str) -> None:
        """Process a single hypothesis through the gather-analyze-verify loop."""
        print(f"\nZHARK: Processing hypothesis: {hyp.statement[:80]}")

        # Phase: Gathering
        self._set_phase(CyclePhase.GATHERING)
        self._emit("gathering_start", {"hypothesis_id": hyp.hypothesis_id, "statement": hyp.statement})

        results = self.web_gatherer.gather_evidence(hyp.statement)
        self._emit("gathering_complete", {
            "hypothesis_id": hyp.hypothesis_id,
            "results_count": len(results),
        })

        # Phase: Analyzing
        self._set_phase(CyclePhase.ANALYZING)
        evidence_list = self._analyze_evidence(hyp, results)
        for evidence in evidence_list:
            self.hypothesis_graph.add_evidence(hyp.hypothesis_id, evidence)

        self._emit("analysis_complete", {
            "hypothesis_id": hyp.hypothesis_id,
            "evidence_added": len(evidence_list),
            "confidence": self.hypothesis_graph.get(hyp.hypothesis_id).confidence if self.hypothesis_graph.get(hyp.hypothesis_id) else 0,
        })

        # Phase: Verifying (inference-time compute scaling)
        self._set_phase(CyclePhase.VERIFYING)
        self._verify_with_compute_scaling(hyp, research_question)

        # Phase: Refining — spawn sub-hypotheses if needed
        self._set_phase(CyclePhase.REFINING)
        updated = self.hypothesis_graph.get(hyp.hypothesis_id)
        if updated and updated.status == HypothesisStatus.INCONCLUSIVE.value and updated.depth < self.max_depth:
            self._spawn_sub_hypotheses(updated, research_question)

    def _form_initial_hypotheses(self, research_question: str) -> None:
        """Generate initial hypotheses from the research question using LLM."""
        if self._llm:
            system = (
                "You are ZHARK, an autonomous research engine. Given a strategic "
                "question, generate 3-5 testable hypotheses that can be investigated "
                "through web research. Each hypothesis should be a clear, falsifiable "
                "claim. Output as a JSON array of strings."
            )
            prompt = f"Research Question: {research_question}\n\nGenerate 3-5 testable hypotheses:"

            prompt = self._gamma_compress(prompt)
            result = self._llm.generate(prompt, system=system, temperature=0.6, max_tokens=1024)

            if result.get("ok"):
                try:
                    output = result.get("output", "")
                    start = output.find("[")
                    end = output.rfind("]") + 1
                    if start >= 0 and end > start:
                        hypotheses = json.loads(output[start:end])
                        for h in hypotheses:
                            self.hypothesis_graph.add_hypothesis(h)
                        print(f"ZHARK: Generated {len(hypotheses)} initial hypotheses")
                        return
                except (json.JSONDecodeError, ValueError):
                    pass

        # Fallback: generate basic hypotheses
        self.hypothesis_graph.add_hypothesis(f"The primary driver of {research_question[:50]} is market demand")
        self.hypothesis_graph.add_hypothesis(f"Technology change is the key enabler for {research_question[:50]}")
        self.hypothesis_graph.add_hypothesis(f"Regulatory factors constrain options for {research_question[:50]}")
        print("ZHARK: Generated 3 fallback hypotheses")

    def _analyze_evidence(self, hyp: Hypothesis, results: List[SearchResult]) -> List[Evidence]:
        """Analyze search results and extract evidence for/against the hypothesis."""
        evidence_list: List[Evidence] = []

        if self._llm:
            # Use LLM to analyze each result
            for result in results[:5]:
                if result.error or not result.content:
                    continue

                system = (
                    "You are ZHARK's evidence analyzer. Given a hypothesis and a piece of "
                    "web content, determine: (1) Does this content support or refute the "
                    "hypothesis? (2) What is the relevance weight (0.1-1.0)? "
                    "(3) What is the key quote or finding? "
                    "Output as JSON: {supports: bool, weight: float, finding: string}"
                )
                prompt = (
                    f"Hypothesis: {hyp.statement}\n\n"
                    f"Source: {result.url}\n"
                    f"Title: {result.title}\n"
                    f"Content (truncated): {result.content[:3000]}\n\n"
                    f"Analyze this evidence:"
                )

                prompt = self._gamma_compress(prompt)
                llm_result = self._llm.generate(prompt, system=system, temperature=0.3, max_tokens=512)

                if llm_result.get("ok"):
                    try:
                        output = llm_result.get("output", "")
                        start = output.find("{")
                        end = output.rfind("}") + 1
                        if start >= 0 and end > start:
                            analysis = json.loads(output[start:end])
                            evidence_list.append(Evidence(
                                source=result.url,
                                content=analysis.get("finding", result.snippet),
                                supports=analysis.get("supports", True),
                                weight=min(1.0, max(0.1, float(analysis.get("weight", 0.5)))),
                                metadata={"title": result.title, "relevance": result.relevance},
                            ))
                            continue
                    except (json.JSONDecodeError, ValueError):
                        pass

                # Fallback for this result
                evidence_list.append(Evidence(
                    source=result.url,
                    content=result.snippet or result.content[:200],
                    supports=True,
                    weight=0.3,
                    metadata={"title": result.title, "fallback": True},
                ))
        else:
            # No LLM — use heuristic evidence from snippets
            for result in results:
                if result.error:
                    continue
                # Simple heuristic: if snippet contains hypothesis keywords
                evidence_list.append(Evidence(
                    source=result.url,
                    content=result.snippet or result.title,
                    supports=True,
                    weight=result.relevance * 0.5,
                    metadata={"title": result.title, "heuristic": True},
                ))

        return evidence_list

    def _verify_with_compute_scaling(self, hyp: Hypothesis, research_question: str) -> None:
        """Use inference-time compute scaling to verify hypothesis analysis."""
        if not self._llm:
            return

        # Generate multiple candidate analyses
        query = f"Analyze and verify: {hyp.statement} in context of: {research_question}"

        for candidate_idx in range(self.verify_candidates):
            system = (
                "You are ZHARK's verification engine. Given a hypothesis and context, "
                "provide a concise assessment of the hypothesis's validity. Consider "
                "evidence quality, potential biases, and alternative explanations. "
                "Output a confidence score (0.0-1.0) and brief reasoning."
            )
            prompt = (
                f"Hypothesis: {hyp.statement}\n"
                f"Current confidence: {hyp.confidence:.2f}\n"
                f"Evidence count: {len(hyp.evidence)}\n"
                f"Research question: {research_question}\n\n"
                f"Assessment (candidate {candidate_idx + 1}/{self.verify_candidates}):"
            )

            prompt = self._gamma_compress(prompt)
            result = self._llm.generate(prompt, system=system, temperature=0.4 + (candidate_idx * 0.1), max_tokens=512)

            if result.get("ok"):
                self.verify_buffer.submit(
                    query=query,
                    output=result.get("output", ""),
                    evidence_context=str([e.to_dict() for e in hyp.evidence[-5:]]),
                    revision=candidate_idx,
                )

        # Evaluate candidates
        evaluation = self.verify_buffer.evaluate(query)
        self._emit("verification_result", {
            "hypothesis_id": hyp.hypothesis_id,
            "status": evaluation.get("status"),
            "consensus_score": evaluation.get("consensus_score", 0),
            "should_refine": evaluation.get("should_refine", False),
        })

        # Check convergence
        convergence = self.verify_buffer.get_convergence(query)
        if convergence.get("converged"):
            self._emit("verification_converged", {
                "hypothesis_id": hyp.hypothesis_id,
                "revisions": convergence.get("revisions"),
                "latest_score": convergence.get("latest_score"),
            })

    def _spawn_sub_hypotheses(self, hyp: Hypothesis, research_question: str) -> None:
        """Spawn sub-hypotheses to investigate inconclusive findings."""
        if self._llm:
            system = (
                "You are ZHARK's hypothesis generator. Given an inconclusive hypothesis, "
                "generate 2-3 sub-hypotheses that would help resolve the uncertainty. "
                "Each should be more specific than the parent. Output as JSON array of strings."
            )
            prompt = (
                f"Parent hypothesis (inconclusive, confidence: {hyp.confidence:.2f}): {hyp.statement}\n"
                f"Research question: {research_question}\n"
                f"Evidence summary: {len(hyp.evidence)} pieces gathered\n\n"
                f"Generate 2-3 sub-hypotheses:"
            )

            prompt = self._gamma_compress(prompt)
            result = self._llm.generate(prompt, system=system, temperature=0.5, max_tokens=512)

            if result.get("ok"):
                try:
                    output = result.get("output", "")
                    start = output.find("[")
                    end = output.rfind("]") + 1
                    if start >= 0 and end > start:
                        sub_hyps = json.loads(output[start:end])
                        for sh in sub_hyps:
                            self.hypothesis_graph.add_hypothesis(sh, parent_id=hyp.hypothesis_id)
                        self._emit("sub_hypotheses_spawned", {
                            "parent_id": hyp.hypothesis_id,
                            "count": len(sub_hyps),
                        })
                        return
                except (json.JSONDecodeError, ValueError):
                    pass

        # Fallback
        self.hypothesis_graph.add_hypothesis(
            f"Specific aspect of: {hyp.statement[:40]}",
            parent_id=hyp.hypothesis_id,
        )

    def _resolve_contradictions(self, contradictions: List) -> None:
        """Attempt to resolve detected contradictions between hypotheses."""
        for h1_id, h2_id, reason in contradictions:
            h1 = self.hypothesis_graph.get(h1_id)
            h2 = self.hypothesis_graph.get(h2_id)
            if not h1 or not h2:
                continue

            # The weaker hypothesis gets superseded
            weaker = h2 if h1.confidence > h2.confidence else h1
            stronger = h1 if h1.confidence > h2.confidence else h2

            weaker.status = HypothesisStatus.SUPERSEDED.value
            self._emit("contradiction_resolved", {
                "weaker": weaker.hypothesis_id,
                "stronger": stronger.hypothesis_id,
                "reason": reason,
            })

    def _update_causal_map(self) -> None:
        """Extract causal relationships from supported hypotheses and update map."""
        supported = self.hypothesis_graph.get_supported(min_confidence=0.3)

        if self._llm and supported:
            for hyp in supported[:5]:
                system = (
                    "You are ZHARK's causal analysis engine. Given a supported hypothesis "
                    "and its evidence, extract causal relationships. Output as JSON array: "
                    "[{cause: string, effect: string, type: 'direct|mediated|inhibitor', "
                    "strength: 0.0-1.0, description: string}]"
                )
                prompt = (
                    f"Hypothesis: {hyp.statement}\n"
                    f"Confidence: {hyp.confidence:.2f}\n"
                    f"Evidence sources: {len(hyp.evidence)}\n\n"
                    f"Extract causal relationships:"
                )

                prompt = self._gamma_compress(prompt)
                result = self._llm.generate(prompt, system=system, temperature=0.3, max_tokens=1024)

                if result.get("ok"):
                    try:
                        output = result.get("output", "")
                        start = output.find("[")
                        end = output.rfind("]") + 1
                        if start >= 0 and end > start:
                            causal_claims = json.loads(output[start:end])
                            for claim in causal_claims:
                                self.causal_mapper.add_edge(
                                    source_name=claim.get("cause", ""),
                                    target_name=claim.get("effect", ""),
                                    causal_type=claim.get("type", CausalType.DIRECT.value),
                                    strength=min(1.0, max(0.0, float(claim.get("strength", 0.5)))),
                                    description=claim.get("description", ""),
                                    evidence_ref=hyp.hypothesis_id,
                                )
                    except (json.JSONDecodeError, ValueError):
                        pass

    def _check_convergence(self) -> bool:
        """Check if the research has converged enough to synthesize strategy."""
        summary = self.hypothesis_graph.summary()
        by_status = summary.get("by_status", {})

        supported = by_status.get(HypothesisStatus.SUPPORTED.value, 0)
        refuted = by_status.get(HypothesisStatus.REFUTED.value, 0)
        total = summary.get("total_hypotheses", 1)

        resolved = supported + refuted
        resolution_rate = resolved / total if total > 0 else 0

        # Converge if >70% of hypotheses are resolved
        return resolution_rate >= 0.7 and supported >= 2

    def _checkpoint(self, strategy: bool = False) -> None:
        """Save current state to SQLite for resume capability."""
        if not self._cycle_id:
            return

        hyp_path = self.output_dir / f"hyp_checkpoint_{self._cycle_id}.json"
        causal_path = self.output_dir / f"causal_checkpoint_{self._cycle_id}.json"

        self.hypothesis_graph.save(hyp_path)
        self.causal_mapper.save(causal_path)

        hyp_json = json.dumps(self.hypothesis_graph.to_dict())
        causal_json = json.dumps(self.causal_mapper.to_dict())
        strategy_json = ""
        if strategy:
            strategy_path = self.output_dir / f"strategy_{self._cycle_id}.json"
            self.strategy_synthesizer.save(strategy_path)
            strategy_json = json.dumps([o.to_dict() for o in self.strategy_synthesizer.get_options()])

        self.state.checkpoint(
            self._cycle_id, self._phase, self._iteration,
            hypothesis_graph_json=hyp_json,
            causal_map_json=causal_json,
            strategy_json=strategy_json,
        )

    def _generate_final_report(
        self,
        research_question: str,
        options: List[StrategyOption],
    ) -> Dict[str, Any]:
        """Generate and save the final research report."""
        # Save strategy report (markdown)
        report_path = self.output_dir / f"zhark_report_{self._cycle_id}.md"
        report_path.write_text(self.strategy_synthesizer.to_report("markdown"), encoding="utf-8")

        # Save full JSON report
        full_report = {
            "cycle_id": self._cycle_id,
            "research_question": research_question,
            "completed": datetime.now(timezone.utc).isoformat(),
            "iterations": self._iteration,
            "hypothesis_graph": self.hypothesis_graph.summary(),
            "causal_map": self.causal_mapper.summary(),
            "strategy_options": [o.to_dict() for o in options],
            "report_path": str(report_path),
        }

        json_path = self.output_dir / f"zhark_report_{self._cycle_id}.json"
        json_path.write_text(json.dumps(full_report, indent=2, default=str), encoding="utf-8")

        # GammaLanguage v1.1C: Wrap report in A2A-DSL frame with v1.1C opcodes
        gamma_frame = None
        if self._gamma_available:
            try:
                gamma_script = (
                    f"!STATE: 0x{hash(self._cycle_id) & 0xFF:02X}\n"
                    f"@INVARIANT: strategy_options != []\n"
                    f"@ALIGN_BOUND BOUND=16\n"
                    f"?ZHARK(research_complete, convergence={full_report.get('hypothesis_graph', {}).get('total_hypotheses', 0)})\n"
                    f"$EXEC {{\n"
                    f"  CAVEMAN_SHRINK(CTX[0], FULL);\n"
                    f"  EMIT_SIGNAL(\"zhark_done\", {self._iteration});\n"
                    f"  CP0_REG_MAP(Status, 0x0);\n"
                    f"  PSX_DMA_DISPATCH(CH1, 0x1F801090);\n"
                    f"}}\n"
                )
                gamma_frame = self._gamma.compile_gamma(gamma_script)
                gamma_frame["zhark_report"] = {
                    "cycle_id": self._cycle_id,
                    "iterations": self._iteration,
                    "strategy_count": len(options),
                }
                gamma_frame["v1_1c_features"] = {
                    "rust_ffi": gamma_frame.get("rust_ffi_features", {}).get("rust_ffi_calls", 0) > 0,
                    "cp0_reg_map": gamma_frame.get("rust_ffi_features", {}).get("cp0_reg_maps", 0) > 0,
                    "align_bound": gamma_frame.get("rust_ffi_features", {}).get("align_bounds", 0) > 0,
                    "psx_dma_dispatch": gamma_frame.get("rust_ffi_features", {}).get("psx_dma_dispatches", 0) > 0,
                    "zhark_query": gamma_frame.get("research_directives", []) != [],
                }
            except Exception:
                gamma_frame = None

        full_report["gamma_frame"] = gamma_frame
        full_report["gamma_compressed"] = self._gamma_available

        return full_report

    def _set_phase(self, phase: CyclePhase) -> None:
        self._phase = phase.value
        if self._cycle_id:
            self.state.update_phase(self._cycle_id, phase.value, self._iteration)
        print(f"ZHARK: Phase → {phase.value}")

    def _signal_handler(self, signum, frame) -> None:
        """Handle Ctrl+C / SIGTERM for graceful shutdown."""
        print(f"\nZHARK: Received signal {signum}. Stopping gracefully...")
        self._stop_event.set()
        self._running = False

    def status(self) -> Dict[str, Any]:
        """Get current orchestrator status."""
        return {
            "running": self._running,
            "cycle_id": self._cycle_id,
            "iteration": self._iteration,
            "phase": self._phase,
            "hypothesis_graph": self.hypothesis_graph.summary(),
            "causal_map": self.causal_mapper.summary(),
            "verify_buffer_size": len(self.verify_buffer._buffer),
            "gamma_enabled": self._gamma_available,
        }

    def list_cycles(self) -> List[Dict[str, Any]]:
        """List all research cycles."""
        return self.state.list_cycles()

    def resume(self, cycle_id: str, max_iterations: Optional[int] = None) -> Dict[str, Any]:
        """Resume a previous research cycle from checkpoint."""
        cycle = self.state.get_cycle(cycle_id)
        if not cycle:
            return {"ok": False, "error": f"Cycle {cycle_id} not found"}

        return self.run(
            research_question=cycle["research_question"],
            max_iterations=max_iterations,
            resume_cycle_id=cycle_id,
        )
