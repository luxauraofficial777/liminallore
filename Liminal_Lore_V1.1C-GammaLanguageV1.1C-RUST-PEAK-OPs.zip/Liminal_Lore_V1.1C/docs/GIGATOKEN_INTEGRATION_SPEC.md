# Gigatoken Integration Specification
**Version:** 1.0  
**Date:** 2026-07-25  
**Author:** Lux Aura  
**Status:** Approved — Implementation Phase

---

## 1. Overview

### 1.1 What is Gigatoken?

Gigatoken is a Rust-based BPE (Byte-Pair Encoding) tokenizer that achieves **GB/s throughput** — approximately 1000x faster than HuggingFace's `tokenizers` library and 681x faster than `tiktoken`. It supports 20+ tokenizer families including **Qwen 2/2.5** (our active model `qwen2.5-coder:7b`), Llama 3/4, GPT-2, DeepSeek V3/R1, Phi-4, and more.

- **Repo:** https://github.com/marcelroed/gigatoken
- **Install:** `pip install gigatoken`
- **License:** MIT
- **API:** Python wrapper over Rust extension (ABI3)
- **Compatibility modes:** Drop-in replacement for HuggingFace `tokenizers` and `tiktoken`

### 1.2 Why Integrate?

The Liminal Lore / VW Nexus orchestration layer currently has **no token awareness**. Token counts are estimated via `len(text) // 4` heuristic, context windows are not checked before LLM calls, and chunk boundaries are character-based rather than token-based. This leads to:

- **RAG chunking imprecision** — Chunks vary wildly in actual token count (200-800 tokens vs target 512)
- **Context window overflow** — Prompts can exceed model limits, causing truncated or failed inference
- **No prompt budgeting** — FUBBU's Router→Worker→Verifier pipeline can't partition context budgets
- **Reactive KV cache management** — TurboQuant triggers after RAM pressure, not before
- **No throughput metrics** — Colibri expert swapping has no token/s feedback signal

### 1.3 Integration Scope

Five integration points across the orchestration layer:

| # | Component | File | Priority | Impact |
|---|-----------|------|----------|--------|
| 1 | VW RAG Chunker | `vw_rag/chunker.py` | HIGH | Exact token-based chunking |
| 2 | LLM Provider | `liminal_lore_vw_deck/config/provider_abstraction.py` | HIGH | Pre-flight token counting + context budgeting |
| 3 | Colibri Bridge | `liminal_lore_vw_deck/colibri_bridge.py` | MEDIUM | Expert throughput metrics |
| 4 | TurboQuant | `liminal_lore_vw_deck/turboquant-liminal.py` | MEDIUM | Proactive KV cache prediction |
| 5 | ZHARK + FUBBU | `zhark/zhark_orchestrator.py`, `fubbu/fubbu_*.py` | MEDIUM | Prompt budget partitioning |

---

## 2. Architecture

### 2.1 New Module: `shared/token_counter.py`

A singleton-style token counting service with graceful fallback. All orchestration components import from this single module.

```
shared/
└── token_counter.py    ← New: TokenCounter class + module-level singleton
```

**Design principles:**
- **Lazy initialization** — Gigatoken is loaded on first use, not at import time
- **Graceful fallback** — If gigatoken isn't installed or fails, falls back to `len(text) // 4` heuristic
- **Model-aware** — Uses the correct tokenizer for the active model (Qwen 2.5, Llama 3, etc.)
- **Thread-safe** — Uses a lock for the lazy init path
- **Cached tokenizer** — Tokenizer instance is created once and reused

### 2.2 API

```python
class TokenCounter:
    """Token counting service with gigatoken acceleration and heuristic fallback."""

    def __init__(self, model: str = "qwen2.5-coder:7b"):
        """
        Args:
            model: Ollama model name. Mapped to gigatoken's tokenizer name.
                   Supported: qwen2.5-coder:7b → "Qwen/Qwen2.5-Coder-7B-Instruct"
                              qwen2.5-coder:14b → "Qwen/Qwen2.5-Coder-14B-Instruct"
                              llama3.1:8b → "meta-llama/Llama-3.1-8B"
                              deepseek-coder:6.7b → "deepseek-ai/deepseek-coder-6.7b-instruct"
                              gpt-4o → "Xenova/gpt-4o"
                              (fallback: len//4 heuristic)
        """

    def count(self, text: str) -> int:
        """Count tokens in a string. Returns int token count."""

    def count_batch(self, texts: list[str]) -> list[int]:
        """Count tokens in multiple strings. Returns list of ints."""

    def truncate_to_budget(self, text: str, max_tokens: int, overlap: int = 0) -> str:
        """Truncate text to fit within max_tokens. Returns truncated string."""

    def fits_in_context(self, prompt: str, system: str, max_tokens: int,
                        context_window: int) -> bool:
        """Check if prompt + system + max_tokens fits in context_window."""

    def budget_for_rag(self, query: str, system: str, max_output: int,
                       context_window: int) -> int:
        """Calculate remaining token budget for RAG context injection.
        Returns max tokens available for RAG results."""

    def split_by_tokens(self, text: str, max_tokens: int = 512,
                        overlap_tokens: int = 64) -> list[str]:
        """Split text into chunks of at most max_tokens with overlap.
        Returns list of chunk strings."""

    @property
    def available(self) -> bool:
        """True if gigatoken is loaded and operational."""

    @property
    def tokenizer_name(self) -> str:
        """The gigatoken tokenizer name in use (or 'heuristic' if fallback)."""


# Module-level singleton — lazily initialized on first use
_default_counter: TokenCounter | None = None

def get_token_counter(model: str = "qwen2.5-coder:7b") -> TokenCounter:
    """Get or create the default TokenCounter singleton."""
    global _default_counter
    if _default_counter is None or _default_counter.model != model:
        _default_counter = TokenCounter(model)
    return _default_counter

def count_tokens(text: str, model: str = "qwen2.5-coder:7b") -> int:
    """Convenience function: count tokens in text."""
    return get_token_counter(model).count(text)
```

### 2.3 Model Mapping

Gigatoken accepts HuggingFace model repo IDs. We map Ollama model names to HF repos:

```python
MODEL_MAP = {
    # Qwen family
    "qwen2.5-coder:7b":       "Qwen/Qwen2.5-Coder-7B-Instruct",
    "qwen2.5-coder:14b":      "Qwen/Qwen2.5-Coder-14B-Instruct",
    "qwen2.5-coder:32b":      "Qwen/Qwen2.5-Coder-32B-Instruct",
    "qwen2.5:7b":             "Qwen/Qwen2.5-7B-Instruct",
    "qwen2.5:14b":            "Qwen/Qwen2.5-14B-Instruct",
    "qwen3:8b":               "Qwen/Qwen3-8B",
    # DeepSeek family
    "deepseek-coder:6.7b":    "deepseek-ai/deepseek-coder-6.7b-instruct",
    "deepseek-coder:33b":     "deepseek-ai/deepseek-coder-33b-instruct",
    "deepseek-r1:7b":         "deepseek-ai/DeepSeek-R1-Distill-Qwen-7B",
    "deepseek-r1:14b":        "deepseek-ai/DeepSeek-R1-Distill-Qwen-14B",
    # Llama family
    "llama3.1:8b":            "meta-llama/Llama-3.1-8B",
    "llama3.1:70b":           "meta-llama/Llama-3.1-70B",
    "llama3.2:3b":            "meta-llama/Llama-3.2-3B",
    # Mistral
    "mistral:7b":             "mistralai/Mistral-7B-v0.3",
    # Phi
    "phi4:14b":               "microsoft/Phi-4",
    "phi3:14b":               "microsoft/Phi-3-medium-4k-instruct",
    # Gemma
    "gemma3:4b":              "google/gemma-3-4b-it",
    "gemma3:12b":             "google/gemma-3-12b-it",
    # Lux Aura custom
    "lux-architect:latest":   "Qwen/Qwen2.5-Coder-7B-Instruct",  # Qwen-based
    "nex:latest":             "Qwen/Qwen2.5-Coder-7B-Instruct",
    "nexx:latest":            "Qwen/Qwen2.5-Coder-7B-Instruct",
    "n3x:latest":             "Qwen/Qwen2.5-Coder-7B-Instruct",
}
```

### 2.4 Fallback Strategy

```
┌─────────────────────────────────────────────────────────┐
│                  TokenCounter.count()                    │
├─────────────────────────────────────────────────────────┤
│  1. Try: import gigatoken                                │
│     ├─ Success → use gt.Tokenizer(model).encode_batch()  │
│     │            (1000x faster, exact counts)            │
│     └─ Fail → fall through                               │
│                                                          │
│  2. Try: import tiktoken                                 │
│     ├─ Success → use cl100k_base encoding                │
│     │            (fast, approximate for BPE models)      │
│     └─ Fail → fall through                               │
│                                                          │
│  3. Fallback: len(text) // 4                             │
│              (crude heuristic, always available)         │
└─────────────────────────────────────────────────────────┘
```

---

## 3. Integration Points

### 3.1 VW RAG Chunker (`vw_rag/chunker.py`)

**Current state:** Chunks by character count (`_MAX_CHUNK_CHARS = 2000`, `_OVERLAP_CHARS = 256`). Token count is `len(chunk_text) // 4` — a crude estimate.

**Changes:**

1. **Import `token_counter`** at module level (lazy — doesn't load gigatoken until first chunk_file call)
2. **Replace `_split_by_size()`** with token-aware splitting:
   - `_MAX_CHUNK_TOKENS = 512` (was `_MAX_CHUNK_CHARS = 2000`)
   - `_OVERLAP_TOKENS = 64` (was `_OVERLAP_CHARS = 256`)
   - Use `token_counter.split_by_tokens()` for the actual splitting
3. **Replace `token_count=len(chunk_text) // 4`** with `token_counter.count(chunk_text)` — exact count stored in Chunk model
4. **Keep character-based boundary detection** — `_find_boundary()` still looks for newlines/sentences, but the size check is now token-based

**Before:**
```python
_MAX_CHUNK_CHARS = 2000  # ~500 tokens at ~4 chars/token
_OVERLAP_CHARS = 256     # ~64 tokens

def _split_by_size(text: str) -> List[str]:
    # Character-based splitting
    ...
```

**After:**
```python
from shared.token_counter import get_token_counter

_MAX_CHUNK_TOKENS = 512
_OVERLAP_TOKENS = 64

def _split_by_size(text: str) -> List[str]:
    tc = get_token_counter()
    if tc.available:
        return tc.split_by_tokens(text, _MAX_CHUNK_TOKENS, _OVERLAP_TOKENS)
    # Fallback: character-based (existing logic)
    ...
```

**Chunk.token_count field:**
```python
# Before:
token_count=len(chunk_text) // 4,

# After:
token_count=get_token_counter().count(chunk_text),
```

**Impact:** RAG chunks are now uniformly 512 tokens. Retrieval quality improves because BM25 and vector similarity operate on consistent-sized semantic units. The `max_bytes` budget in the retriever can be replaced with `max_tokens` for precise context window management.

### 3.2 LLM Provider (`liminal_lore_vw_deck/config/provider_abstraction.py`)

**Current state:** The `LLMProvider` class sends prompts to Ollama/OpenAI-compatible endpoints with no pre-flight token check. `max_tokens` is a fixed parameter (default 2048) that doesn't account for the prompt's own token count.

**Changes:**

1. **Add `count_tokens()` method** to `LLMProvider`:
   ```python
   def count_tokens(self, text: str) -> int:
       """Count tokens using the active model's tokenizer."""
       from shared.token_counter import get_token_counter
       return get_token_counter(self.info.model).count(text)
   ```

2. **Add `fits_in_context()` method**:
   ```python
   def fits_in_context(self, prompt: str, system: str = "",
                       max_tokens: int = 2048) -> bool:
       """Check if prompt + system + max_output fits in context window."""
       tc = get_token_counter(self.info.model)
       prompt_tokens = tc.count(prompt) + tc.count(system)
       context_window = self._get_context_window()  # from config or model default
       return prompt_tokens + max_tokens <= context_window
   ```

3. **Add `budget_for_context()` method**:
   ```python
   def budget_for_context(self, prompt: str, system: str = "",
                          max_output: int = 2048) -> int:
       """Return available token budget for RAG injection."""
       tc = get_token_counter(self.info.model)
       used = tc.count(prompt) + tc.count(system) + max_output
       context_window = self._get_context_window()
       return max(0, context_window - used)
   ```

4. **Add `_get_context_window()` helper** — returns model context window from a lookup table or config:
   ```python
   CONTEXT_WINDOWS = {
       "qwen2.5-coder:7b": 32768,
       "qwen2.5-coder:14b": 32768,
       "deepseek-coder:6.7b": 16384,
       "llama3.1:8b": 131072,
       # ...
   }
   ```

5. **Add token count to `generate()` return dict** — include `prompt_tokens` (counted locally) alongside the existing `tokens_in` (reported by Ollama):
   ```python
   return {
       "ok": True,
       "output": result.get("response", ""),
       "tokens_in": result.get("prompt_eval_count", 0),
       "tokens_out": result.get("eval_count", 0),
       "prompt_tokens_local": tc.count(prompt),  # NEW: local count
       "latency_ms": latency_ms,
       # ...
   }
   ```

**Impact:** ZHARK, FUBBU, and any component using `LLMProvider.generate()` can now check if a prompt fits before sending it, and RAG injection can be sized to exactly fill the remaining context window.

### 3.3 Colibri Bridge (`liminal_lore_vw_deck/colibri_bridge.py`)

**Current state:** Expert swapping is driven by LFRU heat scores and RAM pressure. There's no token throughput metric — the bridge doesn't know how fast an expert is processing tokens.

**Changes:**

1. **Add token throughput tracking** to `ExpertState`:
   ```python
   class ExpertState:
       # ... existing fields ...
       self.tokens_processed = 0    # total tokens processed by this expert
       self.tokens_per_second = 0.0 # rolling average throughput
   ```

2. **Update `access()` method** to record token counts:
   ```python
   def access(self, clock, token_count=0, latency_ms=0):
       # ... existing heat/access logic ...
       if token_count > 0 and latency_ms > 0:
           tps = token_count / (latency_ms / 1000)
           # Exponential moving average
           self.tokens_per_second = 0.7 * self.tokens_per_second + 0.3 * tps
           self.tokens_processed += token_count
   ```

3. **Add `/colibri/throughput` HTTP endpoint** — returns per-expert token/s metrics:
   ```json
   {
       "experts": [
           {"name": "lux-architect", "tps": 4523.1, "total_tokens": 128000},
           {"name": "nex", "tps": 3899.5, "total_tokens": 95000}
       ],
       "aggregate_tps": 8422.6
   }
   ```

4. **Use throughput in swap decisions** — When two experts have similar LFRU scores, prefer to keep the one with higher `tokens_per_second` (it's more productive per RAM MB).

**Impact:** The Colibri bridge gains a productivity signal. High-throughput experts are retained preferentially, and the VW Deck UI can display real-time token/s per expert.

### 3.4 TurboQuant (`liminal_lore_vw_deck/turboquant-liminal.py`)

**Current state:** TurboQuant triggers KV cache scaling when `ram_pct > 65%`. This is reactive — it fires after memory is already under pressure.

**Changes:**

1. **Add `predict_kv_cache_size()` function**:
   ```python
   def predict_kv_cache_size(token_count: int, model: str = "qwen2.5-coder:7b") -> float:
       """Predict KV cache memory usage in MB for a given token count.

       Rough estimate based on model architecture:
       - Qwen 2.5 Coder 7B: 28 layers, 4 KV heads, 128 head_dim, fp16
        → 2 * 28 * 4 * 128 * 2 bytes = 57,344 bytes/token = 0.055 MB/token
       """
       KV_BYTES_PER_TOKEN = {
           "qwen2.5-coder:7b": 57344,
           "deepseek-coder:6.7b": 49152,
           "llama3.1:8b": 65536,
       }
       bytes_per_token = KV_BYTES_PER_TOKEN.get(model, 57344)
       return (token_count * bytes_per_token) / (1024 * 1024)
   ```

2. **Add proactive check in `monitor_tick()`**:
   ```python
   def monitor_tick():
       mem = get_memory_snapshot()
       # ... existing reactive checks ...

       # NEW: Proactive prediction
       # If we know how many tokens are queued, predict if we'll exceed RAM
       if len(active_caches) > 0:
           from shared.token_counter import get_token_counter
           tc = get_token_counter()
           # Estimate total tokens across active caches
           estimated_kv_mb = sum(
               predict_kv_cache_size(tc.count(cache.get('pending_prompt', '')))
               for cache in active_caches.values()
               if isinstance(cache, dict) and cache.get('pending_prompt')
           )
           if mem['ram_used_gb'] * 1024 + estimated_kv_mb > mem['ram_total_gb'] * 1024 * 0.85:
               # Proactive scaling before pressure hits
               scale_kv_caches(3)
               mode = 'proactive_scale'
   ```

3. **Expose prediction via HTTP** — `GET /tq/predict?tokens=4096&model=qwen2.5-coder:7b` returns predicted KV cache MB.

**Impact:** TurboQuant can scale KV caches *before* RAM pressure hits, preventing OOM crashes during long ZHARK research cycles or FUBBU multi-iteration loops.

### 3.5 ZHARK + FUBBU Prompt Budgeting

#### 3.5.1 ZHARK (`zhark/zhark_orchestrator.py`)

**Current state:** ZHARK calls `self._llm.generate()` with fixed `max_tokens` values (512-1024) and no awareness of how much context the prompt + system message will consume.

**Changes:**

1. **Import token_counter** at the top of `zhark_orchestrator.py`
2. **Add `_budget_prompt()` helper**:
   ```python
   def _budget_prompt(self, prompt: str, system: str,
                      max_output: int = 512) -> dict:
       """Calculate token budget for an LLM call.

       Returns dict with:
         - fits: bool — whether prompt fits in context window
         - prompt_tokens: int — tokens in prompt + system
         - output_budget: int — max output tokens (reduced if needed)
         - rag_budget: int — tokens available for RAG injection
       """
       if not self._llm:
           return {"fits": True, "prompt_tokens": 0,
                   "output_budget": max_output, "rag_budget": 0}
       tc = get_token_counter()
       prompt_tokens = tc.count(prompt) + tc.count(system)
       context_window = 32768  # Qwen 2.5 Coder default
       fits = prompt_tokens + max_output <= context_window
       rag_budget = max(0, context_window - prompt_tokens - max_output)
       return {"fits": fits, "prompt_tokens": prompt_tokens,
               "output_budget": max_output, "rag_budget": rag_budget}
   ```

3. **Use in `_form_initial_hypotheses()`** — check budget before LLM call:
   ```python
   def _form_initial_hypotheses(self, research_question: str) -> None:
       if self._llm:
           system = "You are ZHARK..."
           prompt = f"Research Question: {research_question}\n\nGenerate 3-5 testable hypotheses:"

           budget = self._budget_prompt(prompt, system, max_output=1024)
           if not budget["fits"]:
               # Truncate prompt to fit
               tc = get_token_counter()
               prompt = tc.truncate_to_budget(prompt, budget["output_budget"] - 100)

           result = self._llm.generate(prompt, system=system, temperature=0.6, max_tokens=1024)
   ```

4. **Use in `_verify_with_compute_scaling()`** — partition budget across candidates:
   ```python
   def _verify_with_compute_scaling(self, hyp, research_question: str) -> None:
       if not self._llm:
           return

       # Calculate per-candidate budget
       total_budget = 512 * self.verify_candidates
       per_candidate = 512

       # If total exceeds context window, reduce per-candidate
       tc = get_token_counter()
       context_window = 32768
       prompt_base = tc.count(hyp.statement) + tc.count(research_question)
       available = context_window - prompt_base
       if available < total_budget:
           per_candidate = max(128, available // self.verify_candidates)

       for candidate_idx in range(self.verify_candidates):
           # ... existing prompt construction ...
           result = self._llm.generate(prompt, system=system,
                                        temperature=0.4 + (candidate_idx * 0.1),
                                        max_tokens=per_candidate)
   ```

#### 3.5.2 FUBBU (`fubbu/fubbu_router.py`, `fubbu/fubbu_worker.py`, `fubbu/fubbu_verifier.py`)

**Current state:** Each FUBBU component (Router, Worker, Verifier) has hardcoded `max_tokens` values:
- Router: 2048, context 8192
- Worker: 4096, context 32768
- Verifier: 1024, context 8192

No component checks if the prompt + RAG context + system message fits before calling Ollama.

**Changes:**

1. **Add `token_counter` import** to each component
2. **Add pre-flight check in `_call_ollama()`** for each component:
   ```python
   def _call_ollama(self, prompt: str, system: str = WORKER_SYSTEM_PROMPT) -> Dict[str, Any]:
       # NEW: Pre-flight token check
       from shared.token_counter import get_token_counter
       tc = get_token_counter(self.model)
       prompt_tokens = tc.count(prompt) + tc.count(system)

       if prompt_tokens + self.max_tokens > self.num_ctx:
           # Truncate prompt to fit
           available = self.num_ctx - self.max_tokens - 100  # safety margin
           prompt = tc.truncate_to_budget(prompt, available)
           print(f"FUBBU Worker: Prompt truncated from {prompt_tokens} to fit context window", flush=True)

       # ... existing Ollama call ...
   ```

3. **Router: budget RAG injection** — The Router pulls RAG chunks before building the worker prompt. Use token counting to determine how many RAG chunks fit:
   ```python
   # In fubbu_router.py route() method:
   if self.rag_enabled:
       tc = get_token_counter(self.model)
       system_tokens = tc.count(ROUTER_SYSTEM_PROMPT)
       task_tokens = tc.count(task_description)
       output_budget = self.max_tokens
       available = self.num_ctx - system_tokens - task_tokens - output_budget

       # Fetch RAG results up to available token budget
       rag_results = self._rag_query(task_description, max_tokens=available)
   ```

4. **Verifier: track token throughput** — Record tokens processed per verification for Colibri metrics:
   ```python
   # After successful verification:
   result = self._call_ollama(prompt, system=VERIFIER_SYSTEM_PROMPT)
   if result.get("ok"):
       tokens = result.get("tokens_in", 0) + result.get("tokens_out", 0)
       latency = result.get("latency_ms", 0)
       # Report to Colibri bridge
       self._report_throughput(tokens, latency)
   ```

**Impact:** FUBBU's three-stage pipeline becomes token-aware. RAG injection is sized to fit the context window exactly. Prompts that would overflow are truncated intelligently instead of causing Ollama errors or silent truncation.

---

## 4. Data Flow

```
                    ┌──────────────────────┐
                    │  shared/token_counter │
                    │  (gigatoken + fallback)│
                    └──────────┬───────────┘
                               │
         ┌─────────────────────┼─────────────────────┐
         │                     │                     │
         ▼                     ▼                     ▼
   ┌──────────┐      ┌──────────────┐      ┌──────────────┐
   │ vw_rag/  │      │ provider_    │      │ colibri_     │
   │ chunker  │      │ abstraction  │      │ bridge       │
   │          │      │              │      │              │
   │ split_by │      │ count_tokens │      │ throughput   │
   │ tokens() │      │ fits_in_ctx  │      │ tracking     │
   │ count()  │      │ budget_for   │      │ swap weight  │
   └──────────┘      └──────┬───────┘      └──────────────┘
                            │
              ┌─────────────┼─────────────┐
              │             │             │
              ▼             ▼             ▼
        ┌──────────┐  ┌──────────┐  ┌──────────────┐
        │ turboquant│  │ zhark    │  │ fubbu        │
        │          │  │          │  │ router/worker│
        │ predict  │  │ budget   │  │ /verifier    │
        │ kv_cache │  │ prompt   │  │              │
        │ size     │  │ truncate │  │ pre-flight   │
        │          │  │ verify   │  │ check        │
        └──────────┘  │ candidates│  │ RAG budget   │
                      └──────────┘  └──────────────┘
```

---

## 5. Configuration

### 5.1 .env additions

```env
# Gigatoken (optional — falls back to heuristic if not installed)
GIGATOKEN_ENABLED=true
GIGATOKEN_MODEL=Qwen/Qwen2.5-Coder-7B-Instruct
```

### 5.2 liminal_lore.yaml additions

```yaml
# Token counting
token_counter:
  enabled: true
  provider: gigatoken          # gigatoken | tiktoken | heuristic
  default_model: "qwen2.5-coder:7b"
  cache_tokenizers: true       # cache tokenizer instances

  # Context windows per model (tokens)
  context_windows:
    qwen2.5-coder:7b: 32768
    qwen2.5-coder:14b: 32768
    deepseek-coder:6.7b: 16384
    llama3.1:8b: 131072
    default: 8192
```

### 5.3 pyproject.toml additions

```toml
[project.optional-dependencies]
tokenizer = ["gigatoken>=0.1.0"]
```

---

## 6. Testing Plan

### 6.1 Unit Tests (`shared/test_token_counter.py`)

- `test_count_basic` — Count tokens in a known string, verify result > 0
- `test_count_batch` — Batch counting matches individual counts
- `test_truncate_to_budget` — Truncated text has <= max_tokens
- `test_fits_in_context` — Correct boolean for fitting/overflowing prompts
- `test_split_by_tokens` — Chunks respect max_tokens and overlap
- `test_fallback_heuristic` — When gigatoken unavailable, still returns int
- `test_model_mapping` — Ollama model names map to HF repo IDs
- `test_unknown_model_fallback` — Unknown model uses heuristic

### 6.2 Integration Tests

- **RAG:** Index a test file, verify chunks have uniform token counts (±10% of target)
- **Provider:** Call `count_tokens()` through `LLMProvider`, compare with Ollama's `prompt_eval_count`
- **ZHARK:** Run a research cycle, verify no context window overflow errors
- **FUBBU:** Submit a task with large RAG context, verify prompt is truncated to fit

### 6.3 Benchmark

```powershell
# Compare gigatoken vs heuristic on a 1MB text file
python -c "
from shared.token_counter import get_token_counter
import time

tc = get_token_counter('qwen2.5-coder:7b')
text = open('test_data.txt').read()

start = time.perf_counter()
count = tc.count(text)
elapsed = time.perf_counter() - start

print(f'Tokens: {count}')
print(f'Time: {elapsed*1000:.1f}ms')
print(f'Throughput: {len(text)/elapsed/1e6:.1f} MB/s')
print(f'Provider: {tc.tokenizer_name}')
"
```

---

## 7. Windows Compatibility

Gigatoken's README notes: "Windows has not been tested much, so for now prefer using WSL."

**Mitigation strategy:**
1. Attempt `pip install gigatoken` on native Windows first
2. If the Rust extension fails to build/load, the `TokenCounter` class automatically falls back to `tiktoken` (if installed) or the `len//4` heuristic
3. All integration points check `token_counter.available` before relying on gigatoken-specific features
4. The `split_by_tokens()` method has a character-based fallback that produces equivalent results (just less precise)

**Fallback chain:** `gigatoken` → `tiktoken` → `len(text) // 4`

---

## 8. Implementation Order

| Step | Component | Est. Lines Changed | Dependencies |
|------|-----------|-------------------|--------------|
| 1 | `shared/token_counter.py` | ~200 new | None |
| 2 | `vw_rag/chunker.py` | ~30 modified | Step 1 |
| 3 | `provider_abstraction.py` | ~50 added | Step 1 |
| 4 | `colibri_bridge.py` | ~40 added | Step 1 |
| 5 | `turboquant-liminal.py` | ~30 added | Step 1 |
| 6 | `zhark_orchestrator.py` | ~40 modified | Steps 1, 3 |
| 7 | `fubbu/fubbu_*.py` | ~60 modified | Steps 1, 3 |
| 8 | `.env` + `liminal_lore.yaml` | ~15 added | — |
| 9 | `pyproject.toml` | ~3 added | — |
| 10 | Tests + benchmark | ~100 new | Steps 1-7 |

**Total:** ~570 lines (200 new, 370 modified)

---

## 9. Rollback Plan

The V100B backup at `tools/Liminal_Lore_V100B/` contains the pre-integration source. To rollback:

1. `git checkout` individual files if using version control
2. Or copy from `Liminal_Lore_V100B/` back to `liminal_lore_vw_deck/` and `orchestration/`
3. Remove `shared/token_counter.py`
4. Set `GIGATOKEN_ENABLED=false` in `.env` — all components fall back to heuristic

The integration is designed to be **non-breaking** — every component has a fallback path that preserves existing behavior when gigatoken is unavailable.

---

## 10. Future Extensions

- **Fine-tuning support** — Use gigatoken's `train_bpe()` to train a custom tokenizer on VoidWalkers codebase + study notes
- **Token-level RAG** — Index at token granularity instead of chunk granularity for sub-chunk retrieval
- **Streaming token counting** — Count tokens in real-time as LLM streams output, for live throughput display in VW Deck UI
- **Multi-tokenizer committee** — When FUBBU uses different models for Router/Worker/Verifier, each gets its own tokenizer instance
- **Cost prediction** — Estimate inference cost based on token count before sending to cloud providers (OpenRouter)

---

*Lux Aura — https://github.com/LuxAura*
