# Liminal Lore V1.1C — GammaLanguage Enhanced

> **Liminal Lore** is a self-hosted, agentic game development suite with multi-agent
> orchestration, local LLM inference, and pipeline automation. V1.1C adds full
> GammaLanguage v1.1C (A2A-DSL) integration across all subsystems.

## What's New in V1.1C

### GammaLanguage v1.1C Integration
- **Full A2A-DSL compatibility** across FUBBU, ZHARK, VW Nexus, and the C++ Deck host
- **Caveman prompt compression** on all LLM call sites (FUBBU Router, Worker, Verifier; ZHARK Orchestrator)
- **TurboQuant capacity checks** before inference in FUBBU Worker
- **Directive routing** — `?ZHARK` and `¿FUBBU` sigils routed via VW Nexus WebSocket bus
- **Gamma frame output** — all subsystems wrap outputs in A2A-DSL AST frames with v1.1C opcodes
- **New v1.1C opcodes**: `RUST_OFFSET_LOAD`, `RUST_FFI_CALL`, `ALIGN_BOUND`, `CP0_REG_MAP`, `PSX_DMA_DISPATCH`
- **Hive partitions** — `#HIVE`-based RAG routing on the Nexus WebSocket bus
- **Feature reporting** — `get_stats()` across all subsystems reports `gamma_v1_1c` feature flags

### Setup Wizard Updates
- **Step 5c: GammaLanguage v1.1C** — interactive prompt for gamma features
- **Gamma env vars**: `GAMMA_ENABLED`, `GAMMA_CAVEMAN_COMPRESS`, `GAMMA_TURBOQUANT_CHECK`, `GAMMA_FRAME_OUTPUT`, `GAMMA_DIRECTIVE_ROUTING`
- **Shipping manifest** now checks FUBBU Sidecar and GammaLanguage as components 5 and 6
- **Config loader** includes `gamma` section in defaults, YAML template, and export template

### Gigatoken Integration (from V101A)
- **Shared token counter** (`shared/token_counter.py`) with gigatoken → tiktoken → heuristic fallback chain
- **Exact token counting** across all components: RAG chunker, LLM provider, Colibri bridge, TurboQuant, ZHARK, FUBBU
- **Pre-flight token checks** in FUBBU Worker, Router, and Verifier with automatic prompt truncation
- **KV cache prediction** in TurboQuant based on token counts
- **Throughput-aware expert swapping** in Colibri Bridge

### GUI Tabs (from V101A)
- **ZHARK Tab**: Autonomous research orchestrator panel
- **Global Telemetry Tab**: System health dashboard

## Directory Structure

```
Liminal_Lore_V1.1B/
├── README.md                          # This file
├── CHANGELOG_V1.1C.md                 # V1.1C changelog
├── WHATS_NEW_V1.1C.md                 # V1.1C feature highlights
├── versions_log.md                    # Full version history
├── GAMMA_INTEGRATION_BLUEPRINT.md     # GammaLanguage v1.1C integration blueprint
├── docs/
│   └── GIGATOKEN_INTEGRATION_SPEC.md  # Full gigatoken integration specification
├── shared/
│   └── token_counter.py               # Shared token counter (gigatoken → tiktoken → heuristic)
├── liminal_lore_vw_deck/              # Main Liminal Lore application
│   ├── VoidWalkers_Chat_GUI.html      # Web portal GUI (v1.1C with ZHARK + Telemetry tabs)
│   ├── VoidWalkers_Suite.html         # Electron suite HTML
│   ├── hermes-bridge.js               # Hermes API bridge server
│   ├── colibri_bridge.py              # Colibri expert streaming bridge
│   ├── turboquant-liminal.py          # TurboQuant KV cache manager
│   ├── vw_nexus_service.py            # VW Nexus HTTP service
│   ├── vw_deck.cpp                    # Native Win32 deck host
│   ├── vw_deck.config.json            # Deck configuration (v1.1C + gamma fields)
│   ├── liminal_settings.json          # FS service settings
│   ├── SETUP_GUIDE.md                 # Setup & extension guide
│   ├── gamma/                         # GammaLanguage C++ header
│   │   └── A2A_Gamma.h                # A2A-DSL interpreter (v1.1C opcodes)
│   ├── config/                        # Configuration package
│   │   ├── config_loader.py           # Layered config loader (with gamma section)
│   │   ├── provider_abstraction.py    # LLM provider abstraction
│   │   ├── setup_wizard.py            # Interactive setup wizard (with gamma step)
│   │   └── __init__.py
│   ├── electron/                      # Electron desktop wrapper
│   ├── colibri/                       # Colibri C/Rust core
│   ├── scripts/                       # Utility scripts
│   └── data/                          # Runtime data
├── vw_nexus/                          # VW Nexus agent orchestration (v1.1C directive routing)
├── vw_rag/                            # RAG engine (FTS5 + vector search)
├── zhark/                             # ZHARK autonomous research orchestrator (v1.1C gamma)
├── fubbu/                             # FUBBU router-worker-verifier system (v1.1C gamma)
└── docs/                              # Documentation
```

## Key Ports

| Service         | Port  | Protocol |
|-----------------|-------|----------|
| Hermes Bridge   | 8643  | HTTP     |
| TurboQuant      | 8646  | HTTP     |
| Colibri Bridge  | 8648  | HTTP     |
| VW Nexus        | 8651  | HTTP     |
| VW Nexus WS     | 8652  | WebSocket|

## Quick Start

1. **Install dependencies**:
   ```powershell
   pip install gigatoken tiktoken
   ```

2. **Run the setup wizard** (includes GammaLanguage v1.1C configuration):
   ```powershell
   cd liminal_lore_vw_deck
   python -m config.setup_wizard
   ```

3. **Start the Hermes bridge**:
   ```powershell
   cd liminal_lore_vw_deck
   node hermes-bridge.js
   ```

4. **Open the GUI**:
   Navigate to `http://127.0.0.1:8643` in your browser

## GammaLanguage v1.1C Integration Points

| Component         | Integration                                      |
|-------------------|--------------------------------------------------|
| FUBBU Worker      | Caveman compress, TurboQuant check, ¿FUBBU directive, gamma frame output |
| FUBBU Router      | Caveman compress on router model prompts          |
| FUBBU Verifier    | Caveman compress on verifier model prompts        |
| ZHARK Orchestrator| Caveman compress on all 5 LLM call sites, ?ZHARK directive, gamma frame report |
| VW Nexus WebSocket| Directive routing (?ZHARK / ¿FUBBU), #HIVE partitions, gamma frame encode/decode |
| C++ Deck Host     | A2A_Gamma.h interpreter with v1.1C opcodes        |
| Config Loader     | `gamma` config section with env var overrides     |
| Setup Wizard      | Step 5c: Interactive gamma feature configuration  |

## Gigatoken Integration Points

| Component         | Integration                                      |
|-------------------|--------------------------------------------------|
| RAG Chunker       | Token-based chunking replaces char-based         |
| LLM Provider      | `count_tokens`, `fits_in_context`, `budget_for_context` |
| Colibri Bridge    | Throughput tracking, throughput-aware swaps      |
| TurboQuant        | KV cache prediction from token counts            |
| ZHARK             | Prompt budgeting with `_budget_prompt`           |
| FUBBU Worker      | Pre-flight token check + prompt truncation       |
| FUBBU Router      | Pre-flight token check + prompt truncation       |
| FUBBU Verifier    | Pre-flight token check + prompt truncation       |

## Token Counter Fallback Chain

```
gigatoken (Rust, fastest)
    ↓ (if unavailable)
tiktoken (Python, BPE)
    ↓ (if unavailable)
heuristic (len(text) // 4)
```

## License

Proprietary — VoidWalkers Project
