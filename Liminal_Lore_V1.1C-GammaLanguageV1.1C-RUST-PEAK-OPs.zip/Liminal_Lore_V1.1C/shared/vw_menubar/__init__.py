"""
vw_menubar — Shared menu bar for the Void Walkers toolchain.

Public API:
    VWCommandBus              singleton command registry / event bus
    VWCommand                 canonical command enum
    VWMenuBar                 reusable QMenuBar
    VWMainWindow              drop-in QMainWindow wrapper
    VWToolCapabilities        feature flags for graceful degradation
    VWStorageMiddleware       filesystem/cloud/database abstraction
    LocalFileStorageProvider  default local disk provider
    CloudStorageProvider      cloud object storage contract
    DatabaseStorageProvider   shared database contract
    VWStorageContext          uniform payload for Open/Save/Save As
    VWThemeRegistry           global dark/light token set

Example:
    from vw_menubar import (
        VWCommandBus, VWMenuBar, VWMainWindow,
        VWToolCapabilities, VWStorageMiddleware, LocalFileStorageProvider,
    )

    bus = VWCommandBus()
    mw = VWStorageMiddleware()
    mw.register_provider("local", LocalFileStorageProvider())

    bus.register_capabilities(VWToolCapabilities(can_save=True))
    bus.register_save_handler(lambda ctx: mw.save(ctx.path, data={"x": 1}))

    window = VWMainWindow("My Tool", central_widget=MyCanvas())
"""
from __future__ import annotations

from ._qt_compat import QT_BINDING
from .command_bus import (
    VWCommandBus,
    VWCommandDisabledError,
    VWCommandError,
    VWCommandNotRegisteredError,
)
from .main_window import VWMainWindow
from .menu_bar import VWMenuBar
from .storage_middleware import (
    CloudStorageProvider,
    DatabaseStorageProvider,
    LocalFileStorageProvider,
    VWStorageMiddleware,
    VWStorageProvider,
)
from .theme import VWTheme, VWThemeRegistry
from .types import VWCommand, VWStorageContext, VWToolCapabilities

__version__ = "1.0.0"

__all__ = [
    "QT_BINDING",
    "VWCommand",
    "VWCommandBus",
    "VWCommandDisabledError",
    "VWCommandError",
    "VWCommandNotRegisteredError",
    "VWMainWindow",
    "VWMenuBar",
    "VWStorageContext",
    "VWStorageMiddleware",
    "VWStorageProvider",
    "LocalFileStorageProvider",
    "CloudStorageProvider",
    "DatabaseStorageProvider",
    "VWTheme",
    "VWThemeRegistry",
    "VWToolCapabilities",
    "__version__",
]
