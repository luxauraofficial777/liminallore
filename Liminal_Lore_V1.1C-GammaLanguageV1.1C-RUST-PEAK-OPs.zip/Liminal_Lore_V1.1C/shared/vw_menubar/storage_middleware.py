"""
Storage abstraction layer for Open/Save/Save As handlers.

Tools often need to read/write from one of several backends:
  - local filesystem (the default for desktop tools)
  - cloud object storage (S3, Azure Blob, GCS)
  - a shared database / project API

VWStorageMiddleware lets each tool register the backends it supports and then
invoke them through a single uniform API. The menu bar never hardcodes the
storage details; it only triggers the registered handler.
"""
from __future__ import annotations

import json
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from ._qt_compat import QFileDialog
from .types import VWStorageContext


class VWStorageProvider(ABC):
    """Base class for all storage backends."""

    @abstractmethod
    def open(self, ctx: VWStorageContext) -> Any:
        """Read from the backend and return a Python object."""
        ...

    @abstractmethod
    def save(self, ctx: VWStorageContext) -> dict[str, Any]:
        """Write the payload to the backend and return a result summary."""
        ...

    @abstractmethod
    def exists(self, ctx: VWStorageContext) -> bool:
        """Return True if the resource already exists."""
        ...


class LocalFileStorageProvider(VWStorageProvider):
    """
    Default provider for reading/writing JSON/text/binary files on disk.

    The data field in the context is expected to be serializable bytes or dict.
    """

    def open(self, ctx: VWStorageContext) -> Any:
        path = Path(ctx.path)
        if not path.exists():
            raise FileNotFoundError(f"Local file not found: {path}")
        if ctx.metadata.get("binary", False):
            return path.read_bytes()
        text = path.read_text(encoding="utf-8")
        if ctx.metadata.get("format", "json") == "json":
            return json.loads(text)
        return text

    def save(self, ctx: VWStorageContext) -> dict[str, Any]:
        path = Path(ctx.path)
        path.parent.mkdir(parents=True, exist_ok=True)
        data = ctx.data
        if ctx.metadata.get("binary", False):
            if not isinstance(data, bytes):
                raise TypeError("Binary save requires bytes payload")
            path.write_bytes(data)
        else:
            if ctx.metadata.get("format", "json") == "json":
                text = json.dumps(data, indent=2, ensure_ascii=False)
            else:
                text = str(data)
            path.write_text(text, encoding="utf-8")
        return {"provider": "local", "path": str(path), "bytes": path.stat().st_size}

    def exists(self, ctx: VWStorageContext) -> bool:
        return Path(ctx.path).exists()


class CloudStorageProvider(VWStorageProvider):
    """
    Placeholder provider for cloud object storage (S3, Azure Blob, GCS).

    Implementations can inject the actual boto3 / azure-storage-blob / google-cloud-storage
    client via the constructor. This class demonstrates the contract.
    """

    def __init__(self, bucket: str, client: Any | None = None) -> None:
        self.bucket = bucket
        self.client = client

    def open(self, ctx: VWStorageContext) -> Any:
        if self.client is None:
            raise RuntimeError("Cloud storage client not configured")
        # Example: key = ctx.path, fetch object from self.bucket
        raise NotImplementedError("Cloud open() must be implemented per provider")

    def save(self, ctx: VWStorageContext) -> dict[str, Any]:
        if self.client is None:
            raise RuntimeError("Cloud storage client not configured")
        raise NotImplementedError("Cloud save() must be implemented per provider")

    def exists(self, ctx: VWStorageContext) -> bool:
        if self.client is None:
            return False
        raise NotImplementedError("Cloud exists() must be implemented per provider")


class DatabaseStorageProvider(VWStorageProvider):
    """
    Placeholder provider for a shared project database.

    `ctx.path` is treated as a record identifier (e.g., "assets/project_123").
    `ctx.data` is the serialized payload to upsert.
    """

    def __init__(self, connection: Any | None = None) -> None:
        self.connection = connection

    def open(self, ctx: VWStorageContext) -> Any:
        if self.connection is None:
            raise RuntimeError("Database connection not configured")
        record_id = ctx.path
        # Example: SELECT data FROM project_records WHERE id = record_id
        raise NotImplementedError("Database open() must be implemented per provider")

    def save(self, ctx: VWStorageContext) -> dict[str, Any]:
        if self.connection is None:
            raise RuntimeError("Database connection not configured")
        record_id = ctx.path
        # Example: UPSERT project_records (id, data) VALUES (record_id, ctx.data)
        raise NotImplementedError("Database save() must be implemented per provider")

    def exists(self, ctx: VWStorageContext) -> bool:
        if self.connection is None:
            return False
        raise NotImplementedError("Database exists() must be implemented per provider")


class VWStorageMiddleware:
    """
    Central coordinator for storage backends.

    Usage:
        mw = VWStorageMiddleware()
        mw.register_provider("local", LocalFileStorageProvider())
        mw.register_provider("s3", CloudStorageProvider("vw-assets"))
        mw.set_default_provider("local")

        # Inside a save handler:
        result = mw.save("/path/to/project.json", data={"foo": "bar"})
    """

    def __init__(self, default_provider: str = "local") -> None:
        self._providers: dict[str, VWStorageProvider] = {}
        self._default_provider = default_provider

    def register_provider(self, name: str, provider: VWStorageProvider) -> None:
        self._providers[name] = provider

    def set_default_provider(self, name: str) -> None:
        if name not in self._providers:
            raise ValueError(f"Provider '{name}' is not registered.")
        self._default_provider = name

    def get_default_provider(self) -> str:
        return self._default_provider

    def _provider(self, name: str | None) -> VWStorageProvider:
        provider_name = name or self._default_provider
        provider = self._providers.get(provider_name)
        if provider is None:
            raise ValueError(
                f"Storage provider '{provider_name}' is not registered. "
                f"Registered providers: {list(self._providers)}"
            )
        return provider

    def open(self, path: str, provider: str | None = None) -> Any:
        ctx = VWStorageContext(provider=provider or self._default_provider, path=path)
        return self._provider(provider).open(ctx)

    def save(
        self,
        path: str,
        data: Any,
        provider: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        ctx = VWStorageContext(
            provider=provider or self._default_provider,
            path=path,
            data=data,
            metadata=metadata or {},
        )
        return self._provider(provider).save(ctx)

    def exists(self, path: str, provider: str | None = None) -> bool:
        ctx = VWStorageContext(provider=provider or self._default_provider, path=path)
        return self._provider(provider).exists(ctx)

    def pick_local_path(
        self,
        parent: Any,
        title: str = "Open",
        filter_: str = "All Files (*)",
        save: bool = False,
    ) -> str | None:
        """Convenience wrapper around QFileDialog for local file selection."""
        if save:
            path, _ = QFileDialog.getSaveFileName(parent, title, "", filter_)
        else:
            path, _ = QFileDialog.getOpenFileName(parent, title, "", filter_)
        return path or None
