"""
Global theme tokens for the Void Walkers toolchain.

All values are plain CSS-like strings so they can be applied to both PyQt6
and PySide6 widgets without any binding-specific code.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal


@dataclass(frozen=True)
class VWTheme:
    """Complete color + typography token set for the menu bar."""
    name: str
    background: str
    foreground: str
    accent: str
    menu_background: str
    menu_foreground: str
    menu_hover: str
    menu_separator: str
    disabled: str
    border: str
    font_family: str
    font_size: str
    font_size_small: str
    padding_menu: str
    padding_item: str
    border_radius: str


class VWThemeRegistry:
    """Factory and registry for the active theme."""

    DARK = VWTheme(
        name="dark",
        background="#1e1e1e",
        foreground="#e0e0e0",
        accent="#4a9eff",
        menu_background="#2d2d2d",
        menu_foreground="#e0e0e0",
        menu_hover="#3a3a3a",
        menu_separator="#3c3c3c",
        disabled="#666666",
        border="#3c3c3c",
        font_family="Segoe UI, Roboto, Helvetica, sans-serif",
        font_size="13px",
        font_size_small="12px",
        padding_menu="4px",
        padding_item="6px 12px",
        border_radius="4px",
    )

    LIGHT = VWTheme(
        name="light",
        background="#f3f3f3",
        foreground="#1e1e1e",
        accent="#0066cc",
        menu_background="#ffffff",
        menu_foreground="#1e1e1e",
        menu_hover="#e5f1ff",
        menu_separator="#d4d4d4",
        disabled="#a0a0a0",
        border="#d4d4d4",
        font_family="Segoe UI, Roboto, Helvetica, sans-serif",
        font_size="13px",
        font_size_small="12px",
        padding_menu="4px",
        padding_item="6px 12px",
        border_radius="4px",
    )

    _current: VWTheme = DARK

    @classmethod
    def get(cls) -> VWTheme:
        return cls._current

    @classmethod
    def set(cls, name: Literal["dark", "light"]) -> None:
        if name == "light":
            cls._current = cls.LIGHT
        elif name == "dark":
            cls._current = cls.DARK
        else:
            raise ValueError(f"Unknown theme '{name}'. Use 'dark' or 'light'.")

    @classmethod
    def stylesheet(cls) -> str:
        """Return a QMenuBar / QMenu stylesheet generated from the active theme."""
        t = cls._current
        return f"""
        /* Shared menu bar styling */
        QMenuBar {{
            background-color: {t.menu_background};
            color: {t.menu_foreground};
            font-family: {t.font_family};
            font-size: {t.font_size};
            border-bottom: 1px solid {t.border};
            padding: 2px;
        }}
        QMenuBar::item {{
            background: transparent;
            padding: {t.padding_item};
            margin: 2px;
            border-radius: {t.border_radius};
        }}
        QMenuBar::item:selected,
        QMenuBar::item:pressed {{
            background-color: {t.menu_hover};
        }}
        QMenuBar::item:disabled {{
            color: {t.disabled};
        }}
        QMenu {{
            background-color: {t.menu_background};
            color: {t.menu_foreground};
            border: 1px solid {t.border};
            padding: {t.padding_menu};
            font-family: {t.font_family};
            font-size: {t.font_size};
        }}
        QMenu::item {{
            padding: {t.padding_item};
            border-radius: {t.border_radius};
        }}
        QMenu::item:selected {{
            background-color: {t.menu_hover};
        }}
        QMenu::item:disabled {{
            color: {t.disabled};
        }}
        QMenu::separator {{
            height: 1px;
            background-color: {t.menu_separator};
            margin: 4px 8px;
        }}
        """

    @classmethod
    def apply_to_application(cls, app: Any) -> None:
        """Apply the active theme stylesheet to the whole QApplication."""
        app.setStyleSheet(cls.stylesheet())
