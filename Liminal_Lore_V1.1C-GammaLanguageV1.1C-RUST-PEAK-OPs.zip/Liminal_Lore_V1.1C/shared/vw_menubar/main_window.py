"""
Top-level layout wrapper for Void Walkers tools.

VWMainWindow is a drop-in replacement for QMainWindow. It attaches the
standard menu bar and wires a minimal status bar by default. Existing tools can
continue to use their own QMainWindow and simply call `setMenuBar(VWMenuBar(self))`.
"""
from __future__ import annotations

from typing import Any

from ._qt_compat import QMainWindow, QStatusBar
from .command_bus import VWCommandBus
from .menu_bar import VWMenuBar
from .theme import VWThemeRegistry
from .types import VWToolCapabilities


class VWMainWindow(QMainWindow):
    """
    Base main window for the toolchain.

    Parameters:
        title:        window title (defaults to "Void Walkers Tool").
        capabilities: feature flags that drive menu enabled/disabled states.
        central_widget: the primary widget to set as central widget.
        parent:       parent widget, if any.
    """

    def __init__(
        self,
        title: str = "Void Walkers Tool",
        capabilities: VWToolCapabilities | None = None,
        central_widget: Any | None = None,
        parent: Any | None = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(1400, 900)

        self._bus = VWCommandBus()
        self._capabilities = capabilities or VWToolCapabilities()
        self._bus.register_capabilities(self._capabilities)

        self._menu_bar = VWMenuBar(self)
        self.setMenuBar(self._menu_bar)

        self._status_bar = QStatusBar()
        self.setStatusBar(self._status_bar)
        self._status_bar.showMessage("Ready")

        if central_widget is not None:
            self.setCentralWidget(central_widget)

        self.setStyleSheet(VWThemeRegistry.stylesheet())

    def capabilities(self) -> VWToolCapabilities:
        return self._capabilities

    def set_capabilities(self, capabilities: VWToolCapabilities) -> None:
        self._capabilities = capabilities
        self._bus.register_capabilities(capabilities)
        self._menu_bar.refresh()

    def refresh_menu(self) -> None:
        """Call this after registering handlers at runtime."""
        self._menu_bar.refresh()
