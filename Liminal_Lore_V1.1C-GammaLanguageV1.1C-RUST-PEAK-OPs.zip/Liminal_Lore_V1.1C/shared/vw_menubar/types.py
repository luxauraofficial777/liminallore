"""
Shared data types for vw_menubar.

These dataclasses are binding-agnostic so they can be consumed by any tool
regardless of whether it uses PyQt6 or PySide6.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable


class VWCommand(str, Enum):
    """Canonical command names emitted by the standard menu bar."""
    FILE_OPEN = "file.open"
    FILE_SAVE = "file.save"
    FILE_SAVE_AS = "file.save_as"
    FILE_EXIT = "file.exit"
    EDIT_UNDO = "edit.undo"
    EDIT_REDO = "edit.redo"
    EDIT_CUT = "edit.cut"
    EDIT_COPY = "edit.copy"
    EDIT_PASTE = "edit.paste"
    EDIT_PREFERENCES = "edit.preferences"
    SELECT_ALL = "select.all"
    SELECT_NONE = "select.none"
    SELECT_INVERT = "select.invert"
    VIEW_ZOOM_IN = "view.zoom_in"
    VIEW_ZOOM_OUT = "view.zoom_out"
    VIEW_RESET = "view.reset"
    VIEW_FULLSCREEN = "view.fullscreen"
    HELP_ABOUT = "help.about"
    HELP_DOCS = "help.docs"


@dataclass
class VWStorageContext:
    """
    Uniform payload passed into every Open/Save/Save As handler.

    The menu bar is intentionally storage-agnostic: it only knows which
    provider is active (local, cloud, database) and the target path. The
    attached handler decides how to serialize the tool's workspace data.
    """
    provider: str
    path: str
    data: Any | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def with_data(self, data: Any) -> VWStorageContext:
        """Return a new context with the given data payload."""
        return VWStorageContext(
            provider=self.provider,
            path=self.path,
            data=data,
            metadata=self.metadata,
        )


@dataclass
class VWToolCapabilities:
    """
    Feature flags for a tool. Used to disable menu items that do not apply.

    Example: a read-only dashboard would pass can_save=False, can_save_as=False.
    """
    can_open: bool = True
    can_save: bool = True
    can_save_as: bool = True
    can_undo: bool = False
    can_redo: bool = False
    can_cut: bool = False
    can_copy: bool = False
    can_paste: bool = False
    can_select_all: bool = False
    can_select_none: bool = False
    can_select_invert: bool = False
    can_zoom_in: bool = False
    can_zoom_out: bool = False
    can_reset_view: bool = False
    can_toggle_fullscreen: bool = True
    can_preferences: bool = True
    can_help_about: bool = True
    can_help_docs: bool = True


@dataclass
class VWHandlerRegistration:
    """Internal pairing of a capability flag and a command."""
    command: VWCommand
    capability_flag: str
    default_callback: Callable | None = None


HandlerSignature = Callable[..., Any]
