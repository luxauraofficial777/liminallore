"""
Standardized menu bar for the entire Void Walkers toolchain.

Menu structure:
    File   -> Open, Save, Save As, Exit
    Edit   -> Undo, Redo, Cut, Copy, Paste, Preferences
    Select -> All, None, Invert
    View   -> Zoom In, Zoom Out, Reset, Full Screen
    Help   -> Documentation, About
"""
from __future__ import annotations

from typing import Any

from ._qt_compat import QAction, QKeySequence, QMenu, QMenuBar, QMessageBox
from .command_bus import VWCommandBus, VWCommandError
from .theme import VWThemeRegistry
from .types import VWCommand, VWToolCapabilities


class VWMenuBar(QMenuBar):
    """
    A reusable, standard menu bar for any Void Walkers tool.

    The menu bar is intentionally dumb: it only knows how to trigger commands
    on the global command bus. Each tool registers its own handlers and
    capabilities before (or after) the menu bar is instantiated.
    """

    def __init__(self, parent: Any | None = None) -> None:
        super().__init__(parent)
        self._bus = VWCommandBus()
        self._actions: dict[str, QAction] = {}
        self.setStyleSheet(VWThemeRegistry.stylesheet())
        self._build_menus()
        self.refresh()

    def set_capabilities(self, capabilities: VWToolCapabilities) -> None:
        """Update the command bus capabilities and refresh item states."""
        self._bus.register_capabilities(capabilities)
        self.refresh()

    def refresh(self) -> None:
        """Re-evaluate enabled/disabled state for every managed action."""
        for command, action in self._actions.items():
            if command == VWCommand.FILE_EXIT:
                action.setEnabled(True)
                continue
            action.setEnabled(self._bus.is_enabled(command))

    def _build_menus(self) -> None:
        self._build_file_menu()
        self._build_edit_menu()
        self._build_select_menu()
        self._build_view_menu()
        self._build_help_menu()

    def _build_file_menu(self) -> None:
        menu = self.addMenu("&File")
        self._add_action(
            menu, VWCommand.FILE_OPEN, "&Open...",
            QKeySequence.StandardKey.Open, "Open a file"
        )
        self._add_action(
            menu, VWCommand.FILE_SAVE, "&Save",
            QKeySequence.StandardKey.Save, "Save the current file"
        )
        self._add_action(
            menu, VWCommand.FILE_SAVE_AS, "Save &As...",
            QKeySequence("Ctrl+Shift+S"), "Save the current file with a new name"
        )
        menu.addSeparator()
        self._add_action(
            menu, VWCommand.FILE_EXIT, "E&xit",
            QKeySequence.StandardKey.Quit, "Exit the application"
        )

    def _build_edit_menu(self) -> None:
        menu = self.addMenu("&Edit")
        self._add_action(
            menu, VWCommand.EDIT_UNDO, "&Undo",
            QKeySequence.StandardKey.Undo, "Undo the last action"
        )
        self._add_action(
            menu, VWCommand.EDIT_REDO, "&Redo",
            QKeySequence.StandardKey.Redo, "Redo the previously undone action"
        )
        menu.addSeparator()
        self._add_action(
            menu, VWCommand.EDIT_CUT, "Cu&t",
            QKeySequence.StandardKey.Cut, "Cut the current selection"
        )
        self._add_action(
            menu, VWCommand.EDIT_COPY, "&Copy",
            QKeySequence.StandardKey.Copy, "Copy the current selection"
        )
        self._add_action(
            menu, VWCommand.EDIT_PASTE, "&Paste",
            QKeySequence.StandardKey.Paste, "Paste from the clipboard"
        )
        menu.addSeparator()
        self._add_action(
            menu, VWCommand.EDIT_PREFERENCES, "&Preferences...",
            QKeySequence("Ctrl+,"), "Open application preferences"
        )

    def _build_select_menu(self) -> None:
        menu = self.addMenu("&Selection")
        self._add_action(
            menu, VWCommand.SELECT_ALL, "Select &All",
            QKeySequence.StandardKey.SelectAll, "Select all items"
        )
        self._add_action(
            menu, VWCommand.SELECT_NONE, "Select &None",
            QKeySequence("Ctrl+Shift+A"), "Deselect all items"
        )
        self._add_action(
            menu, VWCommand.SELECT_INVERT, "&Invert Selection",
            QKeySequence("Ctrl+I"), "Invert the current selection"
        )

    def _build_view_menu(self) -> None:
        menu = self.addMenu("&View")
        self._add_action(
            menu, VWCommand.VIEW_ZOOM_IN, "Zoom &In",
            QKeySequence.StandardKey.ZoomIn, "Zoom in"
        )
        self._add_action(
            menu, VWCommand.VIEW_ZOOM_OUT, "Zoom &Out",
            QKeySequence.StandardKey.ZoomOut, "Zoom out"
        )
        self._add_action(
            menu, VWCommand.VIEW_RESET, "&Reset View",
            QKeySequence("Ctrl+0"), "Reset zoom and pan"
        )
        menu.addSeparator()
        self._add_action(
            menu, VWCommand.VIEW_FULLSCREEN, "&Full Screen",
            QKeySequence("F11"), "Toggle full screen mode"
        )

    def _build_help_menu(self) -> None:
        menu = self.addMenu("&Help")
        self._add_action(
            menu, VWCommand.HELP_DOCS, "&Documentation",
            None, "Open the online documentation"
        )
        self._add_action(
            menu, VWCommand.HELP_ABOUT, "&About",
            None, "Show application information"
        )

    def _add_action(
        self,
        menu: QMenu,
        command: VWCommand,
        text: str,
        shortcut: QKeySequence | str | None,
        status_tip: str | None,
    ) -> QAction:
        action = QAction(text, self)
        if shortcut is not None:
            action.setShortcut(shortcut)
        if status_tip:
            action.setStatusTip(status_tip)
        action.triggered.connect(lambda _checked, cmd=command: self._dispatch(cmd))
        menu.addAction(action)
        self._actions[str(command)] = action
        return action

    def _dispatch(self, command: VWCommand) -> None:
        if command == VWCommand.FILE_EXIT:
            window = self.parent()
            while window is not None and not hasattr(window, "close"):
                window = window.parent()
            if window is not None:
                window.close()
            return

        try:
            self._bus.execute(command)
        except VWCommandError as exc:
            QMessageBox.information(self, "Menu Action", str(exc))
        except Exception as exc:
            QMessageBox.critical(self, "Menu Action Error", str(exc))
