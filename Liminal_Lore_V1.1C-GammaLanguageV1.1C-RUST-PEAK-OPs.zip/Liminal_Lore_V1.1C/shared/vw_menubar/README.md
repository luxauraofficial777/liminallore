# vw_menubar — Shared Menu Bar for the Void Walkers Toolchain

A standardized `File / Edit / Selection / View / Help` menu bar that can be
dropped into any PyQt6 or PySide6 tool in the Void Walkers toolchain.

## Installation

```bash
# From the Modern_X64/tools directory
pip install -e ./shared/vw_menubar
```

Or install the whole toolchain (the shared package is referenced as a local
dependency):

```bash
pip install -e .
```

## Quick Start

```python
from PyQt6.QtWidgets import QApplication, QTextEdit
from vw_menubar import (
    VWCommandBus,
    VWMainWindow,
    VWToolCapabilities,
    VWStorageMiddleware,
    LocalFileStorageProvider,
    VWStorageContext,
)

app = QApplication([])

# 1. Configure capabilities
bus = VWCommandBus()
bus.register_capabilities(
    VWToolCapabilities(
        can_open=True,
        can_save=True,
        can_save_as=True,
        can_undo=True,
        can_redo=True,
        can_copy=True,
        can_paste=True,
        can_select_all=True,
    )
)

# 2. Configure storage
mw = VWStorageMiddleware()
mw.register_provider("local", LocalFileStorageProvider())

# 3. Bind handlers
editor = QTextEdit()

def handle_open(ctx: VWStorageContext):
    data = mw.open(ctx.path)
    editor.setPlainText(data)

def handle_save(ctx: VWStorageContext):
    mw.save(ctx.path, data=editor.toPlainText())

bus.register_open_handler(handle_open)
bus.register_save_handler(handle_save)

# 4. Create the window
window = VWMainWindow("Demo Tool", central_widget=editor)
window.refresh_menu()
window.show()
app.exec()
```

## Integration Patterns

### New tools

Inherit from `VWMainWindow`:

```python
from vw_menubar import VWMainWindow

class MyToolWindow(VWMainWindow):
    def __init__(self):
        super().__init__(title="My Tool", capabilities=...)
```

### Existing tools

Replace the existing `QMainWindow` subclass or add the menu bar manually:

```python
from vw_menubar import VWCommandBus, VWMenuBar, VWToolCapabilities

class MyExistingMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        bus = VWCommandBus()
        bus.register_capabilities(VWToolCapabilities(...))
        bus.register_open_handler(self._on_open)
        bus.register_save_handler(self._on_save)
        self.setMenuBar(VWMenuBar(self))
        self.menuBar().refresh()
```

## Disabling Features

If a tool does not support saving, pass `can_save=False` and `can_save_as=False`
in `VWToolCapabilities`. The menu bar will grey out the corresponding items
automatically.

## Storage Backends

The default provider is `LocalFileStorageProvider`. Cloud and database providers
are provided as contracts; inject the actual client (boto3, azure-storage-blob,
SQL connection, etc.) and implement `open()`, `save()`, and `exists()`.

```python
mw.register_provider("s3", CloudStorageProvider(bucket="vw-assets", client=s3))
mw.register_provider("db", DatabaseStorageProvider(connection=conn))
mw.set_default_provider("s3")
```
