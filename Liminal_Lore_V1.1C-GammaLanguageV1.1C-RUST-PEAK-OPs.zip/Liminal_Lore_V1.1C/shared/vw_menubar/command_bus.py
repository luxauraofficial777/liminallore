"""
Global command registry / event bus for the Void Walkers toolchain menu bar.

The bus is a singleton within a process so that multiple components (the menu
bar, toolbars, keyboard shortcuts) can all invoke the same registered handler.
"""
from __future__ import annotations

from typing import Any, Callable

from .types import VWCommand, VWStorageContext, VWToolCapabilities


class VWCommandError(Exception):
    """Base exception for command-bus errors."""


class VWCommandNotRegisteredError(VWCommandError):
    """Raised when a command is invoked but no handler is registered."""


class VWCommandDisabledError(VWCommandError):
    """Raised when a command is explicitly disabled for the current tool."""


class VWCommandBus:
    """
    Singleton command bus.

    Usage:
        bus = VWCommandBus()
        bus.register_capabilities(VWToolCapabilities(can_save=True))
        bus.register_open_handler(my_open)
        bus.register_save_handler(my_save)
        bus.execute(VWCommand.FILE_OPEN)
    """

    _instance: VWCommandBus | None = None

    def __new__(cls) -> VWCommandBus:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._handlers: dict[str, Callable[..., Any]] = {}
            cls._instance._capabilities = VWToolCapabilities()
        return cls._instance

    def reset(self) -> None:
        """Clear all handlers and reset capabilities. Useful in tests."""
        self._handlers.clear()
        self._capabilities = VWToolCapabilities()

    # ------------------------------------------------------------------
    # Convenience registration methods
    # ------------------------------------------------------------------
    def register_open_handler(
        self, callback: Callable[[VWStorageContext], Any]
    ) -> None:
        self._handlers[VWCommand.FILE_OPEN] = callback

    def register_save_handler(
        self, callback: Callable[[VWStorageContext], Any]
    ) -> None:
        self._handlers[VWCommand.FILE_SAVE] = callback

    def register_save_as_handler(
        self, callback: Callable[[VWStorageContext], Any]
    ) -> None:
        self._handlers[VWCommand.FILE_SAVE_AS] = callback

    def register_handler(
        self, command: str | VWCommand, callback: Callable[..., Any]
    ) -> None:
        self._handlers[str(command)] = callback

    def register_capabilities(self, capabilities: VWToolCapabilities) -> None:
        self._capabilities = capabilities

    def get_capabilities(self) -> VWToolCapabilities:
        return self._capabilities

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------
    def execute(self, command: str | VWCommand, *args: Any, **kwargs: Any) -> Any:
        cmd = str(command)
        if not self.is_enabled(cmd):
            raise VWCommandDisabledError(
                f"Command '{cmd}' is disabled for this tool."
            )
        handler = self._handlers.get(cmd)
        if handler is None:
            raise VWCommandNotRegisteredError(
                f"Command '{cmd}' has no registered handler."
            )
        return handler(*args, **kwargs)

    def has_handler(self, command: str | VWCommand) -> bool:
        return str(command) in self._handlers

    # ------------------------------------------------------------------
    # Capability mapping
    # ------------------------------------------------------------------
    def is_enabled(self, command: str | VWCommand) -> bool:
        cmd = str(command)
        cap = self._capabilities

        if not self.has_handler(cmd):
            return False

        mapping: dict[str, bool] = {
            VWCommand.FILE_OPEN: cap.can_open,
            VWCommand.FILE_SAVE: cap.can_save,
            VWCommand.FILE_SAVE_AS: cap.can_save_as,
            VWCommand.FILE_EXIT: True,
            VWCommand.EDIT_UNDO: cap.can_undo,
            VWCommand.EDIT_REDO: cap.can_redo,
            VWCommand.EDIT_CUT: cap.can_cut,
            VWCommand.EDIT_COPY: cap.can_copy,
            VWCommand.EDIT_PASTE: cap.can_paste,
            VWCommand.EDIT_PREFERENCES: cap.can_preferences,
            VWCommand.SELECT_ALL: cap.can_select_all,
            VWCommand.SELECT_NONE: cap.can_select_none,
            VWCommand.SELECT_INVERT: cap.can_select_invert,
            VWCommand.VIEW_ZOOM_IN: cap.can_zoom_in,
            VWCommand.VIEW_ZOOM_OUT: cap.can_zoom_out,
            VWCommand.VIEW_RESET: cap.can_reset_view,
            VWCommand.VIEW_FULLSCREEN: cap.can_toggle_fullscreen,
            VWCommand.HELP_ABOUT: cap.can_help_about,
            VWCommand.HELP_DOCS: cap.can_help_docs,
        }

        return mapping.get(cmd, True)
