"""
Qt binding compatibility layer.

The Void Walkers toolchain uses both PyQt6 (atlas_architect, sprite_slicer_gui)
and PySide6 (atlas_forge, lux_maker). vw_menubar works with either binding.
"""
from __future__ import annotations

QT_BINDING: str = ""

# Widgets
try:
    from PyQt6.QtWidgets import (
        QApplication,
        QFileDialog,
        QHBoxLayout,
        QMainWindow,
        QMenu,
        QMenuBar,
        QMessageBox,
        QSplitter,
        QStatusBar,
        QToolBar,
        QVBoxLayout,
        QWidget,
    )
    from PyQt6.QtGui import QAction, QKeySequence
    from PyQt6.QtCore import Qt, QObject, pyqtSignal as Signal
    QT_BINDING = "PyQt6"
except ImportError:
    from PySide6.QtWidgets import (
        QApplication,
        QFileDialog,
        QHBoxLayout,
        QMainWindow,
        QMenu,
        QMenuBar,
        QMessageBox,
        QSplitter,
        QStatusBar,
        QToolBar,
        QVBoxLayout,
        QWidget,
    )
    from PySide6.QtGui import QAction, QKeySequence
    from PySide6.QtCore import Qt, QObject, Signal
    QT_BINDING = "PySide6"

if not QT_BINDING:
    raise ImportError(
        "vw_menubar requires either PyQt6 or PySide6 to be installed."
    )

__all__ = [
    "QT_BINDING",
    "QApplication",
    "QFileDialog",
    "QHBoxLayout",
    "QMainWindow",
    "QMenu",
    "QMenuBar",
    "QMessageBox",
    "QSplitter",
    "QStatusBar",
    "QToolBar",
    "QVBoxLayout",
    "QWidget",
    "QAction",
    "QKeySequence",
    "Qt",
    "QObject",
    "Signal",
]
