"""
Example: Atlas Editor style application using vw_menubar.

Demonstrates:
  - Full Open/Save/Save As registration
  - Edit menu handlers (Undo/Redo/Cut/Copy/Paste/Preferences)
  - Selection menu handlers
  - View menu handlers (zoom, full screen)
  - Local file storage via VWStorageMiddleware
  - Tool-specific workspace data bound to the menu bar

Run:
    python -m vw_menubar.examples.example_atlas_editor
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from vw_menubar import (
    VWCommandBus,
    VWCommand,
    VWMainWindow,
    VWMenuBar,
    VWStorageContext,
    VWStorageMiddleware,
    VWToolCapabilities,
    LocalFileStorageProvider,
)
from vw_menubar._qt_compat import (
    QApplication,
    QFileDialog,
    QKeySequence,
    QLabel,
    QMessageBox,
    QPlainTextEdit,
    QShortcut,
    QStatusBar,
    QVBoxLayout,
    QWidget,
)


class AtlasEditorWorkspace(QWidget):
    """
    Toy workspace for the example. In the real Atlas Architect this would be
    the AtlasCanvas + sidebar; here we use a text editor to stand in for the
    JSON-serialized project state.
    """

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._editor = QPlainTextEdit()
        self._editor.setPlainText('{"project": "AtlasArchitect", "quads": []}')
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._editor)

    def get_state(self) -> dict:
        try:
            return json.loads(self._editor.toPlainText())
        except json.JSONDecodeError:
            return {"error": "invalid_json", "raw": self._editor.toPlainText()}

    def set_state(self, state: dict) -> None:
        self._editor.setPlainText(json.dumps(state, indent=2, ensure_ascii=False))

    def editor(self) -> QPlainTextEdit:
        return self._editor


class AtlasEditorMainWindow(VWMainWindow):
    """
    Atlas Editor integration example.

    Inherits VWMainWindow so the standard menu bar is present automatically.
    """

    def __init__(self) -> None:
        self._workspace = AtlasEditorWorkspace()
        super().__init__(
            title="Atlas Architect — Shared Menu Bar Demo",
            capabilities=VWToolCapabilities(
                can_open=True,
                can_save=True,
                can_save_as=True,
                can_undo=True,
                can_redo=True,
                can_cut=True,
                can_copy=True,
                can_paste=True,
                can_select_all=True,
                can_select_none=True,
                can_select_invert=True,
                can_zoom_in=True,
                can_zoom_out=True,
                can_reset_view=True,
                can_toggle_fullscreen=True,
                can_preferences=True,
                can_help_about=True,
                can_help_docs=True,
            ),
            central_widget=self._workspace,
        )

        self._current_path: str | None = None
        self._history: list[str] = []
        self._history_index: int = -1
        self._record_history()

        # Storage middleware
        self._storage = VWStorageMiddleware()
        self._storage.register_provider("local", LocalFileStorageProvider())

        # Register menu handlers
        self._bus = VWCommandBus()
        self._bus.register_open_handler(self._on_open)
        self._bus.register_save_handler(self._on_save)
        self._bus.register_save_as_handler(self._on_save_as)
        self._bus.register_handler(VWCommand.EDIT_UNDO, self._on_undo)
        self._bus.register_handler(VWCommand.EDIT_REDO, self._on_redo)
        self._bus.register_handler(VWCommand.EDIT_CUT, self._on_cut)
        self._bus.register_handler(VWCommand.EDIT_COPY, self._on_copy)
        self._bus.register_handler(VWCommand.EDIT_PASTE, self._on_paste)
        self._bus.register_handler(VWCommand.EDIT_PREFERENCES, self._on_preferences)
        self._bus.register_handler(VWCommand.SELECT_ALL, self._workspace.editor().selectAll)
        self._bus.register_handler(VWCommand.SELECT_NONE, self._on_select_none)
        self._bus.register_handler(VWCommand.SELECT_INVERT, self._on_select_invert)
        self._bus.register_handler(VWCommand.VIEW_ZOOM_IN, self._on_zoom_in)
        self._bus.register_handler(VWCommand.VIEW_ZOOM_OUT, self._on_zoom_out)
        self._bus.register_handler(VWCommand.VIEW_RESET, self._on_reset_view)
        self._bus.register_handler(VWCommand.VIEW_FULLSCREEN, self._on_fullscreen)
        self._bus.register_handler(VWCommand.HELP_ABOUT, self._on_about)
        self._bus.register_handler(VWCommand.HELP_DOCS, self._on_docs)

        # Refresh after handlers are registered
        self.refresh_menu()
        self._update_status("Ready — Atlas Editor demo")

        # Wire editor changes to history
        self._workspace.editor().textChanged.connect(self._on_text_changed)

    # -------------------------------------------------------------- File
    def _on_open(self, _ctx: VWStorageContext | None = None) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Open Atlas Project", "", "JSON (*.json);;All Files (*)"
        )
        if not path:
            return
        self._current_path = path
        data = self._storage.open(path)
        self._workspace.set_state(data)
        self._history.clear()
        self._history_index = -1
        self._record_history()
        self._update_status(f"Opened {path}")

    def _on_save(self, _ctx: VWStorageContext | None = None) -> None:
        if self._current_path is None:
            self._on_save_as()
            return
        self._storage.save(self._current_path, data=self._workspace.get_state())
        self._update_status(f"Saved {self._current_path}")

    def _on_save_as(self, _ctx: VWStorageContext | None = None) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Atlas Project As", "", "JSON (*.json);;All Files (*)"
        )
        if not path:
            return
        self._current_path = path
        self._storage.save(path, data=self._workspace.get_state())
        self._update_status(f"Saved as {path}")

    # -------------------------------------------------------------- Edit
    def _record_history(self) -> None:
        text = self._workspace.editor().toPlainText()
        # Trim redo stack
        self._history = self._history[: self._history_index + 1]
        if not self._history or self._history[-1] != text:
            self._history.append(text)
            self._history_index += 1

    def _on_text_changed(self) -> None:
        self._record_history()

    def _on_undo(self) -> None:
        if self._history_index > 0:
            self._history_index -= 1
            self._workspace.editor().setPlainText(self._history[self._history_index])
            self._update_status("Undo")

    def _on_redo(self) -> None:
        if self._history_index < len(self._history) - 1:
            self._history_index += 1
            self._workspace.editor().setPlainText(self._history[self._history_index])
            self._update_status("Redo")

    def _on_cut(self) -> None:
        self._workspace.editor().cut()
        self._update_status("Cut")

    def _on_copy(self) -> None:
        self._workspace.editor().copy()
        self._update_status("Copy")

    def _on_paste(self) -> None:
        self._workspace.editor().paste()
        self._update_status("Paste")

    def _on_preferences(self) -> None:
        QMessageBox.information(self, "Preferences", "Preferences dialog would open here.")

    # -------------------------------------------------------------- Selection
    def _on_select_none(self) -> None:
        cursor = self._workspace.editor().textCursor()
        cursor.clearSelection()
        self._workspace.editor().setTextCursor(cursor)

    def _on_select_invert(self) -> None:
        # Toy inversion: select all if none selected, clear otherwise
        cursor = self._workspace.editor().textCursor()
        if cursor.hasSelection():
            self._on_select_none()
        else:
            self._workspace.editor().selectAll()

    # -------------------------------------------------------------- View
    def _on_zoom_in(self) -> None:
        self._workspace.editor().zoomIn(1)
        self._update_status("Zoom in")

    def _on_zoom_out(self) -> None:
        self._workspace.editor().zoomOut(1)
        self._update_status("Zoom out")

    def _on_reset_view(self) -> None:
        self._workspace.editor().zoomIn(0)
        self._update_status("Reset view")

    def _on_fullscreen(self) -> None:
        if self.isFullScreen():
            self.showNormal()
        else:
            self.showFullScreen()

    # -------------------------------------------------------------- Help
    def _on_about(self) -> None:
        QMessageBox.about(
            self,
            "About Atlas Editor",
            "<b>Atlas Editor Demo</b><br>"
            "Standardized menu bar via vw_menubar.<br>"
            "Void Walkers HD toolchain",
        )

    def _on_docs(self) -> None:
        QMessageBox.information(self, "Documentation", "Open docs URL here.")

    def _update_status(self, message: str) -> None:
        status = self.statusBar()
        if isinstance(status, QStatusBar):
            status.showMessage(message)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = AtlasEditorMainWindow()
    window.show()
    sys.exit(app.exec())
