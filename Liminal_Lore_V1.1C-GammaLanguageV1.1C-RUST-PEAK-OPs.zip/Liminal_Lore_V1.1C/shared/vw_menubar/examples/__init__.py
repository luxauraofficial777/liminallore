"""Integration examples for vw_menubar."""
