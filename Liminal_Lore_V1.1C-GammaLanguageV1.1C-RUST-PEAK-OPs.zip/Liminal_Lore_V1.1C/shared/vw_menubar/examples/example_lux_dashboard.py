"""
Example: Read-only Lux Dashboard using vw_menubar.

Demonstrates:
  - Graceful degradation: Save / Save As are disabled because the tool is read-only.
  - Tool-specific metadata passed to the standard menu bar.
  - Local file storage middleware used to load a custom .map file format.
  - A different tool title and window geometry.

Run:
    python -m vw_menubar.examples.example_lux_dashboard
"""
from __future__ import annotations

import sys

from vw_menubar import (
    VWCommandBus,
    VWCommand,
    VWMainWindow,
    VWStorageContext,
    VWStorageMiddleware,
    VWToolCapabilities,
    LocalFileStorageProvider,
)
from vw_menubar._qt_compat import (
    QApplication,
    QFileDialog,
    QLabel,
    QMessageBox,
    QPlainTextEdit,
    QVBoxLayout,
    QWidget,
)


class LuxDashboard(QWidget):
    """
    Toy read-only map dashboard. In the real Lux Maker this would be a
    CanvasPane + layer panel; here we display the loaded map text.
    """

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._label = QLabel("No map loaded")
        self._label.setStyleSheet("padding: 20px; font-size: 16px;")
        self._editor = QPlainTextEdit()
        self._editor.setReadOnly(True)
        self._editor.setPlaceholderText("Open a .map or .txt file to view it.")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._label)
        layout.addWidget(self._editor)

    def set_map(self, name: str, content: str) -> None:
        self._label.setText(f"Loaded: {name}")
        self._editor.setPlainText(content)


class LuxDashboardMainWindow(VWMainWindow):
    """
    Lux Map Viewer integration example.

    This tool is intentionally read-only: Save and Save As are greyed out.
    """

    def __init__(self) -> None:
        self._dashboard = LuxDashboard()
        super().__init__(
            title="Lux Map Viewer — Read-Only",
            capabilities=VWToolCapabilities(
                can_open=True,
                can_save=False,
                can_save_as=False,
                can_undo=False,
                can_redo=False,
                can_cut=False,
                can_copy=True,
                can_paste=False,
                can_select_all=True,
                can_select_none=True,
                can_select_invert=False,
                can_zoom_in=False,
                can_zoom_out=False,
                can_reset_view=False,
                can_toggle_fullscreen=True,
                can_preferences=False,
                can_help_about=True,
                can_help_docs=True,
            ),
            central_widget=self._dashboard,
        )
        self.resize(1200, 800)

        # Storage middleware
        self._storage = VWStorageMiddleware()
        self._storage.register_provider("local", LocalFileStorageProvider())

        # Register handlers
        bus = VWCommandBus()
        bus.register_open_handler(self._on_open)
        bus.register_handler(VWCommand.EDIT_COPY, self._dashboard._editor.copy)
        bus.register_handler(VWCommand.SELECT_ALL, self._dashboard._editor.selectAll)
        bus.register_handler(VWCommand.SELECT_NONE, self._on_select_none)
        bus.register_handler(VWCommand.VIEW_FULLSCREEN, self._on_fullscreen)
        bus.register_handler(VWCommand.HELP_ABOUT, self._on_about)
        bus.register_handler(VWCommand.HELP_DOCS, self._on_docs)

        # Refresh menu bar so Save / Save As are greyed out
        self.refresh_menu()
        self.statusBar().showMessage("Ready — read-only map viewer")

    def _on_open(self, _ctx: VWStorageContext | None = None) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Open Map", "", "Map Files (*.map *.txt);;All Files (*)"
        )
        if not path:
            return
        # Force text format for this tool's specific format
        content = self._storage.open(path, metadata={"format": "text"})
        self._dashboard.set_map(path, str(content))
        self.statusBar().showMessage(f"Opened {path}")

    def _on_select_none(self) -> None:
        cursor = self._dashboard._editor.textCursor()
        cursor.clearSelection()
        self._dashboard._editor.setTextCursor(cursor)

    def _on_fullscreen(self) -> None:
        if self.isFullScreen():
            self.showNormal()
        else:
            self.showFullScreen()

    def _on_about(self) -> None:
        QMessageBox.about(
            self,
            "About Lux Map Viewer",
            "<b>Lux Map Viewer</b><br>"
            "Read-only dashboard using the shared vw_menubar.<br>"
            "Void Walkers HD toolchain",
        )

    def _on_docs(self) -> None:
        QMessageBox.information(self, "Documentation", "Open Lux Maker docs here.")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = LuxDashboardMainWindow()
    window.show()
    sys.exit(app.exec())
