"""
pixel_format.py — Shared pixel format definitions for all VoidWalkers Python tools.

Imported by: IirisFidelityForge, atlas_forge, atlas_architect, vwforge.
This is the SINGLE source of truth for pixel format enums and metadata in Python.
It mirrors tools/shared/PixelFormat.h exactly.
"""
from __future__ import annotations

from enum import IntEnum
from dataclasses import dataclass
from typing import Tuple


class PixelFormat(IntEnum):
    """Canonical pixel format enum for all bit-depth variants."""
    BGRA8    = 0   # 32-bit B8G8R8A8 (engine native, default)
    RGBA8    = 1   # 32-bit R8G8B8A8 (FidelityForge native, DX11)
    RGB565   = 2   # 16-bit R5G6B5 (no alpha, retro opaque)
    RGBA5551 = 3   # 16-bit R5G5B5A1 (1-bit alpha, PSX cutout)
    RGBA4444 = 4   # 16-bit R4G4B4A4 (4-bit alpha, mobile)
    RGB888   = 5   # 24-bit R8G8B8 (no alpha, opaque environment)
    INDEXED8 = 6   # 8-bit paletted (256 colors, classic retro)


class DitherMode(IntEnum):
    """Dithering algorithm for bit-depth reduction."""
    None_          = 0  # trailing underscore to avoid Python keyword conflict
    FloydSteinberg = 1
    Bayer2x2       = 2
    Bayer4x4       = 3
    Bayer8x8       = 4


@dataclass(frozen=True)
class FormatInfo:
    format: PixelFormat
    name: str
    bits_per_pixel: int
    bytes_per_pixel: int
    channels: int
    has_alpha: bool
    alpha_bits: int
    dxgi_name: str


_FORMAT_TABLE = {
    PixelFormat.BGRA8:    FormatInfo(PixelFormat.BGRA8,    "BGRA8",    32, 4, 4, True,  8, "DXGI_FORMAT_B8G8R8A8_UNORM"),
    PixelFormat.RGBA8:    FormatInfo(PixelFormat.RGBA8,    "RGBA8",    32, 4, 4, True,  8, "DXGI_FORMAT_R8G8B8A8_UNORM"),
    PixelFormat.RGB565:   FormatInfo(PixelFormat.RGB565,   "RGB565",   16, 2, 3, False, 0, "DXGI_FORMAT_B5G6R5_UNORM"),
    PixelFormat.RGBA5551: FormatInfo(PixelFormat.RGBA5551, "RGBA5551", 16, 2, 4, True,  1, "DXGI_FORMAT_B5G5R5A1_UNORM"),
    PixelFormat.RGBA4444: FormatInfo(PixelFormat.RGBA4444, "RGBA4444", 16, 2, 4, True,  4, "DXGI_FORMAT_B4G4R4A4_UNORM"),
    PixelFormat.RGB888:   FormatInfo(PixelFormat.RGB888,   "RGB888",   24, 3, 3, False, 0, "DXGI_FORMAT_R8G8B8A8_UNORM"),
    PixelFormat.INDEXED8: FormatInfo(PixelFormat.INDEXED8, "INDEXED8",  8, 1, 1, True,  1, "DXGI_FORMAT_R8_UNORM"),
}


def get_format_info(fmt: PixelFormat) -> FormatInfo:
    return _FORMAT_TABLE[fmt]


def bytes_per_pixel(fmt: PixelFormat) -> int:
    return get_format_info(fmt).bytes_per_pixel


def bytes_per_row(width: int, fmt: PixelFormat) -> int:
    return width * bytes_per_pixel(fmt)


def is_indexed(fmt: PixelFormat) -> bool:
    return fmt == PixelFormat.INDEXED8


def is_packed16(fmt: PixelFormat) -> bool:
    return fmt in (PixelFormat.RGB565, PixelFormat.RGBA5551, PixelFormat.RGBA4444)


def has_alpha(fmt: PixelFormat) -> bool:
    return get_format_info(fmt).has_alpha


def is_8bit(fmt: PixelFormat) -> bool:
    return get_format_info(fmt).bits_per_pixel <= 8


def is_16bit(fmt: PixelFormat) -> bool:
    return get_format_info(fmt).bits_per_pixel == 16


def is_32bit(fmt: PixelFormat) -> bool:
    return get_format_info(fmt).bits_per_pixel == 32


def parse_format_string(s: str) -> PixelFormat:
    """Parse a format string from CLI or JSON into a PixelFormat enum."""
    s = s.strip()
    lookup = {
        "BGRA8": PixelFormat.BGRA8, "32": PixelFormat.BGRA8, "bgra8": PixelFormat.BGRA8,
        "RGBA8": PixelFormat.RGBA8, "rgba8": PixelFormat.RGBA8,
        "RGB565": PixelFormat.RGB565, "565": PixelFormat.RGB565, "rgb565": PixelFormat.RGB565,
        "RGBA5551": PixelFormat.RGBA5551, "5551": PixelFormat.RGBA5551, "rgba5551": PixelFormat.RGBA5551,
        "RGBA4444": PixelFormat.RGBA4444, "4444": PixelFormat.RGBA4444, "rgba4444": PixelFormat.RGBA4444,
        "RGB888": PixelFormat.RGB888, "24": PixelFormat.RGB888, "rgb888": PixelFormat.RGB888,
        "INDEXED8": PixelFormat.INDEXED8, "8": PixelFormat.INDEXED8, "indexed8": PixelFormat.INDEXED8,
    }
    return lookup.get(s, PixelFormat.BGRA8)


def format_to_string(fmt: PixelFormat) -> str:
    return get_format_info(fmt).name


def parse_dither_string(s: str) -> DitherMode:
    s = s.strip().lower()
    lookup = {
        "none": DitherMode.None_, "0": DitherMode.None_,
        "floyd": DitherMode.FloydSteinberg, "1": DitherMode.FloydSteinberg,
        "bayer2": DitherMode.Bayer2x2, "2": DitherMode.Bayer2x2,
        "bayer4": DitherMode.Bayer4x4, "3": DitherMode.Bayer4x4,
        "bayer8": DitherMode.Bayer8x8, "4": DitherMode.Bayer8x8,
    }
    return lookup.get(s, DitherMode.FloydSteinberg)


def dither_to_string(mode: DitherMode) -> str:
    return {
        DitherMode.None_: "none",
        DitherMode.FloydSteinberg: "floyd",
        DitherMode.Bayer2x2: "bayer2",
        DitherMode.Bayer4x4: "bayer4",
        DitherMode.Bayer8x8: "bayer8",
    }.get(mode, "floyd")


# ---------------------------------------------------------------------------
# 16-bit packed encode/decode (mirrors C++ PixelFormat.h)
# ---------------------------------------------------------------------------

def encode_rgb565(r: int, g: int, b: int) -> bytes:
    val = ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3)
    return val.to_bytes(2, "little")


def decode_rgb565(data: bytes) -> Tuple[int, int, int]:
    val = int.from_bytes(data, "little")
    r = (val >> 11) & 0x1F; r = (r << 3) | (r >> 2)
    g = (val >> 5)  & 0x3F; g = (g << 2) | (g >> 4)
    b = val & 0x1F;         b = (b << 3) | (b >> 2)
    return r, g, b


def encode_rgba5551(r: int, g: int, b: int, a: int) -> bytes:
    val = ((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3)
    if a > 127:
        val |= 0x8000
    return val.to_bytes(2, "little")


def decode_rgba5551(data: bytes) -> Tuple[int, int, int, int]:
    val = int.from_bytes(data, "little")
    a = 255 if (val & 0x8000) else 0
    r = (val >> 10) & 0x1F; r = (r << 3) | (r >> 2)
    g = (val >> 5)  & 0x1F; g = (g << 3) | (g >> 2)
    b = val & 0x1F;         b = (b << 3) | (b >> 2)
    return r, g, b, a


def encode_rgba4444(r: int, g: int, b: int, a: int) -> bytes:
    val = ((r >> 4) << 12) | ((g >> 4) << 8) | ((b >> 4) << 4) | (a >> 4)
    return val.to_bytes(2, "little")


def decode_rgba4444(data: bytes) -> Tuple[int, int, int, int]:
    val = int.from_bytes(data, "little")
    r = (val >> 12) & 0xF; r = (r << 4) | r
    g = (val >> 8)  & 0xF; g = (g << 4) | g
    b = (val >> 4)  & 0xF; b = (b << 4) | b
    a = val & 0xF;         a = (a << 4) | a
    return r, g, b, a


# ---------------------------------------------------------------------------
# Bayer dithering matrices
# ---------------------------------------------------------------------------
BAYER_2X2 = [
    [0, 2],
    [3, 1],
]

BAYER_4X4 = [
    [ 0,  8,  2, 10],
    [12,  4, 14,  6],
    [ 3, 11,  1,  9],
    [15,  7, 13,  5],
]

BAYER_8X8 = [
    [ 0, 32,  8, 40,  2, 34, 10, 42],
    [48, 16, 56, 24, 50, 18, 58, 26],
    [12, 44,  4, 36, 14, 46,  6, 38],
    [60, 28, 52, 20, 62, 30, 54, 22],
    [ 3, 35, 11, 43,  1, 33,  9, 41],
    [51, 19, 59, 27, 49, 17, 57, 25],
    [15, 47,  7, 39, 13, 45,  5, 37],
    [63, 31, 55, 23, 61, 29, 53, 21],
]
