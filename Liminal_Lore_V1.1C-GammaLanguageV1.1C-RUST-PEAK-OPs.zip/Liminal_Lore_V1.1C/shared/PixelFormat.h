// ============================================================================
// PixelFormat.h — Shared pixel format definitions for all VoidWalkers tools
// ============================================================================
// Included by: RigForge, AtlasForge, FidelityForge, SpriteSlicer
// This is the SINGLE source of truth for pixel format enums and metadata.
// No tool should define its own format enum.
// ============================================================================
#pragma once

#include <cstdint>
#include <cstring>
#include <string>

namespace vw {

// ============================================================================
// PixelFormat — canonical enum for all bit-depth variants
// ============================================================================
enum class PixelFormat : uint8_t {
    BGRA8     = 0,    // 32-bit B8G8R8A8 (engine native, default)
    RGBA8     = 1,    // 32-bit R8G8B8A8 (FidelityForge native, DX11)
    RGB565    = 2,    // 16-bit R5G6B5 (no alpha, retro opaque)
    RGBA5551  = 3,    // 16-bit R5G5B5A1 (1-bit alpha, PSX cutout)
    RGBA4444  = 4,    // 16-bit R4G4B4A4 (4-bit alpha, mobile)
    RGB888    = 5,    // 24-bit R8G8B8 (no alpha, opaque environment)
    INDEXED8  = 6,    // 8-bit paletted (256 colors, classic retro)
    COUNT     = 7
};

// ============================================================================
// DitherMode — dithering algorithm for bit-depth reduction
// ============================================================================
enum class DitherMode : uint8_t {
    None            = 0,
    FloydSteinberg  = 1,   // Error diffusion (default, best quality)
    Bayer2x2        = 2,   // Ordered dithering (fast, retro)
    Bayer4x4        = 3,   // Ordered dithering (balanced)
    Bayer8x8        = 4,   // Ordered dithering (high quality)
};

// ============================================================================
// PixelFormatInfo — metadata for each format
// ============================================================================
struct PixelFormatInfo {
    PixelFormat  format;
    const char*  name;
    int          bitsPerPixel;
    int          bytesPerPixel;    // May be fractional for packed formats (rounded up)
    int          channels;
    bool         hasAlpha;
    int          alphaBits;        // 0, 1, 4, or 8
    const char*  dxgiFormatName;   // String for logging; engine maps to DXGI_FORMAT
};

// ============================================================================
// Format metadata table
// ============================================================================
} // namespace vw

inline const vw::PixelFormatInfo& GetFormatInfo(vw::PixelFormat fmt) {
    static const vw::PixelFormatInfo table[] = {
        // BGRA8
        { vw::PixelFormat::BGRA8,    "BGRA8",    32, 4, 4, true,  8, "DXGI_FORMAT_B8G8R8A8_UNORM" },
        // RGBA8
        { vw::PixelFormat::RGBA8,    "RGBA8",    32, 4, 4, true,  8, "DXGI_FORMAT_R8G8B8A8_UNORM" },
        // RGB565
        { vw::PixelFormat::RGB565,   "RGB565",   16, 2, 3, false, 0, "DXGI_FORMAT_B5G6R5_UNORM" },
        // RGBA5551
        { vw::PixelFormat::RGBA5551, "RGBA5551", 16, 2, 4, true,  1, "DXGI_FORMAT_B5G5R5A1_UNORM" },
        // RGBA4444
        { vw::PixelFormat::RGBA4444, "RGBA4444", 16, 2, 4, true,  4, "DXGI_FORMAT_B4G4R4A4_UNORM" },
        // RGB888
        { vw::PixelFormat::RGB888,   "RGB888",   24, 3, 3, false, 0, "DXGI_FORMAT_R8G8B8A8_UNORM" },
        // INDEXED8
        { vw::PixelFormat::INDEXED8, "INDEXED8",  8, 1, 1, true,  1, "DXGI_FORMAT_R8_UNORM" },
    };
    return table[static_cast<uint8_t>(fmt)];
}

// ============================================================================
// Helper queries
// ============================================================================
inline int BytesPerPixel(vw::PixelFormat fmt) {
    return GetFormatInfo(fmt).bytesPerPixel;
}

inline int BytesPerRow(int width, vw::PixelFormat fmt) {
    return width * BytesPerPixel(fmt);
}

inline bool IsIndexed(vw::PixelFormat fmt) {
    return fmt == vw::PixelFormat::INDEXED8;
}

inline bool IsPacked16(vw::PixelFormat fmt) {
    return fmt == vw::PixelFormat::RGB565 ||
           fmt == vw::PixelFormat::RGBA5551 ||
           fmt == vw::PixelFormat::RGBA4444;
}

inline bool HasAlpha(vw::PixelFormat fmt) {
    return GetFormatInfo(fmt).hasAlpha;
}

inline bool Is8Bit(vw::PixelFormat fmt) {
    return GetFormatInfo(fmt).bitsPerPixel <= 8;
}

inline bool Is16Bit(vw::PixelFormat fmt) {
    return GetFormatInfo(fmt).bitsPerPixel == 16;
}

inline bool Is24Bit(vw::PixelFormat fmt) {
    return GetFormatInfo(fmt).bitsPerPixel == 24;
}

inline bool Is32Bit(vw::PixelFormat fmt) {
    return GetFormatInfo(fmt).bitsPerPixel == 32;
}

// ============================================================================
// String <-> enum conversion (for CLI parsing and JSON serialization)
// ============================================================================
inline vw::PixelFormat ParseFormatString(const std::string& str) {
    if (str == "BGRA8"    || str == "32" || str == "bgra8")    return vw::PixelFormat::BGRA8;
    if (str == "RGBA8"    || str == "rgba8")                   return vw::PixelFormat::RGBA8;
    if (str == "RGB565"   || str == "565" || str == "rgb565")  return vw::PixelFormat::RGB565;
    if (str == "RGBA5551" || str == "5551" || str == "rgba5551") return vw::PixelFormat::RGBA5551;
    if (str == "RGBA4444" || str == "4444" || str == "rgba4444") return vw::PixelFormat::RGBA4444;
    if (str == "RGB888"   || str == "24" || str == "rgb888")   return vw::PixelFormat::RGB888;
    if (str == "INDEXED8" || str == "8"  || str == "indexed8") return vw::PixelFormat::INDEXED8;
    return vw::PixelFormat::BGRA8; // default
}

inline const char* FormatToString(vw::PixelFormat fmt) {
    return GetFormatInfo(fmt).name;
}

inline vw::DitherMode ParseDitherString(const std::string& str) {
    if (str == "none"   || str == "0") return vw::DitherMode::None;
    if (str == "floyd"  || str == "1") return vw::DitherMode::FloydSteinberg;
    if (str == "bayer2" || str == "2") return vw::DitherMode::Bayer2x2;
    if (str == "bayer4" || str == "3") return vw::DitherMode::Bayer4x4;
    if (str == "bayer8" || str == "4") return vw::DitherMode::Bayer8x8;
    return vw::DitherMode::FloydSteinberg; // default
}

inline const char* DitherToString(vw::DitherMode mode) {
    switch (mode) {
        case vw::DitherMode::None:           return "none";
        case vw::DitherMode::FloydSteinberg: return "floyd";
        case vw::DitherMode::Bayer2x2:       return "bayer2";
        case vw::DitherMode::Bayer4x4:       return "bayer4";
        case vw::DitherMode::Bayer8x8:       return "bayer8";
    }
    return "floyd";
}

// ============================================================================
// 16-bit packed format encode/decode (inline, no dependencies)
// ============================================================================

// RGB565: RRRR RGGG GGGB BBBB
inline void EncodeRGB565(uint8_t r, uint8_t g, uint8_t b, uint8_t out[2]) {
    uint16_t val = ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3);
    out[0] = val & 0xFF;
    out[1] = (val >> 8) & 0xFF;
}

inline void DecodeRGB565(const uint8_t in[2], uint8_t& r, uint8_t& g, uint8_t& b) {
    uint16_t val = in[0] | (in[1] << 8);
    r = (val >> 11) & 0x1F; r = (r << 3) | (r >> 2);
    g = (val >> 5)  & 0x3F; g = (g << 2) | (g >> 4);
    b = val & 0x1F;         b = (b << 3) | (b >> 2);
}

// RGBA5551: RRRR RGGG GGBB BBBA
inline void EncodeRGBA5551(uint8_t r, uint8_t g, uint8_t b, uint8_t a, uint8_t out[2]) {
    uint16_t val = ((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3) << 0;
    if (a > 127) val |= 0x8000;
    out[0] = val & 0xFF;
    out[1] = (val >> 8) & 0xFF;
}

inline void DecodeRGBA5551(const uint8_t in[2], uint8_t& r, uint8_t& g, uint8_t& b, uint8_t& a) {
    uint16_t val = in[0] | (in[1] << 8);
    a = (val & 0x8000) ? 255 : 0;
    r = (val >> 10) & 0x1F; r = (r << 3) | (r >> 2);
    g = (val >> 5)  & 0x1F; g = (g << 3) | (g >> 2);
    b = val & 0x1F;         b = (b << 3) | (b >> 2);
}

// RGBA4444: RRRR GGGG BBBB AAAA
inline void EncodeRGBA4444(uint8_t r, uint8_t g, uint8_t b, uint8_t a, uint8_t out[2]) {
    uint16_t val = ((r >> 4) << 12) | ((g >> 4) << 8) | ((b >> 4) << 4) | (a >> 4);
    out[0] = val & 0xFF;
    out[1] = (val >> 8) & 0xFF;
}

inline void DecodeRGBA4444(const uint8_t in[2], uint8_t& r, uint8_t& g, uint8_t& b, uint8_t& a) {
    uint16_t val = in[0] | (in[1] << 8);
    r = (val >> 12) & 0xF; r = (r << 4) | r;
    g = (val >> 8)  & 0xF; g = (g << 4) | g;
    b = (val >> 4)  & 0xF; b = (b << 4) | b;
    a = val & 0xF;         a = (a << 4) | a;
}

// ============================================================================
// Bayer dithering matrices
// ============================================================================
inline constexpr uint8_t kBayer2x2[4] = {
    0, 2,
    3, 1
};

inline constexpr uint8_t kBayer4x4[16] = {
     0,  8,  2, 10,
    12,  4, 14,  6,
     3, 11,  1,  9,
    15,  7, 13,  5
};

inline constexpr uint8_t kBayer8x8[64] = {
     0, 32,  8, 40,  2, 34, 10, 42,
    48, 16, 56, 24, 50, 18, 58, 26,
    12, 44,  4, 36, 14, 46,  6, 38,
    60, 28, 52, 20, 62, 30, 54, 22,
     3, 35, 11, 43,  1, 33,  9, 41,
    51, 19, 59, 27, 49, 17, 57, 25,
    15, 47,  7, 39, 13, 45,  5, 37,
    63, 31, 55, 23, 61, 29, 53, 21
};
