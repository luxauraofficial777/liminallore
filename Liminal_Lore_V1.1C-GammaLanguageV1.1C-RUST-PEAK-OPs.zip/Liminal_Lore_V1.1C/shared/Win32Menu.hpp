// ============================================================================
// Win32Menu.hpp — Shared Win32 Menu Bar for VoidWalkers Production Suite
// ============================================================================
// Provides a standard professional menu bar (File, Edit, View, Select, Tools,
// Help) for all VoidWalkers C++ tools. When --gui flag is passed, the tool
// opens a Win32 window with this menu bar instead of running CLI-only.
//
// Usage:
//   #include "Win32Menu.hpp"
//   int main(int argc, char* argv[]) {
//     if (hasGuiFlag(argc, argv)) {
//       return Win32Menu::runGui(argc, argv, "AtlasArchitect", {
//         {"Paint", [&](){ /* run paint action */ }},
//         {"Validate", [&](){ /* run validate */ }},
//       });
//     }
//     // ... normal CLI path ...
//   }
//
// Build: Link with user32.lib, gdi32.lib (already linked on Windows)
// ============================================================================

#pragma once

#include <windows.h>
#include <commctrl.h>
#include <string>
#include <vector>
#include <functional>
#include <map>
#include <sstream>
#include <iostream>

namespace Win32Menu {

// ─── Menu Item IDs ───
enum MenuID : UINT {
    // File menu: 1000-1099
    ID_FILE_NEW = 1001,
    ID_FILE_OPEN,
    ID_FILE_SAVE,
    ID_FILE_SAVE_AS,
    ID_FILE_IMPORT,
    ID_FILE_EXPORT,
    ID_FILE_PREFS,
    ID_FILE_EXIT,

    // Edit menu: 1100-1199
    ID_EDIT_UNDO = 1101,
    ID_EDIT_REDO,
    ID_EDIT_CUT,
    ID_EDIT_COPY,
    ID_EDIT_PASTE,
    ID_EDIT_SELECT_ALL,
    ID_EDIT_SELECT_NONE,
    ID_EDIT_INVERT,

    // View menu: 1200-1299
    ID_VIEW_ZOOM_IN = 1201,
    ID_VIEW_ZOOM_OUT,
    ID_VIEW_FIT,
    ID_VIEW_GRID,
    ID_VIEW_RULERS,
    ID_VIEW_CONSOLE,

    // Select menu: 1300-1399
    ID_SELECT_ALL = 1301,
    ID_SELECT_NONE,
    ID_SELECT_INVERT,
    ID_SELECT_REGION,
    ID_SELECT_ALPHA,

    // Tools menu: 2000+ (dynamic, assigned per-tool)
    ID_TOOLS_BASE = 2000,

    // Help menu: 9000+
    ID_HELP_ABOUT = 9001,
    ID_HELP_CLI,
    ID_HELP_DOCS,
};

// ─── Tool Action Callback ───
using ToolAction = std::function<void()>;

// ─── Tool Menu Entry ───
struct ToolMenuEntry {
    std::string label;
    ToolAction callback;
    bool separator = false;
};

// ─── GUI State ───
struct GuiState {
    std::string toolName;
    std::string rootPath;
    int bitDepth = 32;
    std::vector<ToolMenuEntry> toolEntries;
    std::string consoleOutput;
    HWND hMain = nullptr;
    HWND hConsole = nullptr;
    HWND hStatus = nullptr;
    std::map<UINT, ToolAction> actionMap;
};

static GuiState* g_gui = nullptr;

// ─── Console Output ───
void ConsolePrint(const std::string& text) {
    if (!g_gui || !g_gui->hConsole) return;
    g_gui->consoleOutput += text + "\r\n";
    SetWindowTextA(g_gui->hConsole, g_gui->consoleOutput.c_str());

    // Auto-scroll to bottom
    LRESULT lines = SendMessageA(g_gui->hConsole, EM_GETLINECOUNT, 0, 0);
    SendMessageA(g_gui->hConsole, EM_LINESCROLL, 0, lines);
}

void ConsoleClear() {
    if (!g_gui || !g_gui->hConsole) return;
    g_gui->consoleOutput.clear();
    SetWindowTextA(g_gui->hConsole, "");
}

// ─── Build Menu Bar ───
static HMENU BuildMenuBar(const std::vector<ToolMenuEntry>& toolEntries, std::map<UINT, ToolAction>& actionMap) {
    HMENU hFile = CreateMenu();
    AppendMenuA(hFile, MF_STRING, ID_FILE_NEW, "&New Project\tCtrl+N");
    AppendMenuA(hFile, MF_STRING, ID_FILE_OPEN, "&Open...\tCtrl+O");
    AppendMenuA(hFile, MF_SEPARATOR, 0, nullptr);
    AppendMenuA(hFile, MF_STRING, ID_FILE_SAVE, "&Save\tCtrl+S");
    AppendMenuA(hFile, MF_STRING, ID_FILE_SAVE_AS, "Save &As...\tCtrl+Shift+S");
    AppendMenuA(hFile, MF_SEPARATOR, 0, nullptr);
    AppendMenuA(hFile, MF_STRING, ID_FILE_IMPORT, "&Import Asset...\tCtrl+I");
    AppendMenuA(hFile, MF_STRING, ID_FILE_EXPORT, "&Export...\tCtrl+E");
    AppendMenuA(hFile, MF_SEPARATOR, 0, nullptr);
    AppendMenuA(hFile, MF_STRING, ID_FILE_PREFS, "&Preferences...");
    AppendMenuA(hFile, MF_SEPARATOR, 0, nullptr);
    AppendMenuA(hFile, MF_STRING, ID_FILE_EXIT, "E&xit\tAlt+F4");

    HMENU hEdit = CreateMenu();
    AppendMenuA(hEdit, MF_STRING, ID_EDIT_UNDO, "&Undo\tCtrl+Z");
    AppendMenuA(hEdit, MF_STRING, ID_EDIT_REDO, "&Redo\tCtrl+Y");
    AppendMenuA(hEdit, MF_SEPARATOR, 0, nullptr);
    AppendMenuA(hEdit, MF_STRING, ID_EDIT_CUT, "Cu&t\tCtrl+X");
    AppendMenuA(hEdit, MF_STRING, ID_EDIT_COPY, "&Copy\tCtrl+C");
    AppendMenuA(hEdit, MF_STRING, ID_EDIT_PASTE, "&Paste\tCtrl+V");
    AppendMenuA(hEdit, MF_SEPARATOR, 0, nullptr);
    AppendMenuA(hEdit, MF_STRING, ID_EDIT_SELECT_ALL, "Select &All\tCtrl+A");
    AppendMenuA(hEdit, MF_STRING, ID_EDIT_SELECT_NONE, "Select &None\tCtrl+Shift+A");
    AppendMenuA(hEdit, MF_STRING, ID_EDIT_INVERT, "&Invert Selection\tCtrl+Shift+I");

    HMENU hView = CreateMenu();
    AppendMenuA(hView, MF_STRING, ID_VIEW_ZOOM_IN, "Zoom &In\tCtrl++");
    AppendMenuA(hView, MF_STRING, ID_VIEW_ZOOM_OUT, "Zoom &Out\tCtrl+-");
    AppendMenuA(hView, MF_STRING, ID_VIEW_FIT, "&Fit to Screen\tCtrl+0");
    AppendMenuA(hView, MF_SEPARATOR, 0, nullptr);
    AppendMenuA(hView, MF_STRING, ID_VIEW_GRID, "Toggle &Grid\tCtrl+G");
    AppendMenuA(hView, MF_STRING, ID_VIEW_RULERS, "Toggle &Rulers\tCtrl+R");
    AppendMenuA(hView, MF_STRING, ID_VIEW_CONSOLE, "Toggle &Console\tCtrl+`");

    HMENU hSelect = CreateMenu();
    AppendMenuA(hSelect, MF_STRING, ID_SELECT_ALL, "Select &All");
    AppendMenuA(hSelect, MF_STRING, ID_SELECT_NONE, "Select &None");
    AppendMenuA(hSelect, MF_STRING, ID_SELECT_INVERT, "&Invert Selection");
    AppendMenuA(hSelect, MF_SEPARATOR, 0, nullptr);
    AppendMenuA(hSelect, MF_STRING, ID_SELECT_REGION, "Select by &Region...");
    AppendMenuA(hSelect, MF_STRING, ID_SELECT_ALPHA, "Select by &Alpha Threshold...");

    HMENU hTools = CreateMenu();
    UINT toolId = ID_TOOLS_BASE;
    for (const auto& entry : toolEntries) {
        if (entry.separator) {
            AppendMenuA(hTools, MF_SEPARATOR, 0, nullptr);
        } else {
            AppendMenuA(hTools, MF_STRING, toolId, entry.label.c_str());
            actionMap[toolId] = entry.callback;
            toolId++;
        }
    }

    HMENU hHelp = CreateMenu();
    AppendMenuA(hHelp, MF_STRING, ID_HELP_ABOUT, "&About VoidWalkers Suite");
    AppendMenuA(hHelp, MF_STRING, ID_HELP_CLI, "&CLI Reference");
    AppendMenuA(hHelp, MF_STRING, ID_HELP_DOCS, "&Documentation");

    HMENU hBar = CreateMenu();
    AppendMenuA(hBar, MF_POPUP, (UINT_PTR)hFile, "&File");
    AppendMenuA(hBar, MF_POPUP, (UINT_PTR)hEdit, "&Edit");
    AppendMenuA(hBar, MF_POPUP, (UINT_PTR)hView, "&View");
    AppendMenuA(hBar, MF_POPUP, (UINT_PTR)hSelect, "&Select");
    AppendMenuA(hBar, MF_POPUP, (UINT_PTR)hTools, "&Tools");
    AppendMenuA(hBar, MF_POPUP, (UINT_PTR)hHelp, "&Help");

    return hBar;
}

// ─── Window Procedure ───
static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_CREATE: {
        CREATESTRUCTA* cs = (CREATESTRUCTA*)lParam;
        GuiState* gs = (GuiState*)cs->lpCreateParams;

        // Create console edit control (bottom half)
        gs->hConsole = CreateWindowA("EDIT", "",
            WS_CHILD | WS_VISIBLE | WS_VSCROLL | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL,
            0, cs->cy * 2 / 3, cs->cx, cs->cy / 3,
            hwnd, (HMENU)1, cs->hInstance, nullptr);

        // Create status bar
        gs->hStatus = CreateWindowA("msctls_statusbar32", "",
            WS_CHILD | WS_VISIBLE | SBARS_SIZEGRIP,
            0, cs->cy - 20, cs->cx, 20,
            hwnd, (HMENU)2, cs->hInstance, nullptr);

        // Set font
        HFONT hFont = (HFONT)GetStockObject(ANSI_FIXED_FONT);
        SendMessageA(gs->hConsole, WM_SETFONT, (WPARAM)hFont, TRUE);

        std::string welcome = "VoidWalkers Production Suite — " + gs->toolName + "\r\n";
        welcome += "Root: " + gs->rootPath + "\r\n";
        welcome += "Bit Depth: " + std::to_string(gs->bitDepth) + "-bit\r\n";
        welcome += "Ready.\r\n";
        ConsolePrint(welcome);
        break;
    }
    case WM_SIZE: {
        if (g_gui && g_gui->hConsole && g_gui->hStatus) {
            int w = LOWORD(lParam), h = HIWORD(lParam);
            SendMessageA(g_gui->hStatus, WM_SIZE, 0, 0);
            MoveWindow(g_gui->hConsole, 0, h * 2 / 3, w, h / 3 - 20, TRUE);
        }
        break;
    }
    case WM_COMMAND: {
        UINT id = LOWORD(wParam);
        if (!g_gui) break;

        // Check tool-specific actions first
        auto it = g_gui->actionMap.find(id);
        if (it != g_gui->actionMap.end()) {
            it->second();
            break;
        }

        switch (id) {
        case ID_FILE_NEW:
            ConsolePrint("[ACTION] New Project");
            break;
        case ID_FILE_OPEN:
            ConsolePrint("[ACTION] Open File (dialog)");
            {
                char path[MAX_PATH] = {0};
                OPENFILENAMEA ofn = {};
                ofn.lStructSize = sizeof(ofn);
                ofn.hwndOwner = hwnd;
                ofn.lpstrFilter = "All Files\0*.*\0PNG Images\0*.png\0JSON\0*.json\0";
                ofn.lpstrFile = path;
                ofn.nMaxFile = MAX_PATH;
                ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
                if (GetOpenFileNameA(&ofn)) {
                    ConsolePrint(std::string("[OPEN] ") + path);
                }
            }
            break;
        case ID_FILE_SAVE:
            ConsolePrint("[ACTION] Save");
            break;
        case ID_FILE_SAVE_AS:
            ConsolePrint("[ACTION] Save As (dialog)");
            break;
        case ID_FILE_IMPORT:
            ConsolePrint("[ACTION] Import Asset (dialog)");
            break;
        case ID_FILE_EXPORT:
            ConsolePrint("[ACTION] Export (dialog)");
            break;
        case ID_FILE_PREFS:
            ConsolePrint("[ACTION] Preferences");
            break;
        case ID_FILE_EXIT:
            PostMessageA(hwnd, WM_CLOSE, 0, 0);
            break;
        case ID_EDIT_UNDO: ConsolePrint("[ACTION] Undo"); break;
        case ID_EDIT_REDO: ConsolePrint("[ACTION] Redo"); break;
        case ID_EDIT_CUT: ConsolePrint("[ACTION] Cut"); break;
        case ID_EDIT_COPY: ConsolePrint("[ACTION] Copy"); break;
        case ID_EDIT_PASTE: ConsolePrint("[ACTION] Paste"); break;
        case ID_EDIT_SELECT_ALL:
        case ID_SELECT_ALL:
            ConsolePrint("[ACTION] Select All");
            if (g_gui->hStatus) SendMessageA(g_gui->hStatus, SB_SETTEXTA, 0, (LPARAM)"Selection: all");
            break;
        case ID_EDIT_SELECT_NONE:
        case ID_SELECT_NONE:
            ConsolePrint("[ACTION] Select None");
            if (g_gui->hStatus) SendMessageA(g_gui->hStatus, SB_SETTEXTA, 0, (LPARAM)"Selection: 0 items");
            break;
        case ID_EDIT_INVERT:
        case ID_SELECT_INVERT:
            ConsolePrint("[ACTION] Invert Selection");
            break;
        case ID_SELECT_REGION: ConsolePrint("[ACTION] Select by Region"); break;
        case ID_SELECT_ALPHA: ConsolePrint("[ACTION] Select by Alpha Threshold"); break;
        case ID_VIEW_ZOOM_IN: ConsolePrint("[ACTION] Zoom In"); break;
        case ID_VIEW_ZOOM_OUT: ConsolePrint("[ACTION] Zoom Out"); break;
        case ID_VIEW_FIT: ConsolePrint("[ACTION] Fit to Screen"); break;
        case ID_VIEW_GRID: ConsolePrint("[ACTION] Toggle Grid"); break;
        case ID_VIEW_RULERS: ConsolePrint("[ACTION] Toggle Rulers"); break;
        case ID_VIEW_CONSOLE:
            if (g_gui->hConsole) {
                BOOL vis = IsWindowVisible(g_gui->hConsole);
                ShowWindow(g_gui->hConsole, vis ? SW_HIDE : SW_SHOW);
            }
            break;
        case ID_HELP_ABOUT:
            MessageBoxA(hwnd,
                "VoidWalkers Production Suite v1.0.0\n"
                "Liminal Lore Agentic Game Development\n\n"
                "AtlasArchitect | SpriteSlicer | FidelityForge | RigForge\n"
                "Ford Automation for Game Dev",
                "About", MB_OK | MB_ICONINFORMATION);
            break;
        case ID_HELP_CLI:
            ConsolePrint("[HELP] Use --help flag for CLI reference");
            break;
        case ID_HELP_DOCS:
            ConsolePrint("[HELP] See study/VoidWalkers_Production_Suite_Blueprint_Jul5_2026.md");
            break;
        }
        break;
    }
    case WM_CLOSE:
        DestroyWindow(hwnd);
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProcA(hwnd, msg, wParam, lParam);
    }
    return 0;
}

// ─── Run GUI Mode ───
int runGui(const std::string& toolName,
           const std::vector<ToolMenuEntry>& toolEntries,
           const std::string& rootPath = "",
           int bitDepth = 32) {

    static GuiState guiState;
    g_gui = &guiState;
    guiState.toolName = toolName;
    guiState.rootPath = rootPath.empty() ? "." : rootPath;
    guiState.bitDepth = bitDepth;
    guiState.toolEntries = toolEntries;

    HINSTANCE hInst = GetModuleHandleA(nullptr);
    std::string className = "VoidWalkers_" + toolName;

    WNDCLASSEXA wc = {};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszClassName = className.c_str();
    wc.hIcon = LoadIcon(nullptr, IDI_APPLICATION);
    RegisterClassExA(&wc);

    HMENU hMenu = BuildMenuBar(toolEntries, guiState.actionMap);

    std::string title = "VoidWalkers Production Suite — " + toolName;

    HWND hwnd = CreateWindowExA(
        0, className.c_str(), title.c_str(),
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, 900, 600,
        nullptr, hMenu, hInst, &guiState);

    if (!hwnd) {
        MessageBoxA(nullptr, "Failed to create window", "Error", MB_OK | MB_ICONERROR);
        return 1;
    }

    guiState.hMain = hwnd;
    ShowWindow(hwnd, SW_SHOW);
    UpdateWindow(hwnd);

    // Set status bar text
    if (guiState.hStatus) {
        std::string status = (std::string("Tool: ") + toolName + "  |  ").c_str();
        SendMessageA(guiState.hStatus, SB_SETTEXTA, 0, (LPARAM)(std::string("Tool: ") + toolName).c_str());
        SendMessageA(guiState.hStatus, SB_SETTEXTA, 1, (LPARAM)(std::string("Bit Depth: ") + std::to_string(bitDepth) + "-bit").c_str());
        SendMessageA(guiState.hStatus, SB_SETTEXTA, 2, (LPARAM)"Status: Idle");
    }

    MSG msg;
    while (GetMessageA(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageA(&msg);
    }

    g_gui = nullptr;
    return (int)msg.wParam;
}

// ─── Check for --gui flag ───
bool hasGuiFlag(int argc, char* argv[]) {
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--gui" || arg == "-g") return true;
    }
    return false;
}

} // namespace Win32Menu
