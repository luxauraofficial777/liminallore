"""Token counting service with gigatoken acceleration and heuristic fallback.

Provides exact token counts using gigatoken (Rust BPE tokenizer, ~1000x faster
than HuggingFace). Falls back to tiktoken or len//4 heuristic if unavailable.

Usage:
    from shared.token_counter import count_tokens, get_token_counter

    # Simple count
    n = count_tokens("Hello world")

    # Full API
    tc = get_token_counter("qwen2.5-coder:7b")
    n = tc.count("Hello world")
    chunks = tc.split_by_tokens(text, max_tokens=512, overlap_tokens=64)
    fits = tc.fits_in_context(prompt, system, max_output=1024, context_window=32768)
"""

from __future__ import annotations

import os
import threading
from typing import List, Optional

# ── Model name mapping: Ollama model → HuggingFace tokenizer repo ──

MODEL_MAP = {
    # Qwen family
    "qwen2.5-coder:7b":       "Qwen/Qwen2.5-Coder-7B-Instruct",
    "qwen2.5-coder:14b":      "Qwen/Qwen2.5-Coder-14B-Instruct",
    "qwen2.5-coder:32b":      "Qwen/Qwen2.5-Coder-32B-Instruct",
    "qwen2.5:7b":             "Qwen/Qwen2.5-7B-Instruct",
    "qwen2.5:14b":            "Qwen/Qwen2.5-14B-Instruct",
    "qwen3:8b":               "Qwen/Qwen3-8B",
    # DeepSeek family
    "deepseek-coder:6.7b":    "deepseek-ai/deepseek-coder-6.7b-instruct",
    "deepseek-coder:33b":     "deepseek-ai/deepseek-coder-33b-instruct",
    "deepseek-r1:7b":         "deepseek-ai/DeepSeek-R1-Distill-Qwen-7B",
    "deepseek-r1:14b":        "deepseek-ai/DeepSeek-R1-Distill-Qwen-14B",
    # Llama family
    "llama3.1:8b":            "meta-llama/Llama-3.1-8B",
    "llama3.1:70b":           "meta-llama/Llama-3.1-70B",
    "llama3.2:3b":            "meta-llama/Llama-3.2-3B",
    # Mistral
    "mistral:7b":             "mistralai/Mistral-7B-v0.3",
    # Phi
    "phi4:14b":               "microsoft/Phi-4",
    "phi3:14b":               "microsoft/Phi-3-medium-4k-instruct",
    # Gemma
    "gemma3:4b":              "google/gemma-3-4b-it",
    "gemma3:12b":             "google/gemma-3-12b-it",
    # Lux Aura custom (Qwen-based distillations)
    "lux-architect:latest":   "Qwen/Qwen2.5-Coder-7B-Instruct",
    "nex:latest":             "Qwen/Qwen2.5-Coder-7B-Instruct",
    "nexx:latest":            "Qwen/Qwen2.5-Coder-7B-Instruct",
    "n3x:latest":             "Qwen/Qwen2.5-Coder-7B-Instruct",
}

# ── Context windows per model (tokens) ──

CONTEXT_WINDOWS = {
    "qwen2.5-coder:7b":       32768,
    "qwen2.5-coder:14b":      32768,
    "qwen2.5-coder:32b":      32768,
    "qwen2.5:7b":             32768,
    "qwen2.5:14b":            32768,
    "qwen3:8b":               40960,
    "deepseek-coder:6.7b":    16384,
    "deepseek-coder:33b":     16384,
    "deepseek-r1:7b":         65536,
    "deepseek-r1:14b":        65536,
    "llama3.1:8b":            131072,
    "llama3.1:70b":           131072,
    "llama3.2:3b":            131072,
    "mistral:7b":             32768,
    "phi4:14b":               16384,
    "phi3:14b":               4096,
    "gemma3:4b":              131072,
    "gemma3:12b":             131072,
    "lux-architect:latest":   32768,
    "nex:latest":             32768,
    "nexx:latest":            32768,
    "n3x:latest":             32768,
}

DEFAULT_CONTEXT_WINDOW = 8192
HEURISTIC_CHARS_PER_TOKEN = 4


class TokenCounter:
    """Token counting service with gigatoken acceleration and heuristic fallback."""

    def __init__(self, model: str = "qwen2.5-coder:7b"):
        self.model = model
        self._hf_name = MODEL_MAP.get(model, MODEL_MAP.get(model.lower(), ""))
        self._tokenizer = None
        self._provider = "uninitialized"
        self._lock = threading.Lock()
        self._init_error: Optional[str] = None

    def _ensure_tokenizer(self) -> None:
        """Lazy-load the tokenizer on first use. Thread-safe."""
        if self._tokenizer is not None or self._provider != "uninitialized":
            return
        with self._lock:
            if self._tokenizer is not None or self._provider != "uninitialized":
                return

            # Check if gigatoken is enabled
            if os.environ.get("GIGATOKEN_ENABLED", "true").lower() == "false":
                self._provider = "heuristic"
                return

            # Try gigatoken first
            try:
                import gigatoken as gt
                if self._hf_name:
                    self._tokenizer = gt.Tokenizer(self._hf_name)
                else:
                    # Try with the raw model name
                    self._tokenizer = gt.Tokenizer(self.model)
                self._provider = "gigatoken"
                return
            except Exception as e:
                self._init_error = f"gigatoken: {e}"

            # Try tiktoken as fallback
            try:
                import tiktoken
                self._tokenizer = tiktoken.get_encoding("cl100k_base")
                self._provider = "tiktoken"
                return
            except Exception as e:
                self._init_error = f"gigatoken: {self._init_error}; tiktoken: {e}"

            # Final fallback: heuristic
            self._provider = "heuristic"

    @property
    def available(self) -> bool:
        """True if gigatoken or tiktoken is loaded (not heuristic)."""
        self._ensure_tokenizer()
        return self._provider != "heuristic"

    @property
    def tokenizer_name(self) -> str:
        """The provider name in use."""
        self._ensure_tokenizer()
        if self._provider == "gigatoken":
            return self._hf_name or self.model
        return self._provider

    @property
    def provider(self) -> str:
        """The provider type: 'gigatoken', 'tiktoken', or 'heuristic'."""
        self._ensure_tokenizer()
        return self._provider

    def count(self, text: str) -> int:
        """Count tokens in a string."""
        if not text:
            return 0
        self._ensure_tokenizer()

        if self._provider == "gigatoken":
            try:
                result = self._tokenizer.encode(text)
                return int(len(result))
            except Exception:
                return len(text) // HEURISTIC_CHARS_PER_TOKEN

        elif self._provider == "tiktoken":
            try:
                return len(self._tokenizer.encode(text))
            except Exception:
                return len(text) // HEURISTIC_CHARS_PER_TOKEN

        else:
            return len(text) // HEURISTIC_CHARS_PER_TOKEN

    def count_batch(self, texts: List[str]) -> List[int]:
        """Count tokens in multiple strings."""
        if not texts:
            return []
        self._ensure_tokenizer()

        if self._provider == "gigatoken":
            try:
                results = self._tokenizer.encode_batch(texts)
                return [int(len(r)) for r in results]
            except Exception:
                return [len(t) // HEURISTIC_CHARS_PER_TOKEN for t in texts]

        elif self._provider == "tiktoken":
            try:
                return [len(self._tokenizer.encode(t)) for t in texts]
            except Exception:
                return [len(t) // HEURISTIC_CHARS_PER_TOKEN for t in texts]

        else:
            return [len(t) // HEURISTIC_CHARS_PER_TOKEN for t in texts]

    def truncate_to_budget(self, text: str, max_tokens: int,
                           overlap: int = 0) -> str:
        """Truncate text to fit within max_tokens.

        If text exceeds max_tokens, finds a boundary near the limit and truncates.
        """
        if not text:
            return ""
        current = self.count(text)
        if current <= max_tokens:
            return text

        # Binary search for the truncation point
        lo, hi = 0, len(text)
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if self.count(text[:mid]) <= max_tokens:
                lo = mid
            else:
                hi = mid - 1

        # Try to break at a sentence or word boundary
        cutoff = lo
        for pattern in ["\n\n", "\n", ". ", "! ", "? ", "; ", ", ", " "]:
            pos = text.rfind(pattern, max(0, cutoff - 100), cutoff)
            if pos > max(0, cutoff - 200):
                cutoff = pos + len(pattern)
                break

        return text[:cutoff]

    def fits_in_context(self, prompt: str, system: str = "",
                        max_output: int = 2048,
                        context_window: Optional[int] = None) -> bool:
        """Check if prompt + system + max_output fits in context window."""
        ctx = context_window or self.get_context_window()
        prompt_tokens = self.count(prompt) + self.count(system)
        return prompt_tokens + max_output <= ctx

    def budget_for_rag(self, query: str, system: str = "",
                       max_output: int = 2048,
                       context_window: Optional[int] = None) -> int:
        """Calculate remaining token budget for RAG context injection.

        Returns max tokens available for RAG results after accounting for
        query, system prompt, and output budget.
        """
        ctx = context_window or self.get_context_window()
        used = self.count(query) + self.count(system) + max_output
        return max(0, ctx - used)

    def split_by_tokens(self, text: str, max_tokens: int = 512,
                        overlap_tokens: int = 64) -> List[str]:
        """Split text into chunks of at most max_tokens with overlap."""
        if not text or not text.strip():
            return []

        self._ensure_tokenizer()

        # If we have gigatoken, use exact token counting for splitting
        if self._provider in ("gigatoken", "tiktoken"):
            return self._split_by_tokens_exact(text, max_tokens, overlap_tokens)
        else:
            # Fallback: character-based with heuristic ratio
            max_chars = max_tokens * HEURISTIC_CHARS_PER_TOKEN
            overlap_chars = overlap_tokens * HEURISTIC_CHARS_PER_TOKEN
            return self._split_by_chars(text, max_chars, overlap_chars)

    def _split_by_tokens_exact(self, text: str, max_tokens: int,
                               overlap_tokens: int) -> List[str]:
        """Split using exact token counting with boundary detection."""
        total_tokens = self.count(text)
        if total_tokens <= max_tokens:
            return [text.strip()] if text.strip() else []

        chunks = []
        start = 0
        text_len = len(text)

        while start < text_len:
            # Estimate end position based on token/char ratio
            if start < text_len:
                partial = text[start:]
                partial_tokens = self.count(partial)
                if partial_tokens <= max_tokens:
                    if partial.strip():
                        chunks.append(partial.strip())
                    break

                # Estimate where to cut
                ratio = max_tokens / partial_tokens
                est_end = start + int(text_len * ratio * 0.9)  # 90% to be safe
                est_end = min(est_end, text_len)

                # Find a good boundary near est_end
                end = self._find_token_boundary(text, start, est_end, max_tokens)

                chunk = text[start:end].strip()
                if chunk:
                    chunks.append(chunk)

                if end >= text_len:
                    break

                # Calculate overlap start
                overlap_text = text[end:]
                overlap_tokens_actual = min(overlap_tokens, self.count(overlap_text))
                if overlap_tokens_actual > 0:
                    # Find where overlap starts
                    overlap_chars_est = overlap_tokens_actual * HEURISTIC_CHARS_PER_TOKEN
                    next_start = end - overlap_chars_est
                    if next_start <= start:
                        next_start = start + max(1, end - start)
                else:
                    next_start = end

                start = next_start
            else:
                break

        return chunks

    def _find_token_boundary(self, text: str, start: int, est_end: int,
                             max_tokens: int) -> int:
        """Find a good split point near est_end that stays within max_tokens."""
        # Try sentence/paragraph boundaries first
        for pattern in ["\n\n", "\n", ". ", "! ", "? ", "; ", ", ", " "]:
            pos = text.rfind(pattern, start + 50, est_end)
            if pos > start + 50:
                candidate = pos + len(pattern)
                if self.count(text[start:candidate]) <= max_tokens:
                    return candidate

        # Binary search for exact token limit
        lo, hi = start, est_end
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if self.count(text[start:mid]) <= max_tokens:
                lo = mid
            else:
                hi = mid - 1
        return lo

    def _split_by_chars(self, text: str, max_chars: int,
                        overlap_chars: int) -> List[str]:
        """Character-based fallback splitting."""
        text = text.strip()
        if len(text) <= max_chars:
            return [text] if text else []

        chunks = []
        start = 0
        while start < len(text):
            end = start + max_chars
            if end >= len(text):
                end = len(text)
            else:
                # Try to break at a boundary
                for pattern in ["\n\n", "\n", ". ", "! ", "? ", "; ", ", ", " "]:
                    pos = text.rfind(pattern, start + 100, end)
                    if pos > start + 100:
                        end = pos + len(pattern)
                        break

            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)
            if end >= len(text):
                break
            next_start = end - overlap_chars
            if next_start <= start:
                next_start = start + max(100, end - start)
            start = next_start

        return chunks

    def get_context_window(self) -> int:
        """Get the context window size for this model."""
        return CONTEXT_WINDOWS.get(self.model, DEFAULT_CONTEXT_WINDOW)


# ── Module-level singleton ──

_default_counter: Optional[TokenCounter] = None
_singleton_lock = threading.Lock()


def get_token_counter(model: str = "qwen2.5-coder:7b") -> TokenCounter:
    """Get or create the default TokenCounter singleton."""
    global _default_counter
    if _default_counter is None or _default_counter.model != model:
        with _singleton_lock:
            if _default_counter is None or _default_counter.model != model:
                _default_counter = TokenCounter(model)
    return _default_counter


def count_tokens(text: str, model: str = "qwen2.5-coder:7b") -> int:
    """Convenience function: count tokens in text."""
    return get_token_counter(model).count(text)


def split_by_tokens(text: str, max_tokens: int = 512,
                    overlap_tokens: int = 64,
                    model: str = "qwen2.5-coder:7b") -> List[str]:
    """Convenience function: split text by token count."""
    return get_token_counter(model).split_by_tokens(text, max_tokens, overlap_tokens)
