"""FUBBU — Fully Unmanaged Backbone Bridge Unit.

A self-hosted, local multi-agent orchestration sidecar that runs as an
independent OS process alongside the VW Nexus. It implements a
Router-Worker-Verifier loop using local open-weight models (Ollama/vLLM)
for heavy low-level debugging tasks.

Design Principles:
  1. Process isolation — FUBBU runs as a subprocess, never imported into Nexus
  2. State containment — separate SQLite DB (fubbu_state.db), never writes to nexus_state.db
  3. API-only Nexus communication — all Nexus interaction via HTTP, never shared memory
  4. Structural verification — deterministic checks before model-based advisory
  5. Topology tracking — every Think→Route→Delegate→Execute→Verify step is logged

Architecture:
  nexus_router_bridge.py (entry point)
  ├── fubbu_router.py     — task decomposition + RAG context + worker assignment
  ├── fubbu_worker.py     — Ollama/vLLM inference client + prompt builder
  ├── fubbu_verifier.py   — structural checks + advisory model call
  ├── fubbu_state.py      — isolated SQLite state (fubbu_state.db)
  ├── fubbu_nexus_client.py — thin HTTP client wrapping Nexus API
  ├── fubbu_telemetry.py  — step tracking + state mirroring + metrics
  └── fubbu_topography.py — agent communication topology map (Think→Route→...→Verify)
"""

__version__ = "1.0.0"
__author__ = "Lux Aura — Void Walkers Project"

# Module exports
from .fubbu_state import FubbuState
from .fubbu_nexus_client import FubbuNexusClient
from .fubbu_telemetry import FubbuTelemetry, StepType, StepStatus
from .fubbu_topography import FubbuTopography, TopologyNode, TopologyEdge, NodeType
from .fubbu_router import FubbuRouter
from .fubbu_worker import FubbuWorker
from .fubbu_verifier import FubbuVerifier
from .nexus_router_bridge import FubbuSidecar
from .fubbu_worker import parse_fubbu_directive

__all__ = [
    "FubbuState",
    "FubbuNexusClient",
    "FubbuTelemetry",
    "StepType",
    "StepStatus",
    "FubbuTopography",
    "TopologyNode",
    "TopologyEdge",
    "NodeType",
    "FubbuRouter",
    "FubbuWorker",
    "FubbuVerifier",
    "FubbuSidecar",
    "parse_fubbu_directive",
]
