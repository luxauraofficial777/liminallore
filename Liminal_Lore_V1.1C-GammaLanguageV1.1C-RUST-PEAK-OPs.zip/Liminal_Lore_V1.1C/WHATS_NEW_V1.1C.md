# What's New in Liminal Lore V1.1C

**August 10, 2026**

V1.1C is a major feature release that brings full GammaLanguage v1.1C (A2A-DSL) compatibility to the entire Liminal Lore suite. Every subsystem now speaks the same A2A-DSL protocol, enabling compressed inter-agent communication, hardware-aware opcode dispatch, and directive-based routing.

---

## GammaLanguage v1.1C — Full Suite Compatibility

### Caveman Prompt Compression Everywhere

All LLM call sites across FUBBU (Router, Worker, Verifier) and ZHARK (5 call sites) now apply Caveman compression before sending prompts to the model. This cuts approximately 65% of input tokens while keeping code, commands, and error messages byte-for-byte exact.

**Affected call sites:**
- FUBBU Router: `_call_router_model()`
- FUBBU Worker: `_call_model()` (already had v1.1A compression, now v1.1C-aware)
- FUBBU Verifier: `_call_verifier_model()`
- ZHARK: `_call_llm()` for hypothesis, analysis, verification, sub-hypothesis, and causal mapping

### TurboQuant Capacity Checks

FUBBU Worker now performs a pre-flight TurboQuant RAM pressure check before inference. If utilization exceeds 85%, `max_tokens` is automatically reduced to prevent OOM. This check uses `GammaBridge.check_turboquant_capacity()`.

### Directive Routing

The VW Nexus WebSocket bus now detects and routes two new directive sigils:

- **`?ZHARK`** — Routes to the ZHARK orchestrator for autonomous research delegation
- **`¿FUBBU`** — Routes to the FUBBU sidecar for multi-agent task decomposition

Both directives are parsed by their respective subsystems (`parse_zhark_directive`, `parse_fubbu_directive`) and exported from their package `__init__.py` files. The WebSocket server imports these parsers with graceful fallback.

### Gamma Frame Output

All subsystems now wrap their outputs in A2A-DSL AST frames that include:
- v1.1C opcodes (`@ALIGN_BOUND`, `CP0_REG_MAP`, `RUST_OFFSET_LOAD`, `RUST_FFI_CALL`, `PSX_DMA_DISPATCH`)
- `v1_1c_features` dictionary with all feature flags
- Standard A2A-B bytecode structure

### v1.1C Opcodes

Five new opcodes added to the A2A_Gamma.h C++ interpreter:

| Opcode | Purpose |
|--------|---------|
| `RUST_OFFSET_LOAD` | Load Rust FFI zero-copy memory offset |
| `RUST_FFI_CALL` | Dispatch via PEAK function pointer table |
| `ALIGN_BOUND` | Parse alignment boundary for memory layout |
| `CP0_REG_MAP` | Map CP0 registers (Status, Cause, EPC, BadVAddr, Count) |
| `PSX_DMA_DISPATCH` | Dispatch PSX DMA channel with HW interrupt |

### Feature Reporting

`get_stats()` across VW Nexus and all subsystems now reports a `gamma_v1_1c` dictionary with all feature flags, enabling monitoring dashboards to display gamma integration status.

---

## Setup Wizard — Step 5c: GammaLanguage v1.1C

The interactive setup wizard now includes a dedicated step for GammaLanguage configuration:

1. **Enable GammaLanguage** — Master toggle
2. **Caveman compression** — Toggle prompt compression on all LLM calls
3. **TurboQuant checks** — Toggle pre-inference RAM capacity checks
4. **Frame output** — Toggle A2A-DSL AST frame wrapping
5. **Directive routing** — Toggle ?ZHARK / ¿FUBBU routing on Nexus bus

All settings are written to `.env` and reflected in the `gamma` section of `liminal_lore.yaml`.

---

## Shipping Manifest Updates

The `run_ship()` validation now checks two additional components:

- **Component 5: FUBBU Sidecar** — Validates 10 module files are present
- **Component 6: GammaLanguage v1.1C** — Validates gamma_bridge.py, gamma_cli.py, and A2A_Gamma.h

---

## Configuration System

### New `gamma` Config Section

```yaml
gamma:
  enabled: true
  version: "v1.1C"
  features:
    - "A2A-B"
    - "#QVEC"
    - "@PREDICT"
    - "%HW_INT"
    - "^EVICT_SLIDING"
    - "&RUST_OFFSET"
    - "@ALIGN_BOUND"
    - "RUST_FFI_CALL"
    - "CP0_REG_MAP"
    - "PSX_DMA_DISPATCH"
  caveman_compress: true
  turboquant_check: true
  frame_output: true
  directive_routing: true
  hive_partitions: true
```

### Environment Variable Overrides

| Variable | Config Path | Default |
|----------|-------------|---------|
| `GAMMA_ENABLED` | `gamma.enabled` | `true` |
| `GAMMA_CAVEMAN_COMPRESS` | `gamma.caveman_compress` | `true` |
| `GAMMA_TURBOQUANT_CHECK` | `gamma.turboquant_check` | `true` |
| `GAMMA_FRAME_OUTPUT` | `gamma.frame_output` | `true` |
| `GAMMA_DIRECTIVE_ROUTING` | `gamma.directive_routing` | `true` |

---

## Backward Compatibility

All gamma features are additive and gracefully degrade:

- If `gamma_bridge` import fails, all Python subsystems operate in legacy mode
- If `A2A_Gamma.h` is absent, the C++ Deck host runs without gamma command support
- Non-Gamma Nexus clients continue to work — JSON is tried first for all incoming messages
- The `gamma` config section is optional; all features can be disabled individually
