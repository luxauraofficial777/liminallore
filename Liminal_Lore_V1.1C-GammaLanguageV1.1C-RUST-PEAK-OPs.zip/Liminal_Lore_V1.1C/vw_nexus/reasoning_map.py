"""Reasoning map module for VW Nexus.

Provides a structured knowledge graph that maps the relationships between
project components, debugging decisions, test results, and architectural
constraints. Queryable via RAG and MCP tools.
"""

from __future__ import annotations

import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


_REASONING_MAP = {
    "version": "2.0",
    "updated": "",
    "projects": {
        "DQLOSTTRANSLATION": {
            "description": "PS1 DQ4 English translation via Frankenstein ROM (DW7 EXE + DQ4 HBD + DW7 body)",
            "status": "active",
            "blockers": [
                "Game crashes at 0x80000000 (null pointer jump) after 2.25M instructions — likely missing HBD data or uninitialized function table",
                "No LBA progress detected — CD-ROM HBD data reads not progressing through emulator state machine",
                "Custom emulator has no GPU rendering — visual verification requires DuckStation",
            ],
            "milestones": [
                "Phase 1 COMPLETE: $ra corruption fixed in 12 BIOS functions, register clobbering fixed, CD-ROM base addr 0x1F801800, GPU base addr 0x1F801800",
                "Phase 1 COMPLETE: CD-ROM command ordering fixed (params before command), BCD conversion for Setloc, data transfer arming (BFRD)",
                "Phase 2 COMPLETE: SIO0 register emulation added (0x1F801000-0x1F80100F) with digital controller response",
                "Phase 2 COMPLETE: BIOS boots past 0xBFC00378, EXE loads (SLPM_869.16), VBlank interrupts firing, 2.25M instructions before game-code crash",
                "v16: 50M instructions stable, 125 VBlanks, but soft-locked (ChangeTh blocked 44x)",
                "Level 6: 200M+ instructions stable, game engine executing, CD-ROM polling",
                "Bootstrap: 500M stable, but black screen (VBlank spin only)",
                "RC2/Native DQ4: both survive 50M instructions with real game init (GPU calls, pad init)",
            ],
            "components": {
                "cybergrime": {
                    "role": "Custom PSX MIPS R3000A emulator with HLE BIOS",
                    "path": "DQLOSTTRANSLATION/cybergrime",
                    "key_files": ["psx_emulator_core.cpp", "psx_agent_runner.cpp", "psx_test_station.h"],
                    "capabilities": ["crash_detection", "bios_call_analysis", "telemetry", "trace"],
                    "limitations": ["no GPU rendering", "no input", "no memory card", "telemetry cap 200M instr"],
                },
                "duckstation_bridge": {
                    "role": "Live bridge to DuckStation for visual verification and memory inspection",
                    "path": "DQLOSTTRANSLATION/cybergrime/duckstation_bridge.py",
                    "capabilities": ["memory_read_write", "register_access", "patch_injection", "telemetry_streaming"],
                },
                "duckstation_supervisor": {
                    "role": "Live monitoring and control of DuckStation process",
                    "path": "DQLOSTTRANSLATION/cybergrime/duckstation_supervisor.py",
                    "capabilities": ["pc_polling", "stall_detection", "patch_injection", "breakpoint_management"],
                },
                "agent_harness": {
                    "role": "Automated regression testing with freeze detection and JSON telemetry",
                    "path": "DQLOSTTRANSLATION/cybergrime/agent_harness.h",
                    "capabilities": ["tty_capture", "vfs_logging", "freeze_detection", "black_screen_detection"],
                },
                "orchestration_engine": {
                    "role": "Dynamic MIPS execution control with instruction-level hooks",
                    "path": "DQLOSTTRANSLATION/cybergrime/orchestration_engine.h",
                    "capabilities": ["hook_table", "pc_autocorrector", "register_watches", "audit_log", "dual_binary_map"],
                },
                "txrt_hle": {
                    "role": "Surgical bypass of Huffman decompression (pre-decoded leaf values)",
                    "path": "DQLOSTTRANSLATION/cybergrime/txrt_hle.h",
                    "strategy": "Intercept at 0x80073670 entry, skip decompression, write pre-decoded values",
                },
                "pipeline_audit": {
                    "role": "End-to-end pipeline verification (assets, compression, symbols, EXE patches, runtime)",
                    "path": "DQLOSTTRANSLATION/cybergrime/pipeline_audit.py",
                },
                "closed_loop_controller": {
                    "role": "Circle of Truth: telemetry -> analysis -> injection -> verification feedback loop",
                    "path": "DQLOSTTRANSLATION/cybergrime/closed_loop_controller.py",
                },
                "build_orchestrator": {
                    "role": "Build synthesis, constraint enforcement, patch threshold, readiness verification",
                    "path": "DQLOSTTRANSLATION/build_orchestrator.py",
                },
                "pipeline_rulebook": {
                    "role": "Five Laws governing patch application and telemetry validation",
                    "path": "DQLOSTTRANSLATION/pipeline_rulebook.py",
                    "laws": [
                        "Law 1: Patch justification - every byte must have a documented reason",
                        "Law 2: Telemetry source - all claims must reference telemetry data",
                        "Law 3: Historical vector check - check past failure signatures before applying",
                        "Law 4: Binary patching discipline - minimal surgical patches only",
                        "Law 5: Asset transformation continuity - track all transformations",
                    ],
                },
                "translation_tools": {
                    "role": "Java patcher, Python HBD patcher, Frankenstein builder, QA tools",
                    "path": "DQLOSTTRANSLATION/translation-tools",
                },
            },
            "critical_addresses": {
                "exe_load": "0x80017F00",
                "exe_end": "0x800BCF00",
                "bss_clear": "0x8008E284",
                "thread_entry": "0x800D9E80",
                "copy_routine": "0x800BCCF0",
                "huffman_tree_dw7": "0x800EF1C8",
                "stall_event_flag": "0x8009885C",
                "code_cave": "0x800B4A68",
                "vector_shadow_region": "0x800E2000-0x800E2400",
                "bios_entry": "0xBFC00000",
                "cdrom_init": "0xBFC0031C",
                "stuck_loop_resolved": "0xBFC00378",
                "cdrom_regs": "0x1F801800-0x1F801803",
                "gpu_regs": "0x1F801810-0x1F801814",
                "sio0_regs": "0x1F801000-0x1F80100F",
                "game_exe_pc": "0x800918F4",
                "game_crash_addr": "0x80000000",
            },
            "test_builds": {
                "vhb_bios": {"status": "boots_past_loop", "crash": False, "stuck_at": "resolved", "instructions": 2250000},
                "v16": {"status": "stable_50m", "crash": False, "softlocked": True},
                "level_6": {"status": "stable_200m", "crash": False, "engine_executing": True},
                "rc2": {"status": "stable_50m", "crash": False, "game_init": True},
                "native_dq4": {"status": "stable_50m", "crash": False, "game_init": True},
            },
        },
        "Modern_X64": {
            "description": "Void Walkers HD - native x64 engine with DX11 rendering",
            "status": "active",
            "components": {
                "vw_nexus": {
                    "role": "Universal orchestration layer for all agents and tools",
                    "path": "Modern_X64/tools/vw_nexus",
                    "capabilities": ["agent_registry", "task_queue", "mcp_server", "rag", "websocket", "telemetry"],
                },
                "vw_rag": {
                    "role": "Multi-corpus vector DB with BM25 + vector similarity search",
                    "path": "Modern_X64/tools/vw_rag",
                    "capabilities": ["indexing", "retrieval", "graph_traversal", "multi_corpus", "telemetry_ingestion"],
                },
                "mcp_server": {
                    "role": "MCP tool server exposing Nexus capabilities to external clients",
                    "path": "Modern_X64/tools/mcp_server",
                    "capabilities": ["tool_registration", "authority_levels", "rate_limiting", "auto_approve"],
                },
                "x64_engine": {
                    "role": "Native x64 game engine (DX11, combat, world map, save system)",
                    "path": "Modern_X64/%DST%",
                    "capabilities": ["dx11_rendering", "combat", "world_map", "save", "audio", "ui"],
                },
                "build_tools": {
                    "role": "CMake build system, asset pipeline, shader compilation",
                    "path": "Modern_X64/tools/build_scripts",
                },
            },
        },
    },
    "cross_project": {
        "shared_infrastructure": ["vw_nexus", "vw_rag", "mcp_server", "agent_auto_register"],
        "shared_agents": ["cascade", "cybergrime_harness", "duckstation_supervisor", "regression_runner"],
        "telemetry_flow": "harness -> telemetry_ingest -> multi_corpus vector DB -> RAG query -> agent decision",
        "decision_flow": "agent -> MCP tool -> Nexus API -> RAG query -> reasoning map -> task creation -> execution",
    },
}


class ReasoningMap:
    """Provides structured access to the project reasoning map."""

    def __init__(self, map_path: Optional[Path] = None):
        self._map_path = map_path
        self._lock = threading.RLock()
        self._map: Dict[str, Any] = dict(_REASONING_MAP)
        self._map["updated"] = datetime.now(timezone.utc).isoformat()

    def get_full_map(self) -> Dict[str, Any]:
        with self._lock:
            return dict(self._map)

    def get_project(self, project_id: str) -> Dict[str, Any]:
        with self._lock:
            return self._map.get("projects", {}).get(project_id, {})

    def list_projects(self) -> List[Dict[str, Any]]:
        with self._lock:
            return [
                {"project_id": pid, "description": p.get("description", ""), "status": p.get("status", "unknown")}
                for pid, p in self._map.get("projects", {}).items()
            ]

    def get_component(self, project_id: str, component_id: str) -> Dict[str, Any]:
        with self._lock:
            project = self._map.get("projects", {}).get(project_id, {})
            return project.get("components", {}).get(component_id, {})

    def get_blockers(self, project_id: str) -> List[str]:
        with self._lock:
            return self._map.get("projects", {}).get(project_id, {}).get("blockers", [])

    def get_milestones(self, project_id: str) -> List[str]:
        with self._lock:
            return self._map.get("projects", {}).get(project_id, {}).get("milestones", [])

    def get_critical_addresses(self, project_id: str) -> Dict[str, str]:
        with self._lock:
            return self._map.get("projects", {}).get(project_id, {}).get("critical_addresses", {})

    def get_rules(self, project_id: str) -> List[str]:
        with self._lock:
            project = self._map.get("projects", {}).get(project_id, {})
            rulebook = project.get("components", {}).get("pipeline_rulebook", {})
            return rulebook.get("laws", [])

    def query(self, query: str) -> Dict[str, Any]:
        """Natural language query against the reasoning map."""
        query_lower = query.lower()
        query_terms = [t for t in query_lower.split() if len(t) > 2]
        results = []

        with self._lock:
            for pid, project in self._map.get("projects", {}).items():
                # Check if project ID or any query term matches
                desc = project.get("description", "").lower()
                if any(t in pid.lower() or t in desc for t in query_terms) or pid.lower() in query_lower:
                    results.append({"type": "project", "project_id": pid, "data": project})

                for cid, comp in project.get("components", {}).items():
                    role = comp.get("role", "").lower()
                    if any(t in cid.lower() or t in role for t in query_terms) or cid.lower() in query_lower:
                        results.append({"type": "component", "project_id": pid, "component_id": cid, "data": comp})

                for addr_name, addr_val in project.get("critical_addresses", {}).items():
                    if addr_val.lower() in query_lower or addr_name.lower() in query_lower:
                        results.append({"type": "address", "project_id": pid, "name": addr_name, "value": addr_val})

                # Check milestones and blockers for query terms
                for ms in project.get("milestones", []):
                    if any(t in ms.lower() for t in query_terms):
                        results.append({"type": "milestone", "project_id": pid, "text": ms})

                for blocker in project.get("blockers", []):
                    if any(t in blocker.lower() for t in query_terms):
                        results.append({"type": "blocker", "project_id": pid, "text": blocker})

            for key, val in self._map.get("cross_project", {}).items():
                if key.lower() in query_lower:
                    results.append({"type": "cross_project", "key": key, "data": val})

        return {
            "query": query,
            "results": results,
            "total": len(results),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def update_project(self, project_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        with self._lock:
            if project_id not in self._map.get("projects", {}):
                self._map.setdefault("projects", {})[project_id] = {}
            self._map["projects"][project_id].update(data)
            self._map["updated"] = datetime.now(timezone.utc).isoformat()
        return {"ok": True, "project_id": project_id}

    def add_blocker(self, project_id: str, blocker: str) -> Dict[str, Any]:
        with self._lock:
            project = self._map.setdefault("projects", {}).setdefault(project_id, {})
            project.setdefault("blockers", []).append(blocker)
            self._map["updated"] = datetime.now(timezone.utc).isoformat()
        return {"ok": True, "project_id": project_id, "blocker": blocker}

    def resolve_blocker(self, project_id: str, blocker_index: int) -> Dict[str, Any]:
        with self._lock:
            project = self._map.get("projects", {}).get(project_id, {})
            blockers = project.get("blockers", [])
            if 0 <= blocker_index < len(blockers):
                resolved = blockers.pop(blocker_index)
                self._map["updated"] = datetime.now(timezone.utc).isoformat()
                return {"ok": True, "resolved": resolved}
            return {"ok": False, "error": "Invalid blocker index"}

    def status(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "version": self._map.get("version"),
                "updated": self._map.get("updated"),
                "projects": [pid for pid in self._map.get("projects", {})],
                "total_components": sum(
                    len(p.get("components", {}))
                    for p in self._map.get("projects", {}).values()
                ),
                "total_blockers": sum(
                    len(p.get("blockers", []))
                    for p in self._map.get("projects", {}).values()
                ),
            }

    def save(self, path: Optional[Path] = None) -> Dict[str, Any]:
        save_path = path or self._map_path
        if not save_path:
            return {"ok": False, "error": "No path specified"}
        try:
            with self._lock:
                save_path.write_text(json.dumps(self._map, indent=2, default=str), encoding="utf-8")
            return {"ok": True, "path": str(save_path)}
        except Exception as e:
            return {"ok": False, "error": str(e)}
