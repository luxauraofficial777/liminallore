"""Nexus integration for the universal ProviderRegistry.

Wires the ProviderRegistry singleton into the Nexus API, exposing
provider status, health checks, and generation routing via REST endpoints
and MCP tools.
"""

from __future__ import annotations

import json
import sys
import os
from pathlib import Path
from typing import Any, Dict

from .mcp_server import register_tool

# Ensure AGENT/distilled_agents is on sys.path for provider_registry import
_AGENT_DIR = Path(__file__).parent.parent.parent.parent.parent / "AGENT" / "distilled_agents"
if str(_AGENT_DIR) not in sys.path:
    sys.path.insert(0, str(_AGENT_DIR))

from provider_registry import ProviderRegistry


def _get_registry() -> ProviderRegistry:
    """Get the ProviderRegistry singleton."""
    return ProviderRegistry.instance()


def load_registry_from_config_file(config_path: str = None) -> ProviderRegistry:
    """Load provider configurations from vw_deck.config.json."""
    if config_path is None:
        # _AGENT_DIR = .../VoidWalkers_Project/AGENT/distilled_agents
        # Project root = _AGENT_DIR.parent.parent = .../VoidWalkers_Project
        project_root = _AGENT_DIR.parent.parent
        config_path = str(project_root / "Modern_X64" / "tools" / "Liminal_Lore_V101B" / "liminal_lore_vw_deck" / "vw_deck.config.json")
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        registry_config = cfg.get("provider_registry", {})
        if registry_config.get("enabled", False):
            reg = _get_registry()
            reg.load_from_config(registry_config)
            return reg
    except Exception as e:
        print(f"ProviderRegistry config load failed: {e}", file=sys.stderr)
    return _get_registry()


def register_provider_mcp_tools(nexus: Any) -> None:
    """Register ProviderRegistry MCP tools in the Nexus framework."""

    def _provider_list(args: Dict) -> Dict:
        reg = _get_registry()
        return {"providers": reg.list_providers(), "summary": reg.summary()}

    def _provider_status(args: Dict) -> Dict:
        reg = _get_registry()
        provider_id = args.get("provider_id", "")
        if provider_id:
            return reg.status_one(provider_id)
        return reg.status_all()

    def _provider_health(args: Dict) -> Dict:
        reg = _get_registry()
        provider_id = args.get("provider_id", "")
        if provider_id:
            return reg.health_check_one(provider_id)
        return reg.health_check_all()

    def _provider_generate(args: Dict) -> Dict:
        reg = _get_registry()
        return reg.generate(
            provider_id=args.get("provider_id", ""),
            prompt=args.get("prompt", ""),
            model=args.get("model", ""),
            max_tokens=args.get("max_tokens", 2048),
            temperature=args.get("temperature", 0.7),
            stream=args.get("stream", False),
        )

    def _provider_find_model(args: Dict) -> Dict:
        reg = _get_registry()
        model_name = args.get("model", "")
        provider_id = reg.find_model(model_name)
        return {"model": model_name, "provider": provider_id, "found": provider_id is not None}

    def _provider_register(args: Dict) -> Dict:
        reg = _get_registry()
        return reg.register_provider(args.get("config", {}))

    def _provider_unregister(args: Dict) -> Dict:
        reg = _get_registry()
        return reg.unregister_provider(args.get("provider_id", ""))

    def _provider_update_config(args: Dict) -> Dict:
        reg = _get_registry()
        return reg.update_provider_config(
            args.get("provider_id", ""),
            args.get("updates", {}),
        )

    register_tool(
        "provider_list",
        "List all registered LLM/agentic providers and summary stats",
        {},
        _provider_list,
        "read",
    )

    register_tool(
        "provider_status",
        "Get status of one or all providers (alive, models, circuit breaker, latency)",
        {"provider_id": {"type": "string"}},
        _provider_status,
        "read",
    )

    register_tool(
        "provider_health",
        "Run health check on one or all providers",
        {"provider_id": {"type": "string"}},
        _provider_health,
        "execute",
    )

    register_tool(
        "provider_generate",
        "Route a generation request to a specific provider",
        {
            "provider_id": {"type": "string", "required": True},
            "prompt": {"type": "string", "required": True},
            "model": {"type": "string"},
            "max_tokens": {"type": "integer", "default": 2048},
            "temperature": {"type": "number", "default": 0.7},
        },
        _provider_generate,
        "execute",
    )

    register_tool(
        "provider_find_model",
        "Find which provider hosts a given model",
        {"model": {"type": "string", "required": True}},
        _provider_find_model,
        "read",
    )

    register_tool(
        "provider_register",
        "Dynamically register a new provider at runtime",
        {"config": {"type": "object", "required": True}},
        _provider_register,
        "write",
    )

    register_tool(
        "provider_unregister",
        "Remove a provider from the registry",
        {"provider_id": {"type": "string", "required": True}},
        _provider_unregister,
        "write",
    )

    register_tool(
        "provider_update_config",
        "Update a provider's configuration at runtime (endpoint, debug, enabled, etc.)",
        {
            "provider_id": {"type": "string", "required": True},
            "updates": {"type": "object", "required": True},
        },
        _provider_update_config,
        "write",
    )

    # ── Cursor-specific tools ──────────────────────────────────────

    def _cursor_active_runs(args: Dict) -> Dict:
        reg = _get_registry()
        provider = reg.get_provider("cursor_cloud_agent")
        if not provider or not hasattr(provider, "get_active_runs"):
            return {"ok": False, "error": "Cursor provider not registered"}
        return {"ok": True, "active_runs": provider.get_active_runs()}

    def _cursor_cancel_run(args: Dict) -> Dict:
        reg = _get_registry()
        provider = reg.get_provider("cursor_cloud_agent")
        if not provider or not hasattr(provider, "cancel_run"):
            return {"ok": False, "error": "Cursor provider not registered"}
        return provider.cancel_run(args.get("run_id", ""))

    def _cursor_audit_logs(args: Dict) -> Dict:
        reg = _get_registry()
        provider = reg.get_provider("cursor_cloud_agent")
        if not provider or not hasattr(provider, "get_audit_logs"):
            return {"ok": False, "error": "Cursor provider not registered"}
        return provider.get_audit_logs(args.get("since", ""))

    register_tool(
        "cursor_active_runs",
        "List currently active Cursor Cloud Agent runs",
        {},
        _cursor_active_runs,
        "read",
    )

    register_tool(
        "cursor_cancel_run",
        "Cancel an active Cursor Cloud Agent run",
        {"run_id": {"type": "string", "required": True}},
        _cursor_cancel_run,
        "execute",
    )

    register_tool(
        "cursor_audit_logs",
        "Fetch audit logs from Cursor Enterprise Admin API for nexus_telemetry integration",
        {"since": {"type": "string"}},
        _cursor_audit_logs,
        "read",
    )
