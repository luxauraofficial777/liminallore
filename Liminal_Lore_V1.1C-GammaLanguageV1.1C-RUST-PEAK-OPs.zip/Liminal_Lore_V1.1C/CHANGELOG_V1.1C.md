# Changelog — Liminal Lore Deck V1.1C

**Date:** August 10, 2026  
**Type:** Major Feature Release  
**Previous:** V1.1B (Aug 9, 2026)

---

## Overview

V1.1C upgrades the entire Liminal Lore suite to full GammaLanguage v1.1C (A2A-DSL) compatibility. All subsystems — FUBBU, ZHARK, VW Nexus, and the C++ Deck host — now support Caveman prompt compression, TurboQuant capacity checks, directive routing, and A2A-DSL AST frame output with v1.1C opcodes. The setup wizard and config system have been updated with interactive gamma configuration.

---

## New Features

### 1. GammaLanguage v1.1C — Full Suite Integration

#### FUBBU Worker (`fubbu/fubbu_worker.py`)
- **TurboQuant capacity check** — pre-flight RAM pressure check before inference; reduces `max_tokens` if >85% utilization
- **`parse_fubbu_directive()`** — parses ¿FUBBU sigil directives from Gamma scripts
- **Enhanced gamma frame** — output frame includes v1.1C opcodes (`@ALIGN_BOUND`, `CP0_REG_MAP`) and `v1_1c_features` dict
- **Exported** from `fubbu/__init__.py`

#### FUBBU Router (`fubbu/fubbu_router.py`)
- **Caveman compression** on router model prompts before LLM calls
- **GammaLanguage import** with graceful fallback

#### FUBBU Verifier (`fubbu/fubbu_verifier.py`)
- **Caveman compression** on verifier model prompts before LLM calls
- **GammaLanguage import** with graceful fallback

#### ZHARK Orchestrator (`zhark/zhark_orchestrator.py`)
- **Caveman compression** on all 5 LLM call sites (hypothesis, analysis, verification, sub-hypothesis, causal mapping)
- **`parse_zhark_directive()`** — parses ?ZHARK sigil directives
- **Gamma frame report** — final report wrapped in A2A-DSL frame with v1.1C opcodes
- **`gamma_enabled`** flag in `status()`
- **Exported** from `zhark/__init__.py`

#### VW Nexus WebSocket (`vw_nexus/websocket_server.py`)
- **Directive routing** — `?ZHARK` and `¿FUBBU` directives detected, routed, and audited
- **v1.1C feature reporting** in `get_stats()` — `gamma_v1_1c` dict with all feature flags
- **Graceful imports** for `parse_zhark_directive` and `parse_fubbu_directive`

### 2. Setup Wizard Updates (`liminal_lore_vw_deck/config/setup_wizard.py`)
- **Step 5c: GammaLanguage v1.1C** — interactive prompt for gamma feature configuration
- **Gamma env vars** added to ENV template: `GAMMA_ENABLED`, `GAMMA_CAVEMAN_COMPRESS`, `GAMMA_TURBOQUANT_CHECK`, `GAMMA_FRAME_OUTPUT`, `GAMMA_DIRECTIVE_ROUTING`
- **Gamma section** added to YAML template with full feature list and toggles
- **Shipping manifest** now includes:
  - Component 5: FUBBU Sidecar check (10 module files)
  - Component 6: GammaLanguage v1.1C check (bridge + CLI + A2A_Gamma.h)
- **Fixed** `liminal_link_vw_deck` path reference to `liminal_lore_vw_deck`

### 3. Config Loader Updates (`liminal_lore_vw_deck/config/config_loader.py`)
- **`gamma` section** in `_DEFAULTS` with version, features, and feature toggles
- **`get_gamma_config()`** method for reading gamma configuration with env var overrides
- **Env var overrides** for `GAMMA_ENABLED`, `GAMMA_CAVEMAN_COMPRESS`, `GAMMA_TURBOQUANT_CHECK`, `GAMMA_FRAME_OUTPUT`, `GAMMA_DIRECTIVE_ROUTING`
- **Version strings** updated to `1.1C` in defaults, validate(), and export_template()
- **Gamma section** included in export template

### 4. Version String Updates
- `vw_deck.config.json`: `v1.1B+Gamma-v1.1C` → `v1.1C`
- `electron/vw_deck.config.json`: `v1.1B` → `v1.1C` (with gamma fields added)
- `fubbu_config.yaml`: schema_version `1.0` → `1.1C`
- `config_loader.py`: version `1.0.0` → `1.1C`
- `setup_wizard.py`: manifest version `1.0.0` → `1.1C`, YAML template `1.0.0` → `1.1C`

---

## v1.1C Opcodes (A2A_Gamma.h)

| Opcode | Hex | Description |
|--------|-----|-------------|
| `RUST_OFFSET_LOAD` | 0xA0 | Load Rust FFI zero-copy memory offset with repr type detection |
| `RUST_FFI_CALL` | 0xA1 | Dispatch via PEAK function pointer table |
| `ALIGN_BOUND` | 0xA2 | Parse alignment boundary for memory layout |
| `CP0_REG_MAP` | 0xA3 | Map CP0 registers (Status, Cause, EPC, BadVAddr, Count) |
| `PSX_DMA_DISPATCH` | 0xA4 | Dispatch PSX DMA channel with HW interrupt triggering |

---

## Backward Compatibility

- **FUBBU:** If `gamma_bridge` import fails, all three stages (Router, Worker, Verifier) operate in legacy mode
- **ZHARK:** If `gamma_bridge` import fails, orchestrator operates without compression or gamma frame output
- **VW Nexus:** `_decode_gamma_frame()` tries JSON first — non-Gamma clients work unchanged
- **C++ Host:** `ExecuteCommand()` retains all original commands; `gamma` is additive
- **Config:** `gamma` section is optional; all gamma features default to enabled but can be disabled via env vars

---

## Files Changed

| File | Changes |
|------|---------|
| `fubbu/fubbu_worker.py` | v1.1C import, TurboQuant check, ¿FUBBU parser, v1.1C gamma frame |
| `fubbu/fubbu_router.py` | v1.1C import, Caveman compress on router model prompts |
| `fubbu/fubbu_verifier.py` | v1.1C import, Caveman compress on verifier model prompts |
| `fubbu/__init__.py` | +parse_fubbu_directive export |
| `fubbu/fubbu_config.yaml` | schema_version → 1.1C |
| `zhark/zhark_orchestrator.py` | v1.1C import, Caveman compress on all LLM calls, ?ZHARK parser, gamma frame report |
| `zhark/__init__.py` | +parse_zhark_directive export |
| `vw_nexus/websocket_server.py` | v1.1C directive routing, feature reporting |
| `liminal_lore_vw_deck/config/config_loader.py` | +gamma section, +get_gamma_config(), version → 1.1C |
| `liminal_lore_vw_deck/config/setup_wizard.py` | +Step 5c gamma, +FUBBU/Gamma ship checks, version → 1.1C, path fix |
| `liminal_lore_vw_deck/vw_deck.config.json` | version → v1.1C |
| `liminal_lore_vw_deck/electron/vw_deck.config.json` | version → v1.1C, +gamma fields |
| `GAMMA_INTEGRATION_BLUEPRINT.md` | Updated with v1.1C architecture, files table, backward compat |
| `README.md` | Updated for V1.1C |
| `CHANGELOG_V1.1C.md` | Created (this file) |
| `WHATS_NEW_V1.1C.md` | Created |
| `versions_log.md` | +V1.1C entry |
