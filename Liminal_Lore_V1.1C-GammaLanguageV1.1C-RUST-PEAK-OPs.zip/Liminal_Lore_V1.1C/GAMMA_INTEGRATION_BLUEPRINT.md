# Liminal Lore V1.1C — GammaLanguage Integration Blueprint

**Date:** August 10, 2026  
**Version:** V1.1C (Full Suite GammaLanguage v1.1C Compatibility)  
**GammaLanguage Spec:** v1.1C (Rust FFI + Peak Performance + Directive Routing)  
**Status:** COMPLETE — All subsystems integrated and documented

---

## Executive Summary

This document records the full architectural integration of GammaLanguage v1.1C into the Liminal Lore suite. Four subsystems were modified: the C++ host (vw_deck.cpp), the FUBBU sidecar (worker, router, verifier), the ZHARK orchestrator, and the VW Nexus WebSocket bus. The config loader and setup wizard were also updated with gamma configuration. The integration replaces legacy JSON-RPC structures with A2A-DSL AST frames and adds support for all five Peak Performance additions plus the v1.1C Rust FFI extension (zero-copy memory offsets, PEAK subsystem bridging, CyberGrime CP0 mapping, and PSXMatrix DMA dispatch), and introduces Directive Routing for improved message handling.

---

## Changes by Subsystem

### 1. C++ Host Integration (`liminal_lore_vw_deck/`)

#### New File: `gamma/A2A_Gamma.h`
- **Single-file inline header** merging A2AST.h + A2ALexer.h + A2AEvaluator.h
- GPU compute stubbed (no Vulkan dependency for Deck build)
- Contains all v1.1A-Robust+ types: `RegisterBank` (8 banks), `ASTNode`, `ASTArena<256>`, `BytecodeArena<512>`, `A2AB_Instruction`, `BytecodeCompiler`, `Lexer`, `Evaluator`
- All Peak Performance opcodes implemented: QVEC_LOAD, VEC_DELTA, PREDICT_BLOCK, SPEC_COMMIT, SPEC_ROLLBACK, HW_INTERRUPT, EVICT_SLIDING
- All v1.1C Rust FFI opcodes implemented: RUST_OFFSET_LOAD, RUST_FFI_CALL, ALIGN_BOUND, CP0_REG_MAP, PSX_DMA_DISPATCH
- v1.1C types: `RustReprType`, `RustOffsetFlag`, `RustFFIExport` (80-byte struct), `RustFFIDispatchTable`, `CyberGrimeCP0Map`, `PSXHwRegMap`
- RegisterBank extended with FFI dispatch table, CP0 map, PSX hw reg map, AlignBound, FFIExports[4]
- Lexer parses `&RUST_OFFSET` (with READ_ONLY/VOLATILE/UNSAFE/DMA_MAPPED flags) and `@ALIGN_BOUND`
- Direct Threaded Code bytecode VM via `Evaluator::ExecuteBytecode()` with v1.1C opcode dispatch

#### Modified: `vw_deck.cpp`
- **Include:** `#include "gamma/A2A_Gamma.h"` at line 30
- **Globals:** `g_gammaRegs` (RegisterBank), `g_gammaArena` (ASTArena<256>), `g_gammaBytecode` (BytecodeArena<512>), `g_gammaEvaluator` (Evaluator, 10K cycle limit)
- **New function:** `ExecuteGammaPayload(const char* gammaScript)` — parses DSL → AST → execute → compile to bytecode → execute via DTC
- **Command dispatcher:** Added `gamma`, `gamma <script>`, `gamma test`, `gamma status` commands
- **Built-in test script:** Exercises all 5 peak features (!STATE, @INVARIANT, |TARGET, +SKILL, #QVEC, #VEC_DELTA, @PREDICT/SPEC_COMMIT, %HW_INT, ^EVICT_SLIDING, ~MCP_CALL)
- **Register status display:** Shows ActiveTarget, ActiveExpert, RetryCount, FrameCount, PendingInt, SpecBuf state, AST/bytecode counts, LCK locks

#### Modified: `build-deck.bat`
- Updated title to "Build V1.1B+Gamma"
- Added GammaLanguage feature list in build success message
- No compiler flag changes needed (header is inline, no external .cpp files)

#### Modified: `vw_deck.config.json`
- Deck version: `v1.1B+Gamma`
- Added `gamma_language` and `gamma_features` fields

### 2. FUBBU Sidecar (`fubbu/fubbu_worker.py`)

#### Import
- Added `gamma_bridge.GammaBridge` import with path resolution to `GammaLanguage/python/`
- Graceful fallback: `_GAMMA_AVAILABLE = False` if import fails

#### Prompt Compression
- `execute()` method now calls `_gamma.caveman_compress(full_prompt, level="full")` before sending to Ollama
- Strips filler phrases, reduces token count by ~65%
- Ollama API call still uses JSON (required by Ollama protocol)

#### v1.1C Upgrade: TurboQuant Capacity Check
- Before inference, calls `_gamma.check_turboquant_capacity()` to check RAM pressure
- If RAM utilization > 85%, reduces `max_tokens` to 2048 to avoid OOM
- TurboQuant status included in gamma frame output

#### v1.1C Upgrade: ¿FUBBU Directive Parser
- New `parse_fubbu_directive()` function parses ¿FUBBU sigil directives from Gamma scripts
- Extracts task description, constraints, and expected format
- Exported from `__init__.py` for use by VWNexus bus routing

#### v1.1C Upgrade: Enhanced Gamma Frame Output
- Output frame now includes `@ALIGN_BOUND BOUND=16` and `CP0_REG_MAP(Status, 0x0)` opcodes
- `v1_1c_features` dict reports availability of rust_ffi, cp0_reg_map, align_bound, psx_dma_dispatch, turboquant_checked
- Result dict includes `gamma_v1_1c` key with feature flags

#### Output Wrapping
- After successful inference, output is wrapped in a GammaLanguage script frame:
  - `!STATE` with task hash
  - `@INVARIANT: output != ""`
  - `@ALIGN_BOUND BOUND=16`
  - `$EXEC { CAVEMAN_SHRINK(CTX[0], FULL); EMIT_SIGNAL("worker_done", latency); CP0_REG_MAP(Status, 0x0); }`
- Compiled via `GammaBridge.compile_gamma()` and returned as `gamma_frame` in result dict
- `gamma_compressed` boolean flag indicates whether prompt was compressed

### 3. VW Nexus WebSocket (`vw_nexus/websocket_server.py`)

#### GammaLanguage Frame Codec
- `_encode_gamma_frame()`: Outgoing messages wrapped in A2A-DSL script → compiled to AST frame → JSON-serialized with `_envelope` containing original message
- `_decode_gamma_frame()`: Incoming messages tried as JSON first (backward compat), then as raw GammaLanguage DSL, with `_envelope` extraction for Gamma frames

#### #HIVE Routing
- `BusConnection.hive` field added — tracks which #HIVE partition each connection belongs to
- `hive_select` message type — sets connection's hive partition
- `hive_route` message type — routes payload to all agents in a target hive
- `hive_selected` / `hive_routed` response types
- `get_stats()` now reports active hives and `gamma_enabled` flag

#### Gamma Script Execution
- `gamma_script` message type — allows agents to submit raw A2A-DSL scripts for compilation
- `gamma_result` response — returns compiled AST node count, sigil breakdown, peak feature summary

#### v1.1C Upgrade: Directive Routing
- `?ZHARK` directives: Parsed via `parse_zhark_directive()` and routed to ZHARK orchestrator
- `¿FUBBU` directives: Parsed via `parse_fubbu_directive()` and routed to FUBBU pipeline
- Both parsers imported with graceful fallback if subsystems unavailable
- Audit events emitted for each directive type (`gamma_zhark_directive`, `gamma_fubbu_directive`)
- `v1_1c_routing` dict in result indicates which directives were detected

#### v1.1C Upgrade: Feature Reporting
- `get_stats()` now includes `gamma_v1_1c` dict with feature availability flags:
  - `rust_ffi`, `cp0_reg_map`, `align_bound`, `psx_dma_dispatch` (from GammaBridge)
  - `zhark_routing`, `fubbu_routing` (from directive parser availability)
- `gamma_result` responses include `v1_1c_features` with per-script feature detection

#### Outgoing Message Encoding
- `_send()` now calls `_encode_gamma_frame()` instead of `json.dumps()` directly
- All message types (handshake, state_update, handoff, heartbeat, etc.) are Gamma-encoded

### 4. ZHARK Orchestrator (`zhark/zhark_orchestrator.py`)

#### v1.1C NEW: Full GammaLanguage Integration
- **Import:** `GammaBridge` imported with path resolution to `GammaLanguage/python/`
- **Graceful fallback:** `_GAMMA_AVAILABLE = False` if import fails — ZHARK operates in legacy mode

#### v1.1C NEW: Caveman Prompt Compression
- All 5 LLM call sites now apply `_gamma_compress()` before sending to the LLM:
  - `_form_initial_hypotheses()` — hypothesis generation
  - `_analyze_evidence()` — evidence analysis per search result
  - `_verify_with_compute_scaling()` — verification candidates
  - `_spawn_sub_hypotheses()` — sub-hypothesis generation
  - `_update_causal_map()` — causal relationship extraction
- Reduces token consumption by ~65% across all LLM calls

#### v1.1C NEW: ?ZHARK Directive Parser
- New `parse_zhark_directive()` function parses ?ZHARK sigil directives from Gamma scripts
- Extracts research question, optional max_iterations and convergence threshold
- Exported from `__init__.py` for use by VWNexus bus routing

#### v1.1C NEW: Gamma Frame Report Output
- Final research report wrapped in A2A-DSL frame with v1.1C opcodes:
  - `@ALIGN_BOUND BOUND=16`, `CP0_REG_MAP(Status, 0x0)`, `PSX_DMA_DISPATCH(CH1, 0x1F801090)`
  - `?ZHARK(research_complete, convergence=N)` directive for downstream consumers
- `v1_1c_features` dict reports feature availability in the gamma frame
- `gamma_compressed` flag and `gamma_frame` included in final report dict

#### v1.1C NEW: Status Enhancement
- `status()` now includes `gamma_enabled` boolean flag

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                Liminal Lore Deck v1.1C                       │
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│  │  vw_deck.cpp │  │  fubbu_worker│  │  vw_nexus    │       │
│  │  (C++ Host)  │  │  (Python)    │  │  (WebSocket) │       │
│  │              │  │              │  │              │       │
│  │ A2A_Gamma.h  │  │ gamma_bridge │  │ gamma_bridge │       │
│  │  ├ Lexer     │  │  ├ compress  │  │  ├ encode    │       │
│  │  ├ Evaluator │  │  ├ compile   │  │  ├ decode    │       │
│  │  ├ BytecodeVM│  │  ├ TQ check  │  │  ├ #HIVE     │       │
│  │  └ 8 banks   │  │  ├ ¿FUBBU    │  │  ├ ?ZHARK    │       │
│  │              │  │  └ frame v1C │  │  └ ¿FUBBU    │       │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘       │
│         │                 │                 │                │
│  ┌──────┴───────┐         │                 │                │
│  │  zhark_orch  │         │                 │                │
│  │  (Python)    │         │                 │                │
│  │              │         │                 │                │
│  │ gamma_bridge │         │                 │                │
│  │  ├ compress  │         │                 │                │
│  │  ├ ?ZHARK    │         │                 │                │
│  │  └ frame v1C │         │                 │                │
│  └──────┬───────┘         │                 │                │
│         │                 │                 │                │
│         └─────────────────┼─────────────────┘                │
│                           │                                  │
│                   GammaLanguage v1.1C                        │
│                   ├ 15 sigils, 8 register banks              │
│                   ├ PEAK-1: A2A-B Bytecode (DTC)             │
│                   ├ PEAK-2: #QVEC 8-bit quantized            │
│                   ├ PEAK-3: @PREDICT speculative             │
│                   ├ PEAK-4: %HW_INT frame-sync               │
│                   ├ PEAK-5: ^EVICT_SLIDING ring-buffer       │
│                   ├ v1.1C: RUST_OFFSET_LOAD / RUST_FFI_CALL  │
│                   ├ v1.1C: ALIGN_BOUND / CP0_REG_MAP         │
│                   ├ v1.1C: PSX_DMA_DISPATCH                  │
│                   ├ v1.1C: ?ZHARK directive routing          │
│                   └ v1.1C: ¿FUBBU directive routing          │
└─────────────────────────────────────────────────────────────┘
```

---

## Files Modified

| File | Action | Lines Changed |
|------|--------|--------------|
| `liminal_lore_vw_deck/gamma/A2A_Gamma.h` | **NEW** | ~960 lines |
| `liminal_lore_vw_deck/vw_deck.cpp` | Modified | +include, +globals, +ExecuteGammaPayload(), +commands |
| `liminal_lore_vw_deck/build-deck.bat` | Modified | Title + success message |
| `liminal_lore_vw_deck/vw_deck.config.json` | Modified | Version → v1.1C + gamma fields |
| `liminal_lore_vw_deck/electron/vw_deck.config.json` | Modified | Version → v1.1C + gamma fields |
| `fubbu/fubbu_worker.py` | Modified | +v1.1C import, +TurboQuant check, +¿FUBBU parser, +v1.1C gamma frame |
| `fubbu/fubbu_router.py` | Modified | +v1.1C import, +Caveman compress on router model prompts |
| `fubbu/fubbu_verifier.py` | Modified | +v1.1C import, +Caveman compress on verifier model prompts |
| `fubbu/__init__.py` | Modified | +parse_fubbu_directive export |
| `fubbu/fubbu_config.yaml` | Modified | schema_version → 1.1C |
| `vw_nexus/websocket_server.py` | Modified | +v1.1C codec, +#HIVE routing, +?ZHARK/¿FUBBU directive routing, +v1.1C feature reporting |
| `zhark/zhark_orchestrator.py` | Modified | +v1.1C import, +Caveman compress on all LLM calls, +?ZHARK parser, +v1.1C gamma frame report |
| `zhark/__init__.py` | Modified | +parse_zhark_directive export |
| `liminal_lore_vw_deck/config/config_loader.py` | Modified | +gamma section in defaults, +get_gamma_config(), +env var overrides, version → 1.1C |
| `liminal_lore_vw_deck/config/setup_wizard.py` | Modified | +Step 5c gamma config, +FUBBU ship check, +GammaLanguage ship check, version → 1.1C, path fix |
| `README.md` | Modified | Updated for V1.1C with gamma integration points |
| `CHANGELOG_V1.1C.md` | **NEW** | Full changelog |
| `WHATS_NEW_V1.1C.md` | **NEW** | Feature highlights |
| `versions_log.md` | Modified | +V1.1C entry |

---

## Usage

### Deck Terminal (vw_deck.cpp)
```
gamma              — Show GammaLanguage help
gamma test         — Run built-in peak performance test
gamma status       — Show register bank state
gamma !STATE: 0x0A |TARGET: [D3DX11] ~MCP_CALL("test")
```

### FUBBU Worker
- Prompt compression happens automatically when `gamma_bridge` is importable
- TurboQuant capacity check runs before inference — reduces max_tokens if RAM pressure > 85%
- Output dict includes `gamma_frame` (compiled A2A-DSL with v1.1C opcodes), `gamma_compressed` (bool), and `gamma_v1_1c` (feature flags)
- `parse_fubbu_directive()` enables ¿FUBBU sigil routing from Gamma scripts via VWNexus

### ZHARK Orchestrator
- Caveman compression applied to all 5 LLM call sites automatically when `gamma_bridge` is importable
- Final report includes `gamma_frame` with v1.1C opcodes (ALIGN_BOUND, CP0_REG_MAP, PSX_DMA_DISPATCH)
- `parse_zhark_directive()` enables ?ZHARK sigil routing from Gamma scripts via VWNexus
- `status()` includes `gamma_enabled` flag

### VW Nexus WebSocket
- Send `{"type": "hive_select", "hive": "vw_x64"}` to join a hive partition
- Send `{"type": "hive_route", "target_hive": "vw_x64", "payload": {...}}` to route to hive members
- Send `{"type": "gamma_script", "script": "!STATE: 0x0A ..."}` to compile DSL on the bus
- All outgoing messages are Gamma-encoded frames with `_envelope` backward compatibility

---

## Backward Compatibility

- **FUBBU Worker:** If `gamma_bridge` import fails, worker operates in legacy mode (no compression, no TurboQuant check, no frame)
- **FUBBU Router:** If `gamma_bridge` import fails, router operates without Caveman compression
- **FUBBU Verifier:** If `gamma_bridge` import fails, verifier operates without Caveman compression
- **ZHARK:** If `gamma_bridge` import fails, orchestrator operates in legacy mode (no prompt compression, no gamma frame in report)
- **VW Nexus:** `_decode_gamma_frame()` tries JSON first — non-Gamma clients work unchanged. Directive parsers have graceful fallback.
- **C++ Host:** `ExecuteCommand()` retains all original commands; `gamma` is additive
- **Config:** `gamma` section is optional; all features can be disabled via env vars. Deck runs without GammaLanguage if header is absent.

---

## Build Instructions

```bat
cd liminal_lore_vw_deck
build-deck.bat
```

The `gamma/A2A_Gamma.h` header is fully inline — no additional `.cpp` files or linker flags needed. The existing `cl /O2 /EHsc` or `g++ -O2 -std=c++17` commands compile it directly.
