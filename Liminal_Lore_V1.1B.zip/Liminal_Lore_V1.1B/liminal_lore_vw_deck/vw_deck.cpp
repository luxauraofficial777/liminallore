// ═══════════════════════════════════════════════════════════════
//  Liminal Lore Deck v1.1B
//  Pure Win32 C++ — Dark Studio GUI for Engine Toolchain
//  Compile: cl.exe vw_deck.cpp /O2 /EHsc /Fe:vw_deck.exe user32.lib gdi32.lib shell32.lib comctl32.lib
// ═══════════════════════════════════════════════════════════════

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#undef UNICODE
#undef _UNICODE
#include <winsock2.h>
#include <windows.h>
#include <windowsx.h>
#include <shellapi.h>
#include <commctrl.h>
#include <shlobj.h>
#include <exdisp.h>
#include <exdispid.h>
#include <oleidl.h>
#include <ocidl.h>
#include <gdiplus.h>
#include <wininet.h>
#include <string>
#include <vector>
#include <deque>
#include <memory>
#include <algorithm>

#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "gdiplus.lib")
#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "ws2_32.lib")

// ─── Color Palette ───
constexpr COLORREF COL_BG        = RGB(2, 2, 4);        // deep void black
constexpr COLORREF COL_BG_PANEL  = RGB(14, 14, 22);      // translucent dark
constexpr COLORREF COL_BG_INPUT  = RGB(8, 8, 14);
constexpr COLORREF COL_BORDER    = RGB(40, 40, 60);
constexpr COLORREF COL_TEXT      = RGB(200, 200, 210);
constexpr COLORREF COL_TEXT_DIM  = RGB(120, 120, 140);
constexpr COLORREF COL_ACCENT    = RGB(0, 212, 255);
constexpr COLORREF COL_ACCENT2   = RGB(255, 50, 100);
constexpr COLORREF COL_GREEN     = RGB(0, 220, 130);
constexpr COLORREF COL_MENU_BG   = RGB(22, 22, 32);
constexpr COLORREF COL_MENU_HL   = RGB(35, 35, 55);
constexpr COLORREF COL_ORANGE    = RGB(255, 165, 0);

// ─── Layout Constants ───
constexpr int MENU_H        = 26;
constexpr int PANEL_W       = 280;
constexpr int TERM_H        = 220;
constexpr int PAD           = 6;
constexpr int MAX_LOG_LINES = 200;
constexpr int MAX_TERM_LINES = 500;

// ─── Enhanced Color Palette ───
constexpr COLORREF COL_SURFACE    = RGB(22, 22, 34);
constexpr COLORREF COL_CARD       = RGB(28, 28, 42);
constexpr COLORREF COL_CARD_HOVER = RGB(35, 35, 55);
constexpr COLORREF COL_STATUS_OK  = RGB(0, 200, 120);
constexpr COLORREF COL_STATUS_WARN= RGB(255, 180, 0);
constexpr COLORREF COL_STATUS_ERR = RGB(255, 60, 90);
constexpr COLORREF COL_CYAN_DIM   = RGB(0, 160, 200);
constexpr COLORREF COL_PURPLE     = RGB(180, 100, 255);

// ─── Tool Grid ───
struct ToolDef {
    const char* name;
    const char* cli;
    const char* desc;
    const char* cmd;
    const char* args;
    COLORREF color;
    int menuId;
};
ToolDef g_tools[] = {
    {"Neural Link",  "hermes-bridge",     "AI chat portal (Hermes/Nous)",        "node",   "hermes-bridge.js",                                    COL_PURPLE,   1601},
    {"File Service", "voidwalkers-fs",    "File ops, exec, read/write",          "node",   "voidwalkers-fs-service.js",                           COL_CYAN_DIM, 1602},
    {"TurboQuant",   "turboquant",        "KV cache scaler for LLM",             "python", "turboquant-liminal.py --service --port 8646",      COL_ORANGE,   1603},
    {"Runpod Bridge", "runpod-bridge",     "SSH/SFTP remote sync + slash cmds",   "python", "runpod-bridge.py --service --port 8647",             COL_ACCENT,   1604},
    {"VPN Monitor",  "vw-vpn-monitor",    "Auto-reconnect + health checks",        "python", "vw-vpn-monitor.py --port 8645",                      COL_GREEN,    1605},
    {"VPN Watchdog", "watchdog-vpn",      "PowerShell watchdog + failover",      "powershell", "-ExecutionPolicy Bypass -File watchdog-vpn.ps1", COL_ACCENT2,  1606},
    {"VPN Diagnose", "vpn-diagnose",      "Full NIC fix + fastest relay connect",  "powershell", "-ExecutionPolicy Bypass -File vpn-diagnose-fix.ps1", COL_STATUS_WARN, 1607},
    {"Fetch Relays", "fetch-vpngate",     "Import fresh JP/KR VPN Gate relays",    "powershell", "-ExecutionPolicy Bypass -File scripts\\fetch-and-import-vpngate.ps1", COL_STATUS_OK, 1608},
};
constexpr int TOOL_COUNT = sizeof(g_tools)/sizeof(g_tools[0]);

// ─── Status Bar ───
char g_statusMsg[256] = "Ready";
DWORD g_statusColor = COL_STATUS_OK;
DWORD g_statusTime = 0;

// ─── Forward Declarations ───
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void DrawCosmicBackground(HDC hdc, RECT const& rc);
void DrawMenuBar(HDC hdc, RECT const& rc);
void DrawPanel(HDC hdc, int x, int y, int w, int h, const char* title, const char* content, COLORREF titleColor);
void DrawTerminal(HDC hdc, RECT const& rc);
void DrawWorkspace(HDC hdc, RECT const& rc);
void AppendLog(const char* text);
void AppendTerm(const char* text);
void ExecuteCommand(const char* cmd);
void SpawnTool(const char* exe, const char* args);
void UpdateLayout();
void DrawToolGrid(HDC hdc, int x, int y, int w, int h);
void DrawStatusBar(HDC hdc, int x, int y, int w, int h);
void SetStatus(const char* msg, COLORREF col);
void LaunchTool(int idx);

// ─── Embedded Browser (Liminal Link) ───
class BrowserHost : public IOleClientSite, public IOleInPlaceSite {
    LONG m_refCount = 1;
public:
    IOleObject* m_oleObject = nullptr;
    IWebBrowser2* m_webBrowser = nullptr;
    IOleInPlaceObject* m_inPlaceObj = nullptr;
    HWND m_hwndParent = nullptr;
    bool m_created = false;

    STDMETHODIMP QueryInterface(REFIID riid, void** ppv) {
        if (!ppv) return E_POINTER;
        if (IsEqualIID(riid, IID_IUnknown) || IsEqualIID(riid, IID_IOleClientSite))
            *ppv = static_cast<IOleClientSite*>(this);
        else if (IsEqualIID(riid, IID_IOleWindow) || IsEqualIID(riid, IID_IOleInPlaceSite))
            *ppv = static_cast<IOleInPlaceSite*>(this);
        else { *ppv = nullptr; return E_NOINTERFACE; }
        AddRef();
        return S_OK;
    }
    STDMETHODIMP_(ULONG) AddRef() { return InterlockedIncrement(&m_refCount); }
    STDMETHODIMP_(ULONG) Release() { LONG c = InterlockedDecrement(&m_refCount); if (c == 0) delete this; return c; }

    // IOleClientSite
    STDMETHODIMP SaveObject() { return S_OK; }
    STDMETHODIMP GetMoniker(DWORD, DWORD, IMoniker**) { return E_NOTIMPL; }
    STDMETHODIMP GetContainer(IOleContainer** ppContainer) { *ppContainer = nullptr; return E_NOINTERFACE; }
    STDMETHODIMP ShowObject() { return S_OK; }
    STDMETHODIMP OnShowWindow(BOOL) { return S_OK; }
    STDMETHODIMP RequestNewObjectLayout() { return E_NOTIMPL; }

    // IOleWindow
    STDMETHODIMP GetWindow(HWND* phwnd) { *phwnd = m_hwndParent; return S_OK; }
    STDMETHODIMP ContextSensitiveHelp(BOOL) { return E_NOTIMPL; }

    // IOleInPlaceSite
    STDMETHODIMP CanInPlaceActivate() { return S_OK; }
    STDMETHODIMP OnInPlaceActivate() {
        if (m_oleObject) m_oleObject->QueryInterface(IID_IOleInPlaceObject, (void**)&m_inPlaceObj);
        return S_OK;
    }
    STDMETHODIMP OnUIActivate() { return S_OK; }
    STDMETHODIMP GetWindowContext(IOleInPlaceFrame** ppFrame, IOleInPlaceUIWindow** ppDoc, LPRECT lprcPosRect, LPRECT lprcClipRect, LPOLEINPLACEFRAMEINFO pFrameInfo) {
        *ppFrame = nullptr; *ppDoc = nullptr;
        GetClientRect(m_hwndParent, lprcPosRect);
        *lprcClipRect = *lprcPosRect;
        memset(pFrameInfo, 0, sizeof(OLEINPLACEFRAMEINFO));
        pFrameInfo->cb = sizeof(OLEINPLACEFRAMEINFO);
        pFrameInfo->fMDIApp = FALSE;
        pFrameInfo->hwndFrame = m_hwndParent;
        return S_OK;
    }
    STDMETHODIMP Scroll(SIZE) { return E_NOTIMPL; }
    STDMETHODIMP OnUIDeactivate(BOOL) { return S_OK; }
    STDMETHODIMP OnInPlaceDeactivate() { if (m_inPlaceObj) { m_inPlaceObj->Release(); m_inPlaceObj = nullptr; } return S_OK; }
    STDMETHODIMP DiscardUndoState() { return E_NOTIMPL; }
    STDMETHODIMP DeactivateAndUndo() { return E_NOTIMPL; }
    STDMETHODIMP OnPosRectChange(LPCRECT lprcPosRect) { if (m_inPlaceObj) m_inPlaceObj->SetObjectRects(lprcPosRect, lprcPosRect); return S_OK; }

    bool Create(HWND parent) {
        m_hwndParent = parent;
        HRESULT hr = CoCreateInstance(CLSID_WebBrowser, nullptr, CLSCTX_ALL, IID_IOleObject, (void**)&m_oleObject);
        if (FAILED(hr)) return false;
        hr = m_oleObject->QueryInterface(IID_IWebBrowser2, (void**)&m_webBrowser);
        if (FAILED(hr)) { m_oleObject->Release(); m_oleObject = nullptr; return false; }
        OleSetContainedObject(m_oleObject, TRUE);
        m_oleObject->SetClientSite(this);
        RECT rc; GetClientRect(parent, &rc);
        m_oleObject->DoVerb(OLEIVERB_INPLACEACTIVATE, nullptr, this, 0, parent, &rc);
        m_created = true;
        return true;
    }
    void Navigate(const wchar_t* url) {
        if (m_webBrowser) {
            VARIANT vUrl = {};
            vUrl.vt = VT_BSTR;
            vUrl.bstrVal = SysAllocString(url);
            VARIANT v = {}; v.vt = VT_EMPTY;
            m_webBrowser->Navigate2(&vUrl, &v, &v, &v, &v);
            VariantClear(&vUrl);
        }
    }
    void SetRect(const RECT& rc) {
        if (m_inPlaceObj) m_inPlaceObj->SetObjectRects(&rc, &rc);
        else if (m_oleObject) {
            IOleInPlaceObject* ip = nullptr;
            if (SUCCEEDED(m_oleObject->QueryInterface(IID_IOleInPlaceObject, (void**)&ip))) {
                ip->SetObjectRects(&rc, &rc); ip->Release();
            }
        }
    }
    void Destroy() {
        if (m_webBrowser) { m_webBrowser->Release(); m_webBrowser = nullptr; }
        if (m_oleObject) { m_oleObject->Close(OLECLOSE_NOSAVE); m_oleObject->SetClientSite(nullptr); m_oleObject->Release(); m_oleObject = nullptr; }
        if (m_inPlaceObj) { m_inPlaceObj->Release(); m_inPlaceObj = nullptr; }
        m_created = false;
    }
    ~BrowserHost() { Destroy(); }
};

// ─── Global State ───
HWND g_hwnd = nullptr;
HWND g_hwndTermInput = nullptr;
HFONT g_fontMain = nullptr;
HFONT g_fontMono = nullptr;
HFONT g_fontBold = nullptr;
HBRUSH g_brushBg = nullptr;
HBRUSH g_brushPanel = nullptr;
HBRUSH g_brushInput = nullptr;
HBRUSH g_brushMenu = nullptr;
HBRUSH g_brushGreen = nullptr;
HBRUSH g_brushRed = nullptr;
HPEN g_penBorder = nullptr;

// ─── Service Orchestrator ───
struct SvcDef { const char* name; const char* cmd; const char* args; int port; bool autoStart; };
struct SvcState { HANDLE hProcess = nullptr; DWORD pid = 0; bool alive = false; bool wanted = false; DWORD startTick = 0; };

SvcDef g_svcDefs[] = {
    {"Ollama LLM",     "\"..\\..\\..\\AGENT\\distilled_agents\\bin\\ollama.exe\"", "serve", 11434, true},
    {"FS Service",     "node",   "voidwalkers-fs-service.js",                              8644, true},
    {"Hermes Bridge",  "node",   "hermes-bridge.js",                                       8643, true},
    {"TurboQuant",     "python", "turboquant-liminal.py --service --port 8646",             8646, true},
    {"Runpod Bridge",  "python", "runpod-bridge.py --service --port 8647",                8647, true},
    {"Colibri Bridge", "python", "colibri_bridge.py --port 8648",                           8648, true},
    {"VPN Monitor",    "python", "vw-vpn-monitor.py --port 8645",                           8645, false},
    {"VW Nexus",       "python", "vw_nexus_service.py --port 8651",                         8651, true},
    {"FUBBU Sidecar",  "python", "-m fubbu",                                               8653, false},
    {"ZHARK CSO",      "python", "-m zhark",                                               8654, false},
};
constexpr int SVC_COUNT = sizeof(g_svcDefs)/sizeof(g_svcDefs[0]);
SvcState g_svcStates[SVC_COUNT];

void DrawServicePanel(HDC hdc, int x, int y, int w, int h);
void StartSvc(int idx);
void StopSvc(int idx);
void CheckSvcs();
void LaunchBrowser();

// ─── Memory Monitor ───
struct MemState {
    DWORD ramPct = 0;
    DWORD pfPct = 0;
    bool tqTriggered = false;
};
MemState g_mem;
void UpdateMemory();
void DrawMemoryPanel(HDC hdc, int x, int y, int w, int h);

// ─── VPN Monitor ───
struct VpnState {
    bool connected = false;
    bool autoHealth = false;
    bool autoReconnect = false;
    char exitIP[64] = "--";
    char adapterIP[64] = "--";
    char currentAccount[128] = "--";
    char relayList[1024] = "";
    DWORD lastHealthCheck = 0;
    DWORD lastRelayFetch = 0;
    DWORD failureCount = 0;
    double lastSpeedMbps = 0.0;
};
VpnState g_vpn;
void UpdateVpnHealth();
void FetchVpnRelays();
void DrawVpnPanel(HDC hdc, int x, int y, int w, int h);
void VpnConnect();
void VpnDisconnect();
void VpnReconnect();

// ─── Telemetry / Diagnostics ───
struct TelemetryState {
    bool nexusAlive = false;
    bool tqAlive = false;
    bool ollamaAlive = false;
    bool harnessAlive = false;
    bool koboldAlive = false;
    bool heartbeatAlive = false;
    int nexusAgents = 0;
    int nexusTasksPending = 0;
    int nexusTasksDone = 0;
    int nexusTasksFailed = 0;
    int nexusSessions = 0;
    double tqRamPct = 0;
    char tqMode[32] = "offline";
    int tierKvBits = 0;
    char tierName[64] = "--";
    char pipelineLabel[64] = "--";
    int totalPulses = 0;
    int llmInvocations = 0;
    int deterministicBypass = 0;
    char efficiencyRate[16] = "--";
    double triggerFreqPerMin = 0;
    int taskQueueDepth = 0;
    int recentPulseCount = 0;
    double lastPulseRamPressure = 0;
    int chatRequests = 0;
    int committeeTriggers = 0;
    int pipelineSwitches = 0;
    char alertLevel[16] = "";
    char alertMessage[256] = "";
    DWORD lastFetch = 0;
    bool fetched = false;
    // Colibri bridge stats
    bool colibriAlive = false;
    int colibriHotExpert = 0;
    int colibriColdExperts = 0;
    int colibriCacheHits = 0;
    int colibriCacheMisses = 0;
    int colibriSwapEvents = 0;
    int colibriRamBudget = 0;
    int colibriRamUsed = 0;
    char colibriHotExpertName[32] = "--";
    // FUBBU sidecar stats
    bool fubbuAlive = false;
    int fubbuTasksActive = 0;
    int fubbuTasksDone = 0;
    // ZHARK CSO stats
    bool zharkAlive = false;
    int zharkCycles = 0;
    double zharkConvergence = 0;
    // VW RAG stats
    bool ragAlive = false;
    int ragChunkCount = 0;
};
TelemetryState g_telemetry;
bool g_showTelemetry = true;
void FetchTelemetry();
void DrawTelemetryPanel(HDC hdc, int x, int y, int w, int h);

// ─── Minimal JSON helpers ───
std::string JsonGetObject(const std::string& json, const std::string& key);
std::string JsonGetString(const std::string& json, const std::string& key);
double JsonGetNum(const std::string& json, const std::string& key, double defVal = 0);
bool JsonGetBool(const std::string& json, const std::string& key);

int g_clientW = 1280, g_clientH = 720;
bool g_showTerminal = true;
bool g_showAtlas = true;
bool g_showRouter = true;
bool g_showSanitize = true;
bool g_showScriptOutput = false;
bool g_showVpn = true;
bool g_showLiminal = false;
BrowserHost* g_browser = nullptr;
RECT g_rcCenter = {};
ULONG_PTR g_gdiToken = 0;

std::vector<std::string> g_log;
std::deque<std::string> g_termLines;
std::string g_termInput;
FILE* g_logFile = nullptr;
const char* g_projectRoot = "C:\\LuxAura\\VoidWalkers_Project\\Modern_X64";

// Panel content
const char* g_atlasContent     = "Status: IDLE\nRaw Assets: 0\nPacked Regions: 0\nAtlas Size: -- x --\nFormat: DXT5\nLast Build: --";
const char* g_routerContent    = "Provider: HERMES\nModel: KIMI-K2.6\nQueue Depth: 0\nLatency: -- ms\nTokens/min: --\nStatus: ONLINE";
const char* g_sanitizeContent  = "Lint: PASS\nMemCheck: --\nAssets Scanned: 0\nIssues: 0\nLast Run: --\nStatus: READY";
const char* g_scriptContent    = "Build Log:\nNo build started.\n\nUse Run > Build Project to begin.";

// ─── WinMain ───
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nCmdShow) {
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    WSADATA wsaData; WSAStartup(MAKEWORD(2, 2), &wsaData);
    Gdiplus::GdiplusStartupInput gdiInput;
    Gdiplus::GdiplusStartup(&g_gdiToken, &gdiInput, nullptr);
    InitCommonControls();

    WNDCLASSEX wc = {};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wc.lpszClassName = "VoidWalkersDeck";
    RegisterClassEx(&wc);

    g_hwnd = CreateWindowEx(
        WS_EX_APPWINDOW | WS_EX_OVERLAPPEDWINDOW,
        wc.lpszClassName,
        "Liminal Lore Deck // v1.1B",
        WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN | WS_MAXIMIZE,
        0, 0,
        GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN),
        nullptr, nullptr, hInst, nullptr
    );

    // GDI objects
    g_brushBg    = CreateSolidBrush(COL_BG);
    g_brushPanel = CreateSolidBrush(COL_BG_PANEL);
    g_brushInput = CreateSolidBrush(COL_BG_INPUT);
    g_brushMenu  = CreateSolidBrush(COL_MENU_BG);
    g_brushGreen = CreateSolidBrush(COL_GREEN);
    g_brushRed   = CreateSolidBrush(COL_ACCENT2);
    g_penBorder  = CreatePen(PS_SOLID, 1, COL_BORDER);
    g_fontMain   = CreateFont(14, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                              DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                              CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, "Segoe UI");
    g_fontMono   = CreateFont(13, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                              DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                              CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_MODERN, "Consolas");
    g_fontBold   = CreateFont(14, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
                              DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                              CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, "Segoe UI");

    // Build menu bar (top-level only, dropdowns handled manually for dark theme)
    HMENU hMenu = CreateMenu();

    HMENU hFile = CreatePopupMenu();
    AppendMenu(hFile, MF_STRING, 1001, "Start All Services");
    AppendMenu(hFile, MF_STRING, 1002, "Stop All Services");
    AppendMenu(hFile, MF_STRING, 1003, "Restart All");
    AppendMenu(hFile, MF_SEPARATOR, 0, nullptr);
    AppendMenu(hFile, MF_STRING, 1004, "Launch Neural Link\tCtrl+L");
    AppendMenu(hFile, MF_SEPARATOR, 0, nullptr);
    AppendMenu(hFile, MF_STRING, 1005, "E&xit");
    AppendMenu(hMenu, MF_POPUP, (UINT_PTR)hFile, "&File");

    HMENU hSelect = CreatePopupMenu();
    AppendMenu(hSelect, MF_STRING, 1101, "Target: Win32 x64");
    AppendMenu(hSelect, MF_STRING, 1102, "Target: UWP");
    AppendMenu(hSelect, MF_STRING, 1103, "Target: Xbox");
    AppendMenu(hSelect, MF_SEPARATOR, 0, nullptr);
    AppendMenu(hSelect, MF_STRING, 1104, "Core: Hermes (Nous Portal)");
    AppendMenu(hSelect, MF_STRING, 1105, "Core: Gemini Core (Local CLI)");
    AppendMenu(hSelect, MF_STRING, 1106, "Core: Devin (Cognition)");
    AppendMenu(hSelect, MF_SEPARATOR, 0, nullptr);
    AppendMenu(hSelect, MF_STRING, 1107, "Asset Directory...");
    AppendMenu(hMenu, MF_POPUP, (UINT_PTR)hSelect, "&Select");

    HMENU hView = CreatePopupMenu();
    AppendMenu(hView, MF_STRING | (g_showTerminal ? MF_CHECKED : 0), 1201, "Toggle Terminal");
    AppendMenu(hView, MF_STRING | (g_showAtlas ? MF_CHECKED : 0), 1202, "Toggle AtlasArchitect");
    AppendMenu(hView, MF_STRING | (g_showScriptOutput ? MF_CHECKED : 0), 1203, "Toggle Script Output");
    AppendMenu(hView, MF_STRING | (g_showRouter ? MF_CHECKED : 0), 1204, "Toggle Multi-Provider Router");
    AppendMenu(hView, MF_STRING | (g_showSanitize ? MF_CHECKED : 0), 1205, "Toggle Sanitization Node");
    AppendMenu(hView, MF_STRING, 1207, "Open Neural Link\tCtrl+L");
    AppendMenu(hView, MF_STRING | (g_showTelemetry ? MF_CHECKED : 0), 1208, "Toggle Diagnostics");
    AppendMenu(hView, MF_SEPARATOR, 0, nullptr);
    AppendMenu(hView, MF_STRING, 1206, "Reset Layout");
    AppendMenu(hMenu, MF_POPUP, (UINT_PTR)hView, "&View");

    HMENU hVpn = CreatePopupMenu();
    AppendMenu(hVpn, MF_STRING, 1251, "Connect VPN");
    AppendMenu(hVpn, MF_STRING, 1252, "Disconnect VPN");
    AppendMenu(hVpn, MF_STRING, 1253, "Reconnect Fastest");
    AppendMenu(hVpn, MF_SEPARATOR, 0, nullptr);
    AppendMenu(hVpn, MF_STRING | (g_vpn.autoHealth ? MF_CHECKED : 0), 1254, "Auto-Health / Bandwidth");
    AppendMenu(hVpn, MF_STRING | (g_vpn.autoReconnect ? MF_CHECKED : 0), 1255, "Auto-Reconnect");
    AppendMenu(hVpn, MF_SEPARATOR, 0, nullptr);
    AppendMenu(hVpn, MF_STRING | (g_showVpn ? MF_CHECKED : 0), 1256, "Toggle VPN Panel");
    AppendMenu(hMenu, MF_POPUP, (UINT_PTR)hVpn, "&VPN");

    HMENU hTerm = CreatePopupMenu();
    AppendMenu(hTerm, MF_STRING, 1301, "Clear Screen");
    AppendMenu(hTerm, MF_STRING, 1302, "Initialize Shell Node");
    AppendMenu(hTerm, MF_STRING, 1303, "Active Connections");
    AppendMenu(hTerm, MF_STRING, 1304, "View Environment");
    AppendMenu(hMenu, MF_POPUP, (UINT_PTR)hTerm, "&Terminal");

    HMENU hRun = CreatePopupMenu();
    AppendMenu(hRun, MF_STRING, 1401, "Build Project\tF5");
    AppendMenu(hRun, MF_STRING, 1402, "Clean Build");
    AppendMenu(hRun, MF_STRING, 1403, "Validate Assets");
    AppendMenu(hRun, MF_STRING, 1404, "Test Concurrency");
    AppendMenu(hMenu, MF_POPUP, (UINT_PTR)hRun, "&Run");

    HMENU hTools = CreatePopupMenu();
    AppendMenu(hTools, MF_STRING, 1601, "Neural Link\tCtrl+1");
    AppendMenu(hTools, MF_STRING, 1602, "File Service\tCtrl+2");
    AppendMenu(hTools, MF_STRING, 1603, "TurboQuant\tCtrl+3");
    AppendMenu(hTools, MF_STRING, 1604, "Runpod Bridge\tCtrl+4");
    AppendMenu(hTools, MF_STRING, 1605, "VPN Monitor\tCtrl+5");
    AppendMenu(hTools, MF_STRING, 1606, "VW Nexus\tCtrl+6");
    AppendMenu(hTools, MF_SEPARATOR, 0, nullptr);
    AppendMenu(hTools, MF_STRING, 1607, "VPN Watchdog (PS)");
    AppendMenu(hTools, MF_STRING, 1608, "VPN Diagnose & Fix");
    AppendMenu(hTools, MF_STRING, 1609, "Fetch VPN Relays");
    AppendMenu(hMenu, MF_POPUP, (UINT_PTR)hTools, "&Tools");

    HMENU hGo = CreatePopupMenu();
    AppendMenu(hGo, MF_STRING, 1501, "Boot Engine (Live Debug)\tF9");
    AppendMenu(hGo, MF_STRING, 1502, "Detach Process");
    AppendMenu(hGo, MF_STRING, 1503, "Launch Profiler");
    AppendMenu(hMenu, MF_POPUP, (UINT_PTR)hGo, "&Go");

    SetMenu(g_hwnd, hMenu);

    // Terminal input child
    g_hwndTermInput = CreateWindowEx(
        0, "EDIT", "",
        WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
        0, 0, 100, 24, g_hwnd, (HMENU)2001, hInst, nullptr
    );
    SendMessage(g_hwndTermInput, WM_SETFONT, (WPARAM)g_fontMono, TRUE);

    // Open persistent log
    {
        char logPath[MAX_PATH];
        SYSTEMTIME st;
        GetLocalTime(&st);
        snprintf(logPath, MAX_PATH, "%s\\study\\logs\\deck_%04d%02d%02d_%02d%02d%02d.log",
                 g_projectRoot, st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
        CreateDirectoryA((std::string(g_projectRoot) + "\\study\\logs").c_str(), nullptr);
        g_logFile = fopen(logPath, "a");
        if (g_logFile) {
            fprintf(g_logFile, "\n=== Liminal Lore Deck v1.1B Log Start ===\n");
            fflush(g_logFile);
        }
    }

    AppendLog("[SYSTEM] Liminal Lore Deck initialized.");
    AppendLog("[SYSTEM] Engine toolchain ready.");
    AppendLog("[SYSTEM] Services: Bridge=8643 FS=8644 VPN=8645 TQ=8646 Runpod=8647 Colibri=8648 Nexus=8651 Ollama=11434");

    SetTimer(g_hwnd, 1, 5000, nullptr);

    ShowWindow(g_hwnd, SW_MAXIMIZE);
    UpdateWindow(g_hwnd);

    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    // Cleanup
    for (int i=0;i<SVC_COUNT;i++) StopSvc(i);
    if (g_browser) { delete g_browser; g_browser = nullptr; }
    if (g_logFile) { fclose(g_logFile); g_logFile = nullptr; }
    CoUninitialize();
    WSACleanup();
    if (g_gdiToken) Gdiplus::GdiplusShutdown(g_gdiToken);
    DeleteObject(g_brushBg);
    DeleteObject(g_brushPanel);
    DeleteObject(g_brushInput);
    DeleteObject(g_brushMenu);
    DeleteObject(g_brushGreen);
    DeleteObject(g_brushRed);
    DeleteObject(g_penBorder);
    DeleteObject(g_fontMain);
    DeleteObject(g_fontMono);
    DeleteObject(g_fontBold);

    return (int)msg.wParam;
}

// ─── Window Procedure ───
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_SIZE:
        g_clientW = LOWORD(lParam);
        g_clientH = HIWORD(lParam);
        UpdateLayout();
        InvalidateRect(hwnd, nullptr, FALSE);
        return 0;

    case WM_ERASEBKGND:
        return 1;  // prevent black erase flash; we paint everything in WM_PAINT

    case WM_TIMER: {
        static bool prevSvcAlive[SVC_COUNT] = {false};
        static MemState prevMem = {};
        static VpnState prevVpn = {};
        bool needRedraw = false;
        CheckSvcs();
        for (int i = 0; i < SVC_COUNT; i++) {
            if (prevSvcAlive[i] != g_svcStates[i].alive) { prevSvcAlive[i] = g_svcStates[i].alive; needRedraw = true; }
        }
        UpdateMemory();
        int ramDelta = (int)g_mem.ramPct - (int)prevMem.ramPct;
        int pfDelta  = (int)g_mem.pfPct  - (int)prevMem.pfPct;
        if (abs(ramDelta) > 2 || abs(pfDelta) > 2 || prevMem.tqTriggered != g_mem.tqTriggered) {
            prevMem = g_mem; needRedraw = true;
        }
        UpdateVpnHealth();
        if (prevVpn.connected != g_vpn.connected || strcmp(prevVpn.adapterIP, g_vpn.adapterIP) != 0) {
            prevVpn = g_vpn; needRedraw = true;
        }
        FetchVpnRelays();
        // Telemetry polling — every ~20s (timer fires at 5s, poll every 4th tick)
        static int telTickCounter = 0;
        if (g_showTelemetry && ++telTickCounter >= 4) {
            telTickCounter = 0;
            TelemetryState prevTel = g_telemetry;
            FetchTelemetry();
            if (g_telemetry.fetched != prevTel.fetched ||
                g_telemetry.nexusAlive != prevTel.nexusAlive ||
                g_telemetry.ollamaAlive != prevTel.ollamaAlive ||
                g_telemetry.tqAlive != prevTel.tqAlive ||
                strcmp(g_telemetry.alertLevel, prevTel.alertLevel) != 0) {
                needRedraw = true;
            }
        }
        if (needRedraw) InvalidateRect(hwnd, nullptr, FALSE);
        return 0;
    }

    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdcScreen = BeginPaint(hwnd, &ps);
        RECT rcClient;
        GetClientRect(hwnd, &rcClient);
        int cw = rcClient.right;
        int ch = rcClient.bottom;

        // ─── Double Buffer ───
        HDC hdcMem = CreateCompatibleDC(hdcScreen);
        HBITMAP hbmMem = CreateCompatibleBitmap(hdcScreen, cw, ch);
        HBITMAP hbmOld = (HBITMAP)SelectObject(hdcMem, hbmMem);

        // Clear mem DC to background first (prevents uninitialized pixel garbage)
        FillRect(hdcMem, &rcClient, g_brushBg);

        // Cosmic void background
        DrawCosmicBackground(hdcMem, rcClient);

        // Menubar
        RECT rcMenu = { 0, 0, g_clientW, MENU_H };
        DrawMenuBar(hdcMem, rcMenu);

        // Compute layout
        int statusH = 22;
        int leftX = PAD;
        int visiblePanels = (g_showAtlas ? 1 : 0) + (g_showRouter ? 1 : 0) + 1;
        int leftW = visiblePanels > 0 ? PANEL_W : 0;
        int rightW = g_showVpn ? 340 : 0;
        int telW = g_showTelemetry ? 300 : 0;
        int totalRight = rightW + (telW > 0 ? telW + PAD : 0);
        int termY = g_showTerminal ? g_clientH - TERM_H - PAD - statusH : g_clientH - statusH;
        int centerX = leftW > 0 ? leftW + PAD * 2 : PAD;
        int centerW = g_clientW - centerX - totalRight - PAD * (totalRight > 0 ? 2 : 1);
        int centerH = termY - MENU_H - PAD * 2;

        // Left panels (stacked)
        int py = MENU_H + PAD;
        int panelH = visiblePanels > 0 ? (centerH - PAD * (visiblePanels - 1)) / visiblePanels : 0;

        DrawMemoryPanel(hdcMem, leftX, py, leftW, panelH);
        py += panelH + PAD;
        if (g_showRouter) {
            DrawPanel(hdcMem, leftX, py, leftW, panelH, "MULTI-PROVIDER ROUTER", g_routerContent, COL_ORANGE);
            py += panelH + PAD;
        }
        DrawServicePanel(hdcMem, leftX, py, leftW, panelH);
        py += panelH + PAD;

        // Center workspace — Tool Grid
        RECT rcCenter = { centerX, MENU_H + PAD, centerX + centerW, termY - PAD };
        g_rcCenter = rcCenter;
        if (rcCenter.right > rcCenter.left && rcCenter.bottom > rcCenter.top) {
            DrawToolGrid(hdcMem, rcCenter.left, rcCenter.top, rcCenter.right - rcCenter.left, rcCenter.bottom - rcCenter.top);
        }

        // Right panels — VPN + Telemetry side by side
        if (g_showVpn) {
            int rightX = g_clientW - rightW - PAD;
            DrawVpnPanel(hdcMem, rightX, MENU_H + PAD, rightW, centerH);
        }
        if (g_showTelemetry) {
            int telX = g_clientW - rightW - telW - PAD * 2;
            if (!g_showVpn) telX = g_clientW - telW - PAD;
            DrawTelemetryPanel(hdcMem, telX, MENU_H + PAD, telW, centerH);
        }

        // Terminal
        if (g_showTerminal) {
            RECT rcTerm = { centerX, termY, g_clientW - PAD, g_clientH - statusH - PAD };
            DrawTerminal(hdcMem, rcTerm);
        }

        // Status bar at bottom
        DrawStatusBar(hdcMem, PAD, g_clientH - statusH - PAD, g_clientW - PAD * 2, statusH);

        // Blit to screen in one shot (no flicker)
        BitBlt(hdcScreen, 0, 0, cw, ch, hdcMem, 0, 0, SRCCOPY);

        SelectObject(hdcMem, hbmOld);
        DeleteObject(hbmMem);
        DeleteDC(hdcMem);
        EndPaint(hwnd, &ps);
        return 0;
    }

    case WM_COMMAND: {
        int id = LOWORD(wParam);
        switch (id) {
        // ─── FILE ───
        case 1001:
            AppendLog("[SVC] Starting all auto services...");
            for (int i=0;i<SVC_COUNT;i++) if (g_svcDefs[i].autoStart) StartSvc(i);
            break;
        case 1002:
            AppendLog("[SVC] Stopping all services...");
            for (int i=0;i<SVC_COUNT;i++) StopSvc(i);
            break;
        case 1003:
            AppendLog("[SVC] Restarting all services...");
            for (int i=0;i<SVC_COUNT;i++) { StopSvc(i); }
            for (int i=0;i<SVC_COUNT;i++) if (g_svcDefs[i].autoStart) StartSvc(i);
            break;
        case 1004: LaunchBrowser(); break;
        case 1005: PostQuitMessage(0); break;

        // ─── SELECT ───
        case 1101: AppendLog("[SELECT] Target: Win32 x64"); break;
        case 1102: AppendLog("[SELECT] Target: UWP"); break;
        case 1103: AppendLog("[SELECT] Target: Xbox"); break;
        case 1104: AppendLog("[SELECT] Core: Hermes (Nous Portal)"); break;
        case 1105: AppendLog("[SELECT] Core: Gemini Core (Local CLI)"); break;
        case 1106: AppendLog("[SELECT] Core: Devin (Cognition)"); break;
        case 1107: {
            BROWSEINFOA bi = {};
            bi.hwndOwner = hwnd;
            bi.lpszTitle = "Select Asset Directory";
            bi.ulFlags = BIF_RETURNONLYFSDIRS;
            PIDLIST_ABSOLUTE pidl = SHBrowseForFolderA(&bi);
            if (pidl) {
                char path[MAX_PATH];
                SHGetPathFromIDListA(pidl, path);
                CoTaskMemFree(pidl);
                AppendLog((std::string("[SELECT] Asset dir: ") + path).c_str());
            }
            break;
        }

        // ─── VIEW ───
        case 1201: g_showTerminal = !g_showTerminal; AppendLog(g_showTerminal ? "[VIEW] Terminal shown" : "[VIEW] Terminal hidden"); break;
        case 1202: g_showAtlas = !g_showAtlas; AppendLog(g_showAtlas ? "[VIEW] AtlasArchitect shown" : "[VIEW] AtlasArchitect hidden"); break;
        case 1203: g_showScriptOutput = !g_showScriptOutput; AppendLog(g_showScriptOutput ? "[VIEW] Script Output shown" : "[VIEW] Script Output hidden"); break;
        case 1204: g_showRouter = !g_showRouter; AppendLog(g_showRouter ? "[VIEW] Router shown" : "[VIEW] Router hidden"); break;
        case 1205: g_showSanitize = !g_showSanitize; AppendLog(g_showSanitize ? "[VIEW] Sanitize shown" : "[VIEW] Sanitize hidden"); break;
        case 1207: LaunchBrowser(); break; // Open Neural Link in browser
        case 1206:
            g_showTerminal = true; g_showAtlas = true; g_showRouter = true;
            g_showSanitize = true; g_showScriptOutput = false; g_showVpn = true;
            AppendLog("[VIEW] Layout reset.");
            break;

        // ─── VPN ───
        case 1251: VpnConnect(); break;
        case 1252: VpnDisconnect(); break;
        case 1253: VpnReconnect(); break;
        case 1254:
            g_vpn.autoHealth = !g_vpn.autoHealth;
            AppendLog(g_vpn.autoHealth ? "[VPN] Auto-Health ENABLED" : "[VPN] Auto-Health DISABLED");
            break;
        case 1255:
            g_vpn.autoReconnect = !g_vpn.autoReconnect;
            AppendLog(g_vpn.autoReconnect ? "[VPN] Auto-Reconnect ENABLED" : "[VPN] Auto-Reconnect DISABLED");
            break;
        case 1256:
            g_showVpn = !g_showVpn;
            AppendLog(g_showVpn ? "[VPN] Panel shown" : "[VPN] Panel hidden");
            break;
        case 1208:
            g_showTelemetry = !g_showTelemetry;
            AppendLog(g_showTelemetry ? "[DIAG] Telemetry panel shown" : "[DIAG] Telemetry panel hidden");
            break;

        // ─── TERMINAL ───
        case 1301: g_termLines.clear(); AppendLog("[TERM] Screen cleared."); break;
        case 1302: AppendLog("[TERM] Shell Node initialized on port 8643."); break;
        case 1303: AppendLog("[TERM] Connections: Bridge=8643 FS=8644 VPN=8645 TQ=8646 Runpod=8647"); break;
        case 1304: AppendLog("[TERM] Environment: Win32 x64 | Python 3.12 | Node.js Bridge"); break;

        // ─── RUN ───
        case 1401: {
            AppendLog("[RUN] Build Project (CMake + Ninja)...");
            AppendTerm("[BUILD] cmake --build build --config Release");
            std::string cmd = std::string("powershell.exe -Command \"cd '") + g_projectRoot + "'; cmake -B build -S . -G Ninja -DCMAKE_BUILD_TYPE=Release; cmake --build build --config Release; $ec=$LASTEXITCODE; if($ec -eq 0){ Write-Host '[BUILD OK] VoidWalkersHD.exe' } else { Write-Host '[BUILD FAILED]' -ForegroundColor Red }\"";
            SpawnTool("powershell.exe", cmd.c_str() + strlen("powershell.exe "));
            break;
        }
        case 1402: {
            AppendLog("[RUN] Clean Build...");
            AppendTerm("[CLEAN] Removing build/ and *.obj");
            std::string cmd = std::string("powershell.exe -Command \"cd '") + g_projectRoot + "'; Remove-Item -Recurse -Force -ErrorAction SilentlyContinue build; Remove-Item -Force source_Core_X64/*.obj, *.ilk, *.pdb; Write-Host '[CLEAN OK]'\"";
            SpawnTool("powershell.exe", cmd.c_str() + strlen("powershell.exe "));
            break;
        }
        case 1403: {
            AppendLog("[RUN] Validate Assets...");
            AppendTerm("[VALIDATE] vwforge validate assets --agent");
            SpawnTool("python.exe", "-m vwforge validate assets --agent --report validation_report.json");
            break;
        }
        case 1404: AppendLog("[RUN] Concurrency test dispatched."); break;

        // ─── TOOLS ───
        case 1601: LaunchTool(0); break; // Neural Link
        case 1602: LaunchTool(1); break; // File Service
        case 1603: LaunchTool(2); break; // TurboQuant
        case 1604: LaunchTool(3); break; // Runpod Bridge
        case 1605: LaunchTool(4); break; // VPN Monitor
        case 1606: StartSvc(7); break;   // VW Nexus (index 7 in g_svcDefs)
        case 1607: LaunchTool(5); break; // VPN Watchdog
        case 1608: LaunchTool(6); break; // VPN Diagnose
        case 1609: LaunchTool(7); break; // Fetch Relays

        // ─── GO ───
        case 1501: AppendLog("[GO] Booting engine in Live Debug Modus..."); break;
        case 1502: AppendLog("[GO] Process detached."); break;
        case 1503: AppendLog("[GO] Profiler launched."); break;
        }
        UpdateLayout();
        InvalidateRect(hwnd, nullptr, FALSE);
        return 0;
    }

    case WM_LBUTTONDOWN: {
        int mx = LOWORD(lParam), my = HIWORD(lParam);
        if (!g_showVpn) break;
        int rightW = 340;
        int rightX = g_clientW - rightW - PAD;
        int centerH = g_showTerminal ? g_clientH - TERM_H - MENU_H - PAD * 3 : g_clientH - MENU_H - PAD * 2;
        int yBase = MENU_H + PAD;
        int btnY = yBase + centerH - 28;
        RECT rcBtn1 = { rightX + PAD, btnY, rightX + rightW / 2 - PAD, btnY + 22 };
        RECT rcBtn2 = { rightX + rightW / 2 + PAD, btnY, rightX + rightW - PAD, btnY + 22 };
        if (mx >= rcBtn1.left && mx <= rcBtn1.right && my >= rcBtn1.top && my <= rcBtn1.bottom) {
            if (g_vpn.connected) VpnDisconnect(); else VpnConnect();
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }
        if (mx >= rcBtn2.left && mx <= rcBtn2.right && my >= rcBtn2.top && my <= rcBtn2.bottom) {
            VpnReconnect();
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }
        break;
    }

    case WM_KEYDOWN:
        if (wParam == VK_RETURN && GetFocus() == g_hwndTermInput) {
            char buf[1024];
            GetWindowTextA(g_hwndTermInput, buf, 1024);
            if (buf[0]) {
                AppendTerm((std::string("> ") + buf).c_str());
                ExecuteCommand(buf);
                SetWindowTextA(g_hwndTermInput, "");
            }
            return 0;
        }
        if (wParam == VK_F5) {
            AppendLog("[RUN] Build Project (F5)");
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }
        if (wParam == VK_F9) {
            AppendLog("[GO] Boot Engine (F9)");
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }
        if (GetAsyncKeyState(VK_CONTROL) & 0x8000) {
            if (wParam >= '1' && wParam <= '5') {
                int idx = wParam - '1';
                if (idx < TOOL_COUNT) LaunchTool(idx);
                return 0;
            }
            if (wParam == 'L' || wParam == 'l') { LaunchBrowser(); return 0; }
        }
        break;

    case WM_CTLCOLOREDIT: {
        HDC hdcEdit = (HDC)wParam;
        SetTextColor(hdcEdit, COL_TEXT);
        SetBkColor(hdcEdit, COL_BG_INPUT);
        return (LRESULT)g_brushInput;
    }

    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hwnd, msg, wParam, lParam);
}

// ─── Layout Update ───
void UpdateLayout() {
    if (!g_hwndTermInput) return;
    int leftW = ((g_showAtlas ? 1 : 0) + (g_showRouter ? 1 : 0) + (g_showSanitize ? 1 : 0)) > 0 ? PANEL_W : 0;
    int termY = g_showTerminal ? g_clientH - TERM_H - PAD : g_clientH;
    int termH = g_showTerminal ? TERM_H : 0;
    int centerX = leftW > 0 ? leftW + PAD * 2 : PAD;

    if (g_showTerminal) {
        int inputH = 24;
        int statusH = 22;
        MoveWindow(g_hwndTermInput,
                   centerX + PAD, g_clientH - inputH - PAD * 2 - statusH,
                   g_clientW - centerX - PAD * 3, inputH,
                   TRUE);
        ShowWindow(g_hwndTermInput, SW_SHOW);
    } else {
        ShowWindow(g_hwndTermInput, SW_HIDE);
    }
}

// ─── Drawing Helpers ───
void DrawMenuBar(HDC hdc, RECT const& rc) {
    FillRect(hdc, &rc, g_brushMenu);
    SelectObject(hdc, g_penBorder);
    MoveToEx(hdc, rc.left, rc.bottom - 1, nullptr);
    LineTo(hdc, rc.right, rc.bottom - 1);

    SetTextColor(hdc, COL_TEXT);
    SetBkMode(hdc, TRANSPARENT);
    SelectObject(hdc, g_fontMain);

    const char* items[] = { "File", "Select", "View", "Terminal", "Run", "Tools", "Go" };
    int widths[] = { 42, 50, 42, 54, 40, 46, 38 };
    int x = 14;
    for (int i = 0; i < 7; i++) {
        RECT rcItem = { x, rc.top + 4, x + widths[i], rc.bottom - 2 };
        DrawTextA(hdc, items[i], -1, &rcItem, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        x += widths[i] + 12;
    }

    // Status
    SetTextColor(hdc, COL_ACCENT);
    RECT rcStatus = { rc.right - 260, rc.top + 4, rc.right - 12, rc.bottom - 2 };
    DrawTextA(hdc, "Liminal Lore Deck // v1.1B", -1, &rcStatus, DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
}

void DrawPanel(HDC hdc, int x, int y, int w, int h, const char* title, const char* content, COLORREF titleColor) {
    SelectObject(hdc, g_brushPanel);
    SelectObject(hdc, g_penBorder);
    Rectangle(hdc, x, y, x + w, y + h);

    // Title bar
    RECT rcTitle = { x, y, x + w, y + 26 };
    HBRUSH titleBrush = CreateSolidBrush(COL_BG);
    FillRect(hdc, &rcTitle, titleBrush);
    DeleteObject(titleBrush);
    SelectObject(hdc, g_penBorder);
    MoveToEx(hdc, x, y + 26, nullptr);
    LineTo(hdc, x + w, y + 26);

    SetTextColor(hdc, titleColor);
    SetBkMode(hdc, TRANSPARENT);
    SelectObject(hdc, g_fontBold);
    rcTitle.left += PAD;
    DrawTextA(hdc, title, -1, &rcTitle, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

    // Content
    RECT rcContent = { x + PAD, y + 30, x + w - PAD, y + h - PAD };
    SetTextColor(hdc, COL_TEXT_DIM);
    SelectObject(hdc, g_fontMono);
    DrawTextA(hdc, content, -1, &rcContent, DT_LEFT | DT_TOP | DT_WORDBREAK);
}

void SetStatus(const char* msg, COLORREF col) {
    strncpy(g_statusMsg, msg, 255); g_statusMsg[255] = '\0';
    g_statusColor = col;
    g_statusTime = GetTickCount();
    if (g_hwnd) InvalidateRect(g_hwnd, nullptr, FALSE);
}

void LaunchTool(int idx) {
    if (idx < 0 || idx >= TOOL_COUNT) return;
    ToolDef& t = g_tools[idx];
    AppendLog((std::string("[TOOL] Starting ") + t.name + "...").c_str());
    SetStatus((std::string("Launching ") + t.name).c_str(), t.color);
    if (strcmp(t.cmd, "powershell") == 0) {
        SpawnTool("powershell.exe", t.args);
    } else {
        SpawnTool(t.cmd, t.args);
    }
}

void DrawToolGrid(HDC hdc, int x, int y, int w, int h) {
    // Background
    HBRUSH bg = CreateSolidBrush(COL_SURFACE);
    RECT rcBg = { x, y, x + w, y + h };
    FillRect(hdc, &rcBg, bg);
    DeleteObject(bg);
    SelectObject(hdc, g_penBorder);
    Rectangle(hdc, x, y, x + w, y + h);

    // Title
    RECT rcTitle = { x, y, x + w, y + 28 };
    HBRUSH titleBg = CreateSolidBrush(COL_BG);
    FillRect(hdc, &rcTitle, titleBg);
    DeleteObject(titleBg);
    SelectObject(hdc, g_penBorder);
    MoveToEx(hdc, x, y + 28, nullptr); LineTo(hdc, x + w, y + 28);
    SetTextColor(hdc, COL_ACCENT);
    SetBkMode(hdc, TRANSPARENT);
    SelectObject(hdc, g_fontBold);
    rcTitle.left += PAD;
    DrawTextA(hdc, "TOOLCHAIN LAUNCHER", -1, &rcTitle, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

    int cols = 2;
    int cardW = (w - PAD * (cols + 1)) / cols;
    int cardH = 64;
    int cx = x + PAD;
    int cy = y + 28 + PAD;

    for (int i = 0; i < TOOL_COUNT; i++) {
        ToolDef& t = g_tools[i];
        RECT rcCard = { cx, cy, cx + cardW, cy + cardH };

        // Card background
        HBRUSH cardBg = CreateSolidBrush(COL_CARD);
        FillRect(hdc, &rcCard, cardBg);
        DeleteObject(cardBg);
        SelectObject(hdc, g_penBorder);
        Rectangle(hdc, rcCard.left, rcCard.top, rcCard.right, rcCard.bottom);

        // Color accent strip on left
        RECT rcStrip = { cx, cy, cx + 4, cy + cardH };
        HBRUSH strip = CreateSolidBrush(t.color);
        FillRect(hdc, &rcStrip, strip);
        DeleteObject(strip);

        // Tool name
        RECT rcName = { cx + 10, cy + 6, cx + cardW - 6, cy + 22 };
        SetTextColor(hdc, COL_TEXT);
        SelectObject(hdc, g_fontBold);
        DrawTextA(hdc, t.name, -1, &rcName, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);

        // CLI label
        RECT rcCli = { cx + 10, cy + 22, cx + cardW - 6, cy + 36 };
        SetTextColor(hdc, t.color);
        SelectObject(hdc, g_fontMono);
        DrawTextA(hdc, t.cli, -1, &rcCli, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);

        // Description
        RECT rcDesc = { cx + 10, cy + 38, cx + cardW - 6, cy + cardH - 4 };
        SetTextColor(hdc, COL_TEXT_DIM);
        SelectObject(hdc, g_fontMono);
        DrawTextA(hdc, t.desc, -1, &rcDesc, DT_LEFT | DT_WORDBREAK | DT_END_ELLIPSIS);

        cx += cardW + PAD;
        if ((i + 1) % cols == 0) {
            cx = x + PAD;
            cy += cardH + PAD;
        }
    }
}

void DrawStatusBar(HDC hdc, int x, int y, int w, int h) {
    HBRUSH bg = CreateSolidBrush(COL_BG);
    RECT rc = { x, y, x + w, y + h };
    FillRect(hdc, &rc, bg);
    DeleteObject(bg);
    SelectObject(hdc, g_penBorder);
    MoveToEx(hdc, x, y, nullptr); LineTo(hdc, x + w, y);

    SetBkMode(hdc, TRANSPARENT);
    SelectObject(hdc, g_fontMono);

    // Left: status message
    RECT rcMsg = { x + PAD, y + 2, x + w / 2, y + h - 2 };
    SetTextColor(hdc, g_statusColor);
    DrawTextA(hdc, g_statusMsg, -1, &rcMsg, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);

    // Right: shortcuts hint
    RECT rcHint = { x + w / 2, y + 2, x + w - PAD, y + h - 2 };
    SetTextColor(hdc, COL_TEXT_DIM);
    DrawTextA(hdc, "Ctrl+1-5 Launch | F5 Build | F9 Boot | Ctrl+L Link", -1, &rcHint, DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
}

void DrawCosmicBackground(HDC hdc, RECT const& rc) {
    using namespace Gdiplus;
    Graphics gfx(hdc);
    gfx.SetClip(Rect(rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top));

    // Deep void black base
    SolidBrush base(Color(255, 2, 2, 4));
    gfx.FillRectangle(&base, (INT)rc.left, (INT)rc.top, (INT)(rc.right - rc.left), (INT)(rc.bottom - rc.top));

    int w = rc.right - rc.left;
    int h = rc.bottom - rc.top;

    // Purple nebula glow (20% x, 80% y)
    {
        GraphicsPath path;
        int gw = w * 90 / 100;
        int gh = h * 70 / 100;
        int gx = rc.left + w * 5 / 100 - gw / 2;
        int gy = rc.top + h * 80 / 100 - gh / 2;
        path.AddEllipse(gx, gy, gw, gh);
        PathGradientBrush pgb(&path);
        pgb.SetCenterColor(Color(18, 168, 85, 247));
        Color edgeCols[] = { Color(0, 168, 85, 247) };
        int count = 1;
        pgb.SetSurroundColors(edgeCols, &count);
        gfx.FillPath(&pgb, &path);
    }

    // Cyan nebula glow (80% x, 20% y)
    {
        GraphicsPath path;
        int gw = w * 80 / 100;
        int gh = h * 60 / 100;
        int gx = rc.left + w * 80 / 100 - gw / 2;
        int gy = rc.top + h * 15 / 100 - gh / 2;
        path.AddEllipse(gx, gy, gw, gh);
        PathGradientBrush pgb(&path);
        pgb.SetCenterColor(Color(14, 0, 212, 255));
        Color edgeCols[] = { Color(0, 0, 212, 255) };
        int count = 1;
        pgb.SetSurroundColors(edgeCols, &count);
        gfx.FillPath(&pgb, &path);
    }

    // Crimson nebula glow (center)
    {
        GraphicsPath path;
        int gw = w * 70 / 100;
        int gh = h * 70 / 100;
        int gx = rc.left + w / 2 - gw / 2;
        int gy = rc.top + h / 2 - gh / 2;
        path.AddEllipse(gx, gy, gw, gh);
        PathGradientBrush pgb(&path);
        pgb.SetCenterColor(Color(10, 255, 51, 102));
        Color edgeCols[] = { Color(0, 255, 51, 102) };
        int count = 1;
        pgb.SetSurroundColors(edgeCols, &count);
        gfx.FillPath(&pgb, &path);
    }

    // Scanline overlay
    SolidBrush scan(Color(38, 0, 0, 0));
    for (int y = rc.top; y < rc.bottom; y += 4) {
        gfx.FillRectangle(&scan, (INT)rc.left, (INT)y, (INT)w, (INT)2);
    }

    // Subtle vignette
    {
        GraphicsPath path;
        path.AddEllipse(rc.left - w / 4, rc.top - h / 4, w + w / 2, h + h / 2);
        PathGradientBrush pgb(&path);
        pgb.SetCenterColor(Color(0, 0, 0, 0));
        Color edgeCols[] = { Color(80, 0, 0, 0) };
        int count = 1;
        pgb.SetSurroundColors(edgeCols, &count);
        gfx.FillPath(&pgb, &path);
    }
}

void DrawWorkspace(HDC hdc, RECT const& rc) {
    SelectObject(hdc, g_brushPanel);
    SelectObject(hdc, g_penBorder);
    Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);

    SetTextColor(hdc, COL_ACCENT);
    SetBkMode(hdc, TRANSPARENT);
    SelectObject(hdc, g_fontBold);
    RECT rcTitle = { rc.left + PAD, rc.top + PAD, rc.right, rc.top + 24 };
    DrawTextA(hdc, "WORKSPACE LOG", -1, &rcTitle, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

    SetTextColor(hdc, COL_TEXT_DIM);
    SelectObject(hdc, g_fontMono);
    int ly = rc.top + 28;
    for (auto const& line : g_log) {
        if (ly > rc.bottom - PAD - 16) break;
        RECT rcLine = { rc.left + PAD, ly, rc.right - PAD, ly + 16 };
        // Color-code by prefix
        COLORREF lineCol = COL_TEXT_DIM;
        if (line.find("[ERROR]") != std::string::npos || line.find("[FATAL]") != std::string::npos) lineCol = COL_ACCENT2;
        else if (line.find("[GO]") != std::string::npos) lineCol = COL_GREEN;
        else if (line.find("[RUN]") != std::string::npos) lineCol = COL_ORANGE;
        else if (line.find("[SYSTEM]") != std::string::npos) lineCol = COL_ACCENT;
        SetTextColor(hdc, lineCol);
        DrawTextA(hdc, line.c_str(), -1, &rcLine, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
        ly += 16;
    }
}

void DrawTerminal(HDC hdc, RECT const& rc) {
    SelectObject(hdc, g_brushPanel);
    SelectObject(hdc, g_penBorder);
    Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);

    // Title
    RECT rcTitle = { rc.left, rc.top, rc.right, rc.top + 24 };
    HBRUSH titleBrush = CreateSolidBrush(COL_BG);
    FillRect(hdc, &rcTitle, titleBrush);
    DeleteObject(titleBrush);
    SelectObject(hdc, g_penBorder);
    MoveToEx(hdc, rc.left, rc.top + 24, nullptr);
    LineTo(hdc, rc.right, rc.top + 24);

    SetTextColor(hdc, COL_GREEN);
    SetBkMode(hdc, TRANSPARENT);
    SelectObject(hdc, g_fontBold);
    rcTitle.left += PAD;
    DrawTextA(hdc, "SHELL TERMINAL", -1, &rcTitle, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

    // Lines
    RECT rcLines = { rc.left + PAD, rc.top + 28, rc.right - PAD, rc.bottom - 34 };
    SetTextColor(hdc, COL_TEXT);
    SelectObject(hdc, g_fontMono);
    int ly = rcLines.top;
    for (auto const& line : g_termLines) {
        if (ly >= rcLines.bottom) break;
        COLORREF lineCol = COL_TEXT;
        if (line.find("> ") == 0) lineCol = COL_ACCENT;
        else if (line.find("[ERR") != std::string::npos) lineCol = COL_ACCENT2;
        else if (line.find("[OK]") != std::string::npos) lineCol = COL_GREEN;
        SetTextColor(hdc, lineCol);
        RECT rcLine = { rcLines.left, ly, rcLines.right, ly + 15 };
        DrawTextA(hdc, line.c_str(), -1, &rcLine, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
        ly += 15;
    }
}

// ─── Execution ───
void AppendLog(const char* text) {
    g_log.push_back(text);
    if (g_log.size() > MAX_LOG_LINES) g_log.erase(g_log.begin());
    if (g_logFile) {
        SYSTEMTIME st;
        GetLocalTime(&st);
        fprintf(g_logFile, "[%02d:%02d:%02d] %s\n", st.wHour, st.wMinute, st.wSecond, text);
        fflush(g_logFile);
    }
    if (g_hwnd) InvalidateRect(g_hwnd, nullptr, FALSE);
}

void AppendTerm(const char* text) {
    g_termLines.push_back(text);
    if (g_termLines.size() > MAX_TERM_LINES) g_termLines.pop_front();
    if (g_hwnd) InvalidateRect(g_hwnd, nullptr, FALSE);
}

void ExecuteCommand(const char* cmd) {
    std::string c = cmd;
    std::transform(c.begin(), c.end(), c.begin(), ::tolower);
    if (c == "help" || c == "?") {
        AppendTerm("Commands:");
        AppendTerm("  build|b      Build engine project");
        AppendTerm("  clean        Clean intermediates");
        AppendTerm("  status       Show service status");
        AppendTerm("  startall     Start all auto services");
        AppendTerm("  stopall      Stop all services");
        AppendTerm("  restart      Restart all services");
        AppendTerm("  launch       Open Neural Link in browser");
        AppendTerm("  sync         Sync with Runpod remote");
        AppendTerm("  compress     Compress local assets");
        AppendTerm("  save         Save workspace snapshot");
        AppendTerm("  tool1-8      Launch tool by index (see grid)");
        AppendTerm("  vpnconnect   Connect VPN to fastest relay");
        AppendTerm("  vpndisconnect Disconnect VPN");
        AppendTerm("  vpnreconnect Reconnect VPN to fastest relay");
        AppendTerm("  vpnstatus    Show VPN status and relay list");
        AppendTerm("  quit|exit    Close deck");
        AppendTerm("");
        AppendTerm("Shortcuts: Ctrl+1-5 | F5 Build | F9 Boot | Ctrl+L Link");
    } else if (c == "build" || c == "b") {
        AppendTerm("[BUILD] cmake --build build --config Release");
        std::string cmd = std::string("powershell.exe -Command \"cd '") + g_projectRoot + "'; cmake -B build -S . -G Ninja -DCMAKE_BUILD_TYPE=Release; cmake --build build --config Release; $ec=$LASTEXITCODE; if($ec -eq 0){ Write-Host '[BUILD OK]' } else { Write-Host '[BUILD FAILED]' -ForegroundColor Red }\"";
        SpawnTool("powershell.exe", cmd.c_str() + strlen("powershell.exe "));
    } else if (c == "clean") {
        AppendTerm("[CLEAN] Removing build/ and intermediates...");
        std::string cmd = std::string("powershell.exe -Command \"cd '") + g_projectRoot + "'; Remove-Item -Recurse -Force -ErrorAction SilentlyContinue build; Remove-Item -Force source_Core_X64/*.obj, *.ilk, *.pdb; Write-Host '[CLEAN OK]'\"";
        SpawnTool("powershell.exe", cmd.c_str() + strlen("powershell.exe "));
    } else if (c == "status") {
        AppendTerm("Status:");
        for (int i=0;i<SVC_COUNT;i++) {
            std::string st = g_svcStates[i].alive ? "RUNNING" : "STOPPED";
            AppendTerm((std::string("  ") + g_svcDefs[i].name + " :" + std::to_string(g_svcDefs[i].port) + " " + st).c_str());
        }
    } else if (c == "startall") {
        AppendTerm("[SVC] Starting all auto services...");
        for (int i=0;i<SVC_COUNT;i++) if (g_svcDefs[i].autoStart) StartSvc(i);
    } else if (c == "stopall") {
        AppendTerm("[SVC] Stopping all services...");
        for (int i=0;i<SVC_COUNT;i++) StopSvc(i);
    } else if (c == "restart") {
        AppendTerm("[SVC] Restarting all services...");
        for (int i=0;i<SVC_COUNT;i++) { StopSvc(i); }
        for (int i=0;i<SVC_COUNT;i++) if (g_svcDefs[i].autoStart) StartSvc(i);
    } else if (c == "launch") {
        LaunchBrowser();
    } else if (c == "sync") {
        AppendTerm("[SYNC] Starting bi-directional sync to Runpod...");
        SpawnTool("python.exe", "runpod-bridge.py --command \"/sync\"");
    } else if (c == "compress") {
        AppendTerm("[COMPRESS] Packing assets...");
        SpawnTool("python.exe", "runpod-bridge.py --command \"/compress .\"");
    } else if (c == "save") {
        AppendTerm("[SAVE] Checkpointing workspace...");
        SpawnTool("python.exe", "runpod-bridge.py --command \"/save auto\"");
    } else if (c == "vpnconnect") {
        AppendTerm("[VPN] Connecting...");
        VpnConnect();
    } else if (c == "vpndisconnect") {
        AppendTerm("[VPN] Disconnecting...");
        VpnDisconnect();
    } else if (c == "vpnreconnect") {
        AppendTerm("[VPN] Reconnecting...");
        VpnReconnect();
    } else if (c == "vpnstatus") {
        AppendTerm("VPN Status:");
        AppendTerm((std::string("  Connected: ") + (g_vpn.connected ? "YES" : "NO")).c_str());
        AppendTerm((std::string("  Exit IP: ") + g_vpn.exitIP).c_str());
        AppendTerm((std::string("  Adapter: ") + g_vpn.adapterIP).c_str());
        AppendTerm((std::string("  Relay: ") + g_vpn.currentAccount).c_str());
        AppendTerm((std::string("  Auto-Health: ") + (g_vpn.autoHealth ? "ON" : "OFF")).c_str());
        AppendTerm((std::string("  Auto-Reconnect: ") + (g_vpn.autoReconnect ? "ON" : "OFF")).c_str());
        if (g_vpn.relayList[0]) AppendTerm((std::string("  Relays: ") + g_vpn.relayList).c_str());
    } else if (c.rfind("tool", 0) == 0 && c.length() >= 4) {
        int idx = c[4] - '1';
        if (idx >= 0 && idx < TOOL_COUNT) {
            AppendTerm((std::string("[TOOL] Launching ") + g_tools[idx].name).c_str());
            LaunchTool(idx);
        } else {
            AppendTerm("[ERR] Tool index out of range. Use tool1 through tool8.");
        }
    } else if (c == "quit" || c == "exit") {
        PostQuitMessage(0);
    } else {
        AppendTerm((std::string("[EXEC] ") + cmd).c_str());
        SpawnTool("powershell.exe", (std::string("-Command \"") + cmd + "\"").c_str());
    }
}

void SpawnTool(const char* exe, const char* args) {
    std::string cmdline = std::string("\"") + exe + "\" " + args;
    STARTUPINFOA si = {};
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi = {};
    if (CreateProcessA(nullptr, const_cast<char*>(cmdline.c_str()), nullptr, nullptr, FALSE,
                       CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi)) {
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
        AppendTerm("[OK] Tool spawned");
    } else {
        AppendTerm("[ERR] Failed to spawn tool");
    }
}

// ─── Service Orchestrator ───
void StartSvc(int idx) {
    if (idx < 0 || idx >= SVC_COUNT) return;
    if (g_svcStates[idx].alive && g_svcStates[idx].hProcess) {
        DWORD ec = 0;
        if (GetExitCodeProcess(g_svcStates[idx].hProcess, &ec) && ec == STILL_ACTIVE) {
            AppendLog((std::string("[SVC] ") + g_svcDefs[idx].name + " already running.").c_str());
            return;
        }
    }
    AppendLog((std::string("[SVC] Starting ") + g_svcDefs[idx].name + "...").c_str());
    std::string cmd = std::string(g_svcDefs[idx].cmd) + " " + g_svcDefs[idx].args;
    STARTUPINFOA si = {};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_MINIMIZE;
    PROCESS_INFORMATION pi = {};
    char deckDir[MAX_PATH];
    GetModuleFileNameA(nullptr, deckDir, MAX_PATH);
    char* lastSlash = strrchr(deckDir, '\\');
    if (lastSlash) *lastSlash = '\0';
    // Resolve relative paths to absolute for CreateProcessA reliability
    std::string resolvedCmd = cmd;
    if (cmd[0] == '"') {
        size_t endQuote = cmd.find('"', 1);
        if (endQuote != std::string::npos) {
            std::string relPath = cmd.substr(1, endQuote - 1);
            char absPath[MAX_PATH];
    		DWORD len = GetFullPathNameA(relPath.c_str(), MAX_PATH, absPath, nullptr);
            if (len > 0 && len < MAX_PATH) {
                resolvedCmd = std::string("\"") + absPath + "\"" + cmd.substr(endQuote + 1);
            }
        }
    }
    if (CreateProcessA(nullptr, const_cast<char*>(resolvedCmd.c_str()), nullptr, nullptr, FALSE,
                       CREATE_NEW_CONSOLE, nullptr, deckDir, &si, &pi)) {
        g_svcStates[idx].hProcess = pi.hProcess;
        g_svcStates[idx].pid = pi.dwProcessId;
        g_svcStates[idx].alive = true;
        g_svcStates[idx].wanted = true;
        g_svcStates[idx].startTick = GetTickCount();
        CloseHandle(pi.hThread);
        AppendLog((std::string("[SVC] ") + g_svcDefs[idx].name + " started (PID " + std::to_string(pi.dwProcessId) + ")").c_str());
    } else {
        DWORD err = GetLastError();
        char errBuf[256] = {};
        FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, nullptr, err, 0, errBuf, 256, nullptr);
        AppendLog((std::string("[ERR] Failed to start ") + g_svcDefs[idx].name + " (error " + std::to_string(err) + ": " + errBuf + ")").c_str());
    }
}

void StopSvc(int idx) {
    if (idx < 0 || idx >= SVC_COUNT) return;
    g_svcStates[idx].wanted = false;
    if (g_svcStates[idx].hProcess) {
        TerminateProcess(g_svcStates[idx].hProcess, 0);
        CloseHandle(g_svcStates[idx].hProcess);
        g_svcStates[idx].hProcess = nullptr;
    }
    g_svcStates[idx].alive = false;
    g_svcStates[idx].pid = 0;
}

bool ProbeServicePort(int port, DWORD timeoutMs = 3000) {
    SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (s == INVALID_SOCKET) return false;
    u_long nonblock = 1;
    ioctlsocket(s, FIONBIO, &nonblock);
    sockaddr_in addr = {};
    addr.sin_family = AF_INET;
    addr.sin_port = htons((u_short)port);
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    int rc = connect(s, (sockaddr*)&addr, sizeof(addr));
    if (rc == SOCKET_ERROR) {
        int err = WSAGetLastError();
        if (err == WSAEWOULDBLOCK) {
            fd_set fds; FD_ZERO(&fds); FD_SET(s, &fds);
            timeval tv = { (long)(timeoutMs / 1000), (long)((timeoutMs % 1000) * 1000) };
            rc = select(0, nullptr, &fds, nullptr, &tv);
            if (rc > 0) {
                int soerr = 0; int len = sizeof(soerr);
                getsockopt(s, SOL_SOCKET, SO_ERROR, (char*)&soerr, &len);
                rc = (soerr == 0) ? 1 : 0;
            } else { rc = 0; }
        } else { rc = 0; }
    }
    closesocket(s);
    return rc != 0;
}

void CheckSvcs() {
    for (int i = 0; i < SVC_COUNT; i++) {
        bool procAlive = false;
        if (g_svcStates[i].hProcess) {
            DWORD ec = 0;
            if (GetExitCodeProcess(g_svcStates[i].hProcess, &ec) && ec == STILL_ACTIVE) {
                procAlive = true;
            }
        }
        bool wasAlive = g_svcStates[i].alive;
        // During first 6s after start, trust the process handle (startup grace)
        if (GetTickCount() - g_svcStates[i].startTick < 6000) {
            g_svcStates[i].alive = procAlive;
        } else {
            g_svcStates[i].alive = procAlive; // after grace, still process-only (TCP probe moved off UI thread)
        }

        if (wasAlive && !g_svcStates[i].alive) {
            AppendLog((std::string("[SVC] ") + g_svcDefs[i].name + " stopped.").c_str());
            if (g_svcStates[i].hProcess) {
                TerminateProcess(g_svcStates[i].hProcess, 0);
                CloseHandle(g_svcStates[i].hProcess);
                g_svcStates[i].hProcess = nullptr;
            }
            g_svcStates[i].pid = 0;
            if (g_svcStates[i].wanted) {
                AppendLog((std::string("[SVC] Auto-restarting ") + g_svcDefs[i].name + "...").c_str());
                StartSvc(i);
            }
        }
    }
}

void LaunchBrowser() {
    AppendLog("[GO] Opening Neural Link in default browser...");
    // Open via Hermes Bridge (localhost:8643) so the page loads from the
    // same origin as the API. This avoids CORS / mixed-content blocks that
    // occur when opening the HTML directly via file:// protocol.
    ShellExecuteA(g_hwnd, "open", "http://localhost:8643/", nullptr, nullptr, SW_SHOW);
    SetStatus("Neural Link opened in browser", COL_PURPLE);
}

void DrawServicePanel(HDC hdc, int x, int y, int w, int h) {
    SelectObject(hdc, g_brushPanel);
    SelectObject(hdc, g_penBorder);
    Rectangle(hdc, x, y, x + w, y + h);
    RECT rcTitle = { x, y, x + w, y + 26 };
    HBRUSH titleBrush = CreateSolidBrush(COL_BG);
    FillRect(hdc, &rcTitle, titleBrush);
    DeleteObject(titleBrush);
    MoveToEx(hdc, x, y + 26, nullptr); LineTo(hdc, x + w, y + 26);
    SetTextColor(hdc, COL_GREEN); SetBkMode(hdc, TRANSPARENT); SelectObject(hdc, g_fontBold);
    rcTitle.left += PAD;
    DrawTextA(hdc, "SERVICE ORCHESTRATOR", -1, &rcTitle, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

    int ly = y + 32;
    SetTextColor(hdc, COL_TEXT_DIM); SelectObject(hdc, g_fontMono);
    for (int i = 0; i < SVC_COUNT; i++) {
        if (ly > y + h - 20) break;
        bool alive = g_svcStates[i].alive;
        HBRUSH dot = alive ? g_brushGreen : g_brushRed;
        RECT rcDot = { x + PAD + 2, ly + 4, x + PAD + 12, ly + 14 };
        FillRect(hdc, &rcDot, dot);
        SelectObject(hdc, g_penBorder);
        Rectangle(hdc, rcDot.left, rcDot.top, rcDot.right, rcDot.bottom);
        SetTextColor(hdc, alive ? COL_GREEN : COL_ACCENT2);
        RECT rcName = { x + PAD + 18, ly, x + w - PAD, ly + 18 };
        std::string line = std::string(g_svcDefs[i].name) + " :" + std::to_string(g_svcDefs[i].port);
        if (g_svcStates[i].pid > 0) line += " (PID " + std::to_string(g_svcStates[i].pid) + ")";
        DrawTextA(hdc, line.c_str(), -1, &rcName, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
        ly += 20;
    }
    if (ly < y + h - 30) {
        ly += 4;
        RECT rcBtn = { x + PAD, ly, x + w - PAD, ly + 24 };
        HBRUSH btnBrush = CreateSolidBrush(COL_ORANGE);
        FillRect(hdc, &rcBtn, btnBrush);
        DeleteObject(btnBrush);
        SelectObject(hdc, g_penBorder);
        Rectangle(hdc, rcBtn.left, rcBtn.top, rcBtn.right, rcBtn.bottom);
        SetTextColor(hdc, COL_BG); SelectObject(hdc, g_fontBold);
        DrawTextA(hdc, "LAUNCH NEURAL LINK", -1, &rcBtn, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    }
}

// ─── Memory Monitor ───
void UpdateMemory() {
    MEMORYSTATUSEX mem = {};
    mem.dwLength = sizeof(mem);
    if (!GlobalMemoryStatusEx(&mem)) return;
    g_mem.ramPct = mem.dwMemoryLoad;
    if (mem.ullTotalPageFile > 0) {
        g_mem.pfPct = (DWORD)((mem.ullTotalPageFile - mem.ullAvailPageFile) * 100 / mem.ullTotalPageFile);
    } else {
        g_mem.pfPct = 0;
    }
    if (g_mem.ramPct > 65 && !g_mem.tqTriggered) {
        g_mem.tqTriggered = true;
        AppendLog("[TQ] SYSRAM > 65% — triggering TurboQuant KV cache scaling...");
        int bits = g_mem.ramPct > 75 ? 2 : 3;
        std::string args = "turboquant-liminal.py --scale " + std::to_string(bits);
        SpawnTool("python.exe", args.c_str());
    } else if (g_mem.ramPct < 55) {
        g_mem.tqTriggered = false;
    }
}

void DrawMemoryPanel(HDC hdc, int x, int y, int w, int h) {
    SelectObject(hdc, g_brushPanel);
    SelectObject(hdc, g_penBorder);
    Rectangle(hdc, x, y, x + w, y + h);
    RECT rcTitle = { x, y, x + w, y + 26 };
    HBRUSH titleBrush = CreateSolidBrush(COL_BG);
    FillRect(hdc, &rcTitle, titleBrush);
    DeleteObject(titleBrush);
    MoveToEx(hdc, x, y + 26, nullptr); LineTo(hdc, x + w, y + 26);
    SetTextColor(hdc, COL_ACCENT); SetBkMode(hdc, TRANSPARENT); SelectObject(hdc, g_fontBold);
    rcTitle.left += PAD;
    DrawTextA(hdc, "MEMORY NODE", -1, &rcTitle, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

    int ly = y + 34;
    int barW = w - PAD * 4 - 80;
    int barH = 14;

    // SYSRAM bar
    RECT rcLabel = { x + PAD, ly, x + 70, ly + 16 };
    SetTextColor(hdc, COL_TEXT_DIM); SelectObject(hdc, g_fontMono);
    DrawTextA(hdc, "SYSRAM", -1, &rcLabel, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    RECT rcBarBg = { x + 72, ly + 1, x + 72 + barW, ly + barH };
    FillRect(hdc, &rcBarBg, g_brushBg);
    SelectObject(hdc, g_penBorder);
    Rectangle(hdc, rcBarBg.left, rcBarBg.top, rcBarBg.right, rcBarBg.bottom);
    int fillW = (int)(barW * g_mem.ramPct / 100.0);
    if (fillW > 0) {
        COLORREF barCol = g_mem.ramPct > 90 ? COL_ACCENT2 : g_mem.ramPct > 65 ? COL_ORANGE : COL_ACCENT;
        HBRUSH barBrush = CreateSolidBrush(barCol);
        RECT rcFill = { rcBarBg.left + 1, rcBarBg.top + 1, rcBarBg.left + fillW, rcBarBg.bottom - 1 };
        FillRect(hdc, &rcFill, barBrush);
        DeleteObject(barBrush);
    }
    RECT rcPct = { rcBarBg.right + 4, ly, x + w - PAD, ly + 16 };
    SetTextColor(hdc, g_mem.ramPct > 90 ? COL_ACCENT2 : g_mem.ramPct > 65 ? COL_ORANGE : COL_ACCENT);
    std::string pct = std::to_string(g_mem.ramPct) + "%";
    DrawTextA(hdc, pct.c_str(), -1, &rcPct, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    ly += 22;

    // PAGEFILE bar
    RECT rcPfLabel = { x + PAD, ly, x + 70, ly + 16 };
    SetTextColor(hdc, COL_TEXT_DIM); SelectObject(hdc, g_fontMono);
    DrawTextA(hdc, "PAGEFILE", -1, &rcPfLabel, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    RECT rcPfBarBg = { x + 72, ly + 1, x + 72 + barW, ly + barH };
    FillRect(hdc, &rcPfBarBg, g_brushBg);
    SelectObject(hdc, g_penBorder);
    Rectangle(hdc, rcPfBarBg.left, rcPfBarBg.top, rcPfBarBg.right, rcPfBarBg.bottom);
    int pfFillW = (int)(barW * g_mem.pfPct / 100.0);
    if (pfFillW > 0) {
        COLORREF pfCol = g_mem.pfPct > 80 ? COL_ACCENT2 : COL_ACCENT;
        HBRUSH pfBrush = CreateSolidBrush(pfCol);
        RECT rcPfFill = { rcPfBarBg.left + 1, rcPfBarBg.top + 1, rcPfBarBg.left + pfFillW, rcPfBarBg.bottom - 1 };
        FillRect(hdc, &rcPfFill, pfBrush);
        DeleteObject(pfBrush);
    }
    RECT rcPfPct = { rcPfBarBg.right + 4, ly, x + w - PAD, ly + 16 };
    SetTextColor(hdc, g_mem.pfPct > 80 ? COL_ACCENT2 : COL_ACCENT);
    std::string pfPct = std::to_string(g_mem.pfPct) + "%";
    DrawTextA(hdc, pfPct.c_str(), -1, &rcPfPct, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    ly += 24;

    // TurboQuant status
    RECT rcTq = { x + PAD, ly, x + w - PAD, ly + 16 };
    SetTextColor(hdc, g_mem.tqTriggered ? COL_ORANGE : COL_TEXT_DIM);
    SelectObject(hdc, g_fontMono);
    std::string tqLine = g_mem.tqTriggered ? "[TQ] KV cache scaling ACTIVE" : "[TQ] Idle — watching...";
    DrawTextA(hdc, tqLine.c_str(), -1, &rcTq, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
}

// ─── VPN Implementation ───
std::string HttpGet(const char* url, DWORD timeoutMs = 5000) {
    HINTERNET hInternet = InternetOpenA("VoidWalkers-Deck/1.0", INTERNET_OPEN_TYPE_PRECONFIG, nullptr, nullptr, 0);
    if (!hInternet) return "";
    HINTERNET hConnect = InternetOpenUrlA(hInternet, url, nullptr, 0, INTERNET_FLAG_RELOAD, 0);
    if (!hConnect) { InternetCloseHandle(hInternet); return ""; }
    char buffer[4096];
    DWORD read = 0;
    std::string result;
    while (InternetReadFile(hConnect, buffer, sizeof(buffer) - 1, &read) && read > 0) {
        buffer[read] = '\0';
        result += buffer;
    }
    InternetCloseHandle(hConnect);
    InternetCloseHandle(hInternet);
    return result;
}

void UpdateVpnHealth() {
    if (!g_vpn.autoHealth) return;  // disabled by default
    DWORD now = GetTickCount();
    if (now - g_vpn.lastHealthCheck < 15000) return; // check every 15s
    g_vpn.lastHealthCheck = now;

    // Check adapter IP via ipconfig
    {
        FILE* pipe = _popen("ipconfig | findstr \"IPv4.*10\\.211\"", "r");
        if (pipe) {
            char line[256];
            bool found = false;
            while (fgets(line, sizeof(line), pipe)) {
                char* ip = strstr(line, "10.211");
                if (!ip) ip = strstr(line, "192.168.30");
                if (ip) {
                    char* end = ip;
                    while (*end && (*end == '.' || (*end >= '0' && *end <= '9'))) end++;
                    *end = '\0';
                    strncpy(g_vpn.adapterIP, ip, 63);
                    g_vpn.adapterIP[63] = '\0';
                    found = true;
                    break;
                }
            }
            _pclose(pipe);
            if (!found) {
                strcpy(g_vpn.adapterIP, "--");
                g_vpn.connected = false;
            }
        }
    }

    // Test exit IP + bandwidth via VPN monitor HTTP endpoint (if monitor is running)
    std::string health = HttpGet("http://127.0.0.1:8645/health", 3000);
    if (!health.empty() && health.find("\"connected\":true") != std::string::npos) {
        g_vpn.connected = true;
        size_t ipPos = health.find("\"exit_ip\":\"");
        if (ipPos != std::string::npos) {
            ipPos += 11;
            size_t end = health.find("\"", ipPos);
            if (end != std::string::npos) {
                std::string ip = health.substr(ipPos, end - ipPos);
                strncpy(g_vpn.exitIP, ip.c_str(), 63);
                g_vpn.exitIP[63] = '\0';
            }
        }
        size_t acctPos = health.find("\"current_account\":\"");
        if (acctPos != std::string::npos) {
            acctPos += 19;
            size_t end = health.find("\"", acctPos);
            if (end != std::string::npos) {
                std::string acct = health.substr(acctPos, end - acctPos);
                strncpy(g_vpn.currentAccount, acct.c_str(), 127);
                g_vpn.currentAccount[127] = '\0';
            }
        }
        g_vpn.failureCount = 0;
    } else {
        g_vpn.connected = false;
        g_vpn.failureCount++;
        if (g_vpn.autoReconnect && g_vpn.failureCount >= 2) {
            AppendLog("[VPN] Auto-reconnect triggered...");
            VpnReconnect();
            g_vpn.failureCount = 0;
        }
    }

    // Bandwidth test only when autoHealth is on
    if (g_vpn.autoHealth && g_vpn.connected) {
        DWORD speedStart = GetTickCount();
        std::string speedTest = HttpGet("https://checkip.amazonaws.com", 5000);
        DWORD speedElapsed = GetTickCount() - speedStart;
        if (speedElapsed > 0 && !speedTest.empty()) {
            g_vpn.lastSpeedMbps = 0.005 / (speedElapsed / 1000.0) * 8.0;
            if (g_vpn.lastSpeedMbps < 0.5 && g_vpn.autoReconnect) {
                AppendLog("[VPN] Bandwidth low — auto-reconnecting...");
                VpnReconnect();
            }
        }
    }
}

void FetchVpnRelays() {
    if (!g_vpn.autoHealth) return;  // disabled by default
    DWORD now = GetTickCount();
    if (now - g_vpn.lastRelayFetch < 60000) return; // fetch every 60s
    g_vpn.lastRelayFetch = now;
    std::string data = HttpGet("https://www.vpngate.net/api/iphone/", 15000);
    if (data.empty()) return;
    std::string list;
    int count = 0;
    size_t pos = 0;
    while ((pos = data.find('\n', pos)) != std::string::npos) {
        pos++;
        size_t end = data.find('\n', pos);
        if (end == std::string::npos) break;
        std::string line = data.substr(pos, end - pos);
        pos = end;
        std::vector<std::string> cols;
        size_t c = 0;
        while (c < line.size()) {
            size_t ce = line.find(',', c);
            if (ce == std::string::npos) ce = line.size();
            cols.push_back(line.substr(c, ce - c));
            c = ce + 1;
        }
        if (cols.size() < 15) continue;
        if (cols[6] == "JP" || cols[6] == "KR") {
            long score = 0, speed = 0;
            try { score = std::stol(cols[2]); } catch (...) {}
            try { speed = std::stol(cols[4]); } catch (...) {}
            if (score > 200000 && speed > 1500000) {
                list += cols[1] + " (" + cols[6] + ") ";
                if (++count >= 8) break;
            }
        }
    }
    strncpy(g_vpn.relayList, list.c_str(), 1023);
    g_vpn.relayList[1023] = '\0';
}

void VpnConnect() {
    AppendLog("[VPN] Running full diagnose + connect cycle...");
    AppendLog("[VPN] This will create virtual NIC if missing and reset adapter.");
    // Run the comprehensive fix script that handles NIC creation, adapter reset, and connection
    SpawnTool("powershell.exe", "-ExecutionPolicy Bypass -File \"vpn-diagnose-fix.ps1\"");
}

void VpnDisconnect() {
    AppendLog("[VPN] Disconnecting...");
    SpawnTool("powershell.exe", "-Command \"& 'C:\\Program Files\\SoftEther VPN Client\\vpncmd.exe' localhost /CLIENT /CMD AccountDisconnect VW_JP_219.100.37.162; & 'C:\\Program Files\\SoftEther VPN Client\\vpncmd.exe' localhost /CLIENT /CMD AccountDisconnect VW_JP_219.100.37.193; & 'C:\\Program Files\\SoftEther VPN Client\\vpncmd.exe' localhost /CLIENT /CMD AccountDisconnect VPN_Gate_Connection\"");
    g_vpn.connected = false;
    strcpy(g_vpn.exitIP, "--");
    strcpy(g_vpn.adapterIP, "--");
}

void VpnReconnect() {
    AppendLog("[VPN] Reconnecting to fastest available relay...");
    VpnDisconnect();
    Sleep(1000);
    VpnConnect();
}

void DrawVpnPanel(HDC hdc, int x, int y, int w, int h) {
    SelectObject(hdc, g_brushPanel);
    SelectObject(hdc, g_penBorder);
    Rectangle(hdc, x, y, x + w, y + h);
    RECT rcTitle = { x, y, x + w, y + 26 };
    HBRUSH titleBrush = CreateSolidBrush(COL_BG);
    FillRect(hdc, &rcTitle, titleBrush);
    DeleteObject(titleBrush);
    MoveToEx(hdc, x, y + 26, nullptr); LineTo(hdc, x + w, y + 26);
    COLORREF titleCol = g_vpn.connected ? COL_GREEN : COL_ACCENT2;
    SetTextColor(hdc, titleCol); SetBkMode(hdc, TRANSPARENT); SelectObject(hdc, g_fontBold);
    rcTitle.left += PAD;
    DrawTextA(hdc, "VPN TUNNEL", -1, &rcTitle, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

    int ly = y + 32;
    SetTextColor(hdc, COL_TEXT_DIM); SelectObject(hdc, g_fontMono);

    // Status dot
    HBRUSH dot = g_vpn.connected ? g_brushGreen : g_brushRed;
    RECT rcDot = { x + PAD + 2, ly + 2, x + PAD + 12, ly + 12 };
    FillRect(hdc, &rcDot, dot);
    SelectObject(hdc, g_penBorder);
    Rectangle(hdc, rcDot.left, rcDot.top, rcDot.right, rcDot.bottom);

    RECT rcLine = { x + PAD + 18, ly, x + w - PAD, ly + 16 };
    std::string status = g_vpn.connected ? "CONNECTED  " : "DISCONNECTED  ";
    status += g_vpn.exitIP;
    SetTextColor(hdc, g_vpn.connected ? COL_GREEN : COL_ACCENT2);
    DrawTextA(hdc, status.c_str(), -1, &rcLine, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    ly += 18;

    rcLine.top = ly; rcLine.bottom = ly + 16;
    std::string adapter = std::string("Adapter: ") + g_vpn.adapterIP;
    SetTextColor(hdc, COL_TEXT_DIM);
    DrawTextA(hdc, adapter.c_str(), -1, &rcLine, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    ly += 18;

    rcLine.top = ly; rcLine.bottom = ly + 16;
    std::string acct = std::string("Relay: ") + g_vpn.currentAccount;
    SetTextColor(hdc, COL_TEXT_DIM);
    DrawTextA(hdc, acct.c_str(), -1, &rcLine, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    ly += 18;

    rcLine.top = ly; rcLine.bottom = ly + 16;
    char speedBuf[64];
    snprintf(speedBuf, 64, "Health: %s  Speed: %.1f Mbps", g_vpn.autoHealth ? "AUTO" : "MANUAL", g_vpn.lastSpeedMbps);
    SetTextColor(hdc, COL_ORANGE);
    DrawTextA(hdc, speedBuf, -1, &rcLine, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    ly += 20;

    // Relay list
    if (g_vpn.relayList[0]) {
        rcLine.top = ly; rcLine.bottom = ly + 16;
        SetTextColor(hdc, COL_TEXT_DIM);
        DrawTextA(hdc, "Top Relays:", -1, &rcLine, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
        ly += 16;
        rcLine.top = ly; rcLine.bottom = ly + 14;
        SetTextColor(hdc, COL_TEXT_DIM);
        SelectObject(hdc, g_fontMono);
        DrawTextA(hdc, g_vpn.relayList, -1, &rcLine, DT_LEFT | DT_WORDBREAK | DT_END_ELLIPSIS);
    }

    // Buttons
    ly = y + h - 28;
    RECT rcBtn1 = { x + PAD, ly, x + w / 2 - PAD, ly + 22 };
    HBRUSH btnBrush = CreateSolidBrush(g_vpn.connected ? COL_ACCENT2 : COL_GREEN);
    FillRect(hdc, &rcBtn1, btnBrush);
    DeleteObject(btnBrush);
    SelectObject(hdc, g_penBorder);
    Rectangle(hdc, rcBtn1.left, rcBtn1.top, rcBtn1.right, rcBtn1.bottom);
    SetTextColor(hdc, COL_BG); SelectObject(hdc, g_fontBold);
    DrawTextA(hdc, g_vpn.connected ? "DISCONNECT" : "CONNECT", -1, &rcBtn1, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    RECT rcBtn2 = { x + w / 2 + PAD, ly, x + w - PAD, ly + 22 };
    btnBrush = CreateSolidBrush(COL_ORANGE);
    FillRect(hdc, &rcBtn2, btnBrush);
    DeleteObject(btnBrush);
    SelectObject(hdc, g_penBorder);
    Rectangle(hdc, rcBtn2.left, rcBtn2.top, rcBtn2.right, rcBtn2.bottom);
    SetTextColor(hdc, COL_BG); SelectObject(hdc, g_fontBold);
    DrawTextA(hdc, "RECONNECT", -1, &rcBtn2, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}

// ═══════════════════════════════════════════════════════════════
//  Telemetry / Diagnostics Implementation
// ═══════════════════════════════════════════════════════════════

// ─── Minimal JSON helpers (no external lib, just enough for telemetry) ───

std::string JsonGetObject(const std::string& json, const std::string& key) {
    std::string search = "\"" + key + "\":";
    size_t pos = json.find(search);
    if (pos == std::string::npos) return "";
    pos += search.size();
    while (pos < json.size() && (json[pos] == ' ' || json[pos] == '\t' || json[pos] == '\n')) pos++;
    if (pos >= json.size() || json[pos] != '{') return "";
    int depth = 0;
    size_t start = pos;
    for (; pos < json.size(); pos++) {
        if (json[pos] == '{') depth++;
        else if (json[pos] == '}') { depth--; if (depth == 0) { pos++; break; } }
    }
    return json.substr(start, pos - start);
}

std::string JsonGetString(const std::string& json, const std::string& key) {
    std::string search = "\"" + key + "\":";
    size_t pos = json.find(search);
    if (pos == std::string::npos) return "";
    pos += search.size();
    while (pos < json.size() && (json[pos] == ' ' || json[pos] == '\t' || json[pos] == '\n')) pos++;
    if (pos >= json.size() || json[pos] != '"') return "";
    pos++;
    size_t end = pos;
    while (end < json.size() && json[end] != '"') {
        if (json[end] == '\\') end++;
        end++;
    }
    return json.substr(pos, end - pos);
}

double JsonGetNum(const std::string& json, const std::string& key, double defVal) {
    std::string search = "\"" + key + "\":";
    size_t pos = json.find(search);
    if (pos == std::string::npos) return defVal;
    pos += search.size();
    while (pos < json.size() && (json[pos] == ' ' || json[pos] == '\t' || json[pos] == '\n')) pos++;
    if (pos >= json.size()) return defVal;
    try { return std::stod(json.substr(pos)); } catch (...) { return defVal; }
}

bool JsonGetBool(const std::string& json, const std::string& key) {
    std::string search = "\"" + key + "\":";
    size_t pos = json.find(search);
    if (pos == std::string::npos) return false;
    pos += search.size();
    while (pos < json.size() && (json[pos] == ' ' || json[pos] == '\t' || json[pos] == '\n')) pos++;
    return (pos < json.size() && json[pos] == 't');
}

// ─── Local HTTP GET for telemetry endpoints ───
std::string LocalHttpGet(int port, const char* path, DWORD timeoutMs = 4000) {
    SOCKET s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (s == INVALID_SOCKET) return "";
    sockaddr_in addr = {};
    addr.sin_family = AF_INET;
    addr.sin_port = htons((u_short)port);
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    u_long nonblock = 1;
    ioctlsocket(s, FIONBIO, &nonblock);
    connect(s, (sockaddr*)&addr, sizeof(addr));
    fd_set fds; FD_ZERO(&fds); FD_SET(s, &fds);
    timeval tv = { (long)(timeoutMs / 1000), (long)((timeoutMs % 1000) * 1000) };
    int rc = select(0, nullptr, &fds, nullptr, &tv);
    if (rc <= 0) { closesocket(s); return ""; }
    int soerr = 0; int len = sizeof(soerr);
    getsockopt(s, SOL_SOCKET, SO_ERROR, (char*)&soerr, &len);
    if (soerr != 0) { closesocket(s); return ""; }
    // Send HTTP request
    std::string req = std::string("GET ") + path + " HTTP/1.1\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n";
    send(s, req.c_str(), (int)req.size(), 0);
    // Read response
    u_long block = 0;
    ioctlsocket(s, FIONBIO, &block);
    std::string result;
    char buf[4096];
    int n;
    DWORD startTick = GetTickCount();
    do {
        n = recv(s, buf, sizeof(buf) - 1, 0);
        if (n > 0) { buf[n] = '\0'; result += buf; }
        if (GetTickCount() - startTick > timeoutMs) break;
    } while (n > 0);
    closesocket(s);
    // Strip HTTP headers
    size_t bodyStart = result.find("\r\n\r\n");
    if (bodyStart != std::string::npos) return result.substr(bodyStart + 4);
    return result;
}

void FetchTelemetry() {
    // Fetch /nexus/telemetry from Hermes Bridge (port 8643)
    std::string telJson = LocalHttpGet(8643, "/nexus/telemetry", 3000);
    if (telJson.empty()) {
        g_telemetry.fetched = false;
        g_telemetry.lastFetch = GetTickCount();
        return;
    }
    g_telemetry.fetched = true;
    g_telemetry.lastFetch = GetTickCount();

    // Parse service statuses
    std::string nexusObj = JsonGetObject(telJson, "nexus");
    g_telemetry.nexusAlive = JsonGetBool(nexusObj, "alive");
    g_telemetry.nexusAgents = (int)JsonGetNum(nexusObj, "agents");
    std::string tasksObj = JsonGetObject(nexusObj, "tasks");
    g_telemetry.nexusTasksPending = (int)(JsonGetNum(tasksObj, "pending") + JsonGetNum(tasksObj, "claimed") + JsonGetNum(tasksObj, "running"));
    g_telemetry.nexusTasksDone = (int)JsonGetNum(tasksObj, "done");
    g_telemetry.nexusTasksFailed = (int)JsonGetNum(tasksObj, "failed");
    g_telemetry.nexusSessions = (int)JsonGetNum(nexusObj, "sessions");

    std::string tqObj = JsonGetObject(telJson, "turboquant");
    g_telemetry.tqAlive = JsonGetBool(tqObj, "alive");
    g_telemetry.tqRamPct = JsonGetNum(tqObj, "ram_pct");
    std::string tqMode = JsonGetString(tqObj, "mode");
    if (tqMode.empty()) tqMode = "offline";
    strncpy(g_telemetry.tqMode, tqMode.c_str(), 31);
    g_telemetry.tqMode[31] = '\0';

    std::string ollamaObj = JsonGetObject(telJson, "ollama");
    g_telemetry.ollamaAlive = JsonGetBool(ollamaObj, "alive");

    std::string harnessObj = JsonGetObject(telJson, "harness");
    g_telemetry.harnessAlive = JsonGetBool(harnessObj, "alive");

    std::string koboldObj = JsonGetObject(telJson, "koboldcpp");
    g_telemetry.koboldAlive = JsonGetBool(koboldObj, "alive");

    std::string hbObj = JsonGetObject(telJson, "heartbeat");
    g_telemetry.heartbeatAlive = JsonGetBool(hbObj, "alive");

    // Tier
    std::string tierObj = JsonGetObject(telJson, "tier");
    g_telemetry.tierKvBits = (int)JsonGetNum(tierObj, "kv_bits");
    std::string tierName = JsonGetString(tierObj, "current");
    if (!tierName.empty()) { strncpy(g_telemetry.tierName, tierName.c_str(), 63); g_telemetry.tierName[63] = '\0'; }

    // Pipeline
    std::string pipeObj = JsonGetObject(telJson, "pipeline");
    std::string pipeLabel = JsonGetString(pipeObj, "label");
    if (!pipeLabel.empty()) { strncpy(g_telemetry.pipelineLabel, pipeLabel.c_str(), 63); g_telemetry.pipelineLabel[63] = '\0'; }

    // Counters
    std::string cntObj = JsonGetObject(telJson, "counters");
    g_telemetry.chatRequests = (int)JsonGetNum(cntObj, "chat_requests");
    g_telemetry.committeeTriggers = (int)JsonGetNum(cntObj, "committee_triggers");
    g_telemetry.pipelineSwitches = (int)JsonGetNum(cntObj, "pipeline_switches");

    // Alerts — find first alert in array
    size_t alertPos = telJson.find("\"alerts\"");
    if (alertPos != std::string::npos) {
        alertPos = telJson.find('[', alertPos);
        if (alertPos != std::string::npos) {
            size_t alertEnd = telJson.find(']', alertPos);
            if (alertEnd != std::string::npos && alertEnd > alertPos + 2) {
                std::string alertArr = telJson.substr(alertPos + 1, alertEnd - alertPos - 1);
                std::string firstAlert = JsonGetObject(alertArr, "");
                if (!firstAlert.empty()) {
                    std::string level = JsonGetString(firstAlert, "level");
                    std::string msg = JsonGetString(firstAlert, "message");
                    if (!level.empty()) { strncpy(g_telemetry.alertLevel, level.c_str(), 15); g_telemetry.alertLevel[15] = '\0'; }
                    if (!msg.empty()) { strncpy(g_telemetry.alertMessage, msg.c_str(), 255); g_telemetry.alertMessage[255] = '\0'; }
                } else {
                    g_telemetry.alertLevel[0] = '\0';
                }
            } else {
                g_telemetry.alertLevel[0] = '\0';
            }
        }
    } else {
        g_telemetry.alertLevel[0] = '\0';
    }

    // Fetch HBE/Coigni stats
    std::string hbeJson = LocalHttpGet(8643, "/nexus/hbe-stats", 2000);
    if (!hbeJson.empty()) {
        g_telemetry.totalPulses = (int)JsonGetNum(hbeJson, "total_pulses");
        g_telemetry.llmInvocations = (int)JsonGetNum(hbeJson, "llm_invocations");
        g_telemetry.deterministicBypass = (int)JsonGetNum(hbeJson, "deterministic_bypass");
        g_telemetry.triggerFreqPerMin = JsonGetNum(hbeJson, "trigger_frequency_per_min");
        g_telemetry.taskQueueDepth = (int)JsonGetNum(hbeJson, "task_queue_depth");
        std::string eff = JsonGetString(hbeJson, "efficiency_rate");
        if (!eff.empty()) { strncpy(g_telemetry.efficiencyRate, eff.c_str(), 15); g_telemetry.efficiencyRate[15] = '\0'; }
    }

    // Fetch Colibri bridge stats (port 8648)
    std::string colJson = LocalHttpGet(8648, "/colibri/status", 2000);
    if (!colJson.empty()) {
        g_telemetry.colibriAlive = JsonGetBool(colJson, "alive");
        g_telemetry.colibriHotExpert = (int)JsonGetNum(colJson, "hot_expert");
        g_telemetry.colibriColdExperts = (int)JsonGetNum(colJson, "cold_experts");
        g_telemetry.colibriCacheHits = (int)JsonGetNum(colJson, "cache_hits");
        g_telemetry.colibriCacheMisses = (int)JsonGetNum(colJson, "cache_misses");
        g_telemetry.colibriSwapEvents = (int)JsonGetNum(colJson, "swap_events");
        g_telemetry.colibriRamBudget = (int)JsonGetNum(colJson, "ram_budget_mb");
        g_telemetry.colibriRamUsed = (int)JsonGetNum(colJson, "ram_used_mb");
        std::string hotName = JsonGetString(colJson, "hot_expert_name");
        if (!hotName.empty()) { strncpy(g_telemetry.colibriHotExpertName, hotName.c_str(), 31); g_telemetry.colibriHotExpertName[31] = '\0'; }
    } else {
        g_telemetry.colibriAlive = false;
    }

    // FUBBU sidecar (port 8653)
    std::string fubbuObj = JsonGetObject(telJson, "fubbu");
    g_telemetry.fubbuAlive = JsonGetBool(fubbuObj, "alive");
    g_telemetry.fubbuTasksActive = (int)JsonGetNum(fubbuObj, "active_tasks");
    g_telemetry.fubbuTasksDone = (int)JsonGetNum(fubbuObj, "completed_tasks");

    // ZHARK CSO (port 8654)
    std::string zharkObj = JsonGetObject(telJson, "zhark");
    g_telemetry.zharkAlive = JsonGetBool(zharkObj, "alive");
    g_telemetry.zharkCycles = (int)JsonGetNum(zharkObj, "cycles");
    g_telemetry.zharkConvergence = JsonGetNum(zharkObj, "convergence");

    // VW RAG (via Nexus)
    std::string ragObj = JsonGetObject(telJson, "rag");
    g_telemetry.ragAlive = JsonGetBool(ragObj, "alive");
    g_telemetry.ragChunkCount = (int)JsonGetNum(ragObj, "total_chunks");
}

void DrawTelemetryPanel(HDC hdc, int x, int y, int w, int h) {
    // Panel background
    SelectObject(hdc, g_brushPanel);
    SelectObject(hdc, g_penBorder);
    Rectangle(hdc, x, y, x + w, y + h);

    // Title bar
    RECT rcTitle = { x, y, x + w, y + 26 };
    HBRUSH titleBrush = CreateSolidBrush(COL_BG);
    FillRect(hdc, &rcTitle, titleBrush);
    DeleteObject(titleBrush);
    MoveToEx(hdc, x, y + 26, nullptr); LineTo(hdc, x + w, y + 26);
    SetTextColor(hdc, COL_CYAN_DIM); SetBkMode(hdc, TRANSPARENT); SelectObject(hdc, g_fontBold);
    rcTitle.left += PAD;
    DrawTextA(hdc, "DIAGNOSTICS", -1, &rcTitle, DT_LEFT | DT_VCENTER | DT_SINGLELINE);

    int ly = y + 30;
    int lineH = 16;

    // ─── Alert Banner ───
    if (g_telemetry.alertLevel[0]) {
        bool isRed = strcmp(g_telemetry.alertLevel, "red") == 0;
        COLORREF alertCol = isRed ? COL_STATUS_ERR : COL_STATUS_WARN;
        HBRUSH alertBrush = CreateSolidBrush(alertCol);
        RECT rcAlert = { x + PAD, ly, x + w - PAD, ly + 22 };
        FillRect(hdc, &rcAlert, alertBrush);
        DeleteObject(alertBrush);
        SelectObject(hdc, g_penBorder);
        Rectangle(hdc, rcAlert.left, rcAlert.top, rcAlert.right, rcAlert.bottom);
        SetTextColor(hdc, COL_BG); SelectObject(hdc, g_fontBold);
        std::string alertText = std::string("! ") + g_telemetry.alertMessage;
        RECT rcAlertText = { rcAlert.left + 4, rcAlert.top + 2, rcAlert.right - 4, rcAlert.bottom - 2 };
        DrawTextA(hdc, alertText.c_str(), -1, &rcAlertText, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
        ly += 26;
    } else if (g_telemetry.fetched) {
        HBRUSH okBrush = CreateSolidBrush(COL_STATUS_OK);
        RECT rcOk = { x + PAD, ly, x + w - PAD, ly + 18 };
        FillRect(hdc, &rcOk, okBrush);
        DeleteObject(okBrush);
        SetTextColor(hdc, COL_BG); SelectObject(hdc, g_fontBold);
        RECT rcOkText = { rcOk.left + 4, rcOk.top, rcOk.right - 4, rcOk.bottom };
        DrawTextA(hdc, "All systems nominal", -1, &rcOkText, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        ly += 22;
    } else {
        SetTextColor(hdc, COL_TEXT_DIM); SelectObject(hdc, g_fontMono);
        RECT rcNoData = { x + PAD, ly, x + w - PAD, ly + lineH };
        DrawTextA(hdc, "No telemetry — bridge offline?", -1, &rcNoData, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        ly += lineH + 4;
    }

    // ─── Service Status Grid (2 columns) ───
    SetTextColor(hdc, COL_TEXT_DIM); SelectObject(hdc, g_fontMono);
    RECT rcSecHdr = { x + PAD, ly, x + w - PAD, ly + lineH };
    DrawTextA(hdc, "SERVICES", -1, &rcSecHdr, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    ly += lineH + 2;

    struct SvcIndicator { const char* name; bool alive; };
    SvcIndicator svcs[] = {
        {"Bridge",    g_svcStates[2].alive},  // Hermes Bridge
        {"Nexus",     g_telemetry.nexusAlive},
        {"TurboQuant",g_telemetry.tqAlive},
        {"Ollama",    g_telemetry.ollamaAlive},
        {"Colibri",   g_svcStates[5].alive},   // Colibri Bridge
        {"FUBBU",     g_telemetry.fubbuAlive},
        {"ZHARK",     g_telemetry.zharkAlive},
        {"RAG",       g_telemetry.ragAlive},
        {"Harness",   g_telemetry.harnessAlive},
        {"KoboldCpp", g_telemetry.koboldAlive},
        {"Heartbeat", g_telemetry.heartbeatAlive},
        {"FS Service",g_svcStates[1].alive},
    };
    int svcCount = sizeof(svcs) / sizeof(svcs[0]);
    int colW = (w - PAD * 3) / 2;
    for (int i = 0; i < svcCount; i++) {
        int col = i % 2;
        int row = i / 2;
        int sx = x + PAD + col * (colW + PAD);
        int sy = ly + row * 18;
        HBRUSH dot = svcs[i].alive ? g_brushGreen : g_brushRed;
        RECT rcDot = { sx, sy + 4, sx + 10, sy + 14 };
        FillRect(hdc, &rcDot, dot);
        SelectObject(hdc, g_penBorder);
        Rectangle(hdc, rcDot.left, rcDot.top, rcDot.right, rcDot.bottom);
        SetTextColor(hdc, svcs[i].alive ? COL_GREEN : COL_ACCENT2);
        SelectObject(hdc, g_fontMono);
        RECT rcName = { sx + 14, sy, sx + colW, sy + 16 };
        DrawTextA(hdc, svcs[i].name, -1, &rcName, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
    }
    ly += ((svcCount + 1) / 2) * 18 + 4;

    // ─── Nexus Health ───
    SetTextColor(hdc, COL_TEXT_DIM); SelectObject(hdc, g_fontMono);
    rcSecHdr = { x + PAD, ly, x + w - PAD, ly + lineH };
    DrawTextA(hdc, "NEXUS HEALTH", -1, &rcSecHdr, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    ly += lineH + 2;

    auto drawStatLine = [&](const char* label, const char* value, COLORREF valCol) {
        RECT rcLabel = { x + PAD, ly, x + w / 2, ly + lineH };
        SetTextColor(hdc, COL_TEXT_DIM); SelectObject(hdc, g_fontMono);
        DrawTextA(hdc, label, -1, &rcLabel, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        RECT rcVal = { x + w / 2, ly, x + w - PAD, ly + lineH };
        SetTextColor(hdc, valCol);
        DrawTextA(hdc, value, -1, &rcVal, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS);
        ly += lineH;
    };

    char buf[128];
    snprintf(buf, sizeof(buf), "%s", g_telemetry.nexusAlive ? "ONLINE" : "OFFLINE");
    drawStatLine("Status", buf, g_telemetry.nexusAlive ? COL_GREEN : COL_ACCENT2);
    snprintf(buf, sizeof(buf), "%d", g_telemetry.nexusAgents);
    drawStatLine("Agents", buf, COL_TEXT);
    snprintf(buf, sizeof(buf), "%d pend / %d done / %d fail", g_telemetry.nexusTasksPending, g_telemetry.nexusTasksDone, g_telemetry.nexusTasksFailed);
    drawStatLine("Tasks", buf, COL_TEXT);
    snprintf(buf, sizeof(buf), "%d", g_telemetry.nexusSessions);
    drawStatLine("Sessions", buf, COL_TEXT);
    ly += 4;

    // ─── KV-Cache / TurboQuant ───
    SetTextColor(hdc, COL_TEXT_DIM); SelectObject(hdc, g_fontMono);
    rcSecHdr = { x + PAD, ly, x + w - PAD, ly + lineH };
    DrawTextA(hdc, "KV-CACHE / TURBOQUANT", -1, &rcSecHdr, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    ly += lineH + 2;

    if (g_telemetry.tierKvBits > 0) {
        snprintf(buf, sizeof(buf), "%d-bit", g_telemetry.tierKvBits);
    } else {
        snprintf(buf, sizeof(buf), "--");
    }
    drawStatLine("KV Bits", buf, COL_ORANGE);
    snprintf(buf, sizeof(buf), "%s", g_telemetry.tqMode);
    drawStatLine("Mode", buf, strcmp(g_telemetry.tqMode, "halt") == 0 ? COL_ACCENT2 :
                              strcmp(g_telemetry.tqMode, "scale") == 0 ? COL_ORANGE : COL_GREEN);

    // RAM pressure bar
    RECT rcRamLabel = { x + PAD, ly, x + 60, ly + lineH };
    SetTextColor(hdc, COL_TEXT_DIM); SelectObject(hdc, g_fontMono);
    DrawTextA(hdc, "RAM", -1, &rcRamLabel, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    int barW = w - PAD * 3 - 60;
    RECT rcBarBg = { x + 64, ly + 1, x + 64 + barW, ly + 13 };
    FillRect(hdc, &rcBarBg, g_brushBg);
    SelectObject(hdc, g_penBorder);
    Rectangle(hdc, rcBarBg.left, rcBarBg.top, rcBarBg.right, rcBarBg.bottom);
    int ramFill = (int)(barW * g_telemetry.tqRamPct / 100.0);
    if (ramFill > 0) {
        COLORREF ramCol = g_telemetry.tqRamPct >= 65 ? COL_ACCENT2 : g_telemetry.tqRamPct >= 60 ? COL_ORANGE : COL_GREEN;
        HBRUSH ramBrush = CreateSolidBrush(ramCol);
        RECT rcFill = { rcBarBg.left + 1, rcBarBg.top + 1, rcBarBg.left + ramFill, rcBarBg.bottom - 1 };
        FillRect(hdc, &rcFill, ramBrush);
        DeleteObject(ramBrush);
    }
    snprintf(buf, sizeof(buf), "%.0f%%", g_telemetry.tqRamPct);
    SetTextColor(hdc, g_telemetry.tqRamPct >= 65 ? COL_ACCENT2 : g_telemetry.tqRamPct >= 60 ? COL_ORANGE : COL_GREEN);
    RECT rcPct = { rcBarBg.right + 4, ly, x + w - PAD, ly + lineH };
    DrawTextA(hdc, buf, -1, &rcPct, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    ly += lineH + 4;

    // ─── HBE Pulsar ───
    SetTextColor(hdc, COL_TEXT_DIM); SelectObject(hdc, g_fontMono);
    rcSecHdr = { x + PAD, ly, x + w - PAD, ly + lineH };
    DrawTextA(hdc, "HBE PULSAR", -1, &rcSecHdr, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    ly += lineH + 2;

    snprintf(buf, sizeof(buf), "%d", g_telemetry.totalPulses);
    drawStatLine("Pulses", buf, COL_TEXT);
    snprintf(buf, sizeof(buf), "%d", g_telemetry.llmInvocations);
    drawStatLine("LLM Calls", buf, COL_TEXT);
    snprintf(buf, sizeof(buf), "%d", g_telemetry.deterministicBypass);
    drawStatLine("Det Bypass", buf, COL_GREEN);
    snprintf(buf, sizeof(buf), "%s", g_telemetry.efficiencyRate);
    drawStatLine("Efficiency", buf, COL_GREEN);
    snprintf(buf, sizeof(buf), "%.1f/min", g_telemetry.triggerFreqPerMin);
    drawStatLine("Freq", buf, COL_ORANGE);
    snprintf(buf, sizeof(buf), "%d", g_telemetry.taskQueueDepth);
    drawStatLine("Queue Depth", buf, COL_TEXT);
    ly += 4;

    // ─── Colibri Expert Streaming ───
    SetTextColor(hdc, COL_TEXT_DIM); SelectObject(hdc, g_fontMono);
    rcSecHdr = { x + PAD, ly, x + w - PAD, ly + lineH };
    DrawTextA(hdc, "COLIBRI EXPERT CACHE", -1, &rcSecHdr, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    ly += lineH + 2;

    if (!g_telemetry.colibriAlive) {
        SetTextColor(hdc, COL_ACCENT2); SelectObject(hdc, g_fontMono);
        RECT rcOff = { x + PAD, ly, x + w - PAD, ly + lineH };
        DrawTextA(hdc, "Colibri bridge offline", -1, &rcOff, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        ly += lineH + 4;
    } else {
        snprintf(buf, sizeof(buf), "%s", g_telemetry.colibriHotExpertName);
        drawStatLine("Hot Expert", buf, COL_GREEN);
        snprintf(buf, sizeof(buf), "%d hot / %d cold", g_telemetry.colibriHotExpert, g_telemetry.colibriColdExperts);
        drawStatLine("Experts", buf, COL_TEXT);
        int totalAccess = g_telemetry.colibriCacheHits + g_telemetry.colibriCacheMisses;
        double hitRate = totalAccess > 0 ? (100.0 * g_telemetry.colibriCacheHits / totalAccess) : 0;
        snprintf(buf, sizeof(buf), "%d / %d (%.0f%%)", g_telemetry.colibriCacheHits, g_telemetry.colibriCacheMisses, hitRate);
        drawStatLine("Hit/Miss", buf, hitRate > 70 ? COL_GREEN : hitRate > 40 ? COL_ORANGE : COL_ACCENT2);
        snprintf(buf, sizeof(buf), "%d", g_telemetry.colibriSwapEvents);
        drawStatLine("Swaps", buf, COL_ORANGE);
        // RAM budget bar
        RECT rcRamLabel2 = { x + PAD, ly, x + 60, ly + lineH };
        SetTextColor(hdc, COL_TEXT_DIM); SelectObject(hdc, g_fontMono);
        DrawTextA(hdc, "RAM", -1, &rcRamLabel2, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        int barW2 = w - PAD * 3 - 60;
        RECT rcBarBg2 = { x + 64, ly + 1, x + 64 + barW2, ly + 13 };
        FillRect(hdc, &rcBarBg2, g_brushBg);
        SelectObject(hdc, g_penBorder);
        Rectangle(hdc, rcBarBg2.left, rcBarBg2.top, rcBarBg2.right, rcBarBg2.bottom);
        double colRamPct = g_telemetry.colibriRamBudget > 0 ? (100.0 * g_telemetry.colibriRamUsed / g_telemetry.colibriRamBudget) : 0;
        int ramFill2 = (int)(barW2 * colRamPct / 100.0);
        if (ramFill2 > 0) {
            COLORREF ramCol2 = colRamPct >= 85 ? COL_ACCENT2 : colRamPct >= 70 ? COL_ORANGE : COL_GREEN;
            HBRUSH ramBrush2 = CreateSolidBrush(ramCol2);
            RECT rcFill2 = { rcBarBg2.left + 1, rcBarBg2.top + 1, rcBarBg2.left + ramFill2, rcBarBg2.bottom - 1 };
            FillRect(hdc, &rcFill2, ramBrush2);
            DeleteObject(ramBrush2);
        }
        snprintf(buf, sizeof(buf), "%d/%dMB", g_telemetry.colibriRamUsed, g_telemetry.colibriRamBudget);
        SetTextColor(hdc, colRamPct >= 85 ? COL_ACCENT2 : colRamPct >= 70 ? COL_ORANGE : COL_GREEN);
        RECT rcPct2 = { rcBarBg2.right + 4, ly, x + w - PAD, ly + lineH };
        DrawTextA(hdc, buf, -1, &rcPct2, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        ly += lineH + 4;
    }

    // ─── Tier & Pipeline ───
    SetTextColor(hdc, COL_TEXT_DIM); SelectObject(hdc, g_fontMono);
    rcSecHdr = { x + PAD, ly, x + w - PAD, ly + lineH };
    DrawTextA(hdc, "TIER & PIPELINE", -1, &rcSecHdr, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    ly += lineH + 2;

    drawStatLine("Tier", g_telemetry.tierName, COL_PURPLE);
    drawStatLine("Pipeline", g_telemetry.pipelineLabel, COL_ACCENT);
    ly += 4;

    // ─── Request Counters ───
    if (ly < y + h - 20) {
        SetTextColor(hdc, COL_TEXT_DIM); SelectObject(hdc, g_fontMono);
        rcSecHdr = { x + PAD, ly, x + w - PAD, ly + lineH };
        DrawTextA(hdc, "COUNTERS", -1, &rcSecHdr, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
        ly += lineH + 2;

        snprintf(buf, sizeof(buf), "%d", g_telemetry.chatRequests);
        drawStatLine("Chat Reqs", buf, COL_TEXT);
        snprintf(buf, sizeof(buf), "%d", g_telemetry.committeeTriggers);
        drawStatLine("Committee", buf, COL_TEXT);
        snprintf(buf, sizeof(buf), "%d", g_telemetry.pipelineSwitches);
        drawStatLine("Pipe Switch", buf, COL_TEXT);
    }
}
