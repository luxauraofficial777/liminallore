"""FUBBU Router — task decomposition, RAG context retrieval, and worker assignment.

The Router is the first stage of the Think→Route→Delegate→Execute→Verify pipeline.
It receives a task from Nexus, queries RAG for relevant context, decomposes the
task into a worker prompt, and delegates to the Worker.

Uses a small, fast model (qwen2.5-coder:7b) for decomposition — it only needs
to understand task structure, not debug MIPS code.
"""

from __future__ import annotations

import json
import time
from typing import Any, Dict, List, Optional

from .fubbu_telemetry import FubbuTelemetry, StepType, StepStatus
from .fubbu_topography import FubbuTopography
from .fubbu_state import FubbuState
from .fubbu_nexus_client import FubbuNexusClient
from .fubbu_worker import FubbuWorker


ROUTER_SYSTEM_PROMPT = """\
You are the FUBBU Router, a task decomposition agent for the Void Walkers Project.
Your job is to analyze incoming debugging tasks and produce a structured worker prompt.

You operate in a Router-Worker-Verifier pipeline:
1. You receive a task and relevant context from RAG
2. You decompose it into a clear, structured prompt for the Worker
3. The Worker (a larger model) performs the actual analysis
4. The Verifier checks the Worker's output

Output a JSON object with these fields:
{
  "analysis": "Brief analysis of what the task requires",
  "approach": "Step-by-step approach the worker should take",
  "constraints": ["List of constraints the worker must respect"],
  "context_priority": ["Which RAG chunks are most relevant, by index"],
  "worker_prompt": "The full prompt to send to the worker model",
  "expected_output_format": "Description of what the worker should produce"
}

Rules:
- Be concise — the worker model has limited context window
- Include relevant MIPS addresses, file paths, and error messages from the task
- If the task involves MIPS/PSX debugging, remind the worker about valid address ranges
- If the task involves code changes, remind the worker to output diffs
- Never attempt to solve the task yourself — only structure it for the worker
"""


class FubbuRouter:
    """Router agent: decomposes tasks and delegates to workers.

    The Router uses a small local model (7B) for fast task decomposition.
    It queries RAG for context before building the worker prompt.
    """

    def __init__(
        self,
        nexus_client: FubbuNexusClient,
        worker: FubbuWorker,
        state: FubbuState,
        telemetry: FubbuTelemetry,
        topography: FubbuTopography,
        model: str = "qwen2.5-coder:7b",
        endpoint: str = "http://127.0.0.1:11434/api/generate",
        temperature: float = 0.3,
        max_tokens: int = 2048,
        timeout_s: int = 60,
        rag_enabled: bool = True,
        rag_max_chunks: int = 15,
        rag_corpus: Optional[str] = None,
    ):
        self.nexus = nexus_client
        self.worker = worker
        self.state = state
        self.telemetry = telemetry
        self.topography = topography
        self.model = model
        self.endpoint = endpoint
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.timeout_s = timeout_s
        self.rag_enabled = rag_enabled
        self.rag_max_chunks = rag_max_chunks
        self.rag_corpus = rag_corpus

    def _call_router_model(self, prompt: str) -> Dict[str, Any]:
        """Call the small router model for task decomposition."""
        import urllib.request
        import urllib.error

        # Pre-flight token check
        try:
            from shared.token_counter import get_token_counter
            tc = get_token_counter(self.model)
            prompt_tokens = tc.count(prompt) + tc.count(ROUTER_SYSTEM_PROMPT)
            if prompt_tokens + self.max_tokens > 8192:
                available = 8192 - self.max_tokens - 100
                if available > 100:
                    prompt = tc.truncate_to_budget(prompt, available)
                    print(f"FUBBU Router: Prompt truncated from {prompt_tokens} to fit context window", flush=True)
        except Exception:
            pass

        payload = json.dumps({
            "model": self.model,
            "prompt": prompt,
            "system": ROUTER_SYSTEM_PROMPT,
            "stream": False,
            "options": {
                "temperature": self.temperature,
                "num_predict": self.max_tokens,
            },
        }).encode("utf-8")

        try:
            req = urllib.request.Request(
                self.endpoint, data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            start = time.time()
            with urllib.request.urlopen(req, timeout=self.timeout_s) as resp:
                result = json.loads(resp.read().decode("utf-8"))
            latency_ms = (time.time() - start) * 1000
            return {
                "ok": True,
                "output": result.get("response", ""),
                "tokens_in": result.get("prompt_eval_count", 0),
                "tokens_out": result.get("eval_count", 0),
                "latency_ms": latency_ms,
            }
        except Exception as e:
            return {"ok": False, "error": str(e), "output": "", "tokens_in": 0,
                    "tokens_out": 0, "latency_ms": 0}

    def _query_rag(self, task_description: str) -> List[Dict[str, Any]]:
        """Query RAG for relevant context chunks."""
        if not self.rag_enabled:
            return []
        result = self.nexus.rag_query(
            task_description,
            max_chunks=self.rag_max_chunks,
            corpus=self.rag_corpus,
        )
        if not result.get("ok", False):
            return []
        return result.get("chunks", [])

    def _build_router_prompt(
        self,
        task: Dict[str, Any],
        rag_chunks: List[Dict[str, Any]],
    ) -> str:
        """Build the prompt for the router model."""
        rag_text = ""
        if rag_chunks:
            rag_lines = []
            for i, chunk in enumerate(rag_chunks):
                rag_lines.append(
                    f"[Chunk {i}] (score={chunk.get('score', 0):.3f}, "
                    f"file={chunk.get('file', '?')})\n"
                    f"{chunk.get('content', '')[:500]}"
                )
            rag_text = "\n\n".join(rag_lines)
        else:
            rag_text = "No RAG context available."

        return (
            f"TASK:\n{task.get('title', 'Untitled')}\n\n"
            f"DESCRIPTION:\n{task.get('description', 'No description')}\n\n"
            f"RAG CONTEXT:\n{rag_text}\n\n"
            f"Decompose this task into a worker prompt. Output JSON only."
        )

    def _parse_router_output(self, output: str) -> Dict[str, Any]:
        """Parse the router model's JSON output."""
        # Try to extract JSON from the output
        try:
            # Find JSON block in output
            start = output.find("{")
            end = output.rfind("}") + 1
            if start >= 0 and end > start:
                return json.loads(output[start:end])
        except (json.JSONDecodeError, ValueError):
            pass
        # Fallback: use raw output as worker prompt
        return {
            "analysis": "Router output parsing failed — using raw output",
            "approach": "Direct analysis",
            "constraints": [],
            "context_priority": [],
            "worker_prompt": output,
            "expected_output_format": "text",
        }

    def process_task(self, nexus_task: Dict[str, Any]) -> Dict[str, Any]:
        """Process a single task through the Router stage.

        Steps:
          1. THINK: Analyze the task
          2. ROUTE: Query RAG for context
          3. Build worker prompt from task + RAG context
          4. DELEGATE: Send to worker for execution

        Returns dict with router output, worker prompt, and RAG chunks.
        """
        task_id = nexus_task.get("task_id", "")
        task_title = nexus_task.get("title", "Untitled")
        task_desc = nexus_task.get("description", "")

        # Create FUBBU task record
        fubbu_task_id = self.state.create_task(
            nexus_task_id=task_id,
            title=task_title,
            description=task_desc,
            sub_tasks=[],
        )

        # ── THINK: Record task receipt ──────────────────────
        self.telemetry.record_step(
            StepType.THINK, StepStatus.STARTED,
            task_id=fubbu_task_id, agent_role="router",
            model=self.model,
        )
        self.topography.record_think(fubbu_task_id)

        # ── ROUTE: Query RAG ────────────────────────────────
        rag_start = time.time()
        self.telemetry.record_step(
            StepType.ROUTE, StepStatus.STARTED,
            task_id=fubbu_task_id, agent_role="router",
        )
        rag_chunks = self._query_rag(task_desc)
        rag_latency = (time.time() - rag_start) * 1000

        rag_tokens = sum(len(c.get("content", "")) // 4 for c in rag_chunks)
        self.telemetry.record_step(
            StepType.ROUTE, StepStatus.SUCCESS,
            task_id=fubbu_task_id, agent_role="router",
            tokens_in=rag_tokens, latency_ms=rag_latency,
            metadata={"chunk_count": len(rag_chunks)},
        )
        self.topography.record_route(
            fubbu_task_id, tokens_in=rag_tokens, latency_ms=rag_latency
        )

        # ── Build router prompt and call router model ───────
        router_prompt = self._build_router_prompt(
            {"title": task_title, "description": task_desc},
            rag_chunks,
        )

        router_result = self._call_router_model(router_prompt)
        router_output = router_result.get("output", "")
        parsed = self._parse_router_output(router_output)

        self.telemetry.record_step(
            StepType.THINK, StepStatus.SUCCESS if router_result.get("ok") else StepStatus.FAILED,
            task_id=fubbu_task_id, agent_role="router",
            model=self.model,
            tokens_in=router_result.get("tokens_in", 0),
            tokens_out=router_result.get("tokens_out", 0),
            latency_ms=router_result.get("latency_ms", 0),
            metadata={"analysis": parsed.get("analysis", "")},
        )

        if not router_result.get("ok"):
            return {
                "ok": False,
                "error": f"Router model failed: {router_result.get('error', '')}",
                "fubbu_task_id": fubbu_task_id,
            }

        # ── DELEGATE: Record handoff to worker ──────────────
        worker_prompt = parsed.get("worker_prompt", task_desc)
        constraints = parsed.get("constraints", [])
        expected_format = parsed.get("expected_output_format", "text")

        self.telemetry.record_step(
            StepType.DELEGATE, StepStatus.STARTED,
            task_id=fubbu_task_id, agent_role="router",
            metadata={"constraints": constraints, "expected_format": expected_format},
        )
        self.topography.record_delegate(
            fubbu_task_id, tokens_in=len(worker_prompt) // 4
        )

        return {
            "ok": True,
            "fubbu_task_id": fubbu_task_id,
            "nexus_task_id": task_id,
            "router_output": parsed,
            "worker_prompt": worker_prompt,
            "rag_chunks": rag_chunks,
            "constraints": constraints,
            "expected_format": expected_format,
        }
