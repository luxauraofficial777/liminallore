"""FUBBU Worker — local model inference client for the execution stage.

The Worker is the heavy-lifting stage of the pipeline. It receives a
structured prompt from the Router and calls a large local open-weight
model (DeepSeek-Coder, Qwen-Coder) via Ollama/vLLM to perform the
actual debugging analysis.

Designed for low-level tasks: MIPS disassembly analysis, binary diffing,
PSX emulator debugging, architecture review. The worker prompt includes
RAG context and constraints from the Router.
"""

from __future__ import annotations

import json
import time
import urllib.request
import urllib.error
from typing import Any, Dict, List, Optional

from .fubbu_telemetry import FubbuTelemetry, StepType, StepStatus
from .fubbu_topography import FubbuTopography
from .fubbu_state import FubbuState


WORKER_SYSTEM_PROMPT = """\
You are a FUBBU Worker agent for the Void Walkers Project — a low-level
game engine and PSX emulator development project.

You specialize in:
- MIPS R3000A disassembly and analysis
- PSX (PlayStation 1) binary format analysis (HBD archives, EXE headers)
- C/C++ engine code debugging (DX11, Win32)
- Binary diffing and patch generation
- Architecture review and root-cause analysis

Output rules:
- If asked for analysis: provide a structured finding with addresses, root cause, and fix
- If asked for a patch: output a unified diff or explicit hex patches with addresses
- If asked for code: output the code in a fenced block with language tag
- If you reference memory addresses, use full 32-bit hex (e.g., 0x800918F4)
- If you reference files, use absolute paths
- Be precise and technical — no hedging, no "I think", state findings directly
- If you cannot determine the answer, say "INSUFFICIENT_CONTEXT" and explain what's missing
"""


class FubbuWorker:
    """Worker agent: executes inference using a large local model.

    The Worker calls Ollama's /api/generate endpoint with the full
    task prompt (including RAG context and constraints from the Router).
    It handles timeouts, retries, and output parsing.
    """

    def __init__(
        self,
        state: FubbuState,
        telemetry: FubbuTelemetry,
        topography: FubbuTopography,
        model: str = "deepseek-coder:6.7b",
        endpoint: str = "http://127.0.0.1:11434/api/generate",
        temperature: float = 0.1,
        max_tokens: int = 4096,
        timeout_s: int = 180,
        num_ctx: int = 32768,
        max_retries: int = 3,
        retry_backoff_base_s: float = 2.0,
    ):
        self.state = state
        self.telemetry = telemetry
        self.topography = topography
        self.model = model
        self.endpoint = endpoint
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.timeout_s = timeout_s
        self.num_ctx = num_ctx
        self.max_retries = max_retries
        self.retry_backoff_base_s = retry_backoff_base_s

    def _call_ollama(self, prompt: str, system: str = WORKER_SYSTEM_PROMPT) -> Dict[str, Any]:
        """Call Ollama /api/generate with retry logic."""
        # Pre-flight token check
        try:
            from shared.token_counter import get_token_counter
            tc = get_token_counter(self.model)
            prompt_tokens = tc.count(prompt) + tc.count(system)
            if prompt_tokens + self.max_tokens > self.num_ctx:
                available = self.num_ctx - self.max_tokens - 100
                if available > 100:
                    prompt = tc.truncate_to_budget(prompt, available)
                    print(f"FUBBU Worker: Prompt truncated from {prompt_tokens} to fit context window", flush=True)
        except Exception:
            pass

        payload = json.dumps({
            "model": self.model,
            "prompt": prompt,
            "system": system,
            "stream": False,
            "options": {
                "temperature": self.temperature,
                "num_predict": self.max_tokens,
                "num_ctx": self.num_ctx,
            },
        }).encode("utf-8")

        last_error = ""
        for attempt in range(self.max_retries):
            try:
                req = urllib.request.Request(
                    self.endpoint, data=payload,
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                start = time.time()
                with urllib.request.urlopen(req, timeout=self.timeout_s) as resp:
                    result = json.loads(resp.read().decode("utf-8"))
                latency_ms = (time.time() - start) * 1000

                return {
                    "ok": True,
                    "output": result.get("response", ""),
                    "tokens_in": result.get("prompt_eval_count", 0),
                    "tokens_out": result.get("eval_count", 0),
                    "latency_ms": latency_ms,
                    "model": self.model,
                    "attempt": attempt + 1,
                }
            except urllib.error.URLError as e:
                last_error = f"Ollama unreachable: {e}"
            except Exception as e:
                last_error = str(e)

            # Exponential backoff
            if attempt < self.max_retries - 1:
                backoff = self.retry_backoff_base_s * (2 ** attempt)
                time.sleep(backoff)

        return {
            "ok": False,
            "error": last_error,
            "output": "",
            "tokens_in": 0,
            "tokens_out": 0,
            "latency_ms": 0,
            "model": self.model,
            "attempt": self.max_retries,
        }

    def execute(
        self,
        fubbu_task_id: str,
        worker_prompt: str,
        constraints: List[str],
        expected_format: str = "text",
        iteration_num: int = 0,
    ) -> Dict[str, Any]:
        """Execute the worker inference stage.

        Steps:
          1. EXECUTE: Call Ollama with the worker prompt
          2. Record output in state DB
          3. Record topology edges (Worker → Ollama → Worker)

        Returns dict with worker output, parsed result, and metadata.
        """
        # Build full prompt with constraints
        full_prompt = worker_prompt
        if constraints:
            full_prompt += "\n\nCONSTRAINTS:\n"
            for i, c in enumerate(constraints, 1):
                full_prompt += f"{i}. {c}\n"
        if expected_format:
            full_prompt += f"\nEXPECTED OUTPUT FORMAT: {expected_format}\n"

        # ── EXECUTE: Record start ───────────────────────────
        self.telemetry.record_step(
            StepType.EXECUTE, StepStatus.STARTED,
            task_id=fubbu_task_id, agent_role="worker",
            model=self.model,
            metadata={"iteration": iteration_num, "prompt_len": len(full_prompt)},
        )

        # Call the model
        result = self._call_ollama(full_prompt)

        if not result.get("ok"):
            self.telemetry.record_step(
                StepType.EXECUTE, StepStatus.FAILED,
                task_id=fubbu_task_id, agent_role="worker",
                model=self.model,
                metadata={"error": result.get("error", ""), "attempts": result.get("attempt", 0)},
            )
            return {
                "ok": False,
                "error": result.get("error", "Worker inference failed"),
                "fubbu_task_id": fubbu_task_id,
            }

        output = result["output"]
        tokens_in = result["tokens_in"]
        tokens_out = result["tokens_out"]
        latency_ms = result["latency_ms"]

        # Record topology: Worker → Ollama → Worker
        self.topography.record_execute(
            fubbu_task_id, iteration_id=f"iter_{iteration_num}",
            tokens_in=tokens_in, tokens_out=tokens_out, latency_ms=latency_ms,
        )

        # Record success
        self.telemetry.record_step(
            StepType.EXECUTE, StepStatus.SUCCESS,
            task_id=fubbu_task_id, agent_role="worker",
            model=self.model,
            tokens_in=tokens_in, tokens_out=tokens_out,
            latency_ms=latency_ms,
            metadata={"iteration": iteration_num},
        )

        # Parse output — try JSON, fall back to raw text
        parsed = self._parse_output(output, expected_format)

        # Store in state DB
        iteration_id = self.state.record_iteration(
            task_id=fubbu_task_id,
            iteration_num=iteration_num,
            worker_prompt=full_prompt,
            worker_output=output,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            latency_ms=latency_ms,
        )

        self.state.record_worker_output(
            task_id=fubbu_task_id,
            iteration_id=iteration_id,
            model=self.model,
            raw_output=output,
            parsed_output=parsed,
            tokens_in=tokens_in,
            tokens_out=tokens_out,
            latency_ms=latency_ms,
        )

        return {
            "ok": True,
            "fubbu_task_id": fubbu_task_id,
            "iteration_id": iteration_id,
            "output": output,
            "parsed": parsed,
            "tokens_in": tokens_in,
            "tokens_out": tokens_out,
            "latency_ms": latency_ms,
            "model": self.model,
        }

    def _parse_output(self, output: str, expected_format: str) -> Dict[str, Any]:
        """Parse worker output based on expected format."""
        parsed: Dict[str, Any] = {"raw": output}

        # Try JSON extraction
        if "json" in expected_format.lower():
            try:
                start = output.find("{")
                end = output.rfind("}") + 1
                if start >= 0 and end > start:
                    parsed["json"] = json.loads(output[start:end])
            except (json.JSONDecodeError, ValueError):
                parsed["json_error"] = "Failed to parse JSON from output"

        # Extract MIPS addresses (0x800XXXXX pattern)
        import re
        addresses = re.findall(r"0x[89A-Fa-f][0-9A-Fa-f]{6}", output)
        if addresses:
            parsed["mips_addresses"] = list(set(addresses))

        # Extract file paths (Windows absolute paths)
        file_paths = re.findall(r"[A-Za-z]:\\[^\s\"'<>|]+", output)
        if file_paths:
            parsed["file_paths"] = list(set(file_paths))

        # Extract code blocks
        code_blocks = re.findall(r"```(\w+)?\n(.*?)```", output, re.DOTALL)
        if code_blocks:
            parsed["code_blocks"] = [
                {"language": lang or "text", "content": code}
                for lang, code in code_blocks
            ]

        # Extract diff blocks
        diff_blocks = re.findall(r"```diff\n(.*?)```", output, re.DOTALL)
        if diff_blocks:
            parsed["diffs"] = diff_blocks

        return parsed

    def execute_with_feedback(
        self,
        fubbu_task_id: str,
        original_prompt: str,
        rejection_reason: str,
        constraints: List[str],
        expected_format: str = "text",
        iteration_num: int = 0,
    ) -> Dict[str, Any]:
        """Re-execute with verifier feedback injected into the prompt."""
        feedback_prompt = (
            f"{original_prompt}\n\n"
            f"VERIFIER FEEDBACK (previous attempt was rejected):\n"
            f"Rejection reason: {rejection_reason}\n\n"
            f"Please address the above issue and provide a corrected response."
        )
        return self.execute(
            fubbu_task_id, feedback_prompt, constraints,
            expected_format, iteration_num,
        )
