"""MAG (Memory-Augmented Generation) Fusion Engine for VW Nexus.

Implements dual-stream context fusion with strict token budgeting:
  - 60% System Prompt
  - 25% RAG (external factual corpora)
  - 15% MAG (internal persistent agent state / interaction memory)

Provides:
  - STWM (Short-Term Working Memory): in-memory ring buffer for session context
  - LTESM (Long-Term Episodic & Semantic Memory): persistent dict-based mock store
  - Ebbinghaus decay scoring for memory node relevance
  - Context fusion with RAG + MAG deduplication

Integrates with GammaLanguage MAG opcodes:
  - $MEM_QUERY  → query_memory()
  - !MEM_COMMIT → commit_memory()
  - @MEM_PURGE  → purge_memory()
  - ~MEM_SUMMARIZE → summarize_memory()
"""

from __future__ import annotations

import math
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


# ─── Token Budget Constants ──────────────────────────────────────────────

PROMPT_RATIO = 0.60
RAG_RATIO = 0.25
MAG_RATIO = 0.15

DEDUP_THRESHOLD = 0.85  # cosine similarity threshold for RAG/MAG dedup


# ─── Data Schemas ────────────────────────────────────────────────────────

@dataclass
class MemoryNode:
    """A single MAG memory node — mirrors VW::MAG::MemoryNode in C++."""
    memory_id: str
    memory_type: str  # "episodic", "semantic", "preference", "state_invariant"
    content: str
    summary: str = ""
    created_at_ms: int = 0
    last_accessed_at_ms: int = 0
    access_count: int = 0
    decay_factor: float = 1.0
    embedding: List[float] = field(default_factory=list)

    def touch(self, current_ms: int):
        self.last_accessed_at_ms = current_ms
        self.access_count += 1

    def ebbinghaus_weight(self, current_ms: int, s0: float = 1.0, k: float = 0.5) -> float:
        """W(t) = W0 * exp(-dt / S_strength), S_strength = S0 + k * ln(1 + access_count)."""
        dt = (current_ms - self.last_accessed_at_ms) / 1000.0  # seconds
        s_strength = s0 + k * math.log(1 + self.access_count)
        return self.decay_factor * math.exp(-dt / s_strength)


@dataclass
class RAGChunk:
    """A retrieved RAG chunk from external factual corpora."""
    content: str
    cosine_score: float = 0.0
    bm25_score: float = 0.0
    source: str = ""


@dataclass
class FusionResult:
    """Output of context fusion — the assembled prompt with token usage."""
    fused_prompt: str
    prompt_tokens: int = 0
    rag_tokens: int = 0
    mag_tokens: int = 0
    rag_chunks_used: int = 0
    mag_nodes_used: int = 0
    deduped_count: int = 0


# ─── STWM: Short-Term Working Memory ────────────────────────────────────

class STWM:
    """In-memory ring buffer for immediate session context."""

    def __init__(self, capacity: int = 100):
        self.capacity = capacity
        self._buffer: List[MemoryNode] = []
        self._head = 0

    def push(self, node: MemoryNode):
        if len(self._buffer) < self.capacity:
            self._buffer.append(node)
        else:
            self._buffer[self._head] = node
        self._head = (self._head + 1) % self.capacity

    def get_recent(self, n: int = 10) -> List[MemoryNode]:
        if not self._buffer:
            return []
        start = max(0, len(self._buffer) - n)
        return list(reversed(self._buffer[start:]))

    def clear(self):
        self._buffer.clear()
        self._head = 0

    def __len__(self) -> int:
        return len(self._buffer)


# ─── LTESM: Long-Term Episodic & Semantic Memory ────────────────────────

class LTESM:
    """Persistent memory store (dict-based mock; RocksDB in production)."""

    def __init__(self):
        self._nodes: Dict[str, MemoryNode] = {}

    def commit(self, node: MemoryNode):
        self._nodes[node.memory_id] = node

    def get(self, memory_id: str) -> Optional[MemoryNode]:
        node = self._nodes.get(memory_id)
        if node:
            node.touch(int(time.time() * 1000))
        return node

    def query_by_type(self, memory_type: str, limit: int = 10) -> List[MemoryNode]:
        results = [n for n in self._nodes.values() if n.memory_type == memory_type]
        results.sort(key=lambda n: n.last_accessed_at_ms, reverse=True)
        return results[:limit]

    def purge_expired(self, ttl_days: int, current_ms: int) -> int:
        ttl_ms = ttl_days * 86400 * 1000
        expired = [mid for mid, n in self._nodes.items()
                   if (current_ms - n.created_at_ms) > ttl_ms]
        for mid in expired:
            del self._nodes[mid]
        return len(expired)

    def purge_by_type(self, memory_type: str) -> int:
        to_remove = [mid for mid, n in self._nodes.items() if n.memory_type == memory_type]
        for mid in to_remove:
            del self._nodes[mid]
        return len(to_remove)

    def all_nodes(self) -> List[MemoryNode]:
        return list(self._nodes.values())

    def __len__(self) -> int:
        return len(self._nodes)


# ─── Context Fusion Engine ──────────────────────────────────────────────

class FusionEngine:
    """Dual-stream context fusion with token budget enforcement."""

    def __init__(self, total_token_budget: int = 8192):
        self.total_budget = total_token_budget
        self.prompt_budget = int(total_token_budget * PROMPT_RATIO)
        self.rag_budget = int(total_token_budget * RAG_RATIO)
        self.mag_budget = int(total_token_budget * MAG_RATIO)

    def _estimate_tokens(self, text: str) -> int:
        return max(1, len(text) // 4)

    def _score_mag_node(self, query: str, node: MemoryNode,
                        current_ms: int) -> float:
        gamma, delta, epsilon = 0.5, 0.35, 0.15
        query_lower = query.lower()
        content_lower = node.content.lower()
        cos_sim = self._text_similarity(query_lower, content_lower)
        dt = (current_ms - node.last_accessed_at_ms) / 1000.0
        recency = math.exp(-1e-7 * (current_ms - node.last_accessed_at_ms))
        frequency = math.log(1 + node.access_count)
        return gamma * cos_sim + delta * recency + epsilon * frequency

    def _score_rag_chunk(self, query: str, chunk: RAGChunk) -> float:
        alpha, beta = 0.7, 0.3
        cos_sim = self._text_similarity(query.lower(), chunk.content.lower())
        return alpha * cos_sim + beta * chunk.bm25_score

    @staticmethod
    def _text_similarity(a: str, b: str) -> float:
        if not a or not b:
            return 0.0
        a_words = set(a.split())
        b_words = set(b.split())
        if not a_words or not b_words:
            return 0.0
        intersection = a_words & b_words
        union = a_words | b_words
        return len(intersection) / len(union)

    def _deduplicate(self, rag_chunks: List[RAGChunk],
                     mag_nodes: List[MemoryNode]) -> Tuple[List[RAGChunk], int]:
        """Remove RAG chunks that are too similar to MAG nodes."""
        deduped = []
        removed = 0
        for chunk in rag_chunks:
            is_dup = False
            for node in mag_nodes:
                sim = self._text_similarity(chunk.content.lower(),
                                            node.content.lower())
                if sim > DEDUP_THRESHOLD:
                    is_dup = True
                    removed += 1
                    break
            if not is_dup:
                deduped.append(chunk)
        return deduped, removed

    def fuse(self, system_prompt: str,
             rag_chunks: List[RAGChunk],
             mag_nodes: List[MemoryNode],
             query: str = "") -> FusionResult:
        current_ms = int(time.time() * 1000)

        # Score and sort RAG chunks
        scored_rag = [(self._score_rag_chunk(query, c), c) for c in rag_chunks]
        scored_rag.sort(key=lambda x: x[0], reverse=True)

        # Score and sort MAG nodes
        scored_mag = [(self._score_mag_node(query, n, current_ms), n) for n in mag_nodes]
        scored_mag.sort(key=lambda x: x[0], reverse=True)

        # Deduplicate: remove RAG chunks covered by MAG
        top_rag = [c for _, c in scored_rag[:20]]
        top_mag = [n for _, n in scored_mag[:20]]
        deduped_rag, dedup_count = self._deduplicate(top_rag, top_mag)

        # Assemble within token budgets
        prompt_text = system_prompt[:self.prompt_budget * 4]
        prompt_tokens = self._estimate_tokens(prompt_text)

        rag_text_parts = []
        rag_tokens = 0
        for chunk in deduped_rag:
            t = self._estimate_tokens(chunk.content)
            if rag_tokens + t > self.rag_budget:
                break
            rag_text_parts.append(chunk.content)
            rag_tokens += t

        mag_text_parts = []
        mag_tokens = 0
        for node in top_mag:
            text = node.summary or node.content
            t = self._estimate_tokens(text)
            if mag_tokens + t > self.mag_budget:
                break
            mag_text_parts.append(text)
            mag_tokens += t
            node.touch(current_ms)

        fused = prompt_text
        if rag_text_parts:
            fused += "\n\n[RAG Context]\n" + "\n---\n".join(rag_text_parts)
        if mag_text_parts:
            fused += "\n\n[MAG Memory]\n" + "\n---\n".join(mag_text_parts)

        return FusionResult(
            fused_prompt=fused,
            prompt_tokens=prompt_tokens,
            rag_tokens=rag_tokens,
            mag_tokens=mag_tokens,
            rag_chunks_used=len(rag_text_parts),
            mag_nodes_used=len(mag_text_parts),
            deduped_count=dedup_count,
        )


# ─── MAG Engine: Unified Interface ──────────────────────────────────────

class MAGEngine:
    """Unified MAG engine binding GammaLanguage opcodes to memory operations."""

    def __init__(self, token_budget: int = 8192):
        self.stwm = STWM(capacity=100)
        self.ltesm = LTESM()
        self.fusion = FusionEngine(total_token_budget=token_budget)

    def query_memory(self, query: str, k: int = 5,
                     memory_type: str = "episodic") -> List[MemoryNode]:
        """Handle $MEM_QUERY — query persistent MAG store."""
        from_ltesm = self.ltesm.query_by_type(memory_type, limit=k)
        from_stwm = self.stwm.get_recent(k)
        combined = from_ltesm + from_stwm
        current_ms = int(time.time() * 1000)
        scored = [(self.fusion._score_mag_node(query, n, current_ms), n)
                  for n in combined]
        scored.sort(key=lambda x: x[0], reverse=True)
        return [n for _, n in scored[:k]]

    def commit_memory(self, content: str, memory_type: str = "episodic",
                      summary: str = "") -> MemoryNode:
        """Handle !MEM_COMMIT — commit to long-term storage."""
        current_ms = int(time.time() * 1000)
        node = MemoryNode(
            memory_id=str(uuid.uuid4()),
            memory_type=memory_type,
            content=content,
            summary=summary or content[:200],
            created_at_ms=current_ms,
            last_accessed_at_ms=current_ms,
        )
        self.ltesm.commit(node)
        self.stwm.push(node)
        return node

    def purge_memory(self, memory_type: str = "expired",
                     ttl_days: int = 30) -> int:
        """Handle @MEM_PURGE — evict expired or matching memory nodes."""
        current_ms = int(time.time() * 1000)
        if memory_type.lower() == "expired":
            return self.ltesm.purge_expired(ttl_days, current_ms)
        else:
            return self.ltesm.purge_by_type(memory_type)

    def summarize_memory(self, span: int = 100) -> str:
        """Handle ~MEM_SUMMARIZE — compress STWM turn buffers."""
        recent = self.stwm.get_recent(span)
        if not recent:
            return ""
        parts = [n.summary or n.content[:100] for n in recent]
        summary = f"[Summarized {len(recent)} turns] " + " | ".join(parts)
        # Commit the summary as a semantic node
        self.commit_memory(summary, memory_type="semantic", summary=summary)
        return summary

    def fuse_context(self, system_prompt: str,
                     rag_chunks: List[RAGChunk],
                     query: str = "") -> FusionResult:
        """Fuse RAG + MAG context with 60/25/15 token budgeting."""
        mag_nodes = self.ltesm.all_nodes()
        return self.fusion.fuse(system_prompt, rag_chunks, mag_nodes, query)
