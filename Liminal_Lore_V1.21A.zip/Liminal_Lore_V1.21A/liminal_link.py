#!/usr/bin/env python3
"""Liminal Link — Gamma Host Supervisor + Conformance Status Tile.

A Tkinter-based service manager that:
1. Manages the Gamma host as a service (start/stop/restart/health)
2. Shows live PASS/FAIL for four gates: C++, Python e2e, Rust, conformance
3. One-click re-run for each gate

This is a supervisor — it never executes Gamma programs itself.
"""
from __future__ import annotations

import os
import sys
import subprocess
import threading
import time
import tkinter as tk
from tkinter import ttk, scrolledtext
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional


# ─── Paths ───────────────────────────────────────────────────────────────────
GAMMA_ROOT = Path(__file__).resolve().parent.parent.parent / "GammaLanguage"
if not GAMMA_ROOT.exists():
    # Try relative to Modern_X64/tools
    GAMMA_ROOT = Path(__file__).resolve().parent.parent.parent.parent / "GammaLanguage"
    if not GAMMA_ROOT.exists():
        GAMMA_ROOT = Path(r"C:\LuxAura\VoidWalkers_Project\GammaLanguage")

CPP_EXE = GAMMA_ROOT / "cpp" / "build" / "gamma_parser.exe"
CONFORMANCE_TEST = GAMMA_ROOT / "tests" / "test_conformance.py"
E2E_TESTS = ["tests/test_host_e2e.py", "tests/test_mag_fusion.py", "tests/test_cp0_parity.py"]
RUST_TEST = GAMMA_ROOT / "tests" / "test_rust_ffi.py"  # may not exist


class GateStatus:
    """Tracks the status of a single conformance gate."""
    def __init__(self, name: str):
        self.name = name
        self.status = "UNKNOWN"  # PASS, FAIL, UNKNOWN, RUNNING
        self.timestamp = ""
        self.detail = ""
        self.duration = 0.0

    def update(self, status: str, detail: str = "", duration: float = 0.0):
        self.status = status
        self.timestamp = datetime.now().strftime("%H:%M:%S")
        self.detail = detail
        self.duration = duration

    @property
    def color(self) -> str:
        if self.status == "PASS":
            return "#00DC82"
        elif self.status == "FAIL":
            return "#FF3264"
        elif self.status == "RUNNING":
            return "#FFA500"
        return "#7878A0"


class LiminalLink:
    """Main application controller."""

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Liminal Link — Gamma Host Supervisor")
        self.root.geometry("800x600")
        self.root.configure(bg="#0A0A12")

        # Gate statuses
        self.gates: Dict[str, GateStatus] = {
            "C++ Suite": GateStatus("C++ Suite"),
            "Python E2E": GateStatus("Python E2E"),
            "Rust FFI": GateStatus("Rust FFI"),
            "Conformance": GateStatus("Conformance"),
        }

        # Host process
        self.host_process: Optional[subprocess.Popen] = None
        self.host_health = "stopped"

        self._build_ui()
        self._auto_run_all()

    def _build_ui(self):
        """Build the UI."""
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Dark.TFrame", background="#0A0A12")
        style.configure("Dark.TLabel", background="#0A0A12", foreground="#C8C8D2",
                        font=("Consolas", 10))
        style.configure("Title.TLabel", background="#0A0A12", foreground="#00D4FF",
                        font=("Consolas", 14, "bold"))
        style.configure("Dark.TButton", background="#1E1E32", foreground="#C8C8D2",
                        font=("Consolas", 9))
        style.map("Dark.TButton",
                  background=[("active", "#2A2A44")])

        # Title
        title = ttk.Label(self.root, text="LIMINAL LINK — Gamma Host Supervisor",
                          style="Title.TLabel")
        title.pack(pady=(10, 5))

        subtitle = ttk.Label(self.root, text="Conformance Status Tile — Live PASS/FAIL for all gates",
                             style="Dark.TLabel")
        subtitle.pack(pady=(0, 10))

        # ─── Host Control Section ───
        host_frame = ttk.Frame(self.root, style="Dark.TFrame")
        host_frame.pack(fill=tk.X, padx=20, pady=5)

        ttk.Label(host_frame, text="Gamma Host:", style="Dark.TLabel").pack(side=tk.LEFT, padx=(0, 10))
        self.host_status_label = tk.Label(host_frame, text="● STOPPED", bg="#0A0A12",
                                          fg="#7878A0", font=("Consolas", 10, "bold"))
        self.host_status_label.pack(side=tk.LEFT, padx=5)

        ttk.Button(host_frame, text="Start", style="Dark.TButton",
                   command=self.start_host).pack(side=tk.LEFT, padx=5)
        ttk.Button(host_frame, text="Stop", style="Dark.TButton",
                   command=self.stop_host).pack(side=tk.LEFT, padx=5)
        ttk.Button(host_frame, text="Restart", style="Dark.TButton",
                   command=self.restart_host).pack(side=tk.LEFT, padx=5)
        ttk.Button(host_frame, text="Health Check", style="Dark.TButton",
                   command=self.health_check).pack(side=tk.LEFT, padx=5)

        # ─── Gates Section ───
        gates_frame = ttk.Frame(self.root, style="Dark.TFrame")
        gates_frame.pack(fill=tk.X, padx=20, pady=10)

        ttk.Label(gates_frame, text="Conformance Gates", style="Title.TLabel").pack(anchor=tk.W)

        self.gate_labels: Dict[str, tk.Label] = {}
        self.gate_details: Dict[str, tk.Label] = {}

        for gate_name in ["C++ Suite", "Python E2E", "Rust FFI", "Conformance"]:
            row = ttk.Frame(gates_frame, style="Dark.TFrame")
            row.pack(fill=tk.X, pady=2)

            indicator = tk.Label(row, text="●", bg="#0A0A12", fg="#7878A0",
                                 font=("Consolas", 14))
            indicator.pack(side=tk.LEFT, padx=(0, 5))

            label = tk.Label(row, text=f"{gate_name:20s} UNKNOWN", bg="#0A0A12",
                            fg="#7878A0", font=("Consolas", 10, "bold"))
            label.pack(side=tk.LEFT, padx=5)

            detail = tk.Label(row, text="", bg="#0A0A12", fg="#7878A0",
                             font=("Consolas", 8))
            detail.pack(side=tk.LEFT, padx=10)

            ttk.Button(row, text="Re-run", style="Dark.TButton",
                       command=lambda g=gate_name: self.run_gate(g)).pack(side=tk.RIGHT, padx=5)

            self.gate_labels[gate_name] = label
            self.gate_details[gate_name] = detail

        # ─── Run All Button ───
        ttk.Button(self.root, text="Re-run All Gates", style="Dark.TButton",
                   command=self.run_all_gates).pack(pady=5)

        # ─── Log Section ───
        log_frame = ttk.Frame(self.root, style="Dark.TFrame")
        log_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)

        ttk.Label(log_frame, text="Output Log", style="Dark.TLabel").pack(anchor=tk.W)

        self.log = scrolledtext.ScrolledText(log_frame, bg="#08080E", fg="#C8C8D2",
                                             font=("Consolas", 9), height=12,
                                             insertbackground="#C8C8D2")
        self.log.pack(fill=tk.BOTH, expand=True, pady=5)

    def _log(self, msg: str):
        """Append to the output log."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log.insert(tk.END, f"[{timestamp}] {msg}\n")
        self.log.see(tk.END)

    def _update_gate_ui(self, gate_name: str):
        """Update the UI for a single gate."""
        gate = self.gates[gate_name]
        label = self.gate_labels[gate_name]
        detail = self.gate_details[gate_name]

        status_text = f"{gate_name:20s} {gate.status}"
        if gate.timestamp:
            status_text += f"  {gate.timestamp}"
        if gate.duration > 0:
            status_text += f"  ({gate.duration:.1f}s)"

        label.config(text=status_text, fg=gate.color)
        detail.config(text=gate.detail[:80] if gate.detail else "")

    def _run_command(self, cmd: list, cwd: str) -> tuple:
        """Run a command and return (returncode, stdout, stderr)."""
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60,
                                    cwd=cwd)
            return result.returncode, result.stdout, result.stderr
        except subprocess.TimeoutExpired:
            return -1, "", "TIMEOUT"
        except Exception as e:
            return -1, "", str(e)

    def run_gate(self, gate_name: str):
        """Run a single gate in a background thread."""
        threading.Thread(target=self._run_gate_thread, args=(gate_name,), daemon=True).start()

    def _run_gate_thread(self, gate_name: str):
        gate = self.gates[gate_name]
        gate.update("RUNNING")
        self.root.after(0, lambda: self._update_gate_ui(gate_name))
        self.root.after(0, lambda: self._log(f"Running gate: {gate_name}..."))

        start = time.time()

        if gate_name == "C++ Suite":
            if not CPP_EXE.exists():
                gate.update("FAIL", "C++ executable not found")
                self.root.after(0, lambda: self._log(f"  FAIL: {CPP_EXE} not found"))
            else:
                rc, out, err = self._run_command([str(CPP_EXE)], str(GAMMA_ROOT))
                elapsed = time.time() - start
                if rc == 0 and "0 failed" in out:
                    gate.update("PASS", "94 passed, 0 failed", elapsed)
                    self.root.after(0, lambda: self._log(f"  PASS: C++ suite ({elapsed:.1f}s)"))
                else:
                    gate.update("FAIL", f"rc={rc}", elapsed)
                    self.root.after(0, lambda: self._log(f"  FAIL: C++ suite rc={rc}\n{err[:200]}"))

        elif gate_name == "Python E2E":
            cmd = [sys.executable, "-m", "pytest"] + E2E_TESTS + ["-q"]
            rc, out, err = self._run_command(cmd, str(GAMMA_ROOT))
            elapsed = time.time() - start
            if rc == 0:
                # Extract pass count
                import re
                m = re.search(r"(\d+) passed", out)
                count = m.group(1) if m else "?"
                gate.update("PASS", f"{count} passed", elapsed)
                self.root.after(0, lambda: self._log(f"  PASS: Python E2E ({elapsed:.1f}s)"))
            else:
                gate.update("FAIL", f"rc={rc}", elapsed)
                self.root.after(0, lambda: self._log(f"  FAIL: Python E2E rc={rc}\n{err[:200]}"))

        elif gate_name == "Rust FFI":
            if not RUST_TEST.exists():
                gate.update("PASS", "No Rust FFI tests (skipped)", 0.0)
                self.root.after(0, lambda: self._log("  SKIP: No Rust FFI tests found"))
            else:
                rc, out, err = self._run_command([sys.executable, "-m", "pytest",
                                                  str(RUST_TEST), "-q"], str(GAMMA_ROOT))
                elapsed = time.time() - start
                if rc == 0:
                    gate.update("PASS", "Rust FFI passed", elapsed)
                    self.root.after(0, lambda: self._log(f"  PASS: Rust FFI ({elapsed:.1f}s)"))
                else:
                    gate.update("FAIL", f"rc={rc}", elapsed)
                    self.root.after(0, lambda: self._log(f"  FAIL: Rust FFI rc={rc}\n{err[:200]}"))

        elif gate_name == "Conformance":
            rc, out, err = self._run_command([sys.executable, str(CONFORMANCE_TEST)],
                                             str(GAMMA_ROOT))
            elapsed = time.time() - start
            if rc == 0 and "All" in out and "agree" in out:
                import re
                m = re.search(r"All (\d+) corpus", out)
                count = m.group(1) if m else "?"
                gate.update("PASS", f"{count} corpus files agree", elapsed)
                self.root.after(0, lambda: self._log(f"  PASS: Conformance ({elapsed:.1f}s)"))
            else:
                gate.update("FAIL", f"rc={rc}", elapsed)
                self.root.after(0, lambda: self._log(f"  FAIL: Conformance rc={rc}\n{out[:300]}"))

        self.root.after(0, lambda: self._update_gate_ui(gate_name))

    def run_all_gates(self):
        """Run all gates sequentially in a background thread."""
        threading.Thread(target=self._run_all_gates_thread, daemon=True).start()

    def _run_all_gates_thread(self):
        for gate_name in ["C++ Suite", "Python E2E", "Rust FFI", "Conformance"]:
            self._run_gate_thread(gate_name)

    def _auto_run_all(self):
        """Auto-run all gates on startup."""
        self.root.after(500, self.run_all_gates)

    # ─── Host Management ─────────────────────────────────────────────────────

    def start_host(self):
        """Start the Gamma host as a managed subprocess."""
        if self.host_process and self.host_process.poll() is None:
            self._log("Host already running")
            return

        host_script = GAMMA_ROOT / "python" / "gamma_host.py"
        if not host_script.exists():
            self._log(f"Host script not found: {host_script}")
            return

        self._log("Starting Gamma host...")
        try:
            self.host_process = subprocess.Popen(
                [sys.executable, str(host_script)],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                cwd=str(GAMMA_ROOT)
            )
            self.host_health = "running"
            self.host_status_label.config(text="● RUNNING", fg="#00DC82")
            self._log("Gamma host started")
        except Exception as e:
            self._log(f"Failed to start host: {e}")
            self.host_health = "error"
            self.host_status_label.config(text="● ERROR", fg="#FF3264")

    def stop_host(self):
        """Stop the Gamma host."""
        if self.host_process and self.host_process.poll() is None:
            self._log("Stopping Gamma host...")
            self.host_process.terminate()
            try:
                self.host_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.host_process.kill()
            self._log("Gamma host stopped")
        else:
            self._log("Host not running")

        self.host_health = "stopped"
        self.host_status_label.config(text="● STOPPED", fg="#7878A0")

    def restart_host(self):
        """Restart the Gamma host."""
        self.stop_host()
        time.sleep(0.5)
        self.start_host()

    def health_check(self):
        """Check host health."""
        if self.host_process and self.host_process.poll() is None:
            self.host_health = "running"
            self.host_status_label.config(text="● RUNNING", fg="#00DC82")
            self._log("Health check: host is RUNNING")
        else:
            self.host_health = "stopped"
            self.host_status_label.config(text="● STOPPED", fg="#7878A0")
            self._log("Health check: host is STOPPED")


def main():
    root = tk.Tk()
    app = LiminalLink(root)
    root.mainloop()


if __name__ == "__main__":
    main()
