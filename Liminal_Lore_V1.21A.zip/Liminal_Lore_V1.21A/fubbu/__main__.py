"""FUBBU CLI entry point.

Usage:
  python -m fubbu start [--config path] [--project-root path]
  python -m fubbu status
  python -m fubbu topology [--format json|dot]
  python -m fubbu test-connection
"""

from __future__ import annotations

import json
import sys
from typing import Optional


def main(argv: Optional[list] = None) -> int:
    args = argv or sys.argv[1:]

    if not args or args[0] in ("-h", "--help", "help"):
        _print_help()
        return 0

    cmd = args[0]

    if cmd == "start":
        return _cmd_start(args[1:])
    elif cmd == "status":
        return _cmd_status(args[1:])
    elif cmd == "topology":
        return _cmd_topology(args[1:])
    elif cmd == "test-connection":
        return _cmd_test_connection(args[1:])
    else:
        print(f"Unknown command: {cmd}", file=sys.stderr)
        _print_help()
        return 1


def _print_help() -> None:
    print("FUBBU — Fully Unmanaged Backbone Bridge Unit")
    print("Self-hosted local multi-agent orchestration sidecar\n")
    print("Commands:")
    print("  start            Start the FUBBU sidecar process")
    print("  status           Show current sidecar status")
    print("  topology         Export topology graph (json or dot)")
    print("  test-connection  Test Nexus and Ollama connectivity")
    print("\nOptions:")
    print("  --config PATH        Path to fubbu_config.yaml")
    print("  --project-root PATH  Project root directory")
    print("  --format FORMAT      Output format for topology (json|dot)")


def _cmd_start(args: list) -> int:
    config_path = None
    project_root = None

    i = 0
    while i < len(args):
        if args[i] == "--config" and i + 1 < len(args):
            config_path = args[i + 1]
            i += 2
        elif args[i] == "--project-root" and i + 1 < len(args):
            project_root = args[i + 1]
            i += 2
        else:
            i += 1

    from .nexus_router_bridge import FubbuSidecar
    sidecar = FubbuSidecar(config_path=config_path, project_root=project_root)
    sidecar.start()
    return 0


def _cmd_status(args: list) -> int:
    from .nexus_router_bridge import FubbuSidecar
    sidecar = FubbuSidecar()
    print(json.dumps(sidecar.status(), indent=2, default=str))
    return 0


def _cmd_topology(args: list) -> int:
    fmt = "json"
    i = 0
    while i < len(args):
        if args[i] == "--format" and i + 1 < len(args):
            fmt = args[i + 1]
            i += 2
        else:
            i += 1

    from .fubbu_topography import FubbuTopography
    topo = FubbuTopography()
    if fmt == "dot":
        path = topo.export_dot()
    else:
        path = topo.export_json()
    print(f"Topology exported to: {path}")
    summary = topo.get_topology_summary()
    print(json.dumps(summary, indent=2))
    return 0


def _cmd_test_connection(args: list) -> int:
    print("Testing FUBBU connectivity...\n")

    # Test Nexus
    from .fubbu_nexus_client import FubbuNexusClient
    client = FubbuNexusClient()
    nexus_ok = client.is_nexus_alive()
    print(f"  Nexus ({client.nexus_url}): {'ALIVE' if nexus_ok else 'UNREACHABLE'}")

    if nexus_ok:
        status = client.get_nexus_status()
        agents = status.get("agents", [])
        agent_count = len(agents) if isinstance(agents, (list, dict)) else agents
        print(f"    Active agents: {agent_count}")
        tasks = status.get("tasks", {})
        print(f"    Tasks: {tasks}")

    # Test Ollama
    import urllib.request
    import urllib.error
    try:
        req = urllib.request.Request("http://127.0.0.1:11434/api/tags", method="GET")
        with urllib.request.urlopen(req, timeout=5) as resp:
            result = json.loads(resp.read().decode("utf-8"))
        models = [m.get("name", "?") for m in result.get("models", [])]
        print(f"\n  Ollama (127.0.0.1:11434): ALIVE")
        print(f"    Available models: {', '.join(models) if models else 'none'}")
    except Exception as e:
        print(f"\n  Ollama (127.0.0.1:11434): UNREACHABLE ({e})")

    # Summary
    print(f"\n  Nexus: {'OK' if nexus_ok else 'FAIL'}  Ollama: {'OK' if 'models' in dir() else 'FAIL'}")
    if nexus_ok:
        print("\n  FUBBU can start. Run: python -m fubbu start")
    else:
        print("\n  FUBBU requires Nexus to be running. Start Nexus first.")
    return 0 if nexus_ok else 1


if __name__ == "__main__":
    sys.exit(main())
