"""WebSocket server for the VW Nexus real-time agent bus.

Provides:
  - Heartbeats (ping/pong) to keep agents live
  - Topic-based state bus publish/subscribe
  - Liminal handshake messages
  - Autonomous hand-off broadcasts
  - Neural Link audit forwarding
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import threading
import time
import traceback
from typing import Any, Callable, Dict, List, Optional, Set

try:
    import websockets
    from websockets.server import WebSocketServerProtocol
except ImportError as e:
    raise ImportError(
        "The Nexus WebSocket bus requires the 'websockets' package. "
        "Install it with: pip install websockets>=12.0"
    ) from e

from .event_bus import EventBus
from .models import NexusEvent, _now_iso

# ─── GammaLanguage v1.1A-Robust+ Integration ───
_GAMMA_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "..", "GammaLanguage", "python")
if _GAMMA_PATH not in sys.path:
    sys.path.insert(0, os.path.abspath(_GAMMA_PATH))
try:
    from gamma_bridge import GammaBridge
    _gamma = GammaBridge()
    _GAMMA_AVAILABLE = True
except Exception:
    _gamma = None
    _GAMMA_AVAILABLE = False


# ─── GammaLanguage Frame Codec ───
# Transcodes between JSON dicts and A2A-DSL AST frames.
# Incoming: tries GammaLanguage DSL parse first, falls back to raw JSON.
# Outgoing: wraps payload in a GammaLanguage script frame.

def _encode_gamma_frame(message: Dict[str, Any]) -> str:
    """Encode an outgoing message as a GammaLanguage AST frame string."""
    if not _GAMMA_AVAILABLE:
        return json.dumps(message)

    msg_type = message.get("type", "unknown")
    agent_id = message.get("agent_id", message.get("from_agent_id", ""))
    payload = message.get("payload", message.get("context", {}))

    # Build a compact A2A-DSL script representing this message
    lines = [
        f"!STATE: 0x{hash(msg_type) & 0xFF:02X}",
        f"@INVARIANT: type != \"\"",
        f"#HIVE[\"nexus_bus\"]",
        f"$EXEC {{",
        f"  EMIT_SIGNAL(\"{msg_type}\", 0);",
    ]
    if agent_id:
        lines.append(f"  REG[0] = {hash(agent_id) & 0xFFFF};")
    if payload:
        payload_str = json.dumps(payload, separators=(',', ':'))[:512]
        lines.append(f"  CTX[0] = \"{payload_str}\";")
    lines.append("}")

    gamma_script = "\n".join(lines)
    try:
        compiled = _gamma.compile_gamma(gamma_script)
        # Embed the original JSON inside the gamma frame for full fidelity
        compiled["_envelope"] = message
        return json.dumps(compiled, separators=(',', ':'))
    except Exception:
        return json.dumps(message)


def _decode_gamma_frame(raw: str) -> Dict[str, Any]:
    """Decode an incoming message — tries GammaLanguage first, falls back to JSON."""
    # Try JSON first (backward compat with non-Gamma clients)
    try:
        data = json.loads(raw)
        # If this is a compiled Gamma frame with _envelope, extract it
        if isinstance(data, dict) and "_envelope" in data:
            return data["_envelope"]
        # If it's a raw Gamma DSL script string inside JSON
        if isinstance(data, dict) and data.get("type") == "gamma_script":
            script = data.get("script", "")
            if _GAMMA_AVAILABLE:
                compiled = _gamma.compile_gamma(script)
                return compiled
        return data
    except json.JSONDecodeError:
        pass

    # Try as raw GammaLanguage DSL script
    if _GAMMA_AVAILABLE:
        try:
            compiled = _gamma.compile_gamma(raw)
            if compiled.get("ast_nodes", 0) > 0:
                return compiled
        except Exception:
            pass

    # Last resort: wrap as unknown
    return {"type": "error", "error": "Unparseable message — not JSON or GammaLanguage"}


class BusConnection:
    """Wraps a single WebSocket connection with agent metadata."""

    def __init__(self, websocket: WebSocketServerProtocol):
        self.websocket = websocket
        self.agent_id: Optional[str] = None
        self.session_id: Optional[str] = None
        self.subscribed_topics: Set[str] = set()
        self.verified: bool = False
        self.last_seen: float = time.time()
        self.handshakes: Dict[str, Dict[str, Any]] = {}
        self.hive: Optional[str] = None  # #HIVE partition for RAG routing

    def touch(self) -> None:
        self.last_seen = time.time()

    def is_stale(self, timeout_seconds: float = 60.0) -> bool:
        return time.time() - self.last_seen > timeout_seconds


class NexusWebSocketBus:
    """WebSocket bus server for real-time agent communication."""

    def __init__(self, port: int = 8652, event_bus: Optional[EventBus] = None,
                 audit_callback: Optional[Callable[[Dict[str, Any]], None]] = None):
        self.port = port
        self._connections: Set[BusConnection] = set()
        self._lock = threading.RLock()
        self._event_bus = event_bus
        self._audit_callback = audit_callback
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread: Optional[threading.Thread] = None
        self._server: Optional[websockets.WebSocketServer] = None
        self._running = False

    def start(self) -> None:
        if self._running:
            return
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._running = False
        if self._loop:
            try:
                future = asyncio.run_coroutine_threadsafe(self._close_server(), self._loop)
                future.result(timeout=5)
            except Exception:
                pass
        if self._thread:
            self._thread.join(timeout=5)

    async def _close_server(self) -> None:
        if self._server:
            self._server.close()
            await self._server.wait_closed()
        self._loop.stop()

    def _run_loop(self) -> None:
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._serve())

    async def _serve(self) -> None:
        self._server = await websockets.serve(self._handle_client, "127.0.0.1", self.port)
        self._running = True
        while self._running:
            await asyncio.sleep(1)
            await self._prune_stale()

    async def _handle_client(self, websocket: WebSocketServerProtocol) -> None:
        conn = BusConnection(websocket)
        with self._lock:
            self._connections.add(conn)

        try:
            async for message in websocket:
                try:
                    data = _decode_gamma_frame(message)
                    await self._process_message(conn, data)
                except Exception as e:
                    await self._send(conn, {"type": "error", "error": f"Decode failed: {e}"})
        except websockets.exceptions.ConnectionClosed:
            pass
        except Exception as e:
            await self._send(conn, {"type": "error", "error": str(e)})
        finally:
            with self._lock:
                self._connections.discard(conn)
            self._audit("agent_disconnect", {
                "agent_id": conn.agent_id,
                "session_id": conn.session_id,
            })

    async def _process_message(self, conn: BusConnection, data: Dict[str, Any]) -> None:
        conn.touch()
        msg_type = data.get("type", "unknown")

        if msg_type == "handshake":
            await self._handle_handshake(conn, data)
        elif msg_type == "handshake_response":
            await self._handle_handshake_response(conn, data)
        elif msg_type == "subscribe":
            await self._handle_subscribe(conn, data)
        elif msg_type == "unsubscribe":
            await self._handle_unsubscribe(conn, data)
        elif msg_type == "state_update":
            await self._handle_state_update(conn, data)
        elif msg_type == "handoff":
            await self._handle_handoff(conn, data)
        elif msg_type == "heartbeat":
            await self._handle_heartbeat(conn, data)
        elif msg_type == "hive_select":
            await self._handle_hive_select(conn, data)
        elif msg_type == "hive_route":
            await self._handle_hive_route(conn, data)
        elif msg_type == "gamma_script":
            # Direct GammaLanguage script execution on the bus
            await self._handle_gamma_script(conn, data)
        else:
            await self._send(conn, {"type": "error", "error": f"Unknown message type: {msg_type}"})

    async def _handle_handshake(self, conn: BusConnection, data: Dict[str, Any]) -> None:
        """Initiate a Liminal Handshake between two agents."""
        agent_id = data.get("agent_id")
        target_agent_id = data.get("target_agent_id")
        session_id = data.get("session_id")
        challenge = data.get("challenge", "")
        payload = data.get("payload", {})

        if not agent_id or not target_agent_id:
            await self._send(conn, {"type": "handshake_rejected", "reason": "Missing agent_id or target_agent_id"})
            return

        conn.agent_id = agent_id
        conn.session_id = session_id

        handshake_id = f"HS_{int(time.time() * 1000)}_{agent_id}_{target_agent_id}"
        handshake = {
            "handshake_id": handshake_id,
            "from_agent_id": agent_id,
            "to_agent_id": target_agent_id,
            "session_id": session_id,
            "challenge": challenge,
            "payload": payload,
            "status": "pending",
            "timestamp": _now_iso(),
        }
        conn.handshakes[handshake_id] = handshake

        # Forward handshake to target agent if connected
        forwarded = await self._send_to_agent(
            target_agent_id,
            {
                "type": "handshake_request",
                "handshake_id": handshake_id,
                "from_agent_id": agent_id,
                "session_id": session_id,
                "challenge": challenge,
                "payload": payload,
                "timestamp": _now_iso(),
            }
        )

        if not forwarded:
            await self._send(conn, {
                "type": "handshake_rejected",
                "handshake_id": handshake_id,
                "reason": "Target agent not connected",
            })
            return

        await self._send(conn, {
            "type": "handshake_initiated",
            "handshake_id": handshake_id,
            "status": "pending",
        })
        self._audit("handshake_initiated", handshake)

    async def _handle_handshake_response(self, conn: BusConnection, data: Dict[str, Any]) -> None:
        """Accept or reject a handshake."""
        handshake_id = data.get("handshake_id")
        accepted = data.get("accepted", False)
        response = data.get("response", {})
        reason = data.get("reason", "")

        if not handshake_id:
            await self._send(conn, {"type": "error", "error": "Missing handshake_id"})
            return

        # Find the originating connection
        origin_conn = None
        with self._lock:
            for c in self._connections:
                if handshake_id in c.handshakes:
                    origin_conn = c
                    break

        if not origin_conn:
            await self._send(conn, {
                "type": "handshake_rejected",
                "handshake_id": handshake_id,
                "reason": "Handshake origin not found",
            })
            return

        handshake = origin_conn.handshakes[handshake_id]
        handshake["status"] = "accepted" if accepted else "rejected"
        handshake["response"] = response
        handshake["resolved_at"] = _now_iso()
        conn.verified = accepted

        await self._send(origin_conn, {
            "type": "handshake_resolved",
            "handshake_id": handshake_id,
            "accepted": accepted,
            "from_agent_id": conn.agent_id,
            "response": response,
            "reason": reason,
            "timestamp": _now_iso(),
        })

        self._audit("handshake_resolved", handshake)

    async def _handle_subscribe(self, conn: BusConnection, data: Dict[str, Any]) -> None:
        topics = data.get("topics", [])
        if not isinstance(topics, list):
            topics = [topics]
        for t in topics:
            conn.subscribed_topics.add(t)
        conn.agent_id = data.get("agent_id", conn.agent_id)
        conn.session_id = data.get("session_id", conn.session_id)
        await self._send(conn, {
            "type": "subscribed",
            "topics": list(conn.subscribed_topics),
        })

    async def _handle_unsubscribe(self, conn: BusConnection, data: Dict[str, Any]) -> None:
        topics = data.get("topics", [])
        if not isinstance(topics, list):
            topics = [topics]
        for t in topics:
            conn.subscribed_topics.discard(t)
        await self._send(conn, {
            "type": "unsubscribed",
            "topics": list(conn.subscribed_topics),
        })

    async def _handle_state_update(self, conn: BusConnection, data: Dict[str, Any]) -> None:
        """Broadcast a state update to all subscribers of the topic."""
        topic = data.get("topic")
        if not topic:
            await self._send(conn, {"type": "error", "error": "Missing topic"})
            return

        update = {
            "type": "state_update",
            "topic": topic,
            "agent_id": data.get("agent_id", conn.agent_id),
            "session_id": data.get("session_id", conn.session_id),
            "payload": data.get("payload", {}),
            "timestamp": _now_iso(),
        }
        await self._broadcast_to_topic(topic, update)
        self._audit("state_update", update)

    async def _handle_handoff(self, conn: BusConnection, data: Dict[str, Any]) -> None:
        """Pass serialized context from one agent to another."""
        from_agent_id = data.get("agent_id", conn.agent_id)
        to_agent_id = data.get("to_agent_id")
        context = data.get("context", {})
        trigger = data.get("trigger", "manual")

        if not from_agent_id or not to_agent_id:
            await self._send(conn, {"type": "error", "error": "Missing agent_id or to_agent_id"})
            return

        handoff = {
            "type": "handoff",
            "from_agent_id": from_agent_id,
            "to_agent_id": to_agent_id,
            "session_id": data.get("session_id", conn.session_id),
            "context": context,
            "trigger": trigger,
            "timestamp": _now_iso(),
        }

        forwarded = await self._send_to_agent(to_agent_id, handoff)
        if not forwarded:
            await self._send(conn, {
                "type": "handoff_failed",
                "to_agent_id": to_agent_id,
                "reason": "Target agent not connected",
            })
            return

        await self._send(conn, {
            "type": "handoff_sent",
            "to_agent_id": to_agent_id,
            "timestamp": _now_iso(),
        })
        self._audit("handoff", handoff)

    async def _handle_heartbeat(self, conn: BusConnection, data: Dict[str, Any]) -> None:
        conn.agent_id = data.get("agent_id", conn.agent_id)
        conn.session_id = data.get("session_id", conn.session_id)
        conn.touch()
        await self._send(conn, {
            "type": "heartbeat_ack",
            "timestamp": _now_iso(),
            "master_clock": data.get("master_clock", 0),
        })

    async def _send(self, conn: BusConnection, message: Dict[str, Any]) -> bool:
        try:
            frame = _encode_gamma_frame(message)
            await conn.websocket.send(frame)
            return True
        except Exception:
            return False

    async def _send_to_agent(self, agent_id: str, message: Dict[str, Any]) -> bool:
        with self._lock:
            targets = [c for c in self._connections if c.agent_id == agent_id]
        if not targets:
            return False
        sent = False
        for t in targets:
            if await self._send(t, message):
                sent = True
        return sent

    async def _broadcast_to_topic(self, topic: str, message: Dict[str, Any]) -> None:
        with self._lock:
            targets = [c for c in self._connections if topic in c.subscribed_topics]
        for t in targets:
            await self._send(t, message)

    async def _prune_stale(self) -> None:
        with self._lock:
            stale = [c for c in self._connections if c.is_stale()]
            for c in stale:
                self._connections.discard(c)
                try:
                    await c.websocket.close()
                except Exception:
                    pass

    def _audit(self, event_type: str, payload: Dict[str, Any]) -> None:
        if self._event_bus:
            self._event_bus.publish(event_type, payload=payload)
        if self._audit_callback:
            try:
                self._audit_callback({"type": event_type, "payload": payload, "timestamp": _now_iso()})
            except Exception:
                pass

    def broadcast(self, topic: str, payload: Dict[str, Any]) -> None:
        """Synchronous API for broadcasting to a topic from the HTTP layer."""
        if not self._loop:
            return
        asyncio.run_coroutine_threadsafe(
            self._broadcast_to_topic(topic, {
                "type": "state_update",
                "topic": topic,
                "payload": payload,
                "timestamp": _now_iso(),
            }),
            self._loop,
        )

    def get_connected_agents(self) -> List[str]:
        with self._lock:
            return list({c.agent_id for c in self._connections if c.agent_id})

    def get_stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "connections": len(self._connections),
                "agents": self.get_connected_agents(),
                "topics": list({t for c in self._connections for t in c.subscribed_topics}),
                "hives": list({c.hive for c in self._connections if c.hive}),
                "gamma_enabled": _GAMMA_AVAILABLE,
            }

    async def _handle_hive_select(self, conn: BusConnection, data: Dict[str, Any]) -> None:
        """Set the #HIVE partition for this connection's RAG routing."""
        hive_name = data.get("hive", "")
        if not hive_name:
            await self._send(conn, {"type": "error", "error": "Missing hive name"})
            return
        conn.hive = hive_name
        await self._send(conn, {
            "type": "hive_selected",
            "hive": hive_name,
            "timestamp": _now_iso(),
        })
        self._audit("hive_select", {"agent_id": conn.agent_id, "hive": hive_name})

    async def _handle_hive_route(self, conn: BusConnection, data: Dict[str, Any]) -> None:
        """Route a message to all agents in a specific #HIVE partition."""
        target_hive = data.get("target_hive", "")
        payload = data.get("payload", {})
        if not target_hive:
            await self._send(conn, {"type": "error", "error": "Missing target_hive"})
            return

        routed = {
            "type": "hive_message",
            "from_agent_id": conn.agent_id,
            "hive": target_hive,
            "payload": payload,
            "timestamp": _now_iso(),
        }

        with self._lock:
            targets = [c for c in self._connections if c.hive == target_hive and c is not conn]
        for t in targets:
            await self._send(t, routed)

        await self._send(conn, {
            "type": "hive_routed",
            "hive": target_hive,
            "recipients": len(targets),
            "timestamp": _now_iso(),
        })
        self._audit("hive_route", {"from": conn.agent_id, "hive": target_hive, "recipients": len(targets)})

    async def _handle_gamma_script(self, conn: BusConnection, data: Dict[str, Any]) -> None:
        """Execute a GammaLanguage script and return the compiled AST frame."""
        script = data.get("script", "")
        if not script or not _GAMMA_AVAILABLE:
            await self._send(conn, {
                "type": "gamma_result",
                "ok": False,
                "error": "GammaLanguage not available or empty script",
            })
            return

        try:
            result = _gamma.compile_gamma(script)
            result["type"] = "gamma_result"
            result["ok"] = True
            await self._send(conn, result)
        except Exception as e:
            await self._send(conn, {
                "type": "gamma_result",
                "ok": False,
                "error": str(e),
            })
