"""Agent registry: tracks active agent instances, states, and heartbeats."""

from __future__ import annotations

import threading
import time
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional

from .models import Agent, AgentState, _now_iso


class AgentRegistry:
    """Thread-safe registry of active agents."""

    def __init__(self, offline_after_seconds: int = 120):
        self._agents: Dict[str, Agent] = {}
        self._lock = threading.RLock()
        self._offline_after_seconds = offline_after_seconds

    def register(self, agent: Agent) -> Agent:
        with self._lock:
            agent.heartbeat = _now_iso()
            self._agents[agent.agent_id] = agent
        return agent

    def update(self, agent_id: str, **kwargs) -> Optional[Agent]:
        with self._lock:
            agent = self._agents.get(agent_id)
            if not agent:
                return None
            for key, value in kwargs.items():
                if hasattr(agent, key):
                    setattr(agent, key, value)
            agent.heartbeat = _now_iso()
            return agent

    def heartbeat(self, agent_id: str, state: Optional[str] = None, current_task: Optional[str] = None, current_task_title: Optional[str] = None) -> Optional[Agent]:
        with self._lock:
            agent = self._agents.get(agent_id)
            if not agent:
                return None
            agent.heartbeat = _now_iso()
            if state:
                agent.state = state
            if current_task is not None:
                agent.current_task = current_task
            if current_task_title is not None:
                agent.current_task_title = current_task_title
            return agent

    def get(self, agent_id: str) -> Optional[Agent]:
        with self._lock:
            return self._agents.get(agent_id)

    def list(self, include_offline: bool = False) -> List[Agent]:
        with self._lock:
            agents = list(self._agents.values())
        if not include_offline:
            cutoff = datetime.now(timezone.utc) - timedelta(seconds=self._offline_after_seconds)
            filtered = []
            for a in agents:
                try:
                    hb = datetime.fromisoformat(a.heartbeat)
                    if hb.tzinfo is None:
                        hb = hb.replace(tzinfo=timezone.utc)
                    if hb >= cutoff:
                        filtered.append(a)
                except Exception:
                    continue
            return filtered
        return agents

    def unregister(self, agent_id: str) -> bool:
        with self._lock:
            return self._agents.pop(agent_id, None) is not None

    def prune(self) -> List[str]:
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=self._offline_after_seconds)
        removed = []
        with self._lock:
            for agent_id, agent in list(self._agents.items()):
                try:
                    hb = datetime.fromisoformat(agent.heartbeat)
                    if hb.tzinfo is None:
                        hb = hb.replace(tzinfo=timezone.utc)
                    if hb < cutoff:
                        removed.append(agent_id)
                except Exception:
                    removed.append(agent_id)
            for agent_id in removed:
                self._agents.pop(agent_id, None)
        return removed

    def get_by_session(self, session_id: str) -> List[Agent]:
        with self._lock:
            return [a for a in self._agents.values() if a.session_id == session_id]
