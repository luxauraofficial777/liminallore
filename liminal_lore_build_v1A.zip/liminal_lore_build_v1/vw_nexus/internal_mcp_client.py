"""Internal MCP client for VW Nexus.

Provides tools for git operations, build execution, and filesystem access
that agents can invoke through the MCP protocol. This is the in-process
client that wraps subprocess calls and file operations.
"""

from __future__ import annotations

import os
import subprocess
import threading
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional


class InternalMcpClient:
    """In-process MCP client that provides git/build/filesystem tools."""

    def __init__(self, project_root: Path):
        self.project_root = project_root
        self._lock = threading.RLock()
        self._command_history: List[Dict[str, Any]] = []
        self._max_history = 500

    def _log_command(self, tool: str, args: Dict, result: Dict, duration_ms: float) -> None:
        with self._lock:
            self._command_history.append({
                "tool": tool,
                "args": args,
                "result": result,
                "duration_ms": duration_ms,
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            })
            if len(self._command_history) > self._max_history:
                self._command_history = self._command_history[-200:]

    def _run_git(self, args: List[str], timeout: int = 30) -> Dict[str, Any]:
        cmd = ["git"] + args
        start = time.time()
        try:
            proc = subprocess.run(
                cmd,
                cwd=str(self.project_root),
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            duration_ms = (time.time() - start) * 1000
            result = {
                "ok": proc.returncode == 0,
                "stdout": proc.stdout[:5000],
                "stderr": proc.stderr[:2000],
                "returncode": proc.returncode,
            }
            self._log_command("git_" + args[0] if args else "git", {"args": args}, result, duration_ms)
            return result
        except subprocess.TimeoutExpired:
            return {"ok": False, "error": "Git command timed out"}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _run_build(self, command: str, timeout: int = 300) -> Dict[str, Any]:
        start = time.time()
        try:
            proc = subprocess.run(
                command,
                cwd=str(self.project_root),
                capture_output=True,
                text=True,
                timeout=timeout,
                shell=True,
            )
            duration_ms = (time.time() - start) * 1000
            result = {
                "ok": proc.returncode == 0,
                "stdout": proc.stdout[:10000],
                "stderr": proc.stderr[:5000],
                "returncode": proc.returncode,
                "duration_ms": duration_ms,
            }
            self._log_command("build", {"command": command}, result, duration_ms)
            return result
        except subprocess.TimeoutExpired:
            return {"ok": False, "error": "Build timed out", "timeout": timeout}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ── Git Tools ───────────────────────────────────────────────

    def git_status(self) -> Dict[str, Any]:
        return self._run_git(["status", "--porcelain=v2"])

    def git_diff(self, file_path: Optional[str] = None, staged: bool = False) -> Dict[str, Any]:
        args = ["diff"]
        if staged:
            args.append("--staged")
        if file_path:
            args.append("--")
            args.append(file_path)
        return self._run_git(args)

    def git_log(self, count: int = 20, oneline: bool = True) -> Dict[str, Any]:
        args = ["log", f"-{count}"]
        if oneline:
            args.append("--oneline")
        return self._run_git(args)

    def git_branch(self) -> Dict[str, Any]:
        return self._run_git(["branch", "-a"])

    def git_blame(self, file_path: str, start_line: int = 0, end_line: int = 0) -> Dict[str, Any]:
        args = ["blame", "-l"]
        if start_line and end_line:
            args.extend(["-L", f"{start_line},{end_line}"])
        args.append(file_path)
        return self._run_git(args)

    # ── Build Tools ─────────────────────────────────────────────

    def build_vw_deck(self) -> Dict[str, Any]:
        cmd = "cl.exe vw_deck.cpp /O2 /EHsc /Fe:vw_deck.exe user32.lib gdi32.lib shell32.lib comctl32.lib gdiplus.lib wininet.lib ws2_32.lib ole32.lib oleaut32.lib"
        deck_dir = self.project_root / "Modern_X64" / "tools" / "liminal_link_vw_deck"
        start = time.time()
        try:
            proc = subprocess.run(
                cmd,
                cwd=str(deck_dir),
                capture_output=True,
                text=True,
                timeout=300,
                shell=True,
            )
            duration_ms = (time.time() - start) * 1000
            result = {
                "ok": proc.returncode == 0,
                "stdout": proc.stdout[:10000],
                "stderr": proc.stderr[:5000],
                "returncode": proc.returncode,
                "duration_ms": duration_ms,
            }
            self._log_command("build_vw_deck", {}, result, duration_ms)
            return result
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def build_custom(self, command: str, cwd: Optional[str] = None) -> Dict[str, Any]:
        start = time.time()
        work_dir = cwd or str(self.project_root)
        try:
            proc = subprocess.run(
                command,
                cwd=work_dir,
                capture_output=True,
                text=True,
                timeout=300,
                shell=True,
            )
            duration_ms = (time.time() - start) * 1000
            result = {
                "ok": proc.returncode == 0,
                "stdout": proc.stdout[:10000],
                "stderr": proc.stderr[:5000],
                "returncode": proc.returncode,
                "duration_ms": duration_ms,
            }
            self._log_command("build_custom", {"command": command, "cwd": work_dir}, result, duration_ms)
            return result
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ── Filesystem Tools ────────────────────────────────────────

    def read_file(self, relative_path: str, max_bytes: int = 50000) -> Dict[str, Any]:
        full_path = self.project_root / relative_path
        try:
            if not full_path.exists():
                return {"ok": False, "error": "File not found"}
            if full_path.is_dir():
                return {"ok": False, "error": "Path is a directory"}
            data = full_path.read_text(encoding="utf-8", errors="replace")[:max_bytes]
            return {
                "ok": True,
                "path": relative_path,
                "content": data,
                "size": full_path.stat().st_size,
                "truncated": full_path.stat().st_size > max_bytes,
            }
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def list_directory(self, relative_path: str = ".") -> Dict[str, Any]:
        full_path = self.project_root / relative_path
        try:
            if not full_path.exists():
                return {"ok": False, "error": "Directory not found"}
            items = []
            for item in sorted(full_path.iterdir()):
                items.append({
                    "name": item.name,
                    "type": "dir" if item.is_dir() else "file",
                    "size": item.stat().st_size if item.is_file() else 0,
                })
            return {"ok": True, "path": relative_path, "items": items}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def file_info(self, relative_path: str) -> Dict[str, Any]:
        full_path = self.project_root / relative_path
        try:
            if not full_path.exists():
                return {"ok": False, "error": "File not found"}
            stat = full_path.stat()
            return {
                "ok": True,
                "path": relative_path,
                "size": stat.st_size,
                "modified": stat.st_mtime,
                "is_dir": full_path.is_dir(),
                "suffix": full_path.suffix,
            }
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ── Search Tools ────────────────────────────────────────────

    def grep(self, pattern: str, file_glob: str = "*", max_results: int = 50) -> Dict[str, Any]:
        try:
            import fnmatch
            results = []
            for root, dirs, files in os.walk(str(self.project_root)):
                if ".git" in dirs:
                    dirs.remove(".git")
                if "__pycache__" in dirs:
                    dirs.remove("__pycache__")
                if "node_modules" in dirs:
                    dirs.remove("node_modules")
                for fname in files:
                    if not fnmatch.fnmatch(fname, file_glob):
                        continue
                    fpath = Path(root) / fname
                    try:
                        content = fpath.read_text(encoding="utf-8", errors="replace")
                        for i, line in enumerate(content.split("\n"), 1):
                            if pattern.lower() in line.lower():
                                rel = str(fpath.relative_to(self.project_root)).replace("\\", "/")
                                results.append({
                                    "file": rel,
                                    "line": i,
                                    "text": line.strip()[:200],
                                })
                                if len(results) >= max_results:
                                    return {"ok": True, "results": results, "truncated": True}
                    except Exception:
                        continue
            return {"ok": True, "results": results, "truncated": False}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ── Status ──────────────────────────────────────────────────

    def status(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "commands_run": len(self._command_history),
                "project_root": str(self.project_root),
            }

    def history(self, limit: int = 50) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self._command_history[-limit:])


def register_internal_tools(mcp_server: Any, client: InternalMcpClient) -> None:
    """Register internal MCP tools backed by the InternalMcpClient."""
    from .mcp_server import register_tool

    register_tool(
        "git_status", "Get git status of the project", {},
        lambda args: client.git_status(), "read",
    )
    register_tool(
        "git_diff", "Get git diff for a file or all changes",
        {"file_path": {"type": "string"}, "staged": {"type": "boolean", "default": False}},
        lambda args: client.git_diff(args.get("file_path"), args.get("staged", False)), "read",
    )
    register_tool(
        "git_log", "Get recent git log entries",
        {"count": {"type": "integer", "default": 20}},
        lambda args: client.git_log(args.get("count", 20)), "read",
    )
    register_tool(
        "git_branch", "List all git branches", {},
        lambda args: client.git_branch(), "read",
    )
    register_tool(
        "git_blame", "Git blame for a file",
        {"file_path": {"type": "string", "required": True},
         "start_line": {"type": "integer"}, "end_line": {"type": "integer"}},
        lambda args: client.git_blame(args["file_path"], args.get("start_line", 0), args.get("end_line", 0)), "read",
    )
    register_tool(
        "build_vw_deck", "Compile vw_deck.cpp", {},
        lambda args: client.build_vw_deck(), "execute",
    )
    register_tool(
        "build_custom", "Run a custom build command",
        {"command": {"type": "string", "required": True}, "cwd": {"type": "string"}},
        lambda args: client.build_custom(args["command"], args.get("cwd")), "execute",
    )
    register_tool(
        "read_file", "Read a file from the project",
        {"relative_path": {"type": "string", "required": True},
         "max_bytes": {"type": "integer", "default": 50000}},
        lambda args: client.read_file(args["relative_path"], args.get("max_bytes", 50000)), "read",
    )
    register_tool(
        "list_directory", "List directory contents",
        {"relative_path": {"type": "string", "default": "."}},
        lambda args: client.list_directory(args.get("relative_path", ".")), "read",
    )
    register_tool(
        "file_info", "Get file metadata",
        {"relative_path": {"type": "string", "required": True}},
        lambda args: client.file_info(args["relative_path"]), "read",
    )
    register_tool(
        "grep", "Search for a pattern in project files",
        {"pattern": {"type": "string", "required": True},
         "file_glob": {"type": "string", "default": "*"},
         "max_results": {"type": "integer", "default": 50}},
        lambda args: client.grep(args["pattern"], args.get("file_glob", "*"), args.get("max_results", 50)), "read",
    )
