"""Agent identity, self-model, and heartbeat utilities for the VW Nexus.

Provides:
  - AgentIdentity: dataclass describing an agent's identity card
  - SelfModelPrompt: generates the self-model prompt injected at session start
  - AgentClient: HTTP client for registering with the Nexus, sending heartbeats,
    claiming tasks, requesting locks, and querying RAG
  - HeartbeatLoop: background thread that sends periodic heartbeats
"""

from __future__ import annotations

import json
import threading
import time
import urllib.request
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


NEXUS_URL = "http://127.0.0.1:8651"


# ── Agent Identity ────────────────────────────────────────────

@dataclass
class AgentIdentity:
    """Identity card for an autonomous agent."""
    agent_id: str = ""
    name: str = "Unknown"
    provider: str = "unknown"
    model: str = "unknown"
    capabilities: List[str] = field(default_factory=list)
    session_id: str = "default"
    max_concurrent_tasks: int = 2
    preferred_working_hours: str = "any"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_registration(self) -> Dict[str, Any]:
        """Convert to the payload expected by POST /agents."""
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "provider": self.provider,
            "model": self.model,
            "capabilities": self.capabilities,
            "session_id": self.session_id,
            "state": "idle",
            "metadata": {
                "max_concurrent_tasks": self.max_concurrent_tasks,
                "preferred_working_hours": self.preferred_working_hours,
                **self.metadata,
            },
        }


# ── Self-Model Prompt ─────────────────────────────────────────

SELF_MODEL_TEMPLATE = """\
You are {name}, an autonomous agent in the Void Walkers HD project.
Your agent ID: {agent_id}
Your session: {session_id}
Your capabilities: {capabilities}
Your provider/model: {provider}/{model}

ACTIVE AGENTS:
{other_agents}

YOUR CURRENT TASK:
{current_task}

LOCKED FILES:
{locked_files}

PROJECT STATE:
{project_state}

OPERATING RULES:
- Before editing any file, request a lock via POST /nexus/locks with your agent_id.
- When you finish a sub-task, report it via POST /nexus/tasks/{{id}}/done with artifacts.
- Send a heartbeat every 30 seconds via POST /nexus/agents/{agent_id}/heartbeat.
- Reference other agents' work when relevant — check GET /nexus/events for recent activity.
- Use RAG to query the /study corpus: POST /nexus/rag with your query.
- If another agent holds a lock you need, wait for it to be released or coordinate via the event bus.
- Never edit a file you don't hold a lock for.
- When handing off work to another agent, use POST /nexus/handoff with serialized context.
"""


class SelfModelPrompt:
    """Generates the self-model prompt for an agent session."""

    @staticmethod
    def generate(
        identity: AgentIdentity,
        other_agents: Optional[List[Dict[str, Any]]] = None,
        current_task: Optional[str] = None,
        locked_files: Optional[List[Dict[str, Any]]] = None,
        project_state: Optional[Dict[str, Any]] = None,
    ) -> str:
        other_str = "None"
        if other_agents:
            lines = []
            for a in other_agents:
                lines.append(
                    f"  - {a.get('name', '?')} ({a.get('agent_id', '?')}): "
                    f"state={a.get('state', '?')}, task={a.get('current_task_title', 'none')}"
                )
            other_str = "\n".join(lines)

        task_str = current_task or "None assigned"
        locks_str = "None"
        if locked_files:
            locks_str = "\n".join(
                f"  - {l.get('path', '?')} (held by {l.get('agent_id', '?')})"
                for l in locked_files
            )

        state_str = "Unknown"
        if project_state:
            state_str = json.dumps(project_state, indent=2, default=str)

        return SELF_MODEL_TEMPLATE.format(
            name=identity.name,
            agent_id=identity.agent_id,
            session_id=identity.session_id,
            capabilities=", ".join(identity.capabilities) or "general",
            provider=identity.provider,
            model=identity.model,
            other_agents=other_str,
            current_task=task_str,
            locked_files=locks_str,
            project_state=state_str,
        )


# ── Nexus HTTP Client ─────────────────────────────────────────

class AgentClient:
    """HTTP client for agent-to-Nexus communication."""

    def __init__(self, identity: AgentIdentity, nexus_url: str = NEXUS_URL):
        self.identity = identity
        self.nexus_url = nexus_url.rstrip("/")
        self._registered = False

    def _post(self, path: str, data: Dict[str, Any]) -> Dict[str, Any]:
        try:
            payload = json.dumps(data).encode("utf-8")
            req = urllib.request.Request(
                f"{self.nexus_url}{path}",
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            resp = urllib.request.urlopen(req, timeout=10)
            return json.loads(resp.read().decode("utf-8"))
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _get(self, path: str) -> Dict[str, Any]:
        try:
            req = urllib.request.Request(f"{self.nexus_url}{path}", method="GET")
            resp = urllib.request.urlopen(req, timeout=10)
            return json.loads(resp.read().decode("utf-8"))
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def register(self) -> Dict[str, Any]:
        result = self._post("/agents", self.identity.to_registration())
        if result.get("agent_id") or result.get("name"):
            self._registered = True
        return result

    def heartbeat(self, state: str = "idle", current_task: Optional[str] = None,
                  current_task_title: Optional[str] = None) -> Dict[str, Any]:
        data: Dict[str, Any] = {"state": state}
        if current_task is not None:
            data["current_task"] = current_task
        if current_task_title is not None:
            data["current_task_title"] = current_task_title
        return self._post(f"/agents/{self.identity.agent_id}/heartbeat", data)

    def request_lock(self, path: str, intent: str = "", ttl: int = 1800) -> Dict[str, Any]:
        return self._post("/locks", {
            "agent_id": self.identity.agent_id,
            "path": path,
            "intent": intent,
            "ttl_seconds": ttl,
        })

    def release_lock(self, path: str) -> Dict[str, Any]:
        try:
            req = urllib.request.Request(
                f"{self.nexus_url}/locks/{urllib.parse.quote(path, safe='')}",
                data=json.dumps({"agent_id": self.identity.agent_id}).encode(),
                headers={"Content-Type": "application/json"},
                method="DELETE",
            )
            resp = urllib.request.urlopen(req, timeout=10)
            return json.loads(resp.read().decode("utf-8"))
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def claim_task(self, task_id: str) -> Dict[str, Any]:
        return self._post(f"/tasks/{task_id}/claim", {
            "agent_id": self.identity.agent_id,
        })

    def complete_task(self, task_id: str, result: Optional[Dict] = None,
                      artifacts: Optional[List[str]] = None) -> Dict[str, Any]:
        return self._post(f"/tasks/{task_id}/done", {
            "agent_id": self.identity.agent_id,
            "result": result,
            "artifacts": artifacts or [],
        })

    def fail_task(self, task_id: str, error: str) -> Dict[str, Any]:
        return self._post(f"/tasks/{task_id}/fail", {
            "agent_id": self.identity.agent_id,
            "error": error,
        })

    def rag_query(self, query: str, max_chunks: int = 20) -> Dict[str, Any]:
        return self._post("/rag", {
            "query": query,
            "max_chunks": max_chunks,
        })

    def get_ready_tasks(self) -> Dict[str, Any]:
        return self._get("/tasks/ready")

    def get_other_agents(self) -> List[Dict[str, Any]]:
        result = self._get("/agents")
        agents = result.get("agents", [])
        return [a for a in agents if a.get("agent_id") != self.identity.agent_id]

    def get_locked_files(self) -> List[Dict[str, Any]]:
        result = self._get("/locks")
        return result.get("locks", [])

    def get_project_state(self) -> Dict[str, Any]:
        return self._get("/status")

    def get_self_model(self) -> str:
        """Generate a self-model prompt with live Nexus data."""
        other_agents = self.get_other_agents()
        locked_files = self.get_locked_files()
        project_state = self.get_project_state()
        agent = self._get(f"/agents/{self.identity.agent_id}")
        current_task = agent.get("current_task_title", "None")
        return SelfModelPrompt.generate(
            identity=self.identity,
            other_agents=other_agents,
            current_task=current_task,
            locked_files=locked_files,
            project_state=project_state,
        )

    def unregister(self) -> Dict[str, Any]:
        try:
            req = urllib.request.Request(
                f"{self.nexus_url}/agents/{self.identity.agent_id}",
                method="DELETE",
            )
            resp = urllib.request.urlopen(req, timeout=10)
            return json.loads(resp.read().decode("utf-8"))
        except Exception as e:
            return {"ok": False, "error": str(e)}


# ── Heartbeat Loop ────────────────────────────────────────────

class HeartbeatLoop:
    """Background thread that sends periodic heartbeats to the Nexus."""

    def __init__(self, client: AgentClient, interval: float = 30.0,
                 state_provider=None):
        self.client = client
        self.interval = interval
        self.state_provider = state_provider  # callable returning (state, task_id, task_title)
        self._thread: Optional[threading.Thread] = None
        self._running = False
        self._stop_event = threading.Event()

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._running = False
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)

    def _loop(self) -> None:
        while self._running and not self._stop_event.is_set():
            try:
                if self.state_provider:
                    state, task_id, task_title = self.state_provider()
                else:
                    state, task_id, task_title = "idle", None, None
                self.client.heartbeat(
                    state=state,
                    current_task=task_id,
                    current_task_title=task_title,
                )
            except Exception:
                pass
            self._stop_event.wait(self.interval)


# ── Convenience ───────────────────────────────────────────────

def quick_register(
    name: str,
    agent_id: Optional[str] = None,
    provider: str = "unknown",
    model: str = "unknown",
    capabilities: Optional[List[str]] = None,
    session_id: str = "default",
    nexus_url: str = NEXUS_URL,
) -> AgentClient:
    """Create an AgentIdentity, register with the Nexus, and return an AgentClient."""
    import uuid
    identity = AgentIdentity(
        agent_id=agent_id or f"{name.lower()}_{uuid.uuid4().hex[:6]}",
        name=name,
        provider=provider,
        model=model,
        capabilities=capabilities or [],
        session_id=session_id,
    )
    client = AgentClient(identity, nexus_url=nexus_url)
    client.register()
    return client
