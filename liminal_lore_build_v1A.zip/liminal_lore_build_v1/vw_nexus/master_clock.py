"""Master Clock and deterministic conflict resolution for the Nexus.

The Master Clock provides a monotonic, frame-based authority signal that
agents can use to resolve conflicts. The rule is simple: for any given
resource or build artifact, the agent with the highest clock tick at the
time of write is authoritative. If ticks are equal, agent_id is used
as a stable tie-breaker.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from .models import _now_iso


@dataclass
class ConflictEntry:
    resource: str
    agent_id: str
    tick: int
    timestamp: str
    payload: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class MasterClock:
    """Frame-based authority clock for deterministic agent coordination."""

    def __init__(self, tick_interval_ms: float = 100.0):
        self._tick = 0
        self._tick_interval_ms = tick_interval_ms
        self._last_tick_time = time.time()
        self._lock = threading.RLock()
        self._authority_log: Dict[str, ConflictEntry] = {}
        self._history: List[ConflictEntry] = []

    def tick(self) -> int:
        """Return the current master clock tick, advancing if needed."""
        with self._lock:
            now = time.time()
            elapsed_ms = (now - self._last_tick_time) * 1000.0
            if elapsed_ms >= self._tick_interval_ms:
                self._tick += int(elapsed_ms / self._tick_interval_ms)
                self._last_tick_time = now
            return self._tick

    def set_tick(self, tick: int) -> None:
        with self._lock:
            self._tick = max(self._tick, tick)
            self._last_tick_time = time.time()

    def bump(self) -> int:
        """Force a tick increment."""
        with self._lock:
            self._tick += 1
            self._last_tick_time = time.time()
            return self._tick

    def resolve_conflict(self, resource: str, proposals: List[ConflictEntry]) -> Optional[ConflictEntry]:
        """Return the authoritative proposal using tick + agent_id tie-breaker."""
        if not proposals:
            return None
        # Sort by tick descending, then agent_id ascending for deterministic tie-break
        winner = sorted(proposals, key=lambda p: (-p.tick, p.agent_id))[0]
        with self._lock:
            self._authority_log[resource] = winner
            self._history.append(winner)
        return winner

    def declare_authority(self, agent_id: str, resource: str, payload: Dict[str, Any]) -> ConflictEntry:
        """Agent declares authority over a resource at the current tick."""
        entry = ConflictEntry(
            resource=resource,
            agent_id=agent_id,
            tick=self.tick(),
            timestamp=_now_iso(),
            payload=payload,
        )
        with self._lock:
            self._authority_log[resource] = entry
            self._history.append(entry)
        return entry

    def get_authority(self, resource: str) -> Optional[ConflictEntry]:
        with self._lock:
            return self._authority_log.get(resource)

    def get_history(self, resource: Optional[str] = None, limit: int = 100) -> List[ConflictEntry]:
        with self._lock:
            history = list(self._history)
        if resource:
            history = [h for h in history if h.resource == resource]
        return history[-limit:]

    def status(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "tick": self._tick,
                "tick_interval_ms": self._tick_interval_ms,
                "last_tick_time": self._last_tick_time,
                "authoritative_resources": list(self._authority_log.keys()),
                "authority_count": len(self._authority_log),
                "history_count": len(self._history),
                "time": _now_iso(),
            }
