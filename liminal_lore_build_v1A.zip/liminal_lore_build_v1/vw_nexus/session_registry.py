"""Session registry for active work sessions."""

from __future__ import annotations

import threading
from typing import Dict, List, Optional

from .models import WorkSession, _now_iso


class SessionRegistry:
    """Thread-safe registry of work sessions."""

    def __init__(self):
        self._sessions: Dict[str, WorkSession] = {}
        self._lock = threading.RLock()

    def create(self, goal: str, rag_query: Optional[str] = None,
               context_version: str = "", metadata: Optional[Dict] = None) -> WorkSession:
        with self._lock:
            session = WorkSession(
                goal=goal,
                rag_query=rag_query,
                context_version=context_version,
                metadata=metadata or {},
            )
            self._sessions[session.session_id] = session
            return session

    def get(self, session_id: str) -> Optional[WorkSession]:
        with self._lock:
            return self._sessions.get(session_id)

    def list(self) -> List[WorkSession]:
        with self._lock:
            return list(self._sessions.values())

    def add_agent(self, session_id: str, agent_id: str) -> Optional[WorkSession]:
        with self._lock:
            session = self._sessions.get(session_id)
            if not session:
                return None
            if agent_id not in session.agents:
                session.agents.append(agent_id)
            session.updated = _now_iso()
            return session

    def remove_agent(self, session_id: str, agent_id: str) -> Optional[WorkSession]:
        with self._lock:
            session = self._sessions.get(session_id)
            if not session:
                return None
            if agent_id in session.agents:
                session.agents.remove(agent_id)
            session.updated = _now_iso()
            return session

    def update_locks(self, session_id: str, locks: Dict[str, str]) -> Optional[WorkSession]:
        with self._lock:
            session = self._sessions.get(session_id)
            if not session:
                return None
            session.active_file_locks = dict(locks)
            session.updated = _now_iso()
            return session

    def close(self, session_id: str) -> bool:
        with self._lock:
            return self._sessions.pop(session_id, None) is not None
