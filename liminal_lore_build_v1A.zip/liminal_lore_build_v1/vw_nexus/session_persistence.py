"""session_persistence.py

Browser-tab session management for the VW Nexus.

Each session acts as an isolated MCP (Model Context Protocol) environment,
allowing agents to be spun up or killed without impacting the host system's
RAM. Sessions persist their state (conversation history, agent assignments,
file locks, RAG context, provider routing decisions) to SQLite, enabling
session restore after Nexus restart or browser tab refresh.

Architecture:
  ┌─────────────────────────────────────────────────┐
  │              VW Deck Portal (Browser)            │
  │   Tab 1: "DQ4 Translation"  Tab 2: "VW Engine"  │
  │       │                          │               │
  │       ▼                          ▼               │
  │  Session S_a3f1             Session S_b7c2       │
  │  ├─ agents: [nex, nexx]     ├─ agents: [lux]    │
  │  ├─ provider: ollama        ├─ provider: warp    │
  │  ├─ mcp_context: {tools}    ├─ mcp_context: {}   │
  │  ├─ rag_context: {query}    ├─ rag_context: {}   │
  │  └─ conversation: [...]     └─ conversation: []  │
  │       │                          │               │
  │       ▼                          ▼               │
  │  ┌─────────────────────────────────────────────┐ │
  │  │        Nexus SessionManager (SQLite)        │ │
  │  │  persist | restore | list | kill | snapshot │ │
  │  └─────────────────────────────────────────────┘ │
  └─────────────────────────────────────────────────┘

Thread-safe for the Nexus 5-phase agentic suite.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


_SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
    session_id      TEXT PRIMARY KEY,
    label           TEXT DEFAULT '',
    goal            TEXT DEFAULT '',
    agents_json     TEXT DEFAULT '[]',
    provider_id     TEXT DEFAULT '',
    mcp_context     TEXT DEFAULT '{}',
    rag_context     TEXT DEFAULT '{}',
    conversation    TEXT DEFAULT '[]',
    file_locks      TEXT DEFAULT '{}',
    metadata        TEXT DEFAULT '{}',
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL,
    last_active     TEXT NOT NULL,
    status          TEXT DEFAULT 'active',
    tab_color       TEXT DEFAULT '',
    tab_icon        TEXT DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_sessions_status ON sessions(status);
CREATE INDEX IF NOT EXISTS idx_sessions_active ON sessions(last_active);

CREATE TABLE IF NOT EXISTS session_messages (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      TEXT NOT NULL,
    role            TEXT NOT NULL,
    content         TEXT DEFAULT '',
    agent_id        TEXT DEFAULT '',
    provider        TEXT DEFAULT '',
    model           TEXT DEFAULT '',
    latency_ms      REAL DEFAULT 0,
    token_usage     INTEGER DEFAULT 0,
    timestamp       TEXT NOT NULL,
    metadata        TEXT DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_messages_session ON session_messages(session_id);
CREATE INDEX IF NOT EXISTS idx_messages_time ON session_messages(timestamp);
"""


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class SessionManager:
    """Browser-tab-style session persistence with MCP context isolation.

    Each session is an isolated environment that can be:
      - Created (new tab)
      - Restored (reopen tab)
      - Snapshotted (save current state)
      - Killed (close tab — frees agent RAM)
      - Listed (show all open tabs)
    """

    def __init__(self, db_path: Path):
        self._db_path = db_path
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(str(db_path), check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        self._db.executescript(_SCHEMA)
        self._db.commit()

    def create_session(self, label: str = "", goal: str = "",
                       provider_id: str = "", tab_color: str = "",
                       tab_icon: str = "",
                       metadata: Optional[Dict] = None) -> Dict[str, Any]:
        """Create a new session (like opening a new browser tab)."""
        session_id = f"S_{uuid.uuid4().hex[:12]}"
        now = _now_iso()
        with self._lock:
            self._db.execute(
                """INSERT INTO sessions
                   (session_id, label, goal, provider_id, tab_color, tab_icon,
                    metadata, created_at, updated_at, last_active, status)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')""",
                (session_id, label, goal, provider_id, tab_color, tab_icon,
                 json.dumps(metadata or {}), now, now, now)
            )
            self._db.commit()
        return self.get_session(session_id)

    def get_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve a session by ID."""
        with self._lock:
            row = self._db.execute(
                "SELECT * FROM sessions WHERE session_id = ?", (session_id,)
            ).fetchone()
        if not row:
            return None
        return self._row_to_dict(row)

    def list_sessions(self, status: str = None) -> List[Dict[str, Any]]:
        """List all sessions (like listing open browser tabs)."""
        with self._lock:
            if status:
                rows = self._db.execute(
                    "SELECT * FROM sessions WHERE status = ? ORDER BY last_active DESC",
                    (status,)
                ).fetchall()
            else:
                rows = self._db.execute(
                    "SELECT * FROM sessions ORDER BY last_active DESC"
                ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def update_session(self, session_id: str, updates: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update session fields (label, goal, provider, metadata, etc.)."""
        allowed = {"label", "goal", "provider_id", "tab_color", "tab_icon",
                   "status", "metadata"}
        now = _now_iso()
        with self._lock:
            row = self._db.execute(
                "SELECT * FROM sessions WHERE session_id = ?", (session_id,)
            ).fetchone()
            if not row:
                return None

            sets = []
            vals = []
            for key, value in updates.items():
                if key in allowed:
                    if key == "metadata":
                        value = json.dumps(value)
                    sets.append(f"{key} = ?")
                    vals.append(value)

            if not sets:
                return self._row_to_dict(row)

            sets.append("updated_at = ?")
            sets.append("last_active = ?")
            vals.extend([now, now])
            vals.append(session_id)

            self._db.execute(
                f"UPDATE sessions SET {', '.join(sets)} WHERE session_id = ?",
                vals
            )
            self._db.commit()
        return self.get_session(session_id)

    def add_message(self, session_id: str, role: str, content: str,
                    agent_id: str = "", provider: str = "", model: str = "",
                    latency_ms: float = 0, token_usage: int = 0,
                    metadata: Optional[Dict] = None) -> Dict[str, Any]:
        """Add a message to the session conversation history."""
        now = _now_iso()
        with self._lock:
            cur = self._db.execute(
                """INSERT INTO session_messages
                   (session_id, role, content, agent_id, provider, model,
                    latency_ms, token_usage, timestamp, metadata)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (session_id, role, content, agent_id, provider, model,
                 latency_ms, token_usage, now, json.dumps(metadata or {}))
            )
            # Update session last_active
            self._db.execute(
                "UPDATE sessions SET last_active = ?, updated_at = ? WHERE session_id = ?",
                (now, now, session_id)
            )
            self._db.commit()
            msg_id = cur.lastrowid
        return {"id": msg_id, "session_id": session_id, "role": role,
                "content": content, "timestamp": now}

    def get_messages(self, session_id: str, limit: int = 100,
                     offset: int = 0) -> List[Dict[str, Any]]:
        """Retrieve conversation history for a session."""
        with self._lock:
            rows = self._db.execute(
                """SELECT * FROM session_messages WHERE session_id = ?
                   ORDER BY id DESC LIMIT ? OFFSET ?""",
                (session_id, limit, offset)
            ).fetchall()
        messages = []
        for row in reversed(rows):
            messages.append({
                "id": row["id"],
                "session_id": row["session_id"],
                "role": row["role"],
                "content": row["content"],
                "agent_id": row["agent_id"],
                "provider": row["provider"],
                "model": row["model"],
                "latency_ms": row["latency_ms"],
                "token_usage": row["token_usage"],
                "timestamp": row["timestamp"],
                "metadata": json.loads(row["metadata"] or "{}"),
            })
        return messages

    def set_mcp_context(self, session_id: str, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Set the MCP context for a session (isolated tool environment)."""
        now = _now_iso()
        with self._lock:
            self._db.execute(
                "UPDATE sessions SET mcp_context = ?, updated_at = ?, last_active = ? WHERE session_id = ?",
                (json.dumps(context), now, now, session_id)
            )
            self._db.commit()
        return self.get_session(session_id)

    def get_mcp_context(self, session_id: str) -> Dict[str, Any]:
        """Get the MCP context for a session."""
        with self._lock:
            row = self._db.execute(
                "SELECT mcp_context FROM sessions WHERE session_id = ?", (session_id,)
            ).fetchone()
        if not row:
            return {}
        return json.loads(row["mcp_context"] or "{}")

    def set_rag_context(self, session_id: str, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Set the RAG context for a session (isolated knowledge base query)."""
        now = _now_iso()
        with self._lock:
            self._db.execute(
                "UPDATE sessions SET rag_context = ?, updated_at = ?, last_active = ? WHERE session_id = ?",
                (json.dumps(context), now, now, session_id)
            )
            self._db.commit()
        return self.get_session(session_id)

    def set_agents(self, session_id: str, agent_ids: List[str]) -> Optional[Dict[str, Any]]:
        """Set the agents assigned to a session."""
        now = _now_iso()
        with self._lock:
            self._db.execute(
                "UPDATE sessions SET agents_json = ?, updated_at = ?, last_active = ? WHERE session_id = ?",
                (json.dumps(agent_ids), now, now, session_id)
            )
            self._db.commit()
        return self.get_session(session_id)

    def set_file_locks(self, session_id: str, locks: Dict[str, str]) -> Optional[Dict[str, Any]]:
        """Set file locks for a session."""
        now = _now_iso()
        with self._lock:
            self._db.execute(
                "UPDATE sessions SET file_locks = ?, updated_at = ?, last_active = ? WHERE session_id = ?",
                (json.dumps(locks), now, now, session_id)
            )
            self._db.commit()
        return self.get_session(session_id)

    def kill_session(self, session_id: str) -> bool:
        """Kill a session (like closing a browser tab — frees agent RAM).

        Marks the session as 'killed' and releases all associated resources.
        The session data is preserved for potential restore.
        """
        now = _now_iso()
        with self._lock:
            cur = self._db.execute(
                "UPDATE sessions SET status = 'killed', updated_at = ? WHERE session_id = ? AND status = 'active'",
                (now, session_id)
            )
            self._db.commit()
            return cur.rowcount > 0

    def restore_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Restore a killed session (like reopening a closed tab)."""
        now = _now_iso()
        with self._lock:
            self._db.execute(
                "UPDATE sessions SET status = 'active', updated_at = ?, last_active = ? WHERE session_id = ?",
                (now, now, session_id)
            )
            self._db.commit()
        return self.get_session(session_id)

    def snapshot_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Create a full snapshot of a session for backup/transfer."""
        session = self.get_session(session_id)
        if not session:
            return None
        messages = self.get_messages(session_id, limit=10000)
        return {
            "session": session,
            "messages": messages,
            "snapshot_timestamp": _now_iso(),
        }

    def delete_session(self, session_id: str) -> bool:
        """Permanently delete a session and all its messages."""
        with self._lock:
            self._db.execute("DELETE FROM session_messages WHERE session_id = ?", (session_id,))
            cur = self._db.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))
            self._db.commit()
            return cur.rowcount > 0

    def touch(self, session_id: str) -> None:
        """Update last_active timestamp for a session."""
        now = _now_iso()
        with self._lock:
            self._db.execute(
                "UPDATE sessions SET last_active = ? WHERE session_id = ?",
                (now, session_id)
            )
            self._db.commit()

    def status(self) -> Dict[str, Any]:
        """Return summary status for dashboard."""
        with self._lock:
            active = self._db.execute(
                "SELECT COUNT(*) as c FROM sessions WHERE status = 'active'"
            ).fetchone()["c"]
            killed = self._db.execute(
                "SELECT COUNT(*) as c FROM sessions WHERE status = 'killed'"
            ).fetchone()["c"]
            total_msgs = self._db.execute(
                "SELECT COUNT(*) as c FROM session_messages"
            ).fetchone()["c"]
        return {
            "active_sessions": active,
            "killed_sessions": killed,
            "total_messages": total_msgs,
            "db_path": str(self._db_path),
        }

    def _row_to_dict(self, row: sqlite3.Row) -> Dict[str, Any]:
        return {
            "session_id": row["session_id"],
            "label": row["label"],
            "goal": row["goal"],
            "agents": json.loads(row["agents_json"] or "[]"),
            "provider_id": row["provider_id"],
            "mcp_context": json.loads(row["mcp_context"] or "{}"),
            "rag_context": json.loads(row["rag_context"] or "{}"),
            "file_locks": json.loads(row["file_locks"] or "{}"),
            "metadata": json.loads(row["metadata"] or "{}"),
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
            "last_active": row["last_active"],
            "status": row["status"],
            "tab_color": row["tab_color"],
            "tab_icon": row["tab_icon"],
        }

    def close(self) -> None:
        with self._lock:
            self._db.close()
