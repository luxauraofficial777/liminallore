"""In-memory event bus for agent-to-agent communication."""

from __future__ import annotations

import threading
import time
from collections import deque
from datetime import datetime, timedelta, timezone
from typing import Callable, Dict, List, Optional

from .models import NexusEvent, _now_iso


class EventBus:
    """Thread-safe publish/subscribe event bus with optional history."""

    def __init__(self, max_history: int = 1000):
        self._subscribers: List[Callable[[NexusEvent], None]] = []
        self._history: deque = deque(maxlen=max_history)
        self._lock = threading.RLock()

    def subscribe(self, callback: Callable[[NexusEvent], None]) -> None:
        with self._lock:
            if callback not in self._subscribers:
                self._subscribers.append(callback)

    def unsubscribe(self, callback: Callable[[NexusEvent], None]) -> None:
        with self._lock:
            if callback in self._subscribers:
                self._subscribers.remove(callback)

    def publish(self, event_type: str, agent_id: Optional[str] = None,
                session_id: Optional[str] = None, task_id: Optional[str] = None,
                payload: Optional[Dict] = None) -> NexusEvent:
        event = NexusEvent(
            event_type=event_type,
            agent_id=agent_id,
            session_id=session_id,
            task_id=task_id,
            payload=payload or {},
        )
        with self._lock:
            self._history.append(event)
            subscribers = list(self._subscribers)
        for callback in subscribers:
            try:
                callback(event)
            except Exception:
                continue
        return event

    def history(self, event_type: Optional[str] = None, since: Optional[str] = None,
                limit: int = 100) -> List[NexusEvent]:
        with self._lock:
            events = list(self._history)
        filtered = []
        for e in reversed(events):
            if event_type and e.event_type != event_type:
                continue
            if since and e.timestamp < since:
                continue
            filtered.append(e)
            if len(filtered) >= limit:
                break
        return list(reversed(filtered))

    def recent(self, seconds: float = 60.0) -> List[NexusEvent]:
        since = (datetime.now(timezone.utc) - timedelta(seconds=seconds)).isoformat()
        return self.history(since=since, limit=1000)
