"""SQLite-backed persistent state store for VW Nexus.

Provides crash recovery, historical queries, and multi-session support.
Tables: agents, tasks, file_locks, sessions, events, memory_working, memory_longterm.
"""

from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


_SCHEMA = """
CREATE TABLE IF NOT EXISTS agents (
    agent_id    TEXT PRIMARY KEY,
    name        TEXT NOT NULL DEFAULT '',
    provider    TEXT NOT NULL DEFAULT '',
    model       TEXT NOT NULL DEFAULT '',
    session_id  TEXT NOT NULL DEFAULT 'default',
    capabilities TEXT NOT NULL DEFAULT '[]',
    state       TEXT NOT NULL DEFAULT 'idle',
    current_task TEXT,
    current_task_title TEXT,
    heartbeat   TEXT NOT NULL,
    metadata    TEXT NOT NULL DEFAULT '{}',
    updated     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tasks (
    task_id     TEXT PRIMARY KEY,
    title       TEXT NOT NULL DEFAULT '',
    description TEXT NOT NULL DEFAULT '',
    agent_id    TEXT,
    dependencies TEXT NOT NULL DEFAULT '[]',
    status      TEXT NOT NULL DEFAULT 'pending',
    priority    INTEGER NOT NULL DEFAULT 5,
    artifacts   TEXT NOT NULL DEFAULT '[]',
    result      TEXT,
    metadata    TEXT NOT NULL DEFAULT '{}',
    created     TEXT NOT NULL,
    started     TEXT,
    finished    TEXT
);

CREATE TABLE IF NOT EXISTS file_locks (
    lock_id     TEXT PRIMARY KEY,
    agent_id    TEXT NOT NULL,
    path        TEXT NOT NULL,
    intent      TEXT NOT NULL DEFAULT '',
    ttl_seconds INTEGER NOT NULL DEFAULT 1800,
    created     TEXT NOT NULL,
    expires     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
    session_id  TEXT PRIMARY KEY,
    goal        TEXT NOT NULL DEFAULT '',
    agents      TEXT NOT NULL DEFAULT '[]',
    rag_query   TEXT,
    context_version TEXT NOT NULL DEFAULT '',
    active_file_locks TEXT NOT NULL DEFAULT '{}',
    metadata    TEXT NOT NULL DEFAULT '{}',
    created     TEXT NOT NULL,
    updated     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS events (
    event_id    TEXT PRIMARY KEY,
    event_type  TEXT NOT NULL,
    agent_id    TEXT,
    session_id  TEXT,
    task_id     TEXT,
    payload     TEXT NOT NULL DEFAULT '{}',
    timestamp   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS memory_working (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id    TEXT NOT NULL,
    key         TEXT NOT NULL,
    value       TEXT NOT NULL,
    ttl_seconds INTEGER NOT NULL DEFAULT 3600,
    created     TEXT NOT NULL,
    expires     TEXT NOT NULL,
    UNIQUE(agent_id, key)
);

CREATE TABLE IF NOT EXISTS memory_longterm (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id    TEXT,
    key         TEXT NOT NULL UNIQUE,
    value       TEXT NOT NULL,
    tags        TEXT NOT NULL DEFAULT '[]',
    source      TEXT NOT NULL DEFAULT '',
    created     TEXT NOT NULL,
    updated     TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_events_type ON events(event_type);
CREATE INDEX IF NOT EXISTS idx_events_timestamp ON events(timestamp);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_agent ON tasks(agent_id);
CREATE INDEX IF NOT EXISTS idx_locks_agent ON file_locks(agent_id);
CREATE INDEX IF NOT EXISTS idx_locks_expires ON file_locks(expires);
"""


class StateStore:
    """Thread-safe SQLite state store with WAL mode."""

    def __init__(self, db_path: Path):
        self.db_path = db_path
        self._lock = threading.RLock()
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(
            str(db_path),
            check_same_thread=False,
            isolation_level=None,
        )
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.executescript(_SCHEMA)

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    def _now(self) -> str:
        return datetime.now(timezone.utc).isoformat()

    def _json(self, val: Any) -> str:
        return json.dumps(val, default=str)

    def _unjson(self, val: str, default: Any = None) -> Any:
        if not val:
            return default
        try:
            return json.loads(val)
        except Exception:
            return default

    # ── Agents ──────────────────────────────────────────────────

    def upsert_agent(self, agent: Dict[str, Any]) -> None:
        with self._lock:
            self._conn.execute(
                """INSERT INTO agents (agent_id, name, provider, model, session_id,
                    capabilities, state, current_task, current_task_title, heartbeat,
                    metadata, updated)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(agent_id) DO UPDATE SET
                    name=excluded.name, provider=excluded.provider,
                    model=excluded.model, session_id=excluded.session_id,
                    capabilities=excluded.capabilities, state=excluded.state,
                    current_task=excluded.current_task,
                    current_task_title=excluded.current_task_title,
                    heartbeat=excluded.heartbeat, metadata=excluded.metadata,
                    updated=excluded.updated""",
                (
                    agent.get("agent_id", ""),
                    agent.get("name", ""),
                    agent.get("provider", ""),
                    agent.get("model", ""),
                    agent.get("session_id", "default"),
                    self._json(agent.get("capabilities", [])),
                    agent.get("state", "idle"),
                    agent.get("current_task"),
                    agent.get("current_task_title"),
                    agent.get("heartbeat", self._now()),
                    self._json(agent.get("metadata", {})),
                    self._now(),
                ),
            )

    def delete_agent(self, agent_id: str) -> None:
        with self._lock:
            self._conn.execute("DELETE FROM agents WHERE agent_id=?", (agent_id,))

    def load_agents(self) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute("SELECT * FROM agents").fetchall()
        cols = [d[0] for d in self._conn.execute("SELECT * FROM agents LIMIT 0").description]
        result = []
        for row in rows:
            d = dict(zip(cols, row))
            d["capabilities"] = self._unjson(d.get("capabilities", "[]"), [])
            d["metadata"] = self._unjson(d.get("metadata", "{}"), {})
            result.append(d)
        return result

    # ── Tasks ───────────────────────────────────────────────────

    def upsert_task(self, task: Dict[str, Any]) -> None:
        with self._lock:
            self._conn.execute(
                """INSERT INTO tasks (task_id, title, description, agent_id,
                    dependencies, status, priority, artifacts, result, metadata,
                    created, started, finished)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(task_id) DO UPDATE SET
                    title=excluded.title, description=excluded.description,
                    agent_id=excluded.agent_id, dependencies=excluded.dependencies,
                    status=excluded.status, priority=excluded.priority,
                    artifacts=excluded.artifacts, result=excluded.result,
                    metadata=excluded.metadata, started=excluded.started,
                    finished=excluded.finished""",
                (
                    task.get("task_id", ""),
                    task.get("title", ""),
                    task.get("description", ""),
                    task.get("agent_id"),
                    self._json(task.get("dependencies", [])),
                    task.get("status", "pending"),
                    task.get("priority", 5),
                    self._json(task.get("artifacts", [])),
                    self._json(task.get("result")) if task.get("result") else None,
                    self._json(task.get("metadata", {})),
                    task.get("created", self._now()),
                    task.get("started"),
                    task.get("finished"),
                ),
            )

    def load_tasks(self) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute("SELECT * FROM tasks").fetchall()
        cols = [d[0] for d in self._conn.execute("SELECT * FROM tasks LIMIT 0").description]
        result = []
        for row in rows:
            d = dict(zip(cols, row))
            d["dependencies"] = self._unjson(d.get("dependencies", "[]"), [])
            d["artifacts"] = self._unjson(d.get("artifacts", "[]"), [])
            d["result"] = self._unjson(d.get("result"))
            d["metadata"] = self._unjson(d.get("metadata", "{}"), {})
            result.append(d)
        return result

    # ── Locks ───────────────────────────────────────────────────

    def upsert_lock(self, lock: Dict[str, Any]) -> None:
        with self._lock:
            self._conn.execute(
                """INSERT INTO file_locks (lock_id, agent_id, path, intent,
                    ttl_seconds, created, expires)
                VALUES (?,?,?,?,?,?,?)
                ON CONFLICT(lock_id) DO UPDATE SET
                    agent_id=excluded.agent_id, intent=excluded.intent,
                    expires=excluded.expires""",
                (
                    lock.get("lock_id", ""),
                    lock.get("agent_id", ""),
                    lock.get("path", ""),
                    lock.get("intent", ""),
                    lock.get("ttl_seconds", 1800),
                    lock.get("created", self._now()),
                    lock.get("expires", self._now()),
                ),
            )

    def delete_lock(self, lock_id: str) -> None:
        with self._lock:
            self._conn.execute("DELETE FROM file_locks WHERE lock_id=?", (lock_id,))

    def load_locks(self) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute("SELECT * FROM file_locks").fetchall()
        cols = [d[0] for d in self._conn.execute("SELECT * FROM file_locks LIMIT 0").description]
        return [dict(zip(cols, row)) for row in rows]

    # ── Sessions ────────────────────────────────────────────────

    def upsert_session(self, session: Dict[str, Any]) -> None:
        with self._lock:
            self._conn.execute(
                """INSERT INTO sessions (session_id, goal, agents, rag_query,
                    context_version, active_file_locks, metadata, created, updated)
                VALUES (?,?,?,?,?,?,?,?,?)
                ON CONFLICT(session_id) DO UPDATE SET
                    goal=excluded.goal, agents=excluded.agents,
                    rag_query=excluded.rag_query,
                    context_version=excluded.context_version,
                    active_file_locks=excluded.active_file_locks,
                    metadata=excluded.metadata, updated=excluded.updated""",
                (
                    session.get("session_id", ""),
                    session.get("goal", ""),
                    self._json(session.get("agents", [])),
                    session.get("rag_query"),
                    session.get("context_version", ""),
                    self._json(session.get("active_file_locks", {})),
                    self._json(session.get("metadata", {})),
                    session.get("created", self._now()),
                    self._now(),
                ),
            )

    def load_sessions(self) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute("SELECT * FROM sessions").fetchall()
        cols = [d[0] for d in self._conn.execute("SELECT * FROM sessions LIMIT 0").description]
        result = []
        for row in rows:
            d = dict(zip(cols, row))
            d["agents"] = self._unjson(d.get("agents", "[]"), [])
            d["active_file_locks"] = self._unjson(d.get("active_file_locks", "{}"), {})
            d["metadata"] = self._unjson(d.get("metadata", "{}"), {})
            result.append(d)
        return result

    # ── Events ──────────────────────────────────────────────────

    def insert_event(self, event: Dict[str, Any]) -> None:
        with self._lock:
            self._conn.execute(
                """INSERT INTO events (event_id, event_type, agent_id, session_id,
                    task_id, payload, timestamp)
                VALUES (?,?,?,?,?,?,?)""",
                (
                    event.get("event_id", ""),
                    event.get("event_type", ""),
                    event.get("agent_id"),
                    event.get("session_id"),
                    event.get("task_id"),
                    self._json(event.get("payload", {})),
                    event.get("timestamp", self._now()),
                ),
            )

    def load_events(self, limit: int = 100, event_type: Optional[str] = None) -> List[Dict[str, Any]]:
        with self._lock:
            if event_type:
                rows = self._conn.execute(
                    "SELECT * FROM events WHERE event_type=? ORDER BY timestamp DESC LIMIT ?",
                    (event_type, limit),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT * FROM events ORDER BY timestamp DESC LIMIT ?",
                    (limit,),
                ).fetchall()
        cols = [d[0] for d in self._conn.execute("SELECT * FROM events LIMIT 0").description]
        result = []
        for row in rows:
            d = dict(zip(cols, row))
            d["payload"] = self._unjson(d.get("payload", "{}"), {})
            result.append(d)
        return result

    # ── Working Memory ──────────────────────────────────────────

    def set_working_memory(self, agent_id: str, key: str, value: Any, ttl: int = 3600) -> None:
        now = self._now()
        expires = datetime.now(timezone.utc).replace(microsecond=0)
        from datetime import timedelta
        expires = (expires + timedelta(seconds=ttl)).isoformat()
        with self._lock:
            self._conn.execute(
                """INSERT INTO memory_working (agent_id, key, value, ttl_seconds, created, expires)
                VALUES (?,?,?,?,?,?)
                ON CONFLICT(agent_id, key) DO UPDATE SET
                    value=excluded.value, ttl_seconds=excluded.ttl_seconds,
                    created=excluded.created, expires=excluded.expires""",
                (agent_id, key, self._json(value), ttl, now, expires),
            )

    def get_working_memory(self, agent_id: str, key: Optional[str] = None) -> Any:
        now = self._now()
        with self._lock:
            if key:
                rows = self._conn.execute(
                    "SELECT value FROM memory_working WHERE agent_id=? AND key=? AND expires>?",
                    (agent_id, key, now),
                ).fetchall()
                if rows:
                    return self._unjson(rows[0][0])
                return None
            rows = self._conn.execute(
                "SELECT key, value FROM memory_working WHERE agent_id=? AND expires>?",
                (agent_id, now),
            ).fetchall()
        return {r[0]: self._unjson(r[1]) for r in rows}

    def prune_working_memory(self) -> int:
        now = self._now()
        with self._lock:
            cur = self._conn.execute("DELETE FROM memory_working WHERE expires<=?", (now,))
            return cur.rowcount

    # ── Long-term Memory ────────────────────────────────────────

    def set_longterm_memory(self, key: str, value: Any, tags: Optional[List[str]] = None,
                            agent_id: Optional[str] = None, source: str = "") -> None:
        now = self._now()
        with self._lock:
            self._conn.execute(
                """INSERT INTO memory_longterm (agent_id, key, value, tags, source, created, updated)
                VALUES (?,?,?,?,?,?,?)
                ON CONFLICT(key) DO UPDATE SET
                    value=excluded.value, tags=excluded.tags,
                    source=excluded.source, updated=excluded.updated""",
                (agent_id, key, self._json(value), self._json(tags or []), source, now, now),
            )

    def get_longterm_memory(self, key: str) -> Any:
        with self._lock:
            rows = self._conn.execute(
                "SELECT value FROM memory_longterm WHERE key=?", (key,)
            ).fetchall()
            if rows:
                return self._unjson(rows[0][0])
            return None

    def search_longterm_memory(self, query: str, limit: int = 20) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                """SELECT key, value, tags, source, created, updated FROM memory_longterm
                WHERE key LIKE ? OR value LIKE ? ORDER BY updated DESC LIMIT ?""",
                (f"%{query}%", f"%{query}%", limit),
            ).fetchall()
        result = []
        for r in rows:
            result.append({
                "key": r[0],
                "value": self._unjson(r[1]),
                "tags": self._unjson(r[2], []),
                "source": r[3],
                "created": r[4],
                "updated": r[5],
            })
        return result

    # ── Snapshot / Restore ──────────────────────────────────────

    def snapshot(self) -> Dict[str, Any]:
        return {
            "agents": self.load_agents(),
            "tasks": self.load_tasks(),
            "locks": self.load_locks(),
            "sessions": self.load_sessions(),
            "events": self.load_events(limit=500),
        }

    def prune_expired_locks(self) -> int:
        now = self._now()
        with self._lock:
            cur = self._conn.execute("DELETE FROM file_locks WHERE expires<=?", (now,))
            return cur.rowcount
