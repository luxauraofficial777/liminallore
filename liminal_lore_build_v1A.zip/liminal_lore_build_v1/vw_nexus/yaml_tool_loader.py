"""Loader for MCP tool YAML definitions.

Scans the tools/mcp_server/tools/ directory for .yaml files, parses them,
and registers tools that have an in_process or http executor.  This bridges
the gap between the declarative YAML manifests and the programmatic
registration in mcp_server.py.

Usage:
    from vw_nexus.yaml_tool_loader import load_yaml_tools
    load_yaml_tools(nexus, mcp_server_instance)
"""

from __future__ import annotations

import importlib
import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import yaml
except ImportError:
    yaml = None  # type: ignore


def _find_tools_dir() -> Path:
    """Locate the tools/mcp_server/tools directory."""
    here = Path(__file__).resolve()
    # vw_nexus/yaml_tool_loader.py -> ../../mcp_server/tools
    return here.parent.parent / "mcp_server" / "tools"


def _parse_yaml_file(yaml_path: Path) -> Optional[Dict[str, Any]]:
    """Parse a single YAML tool file. Returns None on error."""
    if yaml is None:
        return None
    try:
        with open(yaml_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    except Exception:
        return None


def _convert_schema(yaml_params: Dict[str, Any]) -> Dict[str, Any]:
    """Convert YAML parameters section to mcp_server schema format."""
    schema: Dict[str, Any] = {}
    props = yaml_params.get("properties", {})
    required = set(yaml_params.get("required", []))
    for name, spec in props.items():
        if isinstance(spec, dict):
            entry: Dict[str, Any] = {
                "type": spec.get("type", "string"),
                "description": spec.get("description", ""),
            }
            if name in required:
                entry["required"] = True
            if "default" in spec:
                entry["default"] = spec["default"]
            if "enum" in spec:
                entry["enum"] = spec["enum"]
            schema[name] = entry
    return schema


def _make_http_handler(url: str, method: str):
    """Create a handler that proxies to an HTTP endpoint."""
    import urllib.request
    import urllib.error

    def handler(args: Dict[str, Any]) -> Dict[str, Any]:
        data = json.dumps(args).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"},
            method=method,
        )
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            return {"ok": False, "error": f"HTTP {e.code}: {e.reason}"}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    return handler


def _make_in_process_handler(module_name: str, function_name: str):
    """Create a handler that calls an in-process Python function."""
    def handler(args: Dict[str, Any]) -> Dict[str, Any]:
        try:
            mod = importlib.import_module(module_name)
            fn = getattr(mod, function_name)
            return fn(args)
        except ImportError as e:
            return {"ok": False, "error": f"Module not found: {module_name}: {e}"}
        except AttributeError:
            return {"ok": False, "error": f"Function not found: {module_name}.{function_name}"}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    return handler


def load_yaml_tools(mcp_server: Any = None) -> List[Dict[str, Any]]:
    """Load all YAML tool definitions and register them.

    Returns a list of registration results for diagnostic purposes.
    If mcp_server is provided, tools are registered via its register_tool.
    Otherwise, the global register_tool from mcp_server.py is used.
    """
    if yaml is None:
        return [{"ok": False, "error": "PyYAML not installed"}]

    from .mcp_server import register_tool as _register

    register = _register
    if mcp_server and hasattr(mcp_server, "register_tool"):
        register = mcp_server.register_tool

    tools_dir = _find_tools_dir()
    if not tools_dir.exists():
        return [{"ok": False, "error": f"Tools dir not found: {tools_dir}"}]

    results: List[Dict[str, Any]] = []
    skip_files = {"_schema.yaml"}

    for yaml_file in sorted(tools_dir.glob("*.yaml")):
        if yaml_file.name in skip_files:
            continue

        spec = _parse_yaml_file(yaml_file)
        if not spec:
            results.append({"file": yaml_file.name, "ok": False, "error": "Parse failed"})
            continue

        tool_id = spec.get("tool_id", yaml_file.stem)
        name = spec.get("name", tool_id)
        description = spec.get("description", "")
        params = spec.get("parameters", {})
        schema = _convert_schema(params)
        access = spec.get("access", {})
        rate_limit = access.get("rate_limit", 0)
        executor = spec.get("executor", {})
        exec_type = executor.get("type", "")

        # Skip if already registered (programmatic registration takes priority)
        from .mcp_server import _TOOL_REGISTRY
        if tool_id in _TOOL_REGISTRY:
            results.append({"file": yaml_file.name, "tool_id": tool_id, "ok": True, "skipped": "already registered"})
            continue

        handler = None
        if exec_type == "http":
            handler = _make_http_handler(
                executor.get("url", ""),
                executor.get("method", "POST"),
            )
        elif exec_type == "in_process":
            handler = _make_in_process_handler(
                executor.get("module", ""),
                executor.get("function", ""),
            )
        elif exec_type == "subprocess":
            # Subprocess tools are registered via hermes-bridge /tool-exec, skip
            results.append({"file": yaml_file.name, "tool_id": tool_id, "ok": True, "skipped": "subprocess type"})
            continue
        else:
            results.append({"file": yaml_file.name, "tool_id": tool_id, "ok": False, "error": f"Unknown executor type: {exec_type}"})
            continue

        if handler is None:
            continue

        authority = "read"
        caps = spec.get("capabilities", {})
        if caps.get("destructive", False):
            authority = "write"
        if exec_type == "subprocess":
            authority = "execute"

        register(
            name=tool_id,
            description=description,
            schema=schema,
            handler=handler,
            authority_required=authority,
            rate_limit=rate_limit,
        )
        results.append({"file": yaml_file.name, "tool_id": tool_id, "ok": True})

    return results


def list_yaml_tools() -> List[Dict[str, Any]]:
    """List all YAML tool definitions without registering them."""
    if yaml is None:
        return []
    tools_dir = _find_tools_dir()
    if not tools_dir.exists():
        return []
    skip_files = {"_schema.yaml"}
    tools = []
    for yaml_file in sorted(tools_dir.glob("*.yaml")):
        if yaml_file.name in skip_files:
            continue
        spec = _parse_yaml_file(yaml_file)
        if spec:
            tools.append({
                "file": yaml_file.name,
                "tool_id": spec.get("tool_id", yaml_file.stem),
                "name": spec.get("name", ""),
                "category": spec.get("category", ""),
                "executor_type": spec.get("executor", {}).get("type", ""),
                "destructive": spec.get("capabilities", {}).get("destructive", False),
                "rate_limit": spec.get("access", {}).get("rate_limit", 0),
            })
    return tools
