"""Warp MCP tool registration for VW Nexus.

Registers Warp-specific capabilities as MCP tools so Temple Monks (specifically
N3X for quantization/pipeline tooling) can leverage Warp infrastructure for
accelerated inference/tasks when available.

Tools registered:
  - warp_discover: On-demand discovery of Warp models (no background polling)
  - warp_status: Query Warp provider availability and model list
  - warp_inference: Route a generation request to Warp
  - warp_overflow_check: Check if Warp overflow should be triggered based on RAM pressure
"""

from __future__ import annotations

import json
import time
import urllib.request
import urllib.error
from typing import Any, Dict

from .mcp_server import register_tool

WARP_HARNESS_URL = "http://127.0.0.1:8649"
NEXUS_URL = "http://127.0.0.1:8651"
TELEMETRY_LOG_PATH = None  # Set by register function


def _warp_harness_request(path: str, method: str = "GET", data: bytes = None,
                          timeout: int = 10) -> Dict[str, Any]:
    """Make an HTTP request to the Warp harness."""
    url = f"{WARP_HARNESS_URL}{path}"
    try:
        req = urllib.request.Request(url, data=data, method=method)
        if data:
            req.add_header("Content-Type", "application/json")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.URLError as e:
        return {"ok": False, "error": f"Warp harness unreachable: {e}"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def _log_warp_telemetry(event: str, details: dict) -> None:
    """Log Warp telemetry to nexus_telemetry.log."""
    from pathlib import Path
    import os
    global TELEMETRY_LOG_PATH
    if TELEMETRY_LOG_PATH is None:
        # Resolve path relative to this module
        agent_dir = Path(__file__).parent.parent.parent.parent / "AGENT" / "distilled_agents" / "logs"
        agent_dir.mkdir(parents=True, exist_ok=True)
        TELEMETRY_LOG_PATH = agent_dir / "nexus_telemetry.log"
    try:
        from datetime import datetime
        entry = json.dumps({
            "timestamp": datetime.now().isoformat(),
            "source": "warp_mcp",
            "event": event,
            **details,
        })
        with open(TELEMETRY_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(entry + "\n")
    except Exception:
        pass


def register_warp_mcp_tools(nexus: Any) -> None:
    """Register Warp-specific MCP tools in the Nexus framework."""

    def _warp_discover(args: Dict) -> Dict:
        """Trigger on-demand Warp model discovery (no background polling)."""
        result = _warp_harness_request("/backends/refresh", method="POST")
        _log_warp_telemetry("warp_discover", {
            "alive": result.get("alive", False),
            "model_count": result.get("model_count", 0),
        })
        return result

    def _warp_status(args: Dict) -> Dict:
        """Query Warp provider status and model inventory."""
        return _warp_harness_request("/backends/status")

    def _warp_inference(args: Dict) -> Dict:
        """Route a generation request to Warp infrastructure."""
        model = args.get("model", "")
        prompt = args.get("prompt", "")
        stream = args.get("stream", False)
        payload = json.dumps({
            "model": model,
            "prompt": prompt,
            "stream": stream,
        }).encode()
        result = _warp_harness_request("/api/generate", method="POST", data=payload, timeout=120)
        _log_warp_telemetry("warp_inference", {
            "model": model,
            "stream": stream,
        })
        return result

    def _warp_overflow_check(args: Dict) -> Dict:
        """Check if Warp overflow should be triggered based on current RAM pressure."""
        ram_pct = args.get("ram_pct", 0)
        threshold = 65.0
        warp_status = _warp_harness_request("/health", timeout=5)
        warp_alive = warp_status.get("warp_alive", False)
        should_overflow = ram_pct >= threshold and warp_alive
        _log_warp_telemetry("warp_overflow_check", {
            "ram_pct": ram_pct,
            "threshold": threshold,
            "warp_alive": warp_alive,
            "should_overflow": should_overflow,
        })
        return {
            "ok": True,
            "ram_pct": ram_pct,
            "threshold": threshold,
            "warp_available": warp_alive,
            "should_overflow": should_overflow,
            "recommendation": "overflow_to_warp" if should_overflow else "stay_local",
        }

    register_tool(
        "warp_discover",
        "Trigger on-demand Warp model discovery (no background polling)",
        {},
        _warp_discover,
        "read",
    )

    register_tool(
        "warp_status",
        "Query Warp provider availability and model inventory",
        {},
        _warp_status,
        "read",
    )

    register_tool(
        "warp_inference",
        "Route a generation request to Warp infrastructure for accelerated inference",
        {
            "model": {"type": "string", "required": True},
            "prompt": {"type": "string", "required": True},
            "stream": {"type": "boolean", "default": False},
        },
        _warp_inference,
        "execute",
    )

    register_tool(
        "warp_overflow_check",
        "Check if Warp overflow should be triggered based on RAM pressure threshold (65%)",
        {
            "ram_pct": {"type": "number", "required": True},
        },
        _warp_overflow_check,
        "read",
    )
