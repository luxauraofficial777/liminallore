"""In-process tool functions for agent identity MCP tools.

These are called directly by the MCP dispatcher (in_process executor type).
"""

from __future__ import annotations

from typing import Any, Dict


def generate_self_model(agent_id: str, **kwargs) -> Dict[str, Any]:
    """Generate a self-model prompt for an agent by querying the Nexus."""
    try:
        from vw_nexus.agent_identity import AgentClient, AgentIdentity

        # Fetch the agent's identity from the Nexus
        import json
        import urllib.request

        NEXUS_URL = "http://127.0.0.1:8651"

        try:
            req = urllib.request.Request(
                f"{NEXUS_URL}/agents/{agent_id}", method="GET"
            )
            resp = urllib.request.urlopen(req, timeout=10)
            agent_data = json.loads(resp.read().decode("utf-8"))
        except Exception as e:
            return {"status": "error", "message": f"Agent not found or Nexus offline: {e}"}

        identity = AgentIdentity(
            agent_id=agent_data.get("agent_id", agent_id),
            name=agent_data.get("name", "Unknown"),
            provider=agent_data.get("provider", "unknown"),
            model=agent_data.get("model", "unknown"),
            capabilities=agent_data.get("capabilities", []),
            session_id=agent_data.get("session_id", "default"),
        )

        client = AgentClient(identity, nexus_url=NEXUS_URL)
        prompt = client.get_self_model()

        return {
            "status": "ok",
            "agent_id": agent_id,
            "prompt": prompt,
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}
