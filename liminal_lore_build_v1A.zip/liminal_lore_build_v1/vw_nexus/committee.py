"""Committee modes for multi-agent orchestration.

Modes: solo, chair, deliberate, contest, assembly_line, lazy_sync
Each mode controls how agents collaborate on tasks.
"""

from __future__ import annotations

import threading
from typing import Any, Dict, List, Optional


class CommitteeMode:
    SOLO = "solo"
    CHAIR = "chair"
    DELIBERATE = "deliberate"
    CONTEST = "contest"
    ASSEMBLY_LINE = "assembly_line"
    LAZY_SYNC = "lazy_sync"

    ALL = [SOLO, CHAIR, DELIBERATE, CONTEST, ASSEMBLY_LINE, LAZY_SYNC]

    DESCRIPTIONS = {
        SOLO: "Only the cheapest capable agent runs. Potato-tier default.",
        CHAIR: "One lead agent coordinates; others act as reviewers/specialists.",
        DELIBERATE: "Agents must reach consensus confidence before action.",
        CONTEST: "Two agents argue opposing solutions; human picks winner.",
        ASSEMBLY_LINE: "Tasks flow sequentially through agents (design → code → review → test).",
        LAZY_SYNC: "Agents work independently, sync on conflicts only.",
    }


class CommitteeSession:
    """Manages a committee session with a specific mode."""

    def __init__(self, session_id: str, mode: str = CommitteeMode.LAZY_SYNC):
        self.session_id = session_id
        self.mode = mode
        self.chair_agent_id: Optional[str] = None
        self.participants: List[str] = []
        self.consensus_threshold: float = 0.7
        self.proposals: Dict[str, Dict[str, Any]] = {}
        self.votes: Dict[str, Dict[str, float]] = {}  # proposal_id -> {agent_id: confidence}
        self._lock = threading.RLock()

    def set_mode(self, mode: str) -> None:
        if mode in CommitteeMode.ALL:
            self.mode = mode

    def add_participant(self, agent_id: str) -> None:
        with self._lock:
            if agent_id not in self.participants:
                self.participants.append(agent_id)

    def remove_participant(self, agent_id: str) -> None:
        with self._lock:
            if agent_id in self.participants:
                self.participants.remove(agent_id)

    def set_chair(self, agent_id: str) -> None:
        self.chair_agent_id = agent_id
        self.add_participant(agent_id)

    def submit_proposal(self, proposal_id: str, agent_id: str,
                        content: Dict[str, Any]) -> None:
        with self._lock:
            self.proposals[proposal_id] = {
                "agent_id": agent_id,
                "content": content,
                "status": "pending",
            }
            self.votes[proposal_id] = {}

    def vote(self, proposal_id: str, agent_id: str, confidence: float) -> Dict[str, Any]:
        with self._lock:
            if proposal_id not in self.proposals:
                return {"ok": False, "error": "Proposal not found"}
            self.votes[proposal_id][agent_id] = confidence

            if self.mode == CommitteeMode.DELIBERATE:
                return self._check_consensus(proposal_id)
            elif self.mode == CommitteeMode.CONTEST:
                return self._check_contest(proposal_id)
            else:
                return {"ok": True, "status": "vote_recorded", "confidence": confidence}

    def _check_consensus(self, proposal_id: str) -> Dict[str, Any]:
        votes = self.votes.get(proposal_id, {})
        if len(votes) < len(self.participants):
            return {"ok": True, "status": "awaiting_votes",
                    "votes": len(votes), "needed": len(self.participants)}
        avg_confidence = sum(votes.values()) / len(votes) if votes else 0
        if avg_confidence >= self.consensus_threshold:
            self.proposals[proposal_id]["status"] = "accepted"
            return {"ok": True, "status": "accepted", "avg_confidence": avg_confidence}
        else:
            self.proposals[proposal_id]["status"] = "rejected"
            return {"ok": True, "status": "rejected", "avg_confidence": avg_confidence}

    def _check_contest(self, proposal_id: str) -> Dict[str, Any]:
        votes = self.votes.get(proposal_id, {})
        if len(votes) < 2:
            return {"ok": True, "status": "awaiting_contest_votes", "votes": len(votes)}
        sorted_votes = sorted(votes.items(), key=lambda x: x[1], reverse=True)
        winner = sorted_votes[0]
        self.proposals[proposal_id]["status"] = "contest_winner"
        return {"ok": True, "status": "contest_winner", "winner": winner[0],
                "confidence": winner[1]}

    def get_assembly_line_stage(self, task_type: str) -> Optional[str]:
        if self.mode != CommitteeMode.ASSEMBLY_LINE:
            return None
        stages = ["design", "code", "review", "test"]
        return stages.get(0) if task_type == "code_edit" else None

    def status(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "session_id": self.session_id,
                "mode": self.mode,
                "mode_description": CommitteeMode.DESCRIPTIONS.get(self.mode, ""),
                "chair": self.chair_agent_id,
                "participants": list(self.participants),
                "consensus_threshold": self.consensus_threshold,
                "pending_proposals": sum(1 for p in self.proposals.values()
                                        if p["status"] == "pending"),
                "total_proposals": len(self.proposals),
            }


class CommitteeManager:
    """Manages committee sessions across the Nexus."""

    def __init__(self):
        self._sessions: Dict[str, CommitteeSession] = {}
        self._lock = threading.RLock()
        self._default_mode = CommitteeMode.LAZY_SYNC

    def create_session(self, session_id: str, mode: str = None) -> CommitteeSession:
        with self._lock:
            if session_id in self._sessions:
                self._sessions[session_id].set_mode(mode or self._default_mode)
                return self._sessions[session_id]
            cs = CommitteeSession(session_id, mode or self._default_mode)
            self._sessions[session_id] = cs
            return cs

    def get_session(self, session_id: str) -> Optional[CommitteeSession]:
        with self._lock:
            return self._sessions.get(session_id)

    def set_default_mode(self, mode: str) -> None:
        if mode in CommitteeMode.ALL:
            self._default_mode = mode

    def list_sessions(self) -> List[Dict[str, Any]]:
        with self._lock:
            return [cs.status() for cs in self._sessions.values()]

    def set_session_mode(self, session_id: str, mode: str) -> Dict[str, Any]:
        cs = self.get_session(session_id)
        if not cs:
            cs = self.create_session(session_id, mode)
        else:
            cs.set_mode(mode)
        return cs.status()

    def status(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "default_mode": self._default_mode,
                "active_sessions": len(self._sessions),
                "available_modes": CommitteeMode.ALL,
                "mode_descriptions": CommitteeMode.DESCRIPTIONS,
            }
