"""
VW Nexus — Universal Orchestration Layer for the Void Walkers agentic toolchain.
"""

__version__ = "0.1.0"
