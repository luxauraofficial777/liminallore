"""Core data models for the VW Nexus."""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum, auto
from typing import Any, Dict, List, Optional
import uuid


class AgentState(Enum):
    IDLE = "idle"
    RESEARCHING = "researching"
    CODING = "coding"
    BUILDING = "building"
    WAITING = "waiting"
    ERROR = "error"
    OFFLINE = "offline"


class TaskStatus(Enum):
    PENDING = "pending"
    CLAIMED = "claimed"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class Agent:
    agent_id: str
    name: str
    provider: str
    model: str
    session_id: str
    capabilities: List[str] = field(default_factory=list)
    state: str = AgentState.IDLE.value
    current_task: Optional[str] = None
    current_task_title: Optional[str] = None
    heartbeat: str = field(default_factory=lambda: _now_iso())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Task:
    task_id: str = field(default_factory=lambda: _new_id("T"))
    title: str = ""
    description: str = ""
    agent_id: Optional[str] = None
    dependencies: List[str] = field(default_factory=list)
    status: str = TaskStatus.PENDING.value
    priority: int = 5
    created: str = field(default_factory=lambda: _now_iso())
    started: Optional[str] = None
    finished: Optional[str] = None
    artifacts: List[str] = field(default_factory=list)
    result: Optional[Dict[str, Any]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class WorkSession:
    session_id: str = field(default_factory=lambda: _new_id("S"))
    agents: List[str] = field(default_factory=list)
    goal: str = ""
    rag_query: Optional[str] = None
    context_version: str = ""
    active_file_locks: Dict[str, str] = field(default_factory=dict)
    created: str = field(default_factory=lambda: _now_iso())
    updated: str = field(default_factory=lambda: _now_iso())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class FileLock:
    lock_id: str = field(default_factory=lambda: _new_id("L"))
    agent_id: str = ""
    path: str = ""
    intent: str = ""
    ttl_seconds: int = 1800
    created: str = field(default_factory=lambda: _now_iso())
    expires: str = field(default_factory=lambda: _now_iso(1800))

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class NexusEvent:
    event_id: str = field(default_factory=lambda: _new_id("E"))
    event_type: str = ""
    agent_id: Optional[str] = None
    session_id: Optional[str] = None
    task_id: Optional[str] = None
    payload: Dict[str, Any] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: _now_iso())

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


def _now_iso(offset_seconds: int = 0) -> str:
    return datetime.now(timezone.utc).isoformat()
