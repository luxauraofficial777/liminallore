"""File lock manager for conflict-free agent editing."""

from __future__ import annotations

import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .models import FileLock, _now_iso


class LockManager:
    """Thread-safe file lock manager."""

    def __init__(self):
        self._locks: Dict[str, FileLock] = {}
        self._lock = threading.RLock()

    def request(self, agent_id: str, path: str, intent: str = "",
                ttl_seconds: int = 1800) -> Dict[str, Any]:
        with self._lock:
            self._prune_expired()
            normalized = self._normalize(path)

            existing = self._locks.get(normalized)
            if existing:
                if existing.agent_id == agent_id:
                    # Extend existing lock
                    existing.expires = self._expires(ttl_seconds)
                    return {"status": "granted", "lock": existing.to_dict()}
                return {
                    "status": "queued",
                    "held_by": existing.agent_id,
                    "intent": existing.intent,
                    "expires": existing.expires,
                }

            new_lock = FileLock(
                agent_id=agent_id,
                path=normalized,
                intent=intent,
                ttl_seconds=ttl_seconds,
                expires=self._expires(ttl_seconds),
            )
            self._locks[normalized] = new_lock
            return {"status": "granted", "lock": new_lock.to_dict()}

    def release(self, path: str, agent_id: str) -> bool:
        with self._lock:
            normalized = self._normalize(path)
            lock = self._locks.get(normalized)
            if not lock or lock.agent_id != agent_id:
                return False
            del self._locks[normalized]
            return True

    def release_by_agent(self, agent_id: str) -> List[str]:
        with self._lock:
            paths = [p for p, l in self._locks.items() if l.agent_id == agent_id]
            for p in paths:
                del self._locks[p]
            return paths

    def is_locked(self, path: str) -> Optional[FileLock]:
        with self._lock:
            self._prune_expired()
            normalized = self._normalize(path)
            return self._locks.get(normalized)

    def list(self, agent_id: Optional[str] = None) -> List[FileLock]:
        with self._lock:
            self._prune_expired()
            locks = list(self._locks.values())
            if agent_id:
                locks = [l for l in locks if l.agent_id == agent_id]
            return locks

    def force_unlock(self, path: str) -> bool:
        with self._lock:
            normalized = self._normalize(path)
            return self._locks.pop(normalized, None) is not None

    def _normalize(self, path: str) -> str:
        try:
            return str(Path(path).resolve()).lower()
        except Exception:
            return path.lower()

    def _expires(self, ttl_seconds: int) -> str:
        return (datetime.now(timezone.utc) + timedelta(seconds=ttl_seconds)).isoformat()

    def _prune_expired(self) -> None:
        now = datetime.now(timezone.utc)
        expired = []
        for path, lock in self._locks.items():
            try:
                expires = datetime.fromisoformat(lock.expires)
                if expires.tzinfo is None:
                    expires = expires.replace(tzinfo=timezone.utc)
                if expires < now:
                    expired.append(path)
            except Exception:
                expired.append(path)
        for path in expired:
            self._locks.pop(path, None)
