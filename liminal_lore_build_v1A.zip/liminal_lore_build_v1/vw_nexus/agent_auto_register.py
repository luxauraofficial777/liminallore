"""Agent auto-registration module for VW Nexus.

Provides:
- Agent manifest loading from JSON config
- Auto-registration of all known agents on Nexus startup
- Heartbeat keepalive for registered agents
- Capability-based agent discovery for task routing

Agent types supported:
- ide: IDE-integrated agents (Cascade, Windsurf, etc.)
- cloud: Cloud API agents (Claude, GPT, Gemini, etc.)
- local: Local model agents (Ollama, KoboldCpp, etc.)
- harness: Testing harness agents (CyberGrime, VW64 sim, etc.)
- human: Human operators / reviewers
"""

from __future__ import annotations

import json
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Callable

from .models import Agent, AgentState, _now_iso


_DEFAULT_AGENTS = [
    {
        "agent_id": "cascade",
        "name": "Cascade (Windsurf IDE)",
        "provider": "windsurf",
        "model": "cascade-1.0",
        "session_id": "default",
        "agent_type": "ide",
        "capabilities": ["coding", "debugging", "architecture", "rag_query", "file_edit", "build", "deploy"],
        "state": "idle",
        "metadata": {"ide": "windsurf", "platform": "windows"},
    },
    {
        "agent_id": "cybergrime_harness",
        "name": "CyberGrime PSX Test Harness",
        "provider": "local",
        "model": "cybergrime-agent-runner",
        "session_id": "dqlosttranslation",
        "agent_type": "harness",
        "capabilities": ["psx_emulation", "telemetry", "crash_detection", "regression_test", "bios_analysis"],
        "state": "idle",
        "metadata": {"project": "DQLOSTTRANSLATION", "emulator": "cybergrime"},
    },
    {
        "agent_id": "duckstation_supervisor",
        "name": "DuckStation Supervisor",
        "provider": "local",
        "model": "duckstation-bridge",
        "session_id": "dqlosttranslation",
        "agent_type": "harness",
        "capabilities": ["duckstation", "live_telemetry", "patch_injection", "memory_inspection", "breakpoints"],
        "state": "idle",
        "metadata": {"project": "DQLOSTTRANSLATION", "emulator": "duckstation"},
    },
    {
        "agent_id": "vw64_sim_harness",
        "name": "VW64 X64 Engine Test Harness",
        "provider": "local",
        "model": "vw64-sim",
        "session_id": "vw_x64",
        "agent_type": "harness",
        "capabilities": ["x64_emulation", "dx11_validation", "combat_test", "save_test", "determinism_check"],
        "state": "idle",
        "metadata": {"project": "Modern_X64", "engine": "vw64"},
    },
    {
        "agent_id": "closed_loop_controller",
        "name": "Closed-Loop Controller (Circle of Truth)",
        "provider": "local",
        "model": "closed-loop-controller",
        "session_id": "dqlosttranslation",
        "agent_type": "harness",
        "capabilities": ["build_verification", "telemetry_analysis", "memory_injection", "golden_state", "patch_validation"],
        "state": "idle",
        "metadata": {"project": "DQLOSTTRANSLATION"},
    },
    {
        "agent_id": "pipeline_auditor",
        "name": "Pipeline Auditor",
        "provider": "local",
        "model": "pipeline-audit",
        "session_id": "dqlosttranslation",
        "agent_type": "harness",
        "capabilities": ["asset_audit", "lba_verification", "huffman_check", "symbol_resolution", "exe_patch_verify"],
        "state": "idle",
        "metadata": {"project": "DQLOSTTRANSLATION"},
    },
    {
        "agent_id": "regression_runner",
        "name": "Regression Runner",
        "provider": "local",
        "model": "regression-runner",
        "session_id": "dqlosttranslation",
        "agent_type": "harness",
        "capabilities": ["batch_test", "telemetry_eval", "sqlite_results", "smoke_test", "unit_test"],
        "state": "idle",
        "metadata": {"project": "DQLOSTTRANSLATION"},
    },
    {
        "agent_id": "build_orchestrator",
        "name": "Build Orchestrator (Circle of Truth)",
        "provider": "local",
        "model": "build-orchestrator",
        "session_id": "dqlosttranslation",
        "agent_type": "harness",
        "capabilities": ["build_synthesis", "constraint_enforcement", "patch_threshold", "build_readiness", "root_cause"],
        "state": "idle",
        "metadata": {"project": "DQLOSTTRANSLATION"},
    },
    {
        "agent_id": "ollama_local",
        "name": "Ollama Local LLM",
        "provider": "ollama",
        "model": "llama3",
        "session_id": "default",
        "agent_type": "local",
        "capabilities": ["coding", "analysis", "rag_query", "summarization"],
        "state": "idle",
        "metadata": {"endpoint": "http://localhost:11434"},
    },
    {
        "agent_id": "koboldcpp_local",
        "name": "KoboldCpp Local LLM",
        "provider": "koboldcpp",
        "model": "koboldcpp",
        "session_id": "default",
        "agent_type": "local",
        "capabilities": ["coding", "analysis", "rag_query", "creative_writing"],
        "state": "idle",
        "metadata": {"endpoint": "http://localhost:5001"},
    },
]


class AgentAutoRegistrar:
    """Manages auto-registration and heartbeats for all known agents."""

    def __init__(self, agent_registry: Any, config_path: Optional[Path] = None,
                 heartbeat_interval: float = 30.0):
        self.registry = agent_registry
        self.heartbeat_interval = heartbeat_interval
        self._agents: Dict[str, Dict[str, Any]] = {}
        self._thread: Optional[threading.Thread] = None
        self._running = False
        self._lock = threading.RLock()
        self._config_path = config_path

        # Load agent configs
        configs = self._load_configs(config_path)
        for cfg in configs:
            self._agents[cfg["agent_id"]] = cfg

    def _load_configs(self, config_path: Optional[Path]) -> List[Dict[str, Any]]:
        if config_path and config_path.exists():
            try:
                data = json.loads(config_path.read_text(encoding="utf-8"))
                if isinstance(data, dict) and "agents" in data:
                    return data["agents"]
                if isinstance(data, list):
                    return data
            except Exception:
                pass
        return _DEFAULT_AGENTS

    def register_all(self) -> List[Dict[str, Any]]:
        """Register all known agents with the Nexus agent registry."""
        results = []
        with self._lock:
            for agent_id, cfg in self._agents.items():
                try:
                    agent = Agent(
                        agent_id=agent_id,
                        name=cfg.get("name", agent_id),
                        provider=cfg.get("provider", "unknown"),
                        model=cfg.get("model", "unknown"),
                        session_id=cfg.get("session_id", "default"),
                        capabilities=cfg.get("capabilities", []),
                        state=cfg.get("state", AgentState.IDLE.value),
                        metadata={
                            **cfg.get("metadata", {}),
                            "agent_type": cfg.get("agent_type", "unknown"),
                        },
                    )
                    self.registry.register(agent)
                    results.append({"agent_id": agent_id, "status": "registered", "agent_type": cfg.get("agent_type")})
                except Exception as e:
                    results.append({"agent_id": agent_id, "status": "error", "error": str(e)})
        return results

    def register_one(self, agent_id: str) -> Dict[str, Any]:
        """Register a single agent by ID."""
        with self._lock:
            cfg = self._agents.get(agent_id)
            if not cfg:
                return {"ok": False, "error": f"Unknown agent: {agent_id}"}
            try:
                agent = Agent(
                    agent_id=agent_id,
                    name=cfg.get("name", agent_id),
                    provider=cfg.get("provider", "unknown"),
                    model=cfg.get("model", "unknown"),
                    session_id=cfg.get("session_id", "default"),
                    capabilities=cfg.get("capabilities", []),
                    state=cfg.get("state", AgentState.IDLE.value),
                    metadata={**cfg.get("metadata", {}), "agent_type": cfg.get("agent_type", "unknown")},
                )
                self.registry.register(agent)
                return {"ok": True, "agent_id": agent_id}
            except Exception as e:
                return {"ok": False, "error": str(e)}

    def add_agent(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Add a new agent to the registry config and register it."""
        agent_id = config.get("agent_id", "")
        if not agent_id:
            return {"ok": False, "error": "Missing agent_id"}
        with self._lock:
            self._agents[agent_id] = config
        return self.register_one(agent_id)

    def remove_agent(self, agent_id: str) -> Dict[str, Any]:
        with self._lock:
            self._agents.pop(agent_id, None)
        self.registry.unregister(agent_id)
        return {"ok": True, "agent_id": agent_id}

    def start_heartbeats(self) -> None:
        """Start background heartbeat thread for all registered agents."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._heartbeat_loop, daemon=True, name="agent-heartbeat")
        self._thread.start()

    def stop_heartbeats(self) -> None:
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)
        self._thread = None

    def _heartbeat_loop(self) -> None:
        while self._running:
            with self._lock:
                agent_ids = list(self._agents.keys())
            for agent_id in agent_ids:
                try:
                    self.registry.heartbeat(agent_id)
                except Exception:
                    pass
            time.sleep(self.heartbeat_interval)

    def list_agents(self) -> List[Dict[str, Any]]:
        with self._lock:
            return [
                {
                    "agent_id": aid,
                    "name": cfg.get("name", aid),
                    "agent_type": cfg.get("agent_type", "unknown"),
                    "provider": cfg.get("provider", "unknown"),
                    "model": cfg.get("model", "unknown"),
                    "capabilities": cfg.get("capabilities", []),
                    "session_id": cfg.get("session_id", "default"),
                }
                for aid, cfg in self._agents.items()
            ]

    def find_by_capability(self, capability: str) -> List[Dict[str, Any]]:
        """Find agents that have a specific capability."""
        with self._lock:
            return [
                {"agent_id": aid, **{k: v for k, v in cfg.items() if k != "agent_id"}}
                for aid, cfg in self._agents.items()
                if capability in cfg.get("capabilities", [])
            ]

    def status(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "total_agents": len(self._agents),
                "heartbeats_running": self._running,
                "heartbeat_interval": self.heartbeat_interval,
                "agents": self.list_agents(),
            }
