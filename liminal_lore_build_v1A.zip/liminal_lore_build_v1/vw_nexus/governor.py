"""Cost & latency governor (Orion) for VW Nexus.

Monitors RAM/CPU pressure, model load latency, token cost, and user-defined
latency budgets. Can downgrade context, force bypass paths, or trigger
committee mode changes.
"""

from __future__ import annotations

import threading
import time
from collections import deque
from typing import Any, Callable, Dict, List, Optional


class Governor:
    """Orion governor: monitors resources and enforces budgets."""

    def __init__(self):
        self._lock = threading.RLock()
        self._metrics: deque = deque(maxlen=300)  # 5 min at 1Hz
        self._alerts: List[Dict[str, Any]] = []
        self._budgets: Dict[str, Any] = {
            "max_ram_pct": 65.0,
            "max_latency_ms": 30000,
            "max_token_cost_per_min": 1000,
            "min_cache_hit_rate": 0.3,
            "max_swap_events_per_min": 5,
        }
        self._actions: Dict[str, Callable] = {}
        self._downgrade_count = 0
        self._bypass_count = 0
        self._mode_switches = 0
        self._warp_overflow_count = 0
        self._warp_available = False
        self._warp_latency_ms = 0  # Estimated Warp round-trip latency

    def set_budget(self, key: str, value: Any) -> None:
        with self._lock:
            self._budgets[key] = value

    def get_budgets(self) -> Dict[str, Any]:
        with self._lock:
            return dict(self._budgets)

    def register_action(self, alert_type: str, callback: Callable) -> None:
        with self._lock:
            self._actions[alert_type] = callback

    def record_sample(self, ram_pct: float = 0, cpu_pct: float = 0,
                      latency_ms: float = 0, cache_hit_rate: float = 1.0,
                      swap_events: int = 0, token_cost: int = 0,
                      kv_bits: int = 0, model_load_ms: float = 0) -> Dict[str, Any]:
        sample = {
            "timestamp": time.time(),
            "ram_pct": ram_pct,
            "cpu_pct": cpu_pct,
            "latency_ms": latency_ms,
            "cache_hit_rate": cache_hit_rate,
            "swap_events": swap_events,
            "token_cost": token_cost,
            "kv_bits": kv_bits,
            "model_load_ms": model_load_ms,
        }
        with self._lock:
            self._metrics.append(sample)
        return self._evaluate(sample)

    def _evaluate(self, sample: Dict[str, Any]) -> Dict[str, Any]:
        alerts = []
        actions_taken = []

        if sample["ram_pct"] >= self._budgets["max_ram_pct"]:
            alerts.append({
                "type": "ram_pressure",
                "severity": "critical",
                "value": sample["ram_pct"],
                "threshold": self._budgets["max_ram_pct"],
            })
            action = self._actions.get("ram_pressure")
            if action:
                action(sample)
                actions_taken.append("ram_pressure_handler")
                self._downgrade_count += 1

            # Warp overflow: when RAM pressure exceeds 65% threshold and Warp is available,
            # trigger automated overflow of intensive tasks to Warp infrastructure
            if self._warp_available:
                alerts.append({
                    "type": "warp_overflow_triggered",
                    "severity": "critical",
                    "value": sample["ram_pct"],
                    "threshold": self._budgets["max_ram_pct"],
                    "warp_latency_ms": self._warp_latency_ms,
                })
                warp_action = self._actions.get("warp_overflow")
                if warp_action:
                    warp_action(sample)
                    actions_taken.append("warp_overflow_handler")
                    self._warp_overflow_count += 1

        if sample["latency_ms"] > self._budgets["max_latency_ms"]:
            alerts.append({
                "type": "latency_budget_exceeded",
                "severity": "warning",
                "value": sample["latency_ms"],
                "threshold": self._budgets["max_latency_ms"],
            })

        if sample["cache_hit_rate"] < self._budgets["min_cache_hit_rate"]:
            alerts.append({
                "type": "low_cache_hit_rate",
                "severity": "warning",
                "value": sample["cache_hit_rate"],
                "threshold": self._budgets["min_cache_hit_rate"],
            })

        swap_rate = self._swap_rate()
        if swap_rate > self._budgets["max_swap_events_per_min"]:
            alerts.append({
                "type": "colibri_thrashing",
                "severity": "critical",
                "value": swap_rate,
                "threshold": self._budgets["max_swap_events_per_min"],
            })
            action = self._actions.get("colibri_thrashing")
            if action:
                action(sample)
                actions_taken.append("thrashing_handler")
                self._mode_switches += 1

        result = {"alerts": alerts, "actions_taken": actions_taken}
        if alerts:
            with self._lock:
                for a in alerts:
                    a["timestamp"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
                    self._alerts.append(a)
                if len(self._alerts) > 500:
                    self._alerts = self._alerts[-200:]
        return result

    def _swap_rate(self) -> float:
        cutoff = time.time() - 60
        with self._lock:
            recent = [m for m in self._metrics if m["timestamp"] >= cutoff]
        if not recent:
            return 0.0
        return sum(m["swap_events"] for m in recent)

    def get_metrics(self, seconds: int = 60) -> List[Dict[str, Any]]:
        cutoff = time.time() - seconds
        with self._lock:
            return [m for m in self._metrics if m["timestamp"] >= cutoff]

    def get_alerts(self, limit: int = 50) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self._alerts[-limit:])

    def acknowledge_alert(self, index: int) -> bool:
        with self._lock:
            if 0 <= index < len(self._alerts):
                self._alerts[index]["acknowledged"] = True
                return True
            return False

    def set_warp_status(self, available: bool, latency_ms: float = 0) -> None:
        """Update Warp provider availability and latency for overflow decisions."""
        with self._lock:
            self._warp_available = available
            self._warp_latency_ms = latency_ms

    def status(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "budgets": dict(self._budgets),
                "samples_collected": len(self._metrics),
                "active_alerts": sum(1 for a in self._alerts if not a.get("acknowledged")),
                "total_alerts": len(self._alerts),
                "downgrade_count": self._downgrade_count,
                "bypass_count": self._bypass_count,
                "mode_switches": self._mode_switches,
                "warp_available": self._warp_available,
                "warp_latency_ms": self._warp_latency_ms,
                "warp_overflow_count": self._warp_overflow_count,
            }

    def recommend_kv_bits(self, ram_pct: float) -> int:
        if ram_pct >= 65:
            return 2
        elif ram_pct >= 50:
            return 4
        elif ram_pct >= 35:
            return 6
        return 8

    def recommend_committee_mode(self, ram_pct: float, active_agents: int) -> str:
        if ram_pct >= 65 or active_agents <= 1:
            return "solo"
        elif ram_pct >= 50:
            return "chair"
        return "lazy_sync"

    # ── Telemetry-Driven Load Balancing ───────────────────────────────

    def recommend_provider(self, ram_pct: float, task_type: str = "core",
                           warp_available: bool = None) -> Dict[str, Any]:
        """Recommend which provider should handle a task based on current RAM pressure.

        Task types:
          - 'core': Critical logic, emulator, build — stays local
          - 'polishing': Text refinement, formatting, docs — offload to Warp
          - 'research': RAG queries, analysis — stays local if RAM allows
          - 'heavy': Large generation, multi-turn — offload to Warp

        Returns dict with provider_id, reason, and routing metadata.
        """
        with self._lock:
            warp_ok = self._warp_available if warp_available is None else warp_available
            threshold = self._budgets["max_ram_pct"]

        if ram_pct >= threshold:
            if task_type in ("polishing", "heavy") and warp_ok:
                return {
                    "provider_id": "warp",
                    "reason": f"RAM at {ram_pct:.0f}% >= {threshold:.0f}% threshold — offloading {task_type} to Warp",
                    "ram_pct": ram_pct,
                    "task_type": task_type,
                    "warp_latency_ms": self._warp_latency_ms,
                }
            elif task_type == "core":
                return {
                    "provider_id": "local",
                    "reason": f"RAM at {ram_pct:.0f}% but core logic stays local — will auto-kill non-essential agents",
                    "ram_pct": ram_pct,
                    "task_type": task_type,
                    "action": "kill_non_essential",
                }
            else:
                if warp_ok:
                    return {
                        "provider_id": "warp",
                        "reason": f"RAM at {ram_pct:.0f}% — offloading to Warp to reduce pressure",
                        "ram_pct": ram_pct,
                        "task_type": task_type,
                        "warp_latency_ms": self._warp_latency_ms,
                    }
                return {
                    "provider_id": "local",
                    "reason": f"RAM at {ram_pct:.0f}% but Warp unavailable — staying local",
                    "ram_pct": ram_pct,
                    "task_type": task_type,
                    "action": "downgrade_context",
                }
        elif ram_pct >= threshold * 0.8:  # 80% of threshold = 52%
            if task_type == "heavy" and warp_ok:
                return {
                    "provider_id": "warp",
                    "reason": f"RAM at {ram_pct:.0f}% approaching threshold — proactively offloading heavy task",
                    "ram_pct": ram_pct,
                    "task_type": task_type,
                    "warp_latency_ms": self._warp_latency_ms,
                }
        return {
            "provider_id": "local",
            "reason": f"RAM at {ram_pct:.0f}% — within budget, local execution",
            "ram_pct": ram_pct,
            "task_type": task_type,
        }

    def get_kill_list(self, ram_pct: float, agents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Determine which non-essential agents should be killed under RAM pressure.

        Agent dicts should have: agent_id, state, provider, session_id, current_task
        Priority for killing:
          1. Idle/waiting agents on cloud providers (Devin, Warp) — safe to kill
          2. Idle/waiting agents on local providers — reclaim RAM
          3. Researching agents on cloud providers
          4. Never kill agents actively coding/building (core logic)

        Only triggers when ram_pct >= max_ram_pct threshold.
        """
        threshold = self._budgets["max_ram_pct"]
        if ram_pct < threshold:
            return []

        kill_priority = {"idle": 0, "waiting": 1, "error": 2, "researching": 3, "coding": 4, "building": 5}
        cloud_providers = {"devin", "warp", "hermes", "gemini_cli", "cursor", "openrouter", "custom"}

        candidates = []
        for agent in agents:
            state = agent.get("state", "idle")
            provider = agent.get("provider", "")
            agent_id = agent.get("agent_id", "")

            # Never kill agents actively building or coding
            if state in ("coding", "building"):
                continue

            priority = kill_priority.get(state, 3)
            # Cloud idle agents are highest priority to kill (no local RAM cost, just API)
            if provider in cloud_providers and state in ("idle", "waiting"):
                priority = -1  # Highest kill priority

            candidates.append({
                "agent_id": agent_id,
                "state": state,
                "provider": provider,
                "session_id": agent.get("session_id", ""),
                "current_task": agent.get("current_task", ""),
                "kill_priority": priority,
            })

        # Sort by kill priority (lowest = kill first)
        candidates.sort(key=lambda x: x["kill_priority"])

        # Kill enough agents to get under threshold — assume each agent uses ~5-10% RAM
        # Be conservative: kill at most half the candidates
        max_kills = max(1, len(candidates) // 2)
        return candidates[:max_kills]

    def get_load_balancer_status(self) -> Dict[str, Any]:
        """Return current load balancer state for dashboard display."""
        with self._lock:
            recent_metrics = list(self._metrics)[-10:] if self._metrics else []
            avg_ram = sum(m["ram_pct"] for m in recent_metrics) / len(recent_metrics) if recent_metrics else 0
            avg_latency = sum(m["latency_ms"] for m in recent_metrics) / len(recent_metrics) if recent_metrics else 0

        return {
            "current_ram_pct": round(avg_ram, 1),
            "current_latency_ms": round(avg_latency, 1),
            "warp_available": self._warp_available,
            "warp_latency_ms": self._warp_latency_ms,
            "ram_threshold": self._budgets["max_ram_pct"],
            "warp_overflow_count": self._warp_overflow_count,
            "recommendation": self.recommend_provider(avg_ram, "core"),
            "samples_collected": len(self._metrics),
        }
