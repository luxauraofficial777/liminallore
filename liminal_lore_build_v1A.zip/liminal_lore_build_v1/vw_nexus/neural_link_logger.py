"""Neural Link audit logger for inter-agent traffic.

Writes a JSONL audit trail to the study/logs directory so the Neural Link
portal can display agent communication transparently.

Optionally forwards events to the Hermes bridge if a forwarding URL is set.
"""

from __future__ import annotations

import json
import threading
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional

from .models import _now_iso


class NeuralLinkLogger:
    """JSONL audit logger for the Neural Link portal."""

    def __init__(self, project_root: Path, forward_url: Optional[str] = None):
        self.project_root = project_root
        self.log_dir = project_root / "study" / "logs"
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.log_path = self.log_dir / "neural_link_audit.jsonl"
        self.forward_url = forward_url
        self._lock = threading.Lock()

    def log(self, event_type: str, payload: Dict[str, Any]) -> None:
        entry = {
            "timestamp": _now_iso(),
            "event_type": event_type,
            "payload": payload,
        }
        with self._lock:
            try:
                with open(self.log_path, "a", encoding="utf-8") as f:
                    f.write(json.dumps(entry, default=str) + "\n")
            except Exception as e:
                print(f"NeuralLinkLogger failed: {e}", file=__import__("sys").stderr)

        if self.forward_url:
            self._forward(entry)

    def _forward(self, entry: Dict[str, Any]) -> None:
        try:
            data = json.dumps(entry).encode("utf-8")
            req = urllib.request.Request(
                self.forward_url,
                data=data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            urllib.request.urlopen(req, timeout=2)
        except Exception:
            pass

    def get_recent(self, limit: int = 100) -> list[Dict[str, Any]]:
        entries = []
        try:
            with open(self.log_path, "r", encoding="utf-8") as f:
                for line in f:
                    if line.strip():
                        entries.append(json.loads(line))
        except Exception:
            pass
        return entries[-limit:]
