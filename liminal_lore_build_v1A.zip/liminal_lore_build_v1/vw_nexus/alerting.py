"""Alerting rules engine for VW Nexus.

User-configurable rules that trigger actions based on conditions.
"""

from __future__ import annotations

import re
import threading
import time
from collections import deque
from typing import Any, Callable, Dict, List, Optional


class AlertRule:
    """A single alerting rule."""

    def __init__(self, name: str, condition: str, action: str,
                 severity: str = "warning", cooldown_seconds: int = 120):
        self.name = name
        self.condition = condition
        self.action = action
        self.severity = severity
        self.cooldown_seconds = cooldown_seconds
        self.last_triggered: float = 0
        self.trigger_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "condition": self.condition,
            "action": self.action,
            "severity": self.severity,
            "cooldown_seconds": self.cooldown_seconds,
            "trigger_count": self.trigger_count,
            "last_triggered": self.last_triggered,
        }


class AlertingEngine:
    """Evaluates alerting rules against incoming metrics."""

    def __init__(self):
        self._lock = threading.RLock()
        self._rules: Dict[str, AlertRule] = {}
        self._history: deque = deque(maxlen=500)
        self._action_handlers: Dict[str, Callable] = {}

    def add_rule(self, name: str, condition: str, action: str,
                 severity: str = "warning", cooldown: int = 120) -> None:
        with self._lock:
            self._rules[name] = AlertRule(name, condition, action, severity, cooldown)

    def remove_rule(self, name: str) -> bool:
        with self._lock:
            return self._rules.pop(name, None) is not None

    def register_action(self, action_name: str, handler: Callable) -> None:
        with self._lock:
            self._action_handlers[action_name] = handler

    def evaluate(self, metrics: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Evaluate all rules against a metrics snapshot."""
        triggered = []
        now = time.time()
        with self._lock:
            rules = list(self._rules.values())

        for rule in rules:
            if now - rule.last_triggered < rule.cooldown_seconds:
                continue
            if self._eval_condition(rule.condition, metrics):
                alert = {
                    "rule": rule.name,
                    "severity": rule.severity,
                    "action": rule.action,
                    "metrics": metrics,
                    "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                }
                triggered.append(alert)
                rule.last_triggered = now
                rule.trigger_count += 1
                with self._lock:
                    self._history.append(alert)
                handler = self._action_handlers.get(rule.action)
                if handler:
                    try:
                        handler(metrics, alert)
                    except Exception:
                        pass
        return triggered

    def _eval_condition(self, condition: str, metrics: Dict[str, Any]) -> bool:
        try:
            safe_vars = {k: v for k, v in metrics.items()
                        if isinstance(v, (int, float, str, bool))}
            return bool(eval(condition, {"__builtins__": {}}, safe_vars))
        except Exception:
            return False

    def list_rules(self) -> List[Dict[str, Any]]:
        with self._lock:
            return [r.to_dict() for r in self._rules.values()]

    def history(self, limit: int = 50) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self._history)[-limit:]

    def status(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "rules_configured": len(self._rules),
                "total_triggers": sum(r.trigger_count for r in self._rules.values()),
                "history_size": len(self._history),
            }

    def load_defaults(self) -> None:
        """Load default alerting rules."""
        self.add_rule(
            "colibri-thrashing",
            "swap_events > 5",
            "notify_and_solo",
            "critical",
            cooldown=120,
        )
        self.add_rule(
            "ram-spike",
            "ram_pct > 65",
            "amber_alert",
            "warning",
            cooldown=60,
        )
        self.add_rule(
            "ram-critical",
            "ram_pct > 80",
            "red_alert_pause",
            "critical",
            cooldown=30,
        )
        self.add_rule(
            "task-failure",
            "failed_tasks > 0",
            "red_alert_pause",
            "critical",
            cooldown=60,
        )
        self.add_rule(
            "low-cache-hit",
            "cache_hit_rate < 0.3",
            "notify",
            "warning",
            cooldown=120,
        )
        self.add_rule(
            "high-latency",
            "latency_ms > 30000",
            "notify",
            "warning",
            cooldown=60,
        )
