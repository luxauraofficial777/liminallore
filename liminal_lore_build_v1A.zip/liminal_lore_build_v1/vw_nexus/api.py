"""HTTP API server for the VW Nexus."""

from __future__ import annotations

import json
import threading
import time
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional
from urllib.parse import urlparse, parse_qs
import os

from .agent_registry import AgentRegistry
from .event_bus import EventBus
from .lock_manager import LockManager
from .master_clock import ConflictEntry, MasterClock
from .models import Agent, _now_iso
from .neural_link_logger import NeuralLinkLogger
from .session_registry import SessionRegistry
from .task_queue import TaskQueue
from .websocket_server import NexusWebSocketBus
from .state_store import StateStore
from .mcp_server import McpServer, register_default_tools, list_tools as mcp_list_tools, call_tool as mcp_call_tool
from .committee import CommitteeManager, CommitteeMode
from .governor import Governor
from .alerting import AlertingEngine
from .metrics_db import MetricsDB
from .internal_mcp_client import InternalMcpClient, register_internal_tools
from .warp_mcp_tools import register_warp_mcp_tools
from .provider_nexus import load_registry_from_config_file, register_provider_mcp_tools
from .session_persistence import SessionManager
from .telemetry_export import TelemetryExporter
from .remote_bridge import RemoteWorkerBridge
from .yaml_tool_loader import load_yaml_tools

# RAG imports — graceful fallback if vw_rag is not yet indexed
try:
    from vw_rag.embedder import Embedder as RagEmbedder
    from vw_rag.indexer import Indexer as RagIndexer
    from vw_rag.retriever import Retriever as RagRetriever
    from vw_rag.multi_corpus import MultiCorpusManager
    _RAG_AVAILABLE = True
except ImportError:
    _RAG_AVAILABLE = False
    MultiCorpusManager = None

# Multi-corpus + telemetry + agent registration + reasoning map
try:
    from .telemetry_ingest import TelemetryIngestor
    from .agent_auto_register import AgentAutoRegistrar
    from .reasoning_map import ReasoningMap
    _NEXUS_EXTENSIONS_AVAILABLE = True
except ImportError:
    _NEXUS_EXTENSIONS_AVAILABLE = False
    TelemetryIngestor = None
    AgentAutoRegistrar = None
    ReasoningMap = None


class NexusHandler(BaseHTTPRequestHandler):
    """Request handler for the Nexus REST API."""

    def log_message(self, fmt: str, *args) -> None:
        pass  # Reduce noise; the Nexus logs important actions separately

    def _cors(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, DELETE")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")

    def _json(self, code: int, data: Any) -> None:
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self._cors()
        self.end_headers()
        self.wfile.write(json.dumps(data, indent=2, default=str).encode())

    MAX_BODY_SIZE = 10 * 1024 * 1024  # 10 MB cap

    def _read_body(self) -> Dict[str, Any]:
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        if length > self.MAX_BODY_SIZE:
            self._json(413, {"ok": False, "error": f"Body too large: {length} bytes (max {self.MAX_BODY_SIZE})"})
            return {"_error": "body_too_large"}
        try:
            return json.loads(self.rfile.read(length).decode())
        except Exception:
            return {}

    def do_OPTIONS(self) -> None:
        self.send_response(200)
        self._cors()
        self.end_headers()

    def _check_auth(self) -> bool:
        nexus_api_key = os.environ.get("NEXUS_API_KEY", "")
        if not nexus_api_key:
            return True  # No key configured — open access (localhost-only)
        provided = self.headers.get("X-Nexus-Key", "")
        return provided == nexus_api_key

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)

        if not self._check_auth():
            self._json(401, {"ok": False, "error": "Unauthorized: invalid or missing X-Nexus-Key header"})
            return

        if path == "/health":
            self._json(200, {
                "ok": True,
                "nexus": "running",
                "http_port": self.server.nexus.port,
                "ws_port": self.server.nexus.ws_port,
                "time": _now_iso(),
            })
            return

        if path == "/agents":
            include_offline = query.get("include_offline", ["false"])[0].lower() == "true"
            agents = self.server.nexus.agents.list(include_offline=include_offline)
            self._json(200, {"agents": [a.to_dict() for a in agents]})
            return

        if path.startswith("/agents/"):
            agent_id = path[len("/agents/"):]
            agent = self.server.nexus.agents.get(agent_id)
            if not agent:
                self._json(404, {"ok": False, "error": "Agent not found"})
                return
            self._json(200, agent.to_dict())
            return

        if path == "/tasks":
            status = query.get("status", [None])[0]
            tasks = self.server.nexus.tasks.list(status=status)
            self._json(200, {"tasks": [t.to_dict() for t in tasks]})
            return

        if path.startswith("/tasks/"):
            task_id = path[len("/tasks/"):]
            task = self.server.nexus.tasks.get(task_id)
            if not task:
                self._json(404, {"ok": False, "error": "Task not found"})
                return
            self._json(200, task.to_dict())
            return

        if path == "/tasks/ready":
            tasks = self.server.nexus.tasks.get_ready_tasks()
            self._json(200, {"tasks": [t.to_dict() for t in tasks]})
            return

        if path == "/sessions":
            sessions = self.server.nexus.sessions.list()
            self._json(200, {"sessions": [s.to_dict() for s in sessions]})
            return

        if path.startswith("/sessions/"):
            session_id = path[len("/sessions/"):]
            session = self.server.nexus.sessions.get(session_id)
            if not session:
                self._json(404, {"ok": False, "error": "Session not found"})
                return
            self._json(200, session.to_dict())
            return

        if path == "/locks":
            agent_id = query.get("agent_id", [None])[0]
            locks = self.server.nexus.locks.list(agent_id=agent_id)
            self._json(200, {"locks": [l.to_dict() for l in locks]})
            return

        if path == "/events":
            event_type = query.get("type", [None])[0]
            since = query.get("since", [None])[0]
            limit = int(query.get("limit", ["100"])[0])
            events = self.server.nexus.events.history(event_type=event_type, since=since, limit=limit)
            self._json(200, {"events": [e.to_dict() for e in events]})
            return

        if path == "/bus":
            self._json(200, self.server.nexus.bus.get_stats())
            return

        if path == "/bus/agents":
            self._json(200, {"agents": self.server.nexus.bus.get_connected_agents()})
            return

        if path == "/clock":
            self._json(200, self.server.nexus.clock.status())
            return

        if path == "/clock/authority":
            resource = query.get("resource", [None])[0]
            if resource:
                auth = self.server.nexus.clock.get_authority(resource)
                self._json(200, {"authority": auth.to_dict() if auth else None})
            else:
                history = self.server.nexus.clock.get_history(limit=50)
                self._json(200, {"history": [h.to_dict() for h in history]})
            return

        if path == "/audit":
            limit = int(query.get("limit", ["100"])[0])
            self._json(200, {"audit": self.server.nexus.logger.get_recent(limit=limit)})
            return

        if path == "/status":
            self._json(200, self.server.nexus.status())
            return

        if path == "/rag/status":
            self._json(200, self.server.nexus.rag_status())
            return

        if path == "/rag/graph/status":
            if self.server.nexus._rag_graph:
                self._json(200, self.server.nexus._rag_graph.status())
            else:
                self._json(200, {"edges": 0, "initialized": False})
            return

        if path == "/rag/agent-slice":
            agent_id = query.get("agent_id", [""])[0]
            if not agent_id:
                self._json(400, {"ok": False, "error": "Missing agent_id"})
                return
            if self.server.nexus._rag_graph:
                self._json(200, {"slice": self.server.nexus._rag_graph.get_agent_slice(agent_id)})
            else:
                self._json(200, {"slice": []})
            return

        # ── MCP endpoints ────────────────────────────────────────
        if path == "/mcp/tools":
            self._json(200, {"tools": mcp_list_tools()})
            return

        if path == "/mcp/status":
            self._json(200, self.server.nexus.mcp.status())
            return

        if path == "/mcp/pending":
            self._json(200, {"pending": self.server.nexus.mcp.pending_calls()})
            return

        if path == "/mcp/log":
            limit = int(query.get("limit", ["100"])[0])
            self._json(200, {"log": self.server.nexus.mcp.call_log(limit=limit)})
            return

        if path == "/mcp/yaml-tools":
            self._json(200, {"results": getattr(self.server.nexus, "_yaml_tool_results", [])})
            return

        # ── Committee endpoints ──────────────────────────────────
        if path == "/committee/status":
            self._json(200, self.server.nexus.committee.status())
            return

        if path == "/committee/sessions":
            self._json(200, {"sessions": self.server.nexus.committee.list_sessions()})
            return

        if path.startswith("/committee/sessions/"):
            session_id = path[len("/committee/sessions/"):]
            cs = self.server.nexus.committee.get_session(session_id)
            if not cs:
                self._json(404, {"ok": False, "error": "Committee session not found"})
                return
            self._json(200, cs.status())
            return

        # ── Governor (Orion) endpoints ───────────────────────────
        if path == "/governor/status":
            self._json(200, self.server.nexus.governor.status())
            return

        if path == "/governor/budgets":
            self._json(200, self.server.nexus.governor.get_budgets())
            return

        if path == "/governor/metrics":
            seconds = int(query.get("seconds", ["60"])[0])
            self._json(200, {"metrics": self.server.nexus.governor.get_metrics(seconds=seconds)})
            return

        if path == "/governor/alerts":
            limit = int(query.get("limit", ["50"])[0])
            self._json(200, {"alerts": self.server.nexus.governor.get_alerts(limit=limit)})
            return

        # ── Alerting endpoints ───────────────────────────────────
        if path == "/alerts/rules":
            self._json(200, {"rules": self.server.nexus.alerting.list_rules()})
            return

        if path == "/alerts/history":
            limit = int(query.get("limit", ["50"])[0])
            self._json(200, {"history": self.server.nexus.alerting.history(limit=limit)})
            return

        if path == "/alerts/status":
            self._json(200, self.server.nexus.alerting.status())
            return

        # ── Metrics endpoints ────────────────────────────────────
        if path == "/metrics/status":
            self._json(200, self.server.nexus.metrics.status())
            return

        if path == "/metrics/query":
            metric_name = query.get("name", ["ram_pct"])[0]
            seconds = int(query.get("seconds", ["300"])[0])
            self._json(200, {"data": self.server.nexus.metrics.query(metric_name, seconds=seconds)})
            return

        if path == "/metrics/all":
            seconds = int(query.get("seconds", ["300"])[0])
            self._json(200, self.server.nexus.metrics.query_all(seconds=seconds))
            return

        if path == "/metrics/snapshots":
            seconds = int(query.get("seconds", ["300"])[0])
            self._json(200, {"snapshots": self.server.nexus.metrics.get_snapshots(seconds=seconds)})
            return

        # ── State store endpoints ────────────────────────────────
        if path == "/state/snapshot":
            self._json(200, self.server.nexus.state.snapshot())
            return

        # ── Telemetry endpoints ──────────────────────────────────
        if path == "/telemetry/status":
            self._json(200, self.server.nexus.telemetry.status())
            return

        if path == "/telemetry/spans":
            limit = int(query.get("limit", ["100"])[0])
            name_filter = query.get("name", [None])[0]
            agent_filter = query.get("agent", [None])[0]
            self._json(200, {"spans": self.server.nexus.telemetry.list_spans(limit=limit, name_filter=name_filter, agent_filter=agent_filter)})
            return

        if path == "/telemetry/traces":
            limit = int(query.get("limit", ["50"])[0])
            self._json(200, {"traces": self.server.nexus.telemetry.list_traces(limit=limit)})
            return

        if path == "/telemetry/trace":
            trace_id = query.get("id", [""])[0]
            if not trace_id:
                self._json(400, {"ok": False, "error": "Missing trace id"})
                return
            self._json(200, self.server.nexus.telemetry.get_trace(trace_id))
            return

        if path == "/telemetry/otlp":
            trace_id = query.get("trace_id", [None])[0]
            limit = int(query.get("limit", ["100"])[0])
            self._json(200, self.server.nexus.telemetry.export_otlp(trace_id=trace_id, limit=limit))
            return

        if path == "/telemetry/audit":
            actor = query.get("actor", [None])[0]
            action = query.get("action", [None])[0]
            limit = int(query.get("limit", ["100"])[0])
            since = query.get("since", [None])[0]
            self._json(200, {"entries": self.server.nexus.telemetry.query_audit(actor=actor, action=action, limit=limit, since=since)})
            return

        if path == "/telemetry/audit/verify":
            self._json(200, self.server.nexus.telemetry.verify_audit_integrity())
            return

        # ── Remote worker endpoints ───────────────────────────────
        if path == "/remote/workers":
            status_filter = query.get("status", [None])[0]
            self._json(200, {"workers": self.server.nexus.remote.list_workers(status_filter=status_filter)})
            return

        if path == "/remote/status":
            self._json(200, self.server.nexus.remote.status())
            return

        # ── Provider Registry endpoints ───────────────────────────
        if path == "/providers":
            self._json(200, self.server.nexus.provider_registry.status_all())
            return

        if path == "/providers/summary":
            self._json(200, self.server.nexus.provider_registry.summary())
            return

        if path == "/providers/models":
            self._json(200, self.server.nexus.provider_registry.get_all_models())
            return

        if path == "/providers/health":
            self._json(200, self.server.nexus.provider_registry.health_check_all())
            return

        if path.startswith("/providers/"):
            pid = path.split("/providers/", 1)[1]
            if pid:
                self._json(200, self.server.nexus.provider_registry.status_one(pid))
                return

        # ── Session Persistence endpoints ─────────────────────────
        if path == "/sessions/persisted":
            status_filter = query.get("status", [None])[0]
            self._json(200, {"sessions": self.server.nexus.session_mgr.list_sessions(status=status_filter)})
            return

        if path == "/sessions/status":
            self._json(200, self.server.nexus.session_mgr.status())
            return

        if path.startswith("/sessions/"):
            parts = path.split("/", 3)
            if len(parts) >= 3:
                sid = parts[2]
                if len(parts) == 3:
                    self._json(200, self.server.nexus.session_mgr.get_session(sid))
                    return
                elif parts[3] == "messages":
                    self._json(200, {"messages": self.server.nexus.session_mgr.get_messages(sid)})
                    return
                elif parts[3] == "snapshot":
                    self._json(200, self.server.nexus.session_mgr.snapshot_session(sid))
                    return

        # ── Load Balancer endpoint ────────────────────────────────
        if path == "/loadbalancer":
            self._json(200, self.server.nexus.governor.get_load_balancer_status())
            return

        # ── Multi-Corpus Vector DB endpoints ──────────────────────
        if path == "/mc/status":
            if self.server.nexus._multi_corpus:
                self._json(200, self.server.nexus._multi_corpus.status())
            else:
                self._json(200, {"available": False, "message": "Multi-corpus not initialized"})
            return

        if path == "/mc/corpora":
            if self.server.nexus._multi_corpus:
                self._json(200, {"corpora": self.server.nexus._multi_corpus.list_corpora()})
            else:
                self._json(200, {"corpora": []})
            return

        if path.startswith("/mc/corpora/"):
            corpus_id = path[len("/mc/corpora/"):]
            if self.server.nexus._multi_corpus:
                corpora = self.server.nexus._multi_corpus.list_corpora()
                for c in corpora:
                    if c.get("corpus_id") == corpus_id:
                        self._json(200, c)
                        return
            self._json(404, {"ok": False, "error": "Corpus not found"})
            return

        # ── Telemetry Ingestion endpoints ─────────────────────────
        if path == "/telemetry/ingest/status":
            if self.server.nexus._telemetry_ingestor:
                self._json(200, self.server.nexus._telemetry_ingestor.stats())
            else:
                self._json(200, {"available": False, "message": "Telemetry ingestor not initialized"})
            return

        # ── Reasoning Map endpoints ───────────────────────────────
        if path == "/reasoning/status":
            if self.server.nexus._reasoning_map:
                self._json(200, self.server.nexus._reasoning_map.status())
            else:
                self._json(200, {"available": False})
            return

        if path == "/reasoning/projects":
            if self.server.nexus._reasoning_map:
                self._json(200, {"projects": self.server.nexus._reasoning_map.list_projects()})
            else:
                self._json(200, {"projects": []})
            return

        if path == "/reasoning/map":
            if self.server.nexus._reasoning_map:
                self._json(200, self.server.nexus._reasoning_map.get_full_map())
            else:
                self._json(200, {"available": False})
            return

        if path == "/reasoning/blockers":
            project_id = query.get("project_id", ["DQLOSTTRANSLATION"])[0]
            if self.server.nexus._reasoning_map:
                self._json(200, {"project_id": project_id, "blockers": self.server.nexus._reasoning_map.get_blockers(project_id)})
            else:
                self._json(200, {"project_id": project_id, "blockers": []})
            return

        if path == "/reasoning/rules":
            project_id = query.get("project_id", ["DQLOSTTRANSLATION"])[0]
            if self.server.nexus._reasoning_map:
                self._json(200, {"project_id": project_id, "rules": self.server.nexus._reasoning_map.get_rules(project_id)})
            else:
                self._json(200, {"project_id": project_id, "rules": []})
            return

        if path.startswith("/reasoning/project/"):
            project_id = path[len("/reasoning/project/"):]
            if self.server.nexus._reasoning_map:
                self._json(200, self.server.nexus._reasoning_map.get_project(project_id))
            else:
                self._json(404, {"ok": False, "error": "Reasoning map not available"})
            return

        # ── Agent Auto-Registration endpoints ─────────────────────
        if path == "/agents/registered":
            if self.server.nexus._agent_registrar:
                self._json(200, {"agents": self.server.nexus._agent_registrar.list_agents()})
            else:
                self._json(200, {"agents": []})
            return

        if path == "/agents/discover":
            capability = query.get("capability", [None])[0]
            if self.server.nexus._agent_registrar:
                if capability:
                    self._json(200, {"agents": self.server.nexus._agent_registrar.find_by_capability(capability)})
                else:
                    self._json(200, {"agents": self.server.nexus._agent_registrar.list_agents()})
            else:
                self._json(200, {"agents": []})
            return

        if path == "/agents/registrar/status":
            if self.server.nexus._agent_registrar:
                self._json(200, self.server.nexus._agent_registrar.status())
            else:
                self._json(200, {"available": False})
            return

        self._json(404, {"ok": False, "error": "Not found"})

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        body = self._read_body()

        if body.get("_error") == "body_too_large":
            return  # already responded with 413

        if not self._check_auth():
            self._json(401, {"ok": False, "error": "Unauthorized: invalid or missing X-Nexus-Key header"})
            return

        if path == "/agents":
            agent = Agent(
                agent_id=body.get("agent_id") or body.get("name", "unknown"),
                name=body.get("name", "unknown"),
                provider=body.get("provider", "unknown"),
                model=body.get("model", "unknown"),
                session_id=body.get("session_id", "default"),
                capabilities=body.get("capabilities", []),
                state=body.get("state", "idle"),
                metadata=body.get("metadata", {}),
            )
            self.server.nexus.agents.register(agent)
            self.server.nexus.events.publish(
                "agent_registered", agent_id=agent.agent_id,
                session_id=agent.session_id, payload={"name": agent.name}
            )
            self._json(201, agent.to_dict())
            return

        if path.startswith("/agents/") and path.endswith("/heartbeat"):
            agent_id = path[len("/agents/"):-len("/heartbeat")]
            agent = self.server.nexus.agents.heartbeat(
                agent_id,
                state=body.get("state"),
                current_task=body.get("current_task"),
                current_task_title=body.get("current_task_title"),
            )
            if not agent:
                self._json(404, {"ok": False, "error": "Agent not found"})
                return
            self._json(200, agent.to_dict())
            return

        if path == "/tasks":
            task = self.server.nexus.tasks.create(
                title=body.get("title", "Untitled"),
                description=body.get("description", ""),
                agent_id=body.get("agent_id"),
                dependencies=body.get("dependencies", []),
                priority=body.get("priority", 5),
                metadata=body.get("metadata", {}),
            )
            self.server.nexus.events.publish(
                "task_created", task_id=task.task_id,
                payload={"title": task.title}
            )
            self._json(201, task.to_dict())
            return

        if path.startswith("/tasks/") and path.endswith("/claim"):
            task_id = path[len("/tasks/"):-len("/claim")]
            agent_id = body.get("agent_id")
            if not agent_id:
                self._json(400, {"ok": False, "error": "Missing agent_id"})
                return
            task = self.server.nexus.tasks.claim(task_id, agent_id)
            if not task:
                self._json(409, {"ok": False, "error": "Task unavailable or dependencies not met"})
                return
            self.server.nexus.events.publish(
                "task_claimed", agent_id=agent_id, task_id=task.task_id,
                payload={"title": task.title}
            )
            self._json(200, task.to_dict())
            return

        if path.startswith("/tasks/") and path.endswith("/start"):
            task_id = path[len("/tasks/"):-len("/start")]
            agent_id = body.get("agent_id")
            task = self.server.nexus.tasks.start(task_id, agent_id)
            if not task:
                self._json(409, {"ok": False, "error": "Cannot start task"})
                return
            self.server.nexus.events.publish(
                "task_started", agent_id=agent_id, task_id=task.task_id,
                payload={"title": task.title}
            )
            self._json(200, task.to_dict())
            return

        if path.startswith("/tasks/") and path.endswith("/done"):
            task_id = path[len("/tasks/"):-len("/done")]
            agent_id = body.get("agent_id")
            task = self.server.nexus.tasks.complete(
                task_id, agent_id,
                result=body.get("result"),
                artifacts=body.get("artifacts", [])
            )
            if not task:
                self._json(409, {"ok": False, "error": "Cannot complete task"})
                return
            self.server.nexus.events.publish(
                "task_done", agent_id=agent_id, task_id=task.task_id,
                payload={"title": task.title, "artifacts": task.artifacts}
            )
            self._json(200, task.to_dict())
            return

        if path.startswith("/tasks/") and path.endswith("/fail"):
            task_id = path[len("/tasks/"):-len("/fail")]
            agent_id = body.get("agent_id")
            task = self.server.nexus.tasks.fail(task_id, agent_id, body.get("error", "Unknown error"))
            if not task:
                self._json(409, {"ok": False, "error": "Cannot fail task"})
                return
            self.server.nexus.events.publish(
                "task_failed", agent_id=agent_id, task_id=task.task_id,
                payload={"error": task.result}
            )
            self._json(200, task.to_dict())
            return

        if path == "/sessions":
            session = self.server.nexus.sessions.create(
                goal=body.get("goal", ""),
                rag_query=body.get("rag_query"),
                context_version=body.get("context_version", ""),
                metadata=body.get("metadata", {}),
            )
            self.server.nexus.events.publish(
                "session_created", session_id=session.session_id,
                payload={"goal": session.goal}
            )
            self._json(201, session.to_dict())
            return

        if path.startswith("/sessions/") and path.endswith("/join"):
            session_id = path[len("/sessions/"):-len("/join")]
            agent_id = body.get("agent_id")
            if not agent_id:
                self._json(400, {"ok": False, "error": "Missing agent_id"})
                return
            session = self.server.nexus.sessions.add_agent(session_id, agent_id)
            if not session:
                self._json(404, {"ok": False, "error": "Session not found"})
                return
            self.server.nexus.events.publish(
                "agent_joined", agent_id=agent_id, session_id=session_id
            )
            self._json(200, session.to_dict())
            return

        if path == "/locks":
            result = self.server.nexus.locks.request(
                agent_id=body.get("agent_id"),
                path=body.get("path"),
                intent=body.get("intent", ""),
                ttl_seconds=body.get("ttl_seconds", 1800),
            )
            if result.get("status") == "granted":
                lock = result["lock"]
                self.server.nexus.events.publish(
                    "lock_granted", agent_id=lock["agent_id"],
                    payload={"path": lock["path"], "intent": lock["intent"]}
                )
            self._json(200 if result.get("status") != "error" else 409, result)
            return

        if path == "/events":
            event = self.server.nexus.events.publish(
                event_type=body.get("event_type", "custom"),
                agent_id=body.get("agent_id"),
                session_id=body.get("session_id"),
                task_id=body.get("task_id"),
                payload=body.get("payload", {}),
            )
            self._json(201, event.to_dict())
            return

        if path == "/broadcast":
            event = self.server.nexus.events.publish(
                event_type=body.get("event_type", "broadcast"),
                agent_id=body.get("agent_id"),
                session_id=body.get("session_id"),
                payload=body.get("payload", {}),
            )
            self._json(201, event.to_dict())
            return

        if path == "/bus/broadcast":
            topic = body.get("topic")
            if not topic:
                self._json(400, {"ok": False, "error": "Missing topic"})
                return
            self.server.nexus.bus.broadcast(topic, body.get("payload", {}))
            self._json(201, {"ok": True, "topic": topic})
            return

        if path == "/handshake":
            # HTTP fallback for initiating a Liminal Handshake
            result = self.server.nexus.initiate_handshake(
                agent_id=body.get("agent_id"),
                target_agent_id=body.get("target_agent_id"),
                session_id=body.get("session_id"),
                challenge=body.get("challenge", ""),
                payload=body.get("payload", {}),
            )
            self._json(200 if result.get("ok") else 409, result)
            return

        if path == "/handshake/resolve":
            result = self.server.nexus.resolve_handshake(
                handshake_id=body.get("handshake_id"),
                accepted=body.get("accepted", False),
                response=body.get("response", {}),
                reason=body.get("reason", ""),
            )
            self._json(200 if result.get("ok") else 409, result)
            return

        if path == "/handoff":
            result = self.server.nexus.initiate_handoff(
                agent_id=body.get("agent_id"),
                to_agent_id=body.get("to_agent_id"),
                session_id=body.get("session_id"),
                context=body.get("context", {}),
                trigger=body.get("trigger", "manual"),
            )
            self._json(200 if result.get("ok") else 409, result)
            return

        if path == "/clock/resolve":
            proposals = body.get("proposals", [])
            entries = [
                ConflictEntry(
                    resource=p.get("resource", ""),
                    agent_id=p.get("agent_id", ""),
                    tick=p.get("tick", 0),
                    timestamp=p.get("timestamp", _now_iso()),
                    payload=p.get("payload", {}),
                )
                for p in proposals
            ]
            winner = self.server.nexus.clock.resolve_conflict(
                body.get("resource", "unknown"), entries
            )
            self._json(200, {"winner": winner.to_dict() if winner else None})
            return

        if path == "/clock/declare":
            entry = self.server.nexus.clock.declare_authority(
                agent_id=body.get("agent_id", ""),
                resource=body.get("resource", ""),
                payload=body.get("payload", {}),
            )
            self._json(200, entry.to_dict())
            return

        if path == "/rag":
            result = self.server.nexus.rag_query(
                query=body.get("query", ""),
                max_chunks=body.get("max_chunks", 20),
                max_bytes=body.get("max_bytes", 200000),
                tags=body.get("tags"),
                after=body.get("after"),
                agent_id=body.get("agent_id"),
                graph_hops=body.get("graph_hops", 0),
            )
            self._json(200 if result.get("status") != "error" else 500, result)
            return

        if path == "/rag/index":
            result = self.server.nexus.rag_index(force=body.get("force", False))
            self._json(200 if result.get("status") != "error" else 500, result)
            return

        if path == "/rag/graph/build":
            if not self.server.nexus._ensure_rag():
                self._json(500, {"ok": False, "error": "RAG not available"})
                return
            if not self.server.nexus._rag_graph:
                self._json(500, {"ok": False, "error": "Graph index not initialized"})
                return
            result = self.server.nexus._rag_graph.build_from_indexer(self.server.nexus._rag_indexer)
            self.server.nexus.events.publish("rag_graph_built", payload=result)
            self._json(200, result)
            return

        if path == "/rag/agent-slice":
            agent_id = body.get("agent_id", "")
            relative_path = body.get("relative_path", "")
            priority = body.get("priority", 1.0)
            tags = body.get("tags", [])
            if not agent_id or not relative_path:
                self._json(400, {"ok": False, "error": "Missing agent_id or relative_path"})
                return
            if not self.server.nexus._rag_graph:
                self._json(500, {"ok": False, "error": "Graph index not initialized"})
                return
            self.server.nexus._rag_graph.set_agent_slice(agent_id, relative_path, priority, tags)
            self._json(201, {"ok": True})
            return

        # ── Multi-Corpus Vector DB POST endpoints ─────────────────
        if path == "/mc/query":
            if not self.server.nexus._multi_corpus:
                self._json(500, {"ok": False, "error": "Multi-corpus not available"})
                return
            result = self.server.nexus._multi_corpus.query(
                query=body.get("query", ""),
                max_chunks=body.get("max_chunks", 20),
                corpora=body.get("corpora"),
                tags=body.get("tags"),
            )
            self._json(200, result)
            return

        if path == "/mc/index":
            if not self.server.nexus._multi_corpus:
                self._json(500, {"ok": False, "error": "Multi-corpus not available"})
                return
            corpus_id = body.get("corpus_id")
            force = body.get("force", False)
            if corpus_id:
                result = self.server.nexus._multi_corpus.index_one(corpus_id, force=force)
            else:
                result = self.server.nexus._multi_corpus.index_all(force=force)
            self._json(200, result)
            return

        if path == "/mc/corpus/add":
            if not self.server.nexus._multi_corpus:
                self._json(500, {"ok": False, "error": "Multi-corpus not available"})
                return
            result = self.server.nexus._multi_corpus.add_corpus(body)
            self._json(201 if result.get("ok") else 400, result)
            return

        # ── Telemetry Ingestion POST endpoints ────────────────────
        if path == "/telemetry/ingest":
            if not self.server.nexus._telemetry_ingestor:
                self._json(500, {"ok": False, "error": "Telemetry ingestor not available"})
                return
            result = self.server.nexus._telemetry_ingestor.ingest_manual(
                corpus_id=body.get("corpus_id", "dq_cybergrime"),
                telemetry=body.get("telemetry", body),
            )
            self._json(201 if result.get("ok") else 400, result)
            return

        if path == "/telemetry/ingest/source/add":
            if not self.server.nexus._telemetry_ingestor:
                self._json(500, {"ok": False, "error": "Telemetry ingestor not available"})
                return
            source_id = body.get("source_id", "")
            if not source_id:
                self._json(400, {"ok": False, "error": "Missing source_id"})
                return
            result = self.server.nexus._telemetry_ingestor.add_source(source_id, body.get("config", {}))
            self._json(201, result)
            return

        # ── Reasoning Map POST endpoints ──────────────────────────
        if path == "/reasoning/query":
            if not self.server.nexus._reasoning_map:
                self._json(500, {"ok": False, "error": "Reasoning map not available"})
                return
            result = self.server.nexus._reasoning_map.query(body.get("query", ""))
            self._json(200, result)
            return

        if path == "/reasoning/blocker/add":
            if not self.server.nexus._reasoning_map:
                self._json(500, {"ok": False, "error": "Reasoning map not available"})
                return
            project_id = body.get("project_id", "DQLOSTTRANSLATION")
            blocker = body.get("blocker", "")
            if not blocker:
                self._json(400, {"ok": False, "error": "Missing blocker text"})
                return
            result = self.server.nexus._reasoning_map.add_blocker(project_id, blocker)
            self._json(201, result)
            return

        if path == "/reasoning/blocker/resolve":
            if not self.server.nexus._reasoning_map:
                self._json(500, {"ok": False, "error": "Reasoning map not available"})
                return
            project_id = body.get("project_id", "DQLOSTTRANSLATION")
            blocker_index = body.get("blocker_index", -1)
            result = self.server.nexus._reasoning_map.resolve_blocker(project_id, blocker_index)
            self._json(200, result)
            return

        # ── Agent Registration POST endpoints ─────────────────────
        if path == "/agents/auto-register":
            if not self.server.nexus._agent_registrar:
                self._json(500, {"ok": False, "error": "Agent registrar not available"})
                return
            results = self.server.nexus._agent_registrar.register_all()
            self._json(200, {"ok": True, "registered": results})
            return

        if path == "/agents/register":
            if not self.server.nexus._agent_registrar:
                self._json(500, {"ok": False, "error": "Agent registrar not available"})
                return
            result = self.server.nexus._agent_registrar.add_agent({
                "agent_id": body.get("agent_id", ""),
                "name": body.get("name", body.get("agent_id", "")),
                "provider": body.get("provider", "unknown"),
                "model": body.get("model", "unknown"),
                "session_id": body.get("session_id", "default"),
                "agent_type": body.get("agent_type", "local"),
                "capabilities": body.get("capabilities", []),
                "state": "idle",
                "metadata": body.get("metadata", {}),
            })
            self._json(201 if result.get("ok") else 400, result)
            return

        # ── Telemetry span endpoints ─────────────────────────────
        if path == "/telemetry/span/start":
            name = body.get("name", "")
            if not name:
                self._json(400, {"ok": False, "error": "Missing span name"})
                return
            span = self.server.nexus.telemetry.start_span(
                name=name,
                trace_id=body.get("trace_id"),
                parent_span_id=body.get("parent_span_id"),
                kind=body.get("kind", "internal"),
                agent_id=body.get("agent_id", ""),
                attributes=body.get("attributes"),
            )
            self._json(201, span.to_dict())
            return

        if path == "/telemetry/span/end":
            span_id = body.get("span_id", "")
            if not span_id:
                self._json(400, {"ok": False, "error": "Missing span_id"})
                return
            span = self.server.nexus.telemetry._active_spans.get(span_id)
            if not span:
                self._json(404, {"ok": False, "error": "Span not found or already ended"})
                return
            self.server.nexus.telemetry.end_span(span, status=body.get("status", "ok"), message=body.get("message", ""))
            self._json(200, span.to_dict())
            return

        if path == "/telemetry/audit":
            actor = body.get("actor", "")
            action = body.get("action", "")
            if not actor or not action:
                self._json(400, {"ok": False, "error": "Missing actor or action"})
                return
            entry_hash = self.server.nexus.telemetry.audit(
                actor=actor,
                action=action,
                target=body.get("target", ""),
                decision=body.get("decision", "allow"),
                reason=body.get("reason", ""),
                context=body.get("context"),
                span_id=body.get("span_id", ""),
            )
            self._json(201, {"ok": True, "hash": entry_hash})
            return

        # ── Remote worker endpoints ──────────────────────────────
        if path == "/remote/register":
            result = self.server.nexus.remote.register_worker(
                name=body.get("name", "remote-worker"),
                endpoint=body.get("endpoint", ""),
                capabilities=body.get("capabilities", []),
                auth_token=body.get("auth_token"),
            )
            self._json(201, result)
            return

        if path == "/remote/heartbeat":
            worker_id = body.get("worker_id", "")
            if not worker_id:
                self._json(400, {"ok": False, "error": "Missing worker_id"})
                return
            result = self.server.nexus.remote.heartbeat(worker_id, body.get("status", "active"))
            self._json(200, result)
            return

        if path == "/remote/assign":
            worker_id = body.get("worker_id", "")
            task_id = body.get("task_id", "")
            if not worker_id or not task_id:
                self._json(400, {"ok": False, "error": "Missing worker_id or task_id"})
                return
            result = self.server.nexus.remote.assign_task(worker_id, task_id)
            self._json(200, result)
            return

        if path == "/remote/complete":
            worker_id = body.get("worker_id", "")
            task_id = body.get("task_id", "")
            if not worker_id or not task_id:
                self._json(400, {"ok": False, "error": "Missing worker_id or task_id"})
                return
            result = self.server.nexus.remote.complete_task(
                worker_id, task_id, body.get("result"), body.get("success", True)
            )
            self._json(200, result)
            return

        # ── Provider Registry endpoints ───────────────────────────
        if path == "/providers/generate":
            result = self.server.nexus.provider_registry.generate(
                provider_id=body.get("provider_id", ""),
                prompt=body.get("prompt", ""),
                model=body.get("model", ""),
                max_tokens=body.get("max_tokens", 2048),
                temperature=body.get("temperature", 0.7),
                stream=body.get("stream", False),
            )
            self._json(200 if result.get("ok") else 503, result)
            return

        if path == "/providers/health":
            pid = body.get("provider_id", "")
            if pid:
                result = self.server.nexus.provider_registry.health_check_one(pid)
            else:
                result = self.server.nexus.provider_registry.health_check_all()
            self._json(200, result)
            return

        if path == "/providers/register":
            result = self.server.nexus.provider_registry.register_provider(body.get("config", {}))
            self._json(200 if result.get("ok") else 400, result)
            return

        if path == "/providers/unregister":
            result = self.server.nexus.provider_registry.unregister_provider(body.get("provider_id", ""))
            self._json(200 if result.get("ok") else 404, result)
            return

        if path == "/providers/update":
            result = self.server.nexus.provider_registry.update_provider_config(
                body.get("provider_id", ""), body.get("updates", {})
            )
            self._json(200 if result.get("ok") else 404, result)
            return

        if path == "/providers/find-model":
            model_name = body.get("model", "")
            provider_id = self.server.nexus.provider_registry.find_model(model_name)
            self._json(200, {"model": model_name, "provider": provider_id, "found": provider_id is not None})
            return

        # ── Session Persistence endpoints ─────────────────────────
        if path == "/sessions/create":
            session = self.server.nexus.session_mgr.create_session(
                label=body.get("label", ""),
                goal=body.get("goal", ""),
                provider_id=body.get("provider_id", ""),
                tab_color=body.get("tab_color", ""),
                tab_icon=body.get("tab_icon", ""),
                metadata=body.get("metadata"),
            )
            self._json(200, session)
            return

        if path == "/sessions/update":
            result = self.server.nexus.session_mgr.update_session(
                body.get("session_id", ""), body.get("updates", {})
            )
            self._json(200 if result else 404, result or {"ok": False, "error": "Session not found"})
            return

        if path == "/sessions/message":
            result = self.server.nexus.session_mgr.add_message(
                body.get("session_id", ""),
                role=body.get("role", "user"),
                content=body.get("content", ""),
                agent_id=body.get("agent_id", ""),
                provider=body.get("provider", ""),
                model=body.get("model", ""),
                latency_ms=body.get("latency_ms", 0),
                token_usage=body.get("token_usage", 0),
                metadata=body.get("metadata"),
            )
            self._json(200, result)
            return

        if path == "/sessions/mcp-context":
            result = self.server.nexus.session_mgr.set_mcp_context(
                body.get("session_id", ""), body.get("context", {})
            )
            self._json(200 if result else 404, result or {"ok": False, "error": "Session not found"})
            return

        if path == "/sessions/agents":
            result = self.server.nexus.session_mgr.set_agents(
                body.get("session_id", ""), body.get("agents", [])
            )
            self._json(200 if result else 404, result or {"ok": False, "error": "Session not found"})
            return

        if path == "/sessions/kill":
            ok = self.server.nexus.session_mgr.kill_session(body.get("session_id", ""))
            self._json(200 if ok else 404, {"ok": ok})
            return

        if path == "/sessions/restore":
            result = self.server.nexus.session_mgr.restore_session(body.get("session_id", ""))
            self._json(200 if result else 404, result or {"ok": False, "error": "Session not found"})
            return

        if path == "/sessions/delete":
            ok = self.server.nexus.session_mgr.delete_session(body.get("session_id", ""))
            self._json(200 if ok else 404, {"ok": ok})
            return

        # ── Load Balancer endpoints ───────────────────────────────
        if path == "/loadbalancer/recommend":
            ram_pct = body.get("ram_pct", 0)
            task_type = body.get("task_type", "core")
            result = self.server.nexus.governor.recommend_provider(ram_pct, task_type)
            self._json(200, result)
            return

        if path == "/loadbalancer/kill-list":
            ram_pct = body.get("ram_pct", 0)
            agents = body.get("agents", [])
            kill_list = self.server.nexus.governor.get_kill_list(ram_pct, agents)
            self._json(200, {"kill_list": kill_list, "ram_pct": ram_pct})
            return

        if path == "/loadbalancer/record":
            result = self.server.nexus.governor.record_sample(
                ram_pct=body.get("ram_pct", 0),
                cpu_pct=body.get("cpu_pct", 0),
                latency_ms=body.get("latency_ms", 0),
                cache_hit_rate=body.get("cache_hit_rate", 1.0),
                swap_events=body.get("swap_events", 0),
                token_cost=body.get("token_cost", 0),
                kv_bits=body.get("kv_bits", 0),
                model_load_ms=body.get("model_load_ms", 0),
            )
            self._json(200, result)
            return

        # ── MCP endpoints ────────────────────────────────────────
        if path == "/mcp/call":
            tool_name = body.get("tool")
            args = body.get("args", {})
            agent_id = body.get("agent_id", "")
            authority = body.get("authority", "read")
            require_approval = body.get("require_approval", False)
            if not tool_name:
                self._json(400, {"ok": False, "error": "Missing tool name"})
                return
            if require_approval:
                result = self.server.nexus.mcp.request_call(tool_name, args, agent_id, authority)
            else:
                from .mcp_server import call_tool as _ct
                result = _ct(tool_name, args, agent_id, authority)
                self.server.nexus.mcp._log_call(tool_name, agent_id, args, result, approved=True, auto=True)
            self._json(200 if result.get("ok") else 409, result)
            return

        if path == "/mcp/approve":
            call_id = body.get("call_id")
            if not call_id:
                self._json(400, {"ok": False, "error": "Missing call_id"})
                return
            result = self.server.nexus.mcp.approve_call(call_id)
            self._json(200 if result.get("ok") else 409, result)
            return

        if path == "/mcp/deny":
            call_id = body.get("call_id")
            reason = body.get("reason", "")
            if not call_id:
                self._json(400, {"ok": False, "error": "Missing call_id"})
                return
            result = self.server.nexus.mcp.deny_call(call_id, reason)
            self._json(200, result)
            return

        if path == "/mcp/auto-approve":
            tool_name = body.get("tool", "*")
            agent_id = body.get("agent", "*")
            path_pattern = body.get("path_pattern", "*")
            self.server.nexus.mcp.add_auto_approve_rule(tool_name, agent_id, path_pattern)
            self._json(200, {"ok": True, "rule_added": True})
            return

        # ── Committee endpoints ──────────────────────────────────
        if path == "/committee/mode":
            session_id = body.get("session_id", "default")
            mode = body.get("mode", "lazy_sync")
            result = self.server.nexus.committee.set_session_mode(session_id, mode)
            self.server.nexus.events.publish(
                "committee_mode_changed", session_id=session_id,
                payload={"mode": mode}
            )
            self._json(200, result)
            return

        if path == "/committee/default-mode":
            mode = body.get("mode", "lazy_sync")
            self.server.nexus.committee.set_default_mode(mode)
            self._json(200, {"ok": True, "default_mode": mode})
            return

        if path.startswith("/committee/sessions/") and path.endswith("/vote"):
            parts = path[len("/committee/sessions/"):].split("/")
            if len(parts) == 2:
                session_id = parts[0]
                proposal_id = parts[1].replace("/vote", "")
                cs = self.server.nexus.committee.get_session(session_id)
                if not cs:
                    self._json(404, {"ok": False, "error": "Session not found"})
                    return
                result = cs.vote(proposal_id, body.get("agent_id", ""), body.get("confidence", 0.5))
                self._json(200, result)
                return

        if path.startswith("/committee/sessions/") and path.endswith("/propose"):
            parts = path[len("/committee/sessions/"):].split("/")
            if len(parts) == 2:
                session_id = parts[0]
                proposal_id = parts[1].replace("/propose", "")
                cs = self.server.nexus.committee.get_session(session_id)
                if not cs:
                    cs = self.server.nexus.committee.create_session(session_id)
                cs.submit_proposal(proposal_id, body.get("agent_id", ""), body.get("content", {}))
                self._json(201, {"ok": True, "proposal_id": proposal_id})
                return

        # ── Governor endpoints ───────────────────────────────────
        if path == "/governor/budget":
            key = body.get("key")
            value = body.get("value")
            if not key or value is None:
                self._json(400, {"ok": False, "error": "Missing key or value"})
                return
            self.server.nexus.governor.set_budget(key, value)
            self._json(200, {"ok": True, "budget": {key: value}})
            return

        if path == "/governor/sample":
            result = self.server.nexus.governor.record_sample(
                ram_pct=body.get("ram_pct", 0),
                cpu_pct=body.get("cpu_pct", 0),
                latency_ms=body.get("latency_ms", 0),
                cache_hit_rate=body.get("cache_hit_rate", 1.0),
                swap_events=body.get("swap_events", 0),
                token_cost=body.get("token_cost", 0),
                kv_bits=body.get("kv_bits", 0),
                model_load_ms=body.get("model_load_ms", 0),
            )
            # Also record to metrics DB
            for k, v in body.items():
                if isinstance(v, (int, float)):
                    self.server.nexus.metrics.record(k, float(v))
            # Evaluate alerting rules
            alerts = self.server.nexus.alerting.evaluate(body)
            if alerts:
                for a in alerts:
                    self.server.nexus.events.publish("alert", payload=a)
            self._json(200, {"governor": result, "alerts": alerts})
            return

        # ── Alerting endpoints ───────────────────────────────────
        if path == "/alerts/rules":
            name = body.get("name")
            condition = body.get("condition")
            action = body.get("action", "notify")
            severity = body.get("severity", "warning")
            cooldown = body.get("cooldown", 120)
            if not name or not condition:
                self._json(400, {"ok": False, "error": "Missing name or condition"})
                return
            self.server.nexus.alerting.add_rule(name, condition, action, severity, cooldown)
            self._json(201, {"ok": True, "rule": name})
            return

        if path == "/alerts/ack":
            index = body.get("index", 0)
            if self.server.nexus.governor.acknowledge_alert(index):
                self._json(200, {"ok": True})
            else:
                self._json(404, {"ok": False, "error": "Alert not found"})
            return

        # ── Metrics endpoints ────────────────────────────────────
        if path == "/metrics/record":
            name = body.get("name")
            value = body.get("value")
            tags = body.get("tags")
            if not name or value is None:
                self._json(400, {"ok": False, "error": "Missing name or value"})
                return
            self.server.nexus.metrics.record(name, float(value), tags)
            self._json(201, {"ok": True})
            return

        if path == "/metrics/snapshot":
            snapshot = body.get("snapshot", body)
            self.server.nexus.metrics.record_snapshot(snapshot)
            self._json(201, {"ok": True})
            return

        if path == "/metrics/prune":
            max_age = body.get("max_age_seconds", 86400)
            pruned = self.server.nexus.metrics.prune(max_age)
            self._json(200, {"ok": True, "pruned": pruned})
            return

        # ── Memory endpoints ─────────────────────────────────────
        if path == "/memory/working":
            agent_id = body.get("agent_id", "")
            key = body.get("key")
            value = body.get("value")
            ttl = body.get("ttl", 3600)
            if not agent_id or not key:
                self._json(400, {"ok": False, "error": "Missing agent_id or key"})
                return
            self.server.nexus.state.set_working_memory(agent_id, key, value, ttl)
            self._json(201, {"ok": True})
            return

        if path == "/memory/longterm":
            key = body.get("key")
            value = body.get("value")
            tags = body.get("tags", [])
            agent_id = body.get("agent_id")
            source = body.get("source", "")
            if not key or value is None:
                self._json(400, {"ok": False, "error": "Missing key or value"})
                return
            self.server.nexus.state.set_longterm_memory(key, value, tags, agent_id, source)
            self._json(201, {"ok": True})
            return

        self._json(404, {"ok": False, "error": "Not found"})

    def do_DELETE(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        body = self._read_body()

        if not self._check_auth():
            self._json(401, {"ok": False, "error": "Unauthorized: invalid or missing X-Nexus-Key header"})
            return

        if path.startswith("/locks/"):
            encoded_path = path[len("/locks/"):]
            import urllib.parse
            file_path = urllib.parse.unquote(encoded_path)
            agent_id = body.get("agent_id")
            if self.server.nexus.locks.release(file_path, agent_id):
                self.server.nexus.events.publish(
                    "lock_released", agent_id=agent_id,
                    payload={"path": file_path}
                )
                self._json(200, {"ok": True, "path": file_path})
                return
            self._json(409, {"ok": False, "error": "Lock not held by agent"})
            return

        if path.startswith("/agents/"):
            agent_id = path[len("/agents/"):]
            if self.server.nexus.agents.unregister(agent_id):
                self.server.nexus.locks.release_by_agent(agent_id)
                self.server.nexus.events.publish(
                    "agent_unregistered", agent_id=agent_id
                )
                self._json(200, {"ok": True})
                return
            self._json(404, {"ok": False, "error": "Agent not found"})
            return

        self._json(404, {"ok": False, "error": "Not found"})


class NexusAPI:
    """Container that ties registries, WebSocket bus, Master Clock, audit logger, and RAG together."""

    def __init__(self, project_root: Path, port: int = 8651, ws_port: int = 8652,
                 forward_url: Optional[str] = None):
        self.project_root = project_root
        self.port = port
        self.ws_port = ws_port
        self.agents = AgentRegistry()
        self.tasks = TaskQueue()
        self.sessions = SessionRegistry()
        self.locks = LockManager()
        self.events = EventBus()
        self.clock = MasterClock()
        self.logger = NeuralLinkLogger(project_root, forward_url=forward_url)
        self.bus = NexusWebSocketBus(
            port=ws_port,
            event_bus=self.events,
            audit_callback=self._on_bus_audit,
        )
        self._server: Optional[HTTPServer] = None
        self._thread: Optional[threading.Thread] = None

        # Persistent state store
        self._db_dir = project_root / "tools" / "vw_nexus" / "data"
        self.state = StateStore(self._db_dir / "nexus_state.db")

        # MCP server
        self.mcp = McpServer()
        register_default_tools(self)

        # Internal MCP client (git/build/filesystem tools)
        self.internal_client = InternalMcpClient(project_root)
        register_internal_tools(self.mcp, self.internal_client)

        # Warp MCP tools (warp_discover, warp_status, warp_inference, warp_overflow_check)
        register_warp_mcp_tools(self)

        # Universal ProviderRegistry — load from vw_deck.config.json and register MCP tools
        self.provider_registry = load_registry_from_config_file()
        register_provider_mcp_tools(self)

        # Load YAML-defined tools (skips any already registered programmatically)
        try:
            self._yaml_tool_results = load_yaml_tools()
        except Exception as e:
            self._yaml_tool_results = [{"ok": False, "error": str(e)}]

        # Session persistence (browser-tab session management)
        self.session_mgr = SessionManager(self._db_dir / "nexus_sessions.db")

        # RAG graph index
        self._rag_graph = None
        self._rag_graph_path = project_root / "tools" / "vw_rag" / "vw_rag_graph.db"

        # Committee manager
        self.committee = CommitteeManager()

        # Cost/latency governor (Orion)
        self.governor = Governor()

        # Alerting rules engine
        self.alerting = AlertingEngine()
        self.alerting.load_defaults()

        # Persistent metrics DB
        self.metrics = MetricsDB(self._db_dir / "nexus_metrics.db")

        # Telemetry exporter (OpenTelemetry-style spans + audit log)
        self.telemetry = TelemetryExporter(self._db_dir / "nexus_telemetry.db")

        # Remote worker bridge
        self.remote = RemoteWorkerBridge(self._db_dir / "nexus_remote.db")

        # RAG engine — lazy-initialized on first query
        self._rag_indexer = None
        self._rag_retriever = None
        self._rag_lock = threading.Lock()
        self._rag_study_root = project_root / "study"
        self._rag_db_path = project_root / "tools" / "vw_rag" / "vw_rag_index.db"

        # ── Multi-corpus Vector DB + Telemetry Ingestion + Agent Registration + Reasoning Map ──
        self._multi_corpus = None
        self._telemetry_ingestor = None
        self._agent_registrar = None
        self._reasoning_map = None

        if _NEXUS_EXTENSIONS_AVAILABLE:
            # Reasoning map (always available — pure Python)
            self._reasoning_map = ReasoningMap(
                map_path=project_root / "tools" / "vw_nexus" / "data" / "reasoning_map.json"
            )

            # Agent auto-registrar
            self._agent_registrar = AgentAutoRegistrar(
                self.agents,
                config_path=project_root / "tools" / "vw_nexus" / "data" / "agent_manifest.json",
            )
            # Register all known agents immediately
            self._agent_registrar.register_all()
            # Start heartbeat keepalive
            self._agent_registrar.start_heartbeats()

            # Multi-corpus vector DB manager
            if MultiCorpusManager is not None:
                corpus_config = project_root / "tools" / "vw_nexus" / "data" / "corpus_config.json"
                self._multi_corpus = MultiCorpusManager(
                    db_dir=project_root / "tools" / "vw_rag" / "multi_corpus",
                    config_path=corpus_config if corpus_config.exists() else None,
                    embedder=RagEmbedder() if _RAG_AVAILABLE else None,
                )

                # Telemetry ingestor (depends on multi-corpus)
                self._telemetry_ingestor = TelemetryIngestor(
                    multi_corpus=self._multi_corpus,
                    poll_interval=5.0,
                )
                # Set callback to publish ingestion events on the bus
                self._telemetry_ingestor.set_on_ingest_callback(self._on_telemetry_ingested)

            # Register new MCP tools for multi-corpus + reasoning map
            self._register_extension_mcp_tools()

    def _on_bus_audit(self, entry: Dict[str, Any]) -> None:
        self.logger.log(entry.get("type", "bus_event"), entry.get("payload", {}))

    # ── RAG Engine ──────────────────────────────────────────────

    def _ensure_rag(self) -> bool:
        """Lazy-initialize the RAG indexer, retriever, and graph."""
        if not _RAG_AVAILABLE:
            return False
        with self._rag_lock:
            if self._rag_indexer is None:
                try:
                    embedder = RagEmbedder()
                    self._rag_indexer = RagIndexer(
                        self._rag_db_path, self._rag_study_root, embedder
                    )
                    # Initialize graph index
                    try:
                        from vw_rag.graph_index import GraphIndex
                        self._rag_graph = GraphIndex(self._rag_graph_path)
                    except Exception:
                        self._rag_graph = None
                    self._rag_retriever = RagRetriever(
                        self._rag_indexer, embedder, graph=self._rag_graph
                    )
                except Exception as e:
                    print(f"RAG init failed: {e}", file=__import__("sys").stderr)
                    return False
            return True

    def rag_query(self, query: str, max_chunks: int = 20, max_bytes: int = 200000,
                  tags: Optional[List[str]] = None, after: Optional[str] = None,
                  agent_id: Optional[str] = None, graph_hops: int = 0) -> Dict[str, Any]:
        if not self._ensure_rag():
            return {"status": "error", "message": "RAG engine not available (install vw_rag package)"}
        try:
            return self._rag_retriever.query(
                query, max_chunks=max_chunks, max_bytes=max_bytes,
                tags=tags, after=after,
                agent_id=agent_id, graph_hops=graph_hops,
            )
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def rag_index(self, force: bool = False) -> Dict[str, Any]:
        if not self._ensure_rag():
            return {"status": "error", "message": "RAG engine not available"}
        try:
            stats = self._rag_indexer.index_directory(force=force)
            self.events.publish("rag_indexed", payload=stats.to_dict())
            return {"status": "ok", "stats": stats.to_dict()}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def rag_status(self) -> Dict[str, Any]:
        if not self._ensure_rag():
            return {"status": "error", "message": "RAG engine not available"}
        try:
            stats = self._rag_indexer.get_stats()
            return {"status": "ok", "stats": stats.to_dict()}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # ── Multi-Corpus + Telemetry + Reasoning Map ────────────────

    def _on_telemetry_ingested(self, corpus_id: str, telemetry: Dict) -> None:
        """Callback when telemetry is ingested into a corpus vector DB."""
        self.events.publish("telemetry_ingested", payload={
            "corpus_id": corpus_id,
            "source": telemetry.get("_meta", {}).get("source_id", "unknown"),
            "file": telemetry.get("_meta", {}).get("source_file", ""),
        })

    def _register_extension_mcp_tools(self) -> None:
        """Register MCP tools for multi-corpus query, telemetry, reasoning map, and agent discovery."""
        from .mcp_server import register_tool

        nexus = self

        def _mc_query(args: Dict) -> Dict:
            if not nexus._multi_corpus:
                return {"ok": False, "error": "Multi-corpus not available"}
            return nexus._multi_corpus.query(
                query=args.get("query", ""),
                max_chunks=args.get("max_chunks", 20),
                corpora=args.get("corpora"),
                tags=args.get("tags"),
            )

        def _mc_index(args: Dict) -> Dict:
            if not nexus._multi_corpus:
                return {"ok": False, "error": "Multi-corpus not available"}
            corpus_id = args.get("corpus_id")
            if corpus_id:
                return nexus._multi_corpus.index_one(corpus_id, force=args.get("force", False))
            return {"results": nexus._multi_corpus.index_all(force=args.get("force", False))}

        def _mc_status(args: Dict) -> Dict:
            if not nexus._multi_corpus:
                return {"ok": False, "error": "Multi-corpus not available"}
            return nexus._multi_corpus.status()

        def _mc_list_corpora(args: Dict) -> Dict:
            if not nexus._multi_corpus:
                return {"ok": False, "error": "Multi-corpus not available"}
            return {"corpora": nexus._multi_corpus.list_corpora()}

        def _telemetry_status(args: Dict) -> Dict:
            if not nexus._telemetry_ingestor:
                return {"ok": False, "error": "Telemetry ingestor not available"}
            return nexus._telemetry_ingestor.stats()

        def _telemetry_ingest(args: Dict) -> Dict:
            if not nexus._telemetry_ingestor:
                return {"ok": False, "error": "Telemetry ingestor not available"}
            return nexus._telemetry_ingestor.ingest_manual(
                corpus_id=args.get("corpus_id", "dq_cybergrime"),
                telemetry=args.get("telemetry", {}),
            )

        def _reasoning_query(args: Dict) -> Dict:
            if not nexus._reasoning_map:
                return {"ok": False, "error": "Reasoning map not available"}
            return nexus._reasoning_map.query(args.get("query", ""))

        def _reasoning_status(args: Dict) -> Dict:
            if not nexus._reasoning_map:
                return {"ok": False, "error": "Reasoning map not available"}
            return nexus._reasoning_map.status()

        def _reasoning_blockers(args: Dict) -> Dict:
            if not nexus._reasoning_map:
                return {"ok": False, "error": "Reasoning map not available"}
            project = args.get("project_id", "DQLOSTTRANSLATION")
            return {"project_id": project, "blockers": nexus._reasoning_map.get_blockers(project)}

        def _reasoning_rules(args: Dict) -> Dict:
            if not nexus._reasoning_map:
                return {"ok": False, "error": "Reasoning map not available"}
            project = args.get("project_id", "DQLOSTTRANSLATION")
            return {"project_id": project, "rules": nexus._reasoning_map.get_rules(project)}

        def _agent_discover(args: Dict) -> Dict:
            if not nexus._agent_registrar:
                return {"ok": False, "error": "Agent registrar not available"}
            capability = args.get("capability", "")
            if capability:
                return {"agents": nexus._agent_registrar.find_by_capability(capability)}
            return {"agents": nexus._agent_registrar.list_agents()}

        def _agent_register(args: Dict) -> Dict:
            if not nexus._agent_registrar:
                return {"ok": False, "error": "Agent registrar not available"}
            return nexus._agent_registrar.add_agent({
                "agent_id": args.get("agent_id", ""),
                "name": args.get("name", args.get("agent_id", "")),
                "provider": args.get("provider", "unknown"),
                "model": args.get("model", "unknown"),
                "session_id": args.get("session_id", "default"),
                "agent_type": args.get("agent_type", "local"),
                "capabilities": args.get("capabilities", []),
                "state": "idle",
                "metadata": args.get("metadata", {}),
            })

        register_tool("mc_query", "Search across all corpus vector DBs",
                      {"query": {"type": "string", "required": True},
                       "max_chunks": {"type": "integer", "default": 20},
                       "corpora": {"type": "array", "items": {"type": "string"}},
                       "tags": {"type": "array", "items": {"type": "string"}}},
                      _mc_query, "read", rate_limit=60)

        register_tool("mc_index", "Trigger multi-corpus re-indexing (all or one corpus)",
                      {"corpus_id": {"type": "string"},
                       "force": {"type": "boolean", "default": False}},
                      _mc_index, "execute", rate_limit=2)

        register_tool("mc_status", "Get multi-corpus vector DB status",
                      {}, _mc_status, "read", rate_limit=60)

        register_tool("mc_list_corpora", "List all available corpora",
                      {}, _mc_list_corpora, "read", rate_limit=60)

        register_tool("telemetry_status", "Get telemetry ingestion service status",
                      {}, _telemetry_status, "read", rate_limit=60)

        register_tool("telemetry_ingest", "Manually ingest telemetry into a corpus vector DB",
                      {"corpus_id": {"type": "string", "default": "dq_cybergrime"},
                       "telemetry": {"type": "object", "required": True}},
                      _telemetry_ingest, "write", rate_limit=30)

        register_tool("reasoning_query", "Query the project reasoning map for components, blockers, addresses",
                      {"query": {"type": "string", "required": True}},
                      _reasoning_query, "read", rate_limit=60)

        register_tool("reasoning_status", "Get reasoning map status",
                      {}, _reasoning_status, "read", rate_limit=60)

        register_tool("reasoning_blockers", "Get current blockers for a project",
                      {"project_id": {"type": "string", "default": "DQLOSTTRANSLATION"}},
                      _reasoning_blockers, "read", rate_limit=60)

        register_tool("reasoning_rules", "Get pipeline rules for a project",
                      {"project_id": {"type": "string", "default": "DQLOSTTRANSLATION"}},
                      _reasoning_rules, "read", rate_limit=60)

        register_tool("agent_discover", "Find agents by capability or list all registered agents",
                      {"capability": {"type": "string"}},
                      _agent_discover, "read", rate_limit=60)

        register_tool("agent_register", "Register a new agent with the Nexus",
                      {"agent_id": {"type": "string", "required": True},
                       "name": {"type": "string"},
                       "provider": {"type": "string"},
                       "model": {"type": "string"},
                       "agent_type": {"type": "string"},
                       "capabilities": {"type": "array", "items": {"type": "string"}}},
                      _agent_register, "write", rate_limit=20)

    def initiate_handshake(self, agent_id: Optional[str], target_agent_id: Optional[str],
                           session_id: Optional[str], challenge: str,
                           payload: Dict[str, Any]) -> Dict[str, Any]:
        if not agent_id or not target_agent_id:
            return {"ok": False, "error": "Missing agent_id or target_agent_id"}
        # This is a synchronous HTTP fallback. The actual handshake is async over WebSocket.
        # We create a pending handshake and ask the target agent to connect to the bus.
        handshake_id = f"HS_{int(time.time() * 1000)}_{agent_id}_{target_agent_id}"
        self.logger.log("handshake_initiated", {
            "handshake_id": handshake_id,
            "from_agent_id": agent_id,
            "to_agent_id": target_agent_id,
            "session_id": session_id,
            "challenge": challenge,
            "payload": payload,
        })
        return {
            "ok": True,
            "handshake_id": handshake_id,
            "status": "pending",
            "message": "Target agent must connect to the WebSocket bus and respond",
        }

    def resolve_handshake(self, handshake_id: Optional[str], accepted: bool,
                          response: Dict[str, Any], reason: str) -> Dict[str, Any]:
        if not handshake_id:
            return {"ok": False, "error": "Missing handshake_id"}
        self.logger.log("handshake_resolved", {
            "handshake_id": handshake_id,
            "accepted": accepted,
            "response": response,
            "reason": reason,
        })
        return {"ok": True, "handshake_id": handshake_id, "accepted": accepted}

    def initiate_handoff(self, agent_id: Optional[str], to_agent_id: Optional[str],
                         session_id: Optional[str], context: Dict[str, Any],
                         trigger: str) -> Dict[str, Any]:
        if not agent_id or not to_agent_id:
            return {"ok": False, "error": "Missing agent_id or to_agent_id"}
        self.bus.broadcast("handoff", {
            "from_agent_id": agent_id,
            "to_agent_id": to_agent_id,
            "session_id": session_id,
            "context": context,
            "trigger": trigger,
        })
        self.logger.log("handoff", {
            "from_agent_id": agent_id,
            "to_agent_id": to_agent_id,
            "session_id": session_id,
            "context": context,
            "trigger": trigger,
        })
        return {"ok": True, "to_agent_id": to_agent_id, "trigger": trigger}

    def status(self) -> Dict[str, Any]:
        return {
            "ok": True,
            "nexus": "running",
            "http_port": self.port,
            "ws_port": self.ws_port,
            "agents": len(self.agents.list(include_offline=False)),
            "tasks": {
                "pending": len(self.tasks.list(status="pending")),
                "claimed": len(self.tasks.list(status="claimed")),
                "running": len(self.tasks.list(status="running")),
                "done": len(self.tasks.list(status="done")),
                "failed": len(self.tasks.list(status="failed")),
            },
            "sessions": len(self.sessions.list()),
            "locks": len(self.locks.list()),
            "events": len(self.events.history(limit=1)),
            "clock": self.clock.status(),
            "bus": self.bus.get_stats(),
            "rag_available": _RAG_AVAILABLE,
            "mcp": self.mcp.status(),
            "internal_client": self.internal_client.status(),
            "graph": self._rag_graph.status() if self._rag_graph else {"edges": 0, "initialized": False},
            "committee": self.committee.status(),
            "governor": self.governor.status(),
            "alerting": self.alerting.status(),
            "metrics": self.metrics.status(),
            "telemetry": self.telemetry.status(),
            "remote": self.remote.status(),
            "provider_registry": self.provider_registry.summary(),
            "session_persistence": self.session_mgr.status(),
            "load_balancer": self.governor.get_load_balancer_status(),
            "multi_corpus": self._multi_corpus.status() if self._multi_corpus else {"available": False},
            "telemetry_ingestor": self._telemetry_ingestor.stats() if self._telemetry_ingestor else {"available": False},
            "agent_registrar": self._agent_registrar.status() if self._agent_registrar else {"available": False},
            "reasoning_map": self._reasoning_map.status() if self._reasoning_map else {"available": False},
            "time": _now_iso(),
        }

    def start(self) -> None:
        if self._server:
            return
        self._server = ThreadingHTTPServer(("127.0.0.1", self.port), NexusHandler)
        self._server.nexus = self
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()
        self.bus.start()
        # Start telemetry ingestion background thread
        if self._telemetry_ingestor:
            self._telemetry_ingestor.start()

    def stop(self) -> None:
        # Stop telemetry ingestion
        if self._telemetry_ingestor:
            self._telemetry_ingestor.stop()
        # Stop agent heartbeats
        if self._agent_registrar:
            self._agent_registrar.stop_heartbeats()
        self.bus.stop()
        if self._server:
            self._server.shutdown()
            self._server = None
        self._thread = None
        self.state.close()
        self.metrics.close()
        if self._rag_graph:
            self._rag_graph.close()
        # Close multi-corpus
        if self._multi_corpus:
            self._multi_corpus.close()
        self.telemetry.close()
        self.remote.close()
        self.session_mgr.close()
