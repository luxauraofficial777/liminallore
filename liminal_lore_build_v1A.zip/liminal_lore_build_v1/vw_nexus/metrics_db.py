"""Persistent metrics database for VW Nexus.

Stores time-series telemetry data in SQLite for dashboard charts and
historical analysis.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from typing import Any, Dict, List, Optional
from pathlib import Path


_SCHEMA = """
CREATE TABLE IF NOT EXISTS metrics (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp   REAL NOT NULL,
    metric_name TEXT NOT NULL,
    value       REAL NOT NULL,
    tags        TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_metrics_name_time ON metrics(metric_name, timestamp);
CREATE INDEX IF NOT EXISTS idx_metrics_time ON metrics(timestamp);

CREATE TABLE IF NOT EXISTS metric_snapshots (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp   REAL NOT NULL,
    snapshot    TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_snapshots_time ON metric_snapshots(timestamp);
"""


class MetricsDB:
    """Time-series metrics storage."""

    def __init__(self, db_path: Path):
        self.db_path = db_path
        self._lock = threading.RLock()
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(
            str(db_path),
            check_same_thread=False,
            isolation_level=None,
        )
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.executescript(_SCHEMA)

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    def record(self, metric_name: str, value: float, tags: Optional[Dict] = None) -> None:
        ts = time.time()
        with self._lock:
            self._conn.execute(
                "INSERT INTO metrics (timestamp, metric_name, value, tags) VALUES (?,?,?,?)",
                (ts, metric_name, value, json.dumps(tags or {})),
            )

    def record_snapshot(self, snapshot: Dict[str, Any]) -> None:
        ts = time.time()
        with self._lock:
            self._conn.execute(
                "INSERT INTO metric_snapshots (timestamp, snapshot) VALUES (?,?)",
                (ts, json.dumps(snapshot, default=str)),
            )

    def query(self, metric_name: str, seconds: int = 300,
              limit: int = 1000) -> List[Dict[str, Any]]:
        cutoff = time.time() - seconds
        with self._lock:
            rows = self._conn.execute(
                """SELECT timestamp, value, tags FROM metrics
                WHERE metric_name=? AND timestamp>=?
                ORDER BY timestamp ASC LIMIT ?""",
                (metric_name, cutoff, limit),
            ).fetchall()
        return [
            {"timestamp": r[0], "value": r[1], "tags": json.loads(r[2])}
            for r in rows
        ]

    def query_all(self, seconds: int = 300) -> Dict[str, List[Dict[str, Any]]]:
        cutoff = time.time() - seconds
        with self._lock:
            rows = self._conn.execute(
                """SELECT metric_name, timestamp, value, tags FROM metrics
                WHERE timestamp>=? ORDER BY timestamp ASC""",
                (cutoff,),
            ).fetchall()
        result: Dict[str, List[Dict[str, Any]]] = {}
        for r in rows:
            name = r[0]
            if name not in result:
                result[name] = []
            result[name].append({
                "timestamp": r[1],
                "value": r[2],
                "tags": json.loads(r[3]),
            })
        return result

    def get_snapshots(self, seconds: int = 300, limit: int = 100) -> List[Dict[str, Any]]:
        cutoff = time.time() - seconds
        with self._lock:
            rows = self._conn.execute(
                """SELECT timestamp, snapshot FROM metric_snapshots
                WHERE timestamp>=? ORDER BY timestamp DESC LIMIT ?""",
                (cutoff, limit),
            ).fetchall()
        return [
            {"timestamp": r[0], "data": json.loads(r[1])}
            for r in rows
        ]

    def prune(self, max_age_seconds: int = 86400) -> int:
        cutoff = time.time() - max_age_seconds
        with self._lock:
            cur = self._conn.execute("DELETE FROM metrics WHERE timestamp<?", (cutoff,))
            self._conn.execute("DELETE FROM metric_snapshots WHERE timestamp<?", (cutoff,))
            return cur.rowcount

    def status(self) -> Dict[str, Any]:
        with self._lock:
            count = self._conn.execute("SELECT COUNT(*) FROM metrics").fetchone()[0]
            snapshots = self._conn.execute("SELECT COUNT(*) FROM metric_snapshots").fetchone()[0]
            names = self._conn.execute(
                "SELECT DISTINCT metric_name FROM metrics"
            ).fetchall()
        return {
            "total_samples": count,
            "total_snapshots": snapshots,
            "metric_names": [n[0] for n in names],
        }
