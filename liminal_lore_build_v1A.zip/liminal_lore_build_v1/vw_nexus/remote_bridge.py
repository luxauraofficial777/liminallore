"""Remote worker bridge for VW Nexus.

Allows agents on remote machines to connect to the Nexus via
a simple HTTP relay protocol. Workers register, receive tasks,
report results, and sync state — all through the HTTP API.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from typing import Any, Dict, List, Optional


_SCHEMA = """
CREATE TABLE IF NOT EXISTS remote_workers (
    worker_id       TEXT PRIMARY KEY,
    name            TEXT NOT NULL DEFAULT '',
    endpoint        TEXT NOT NULL DEFAULT '',
    auth_token      TEXT NOT NULL DEFAULT '',
    capabilities    TEXT DEFAULT '[]',
    status          TEXT NOT NULL DEFAULT 'registered',
    last_heartbeat  TEXT DEFAULT '',
    tasks_completed INTEGER DEFAULT 0,
    tasks_failed    INTEGER DEFAULT 0,
    registered_at   TEXT DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_workers_status ON remote_workers(status);

CREATE TABLE IF NOT EXISTS worker_tasks (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    worker_id       TEXT NOT NULL,
    task_id         TEXT NOT NULL,
    assigned_at     TEXT DEFAULT '',
    completed_at    TEXT DEFAULT '',
    result          TEXT DEFAULT '',
    status          TEXT DEFAULT 'assigned'
);

CREATE INDEX IF NOT EXISTS idx_wtasks_worker ON worker_tasks(worker_id);
"""


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


class RemoteWorkerBridge:
    """Manages remote worker registration, task assignment, and result collection."""

    def __init__(self, db_path: Any):
        self.db_path = db_path
        self._lock = threading.RLock()
        self._conn: Optional[sqlite3.Connection] = None
        self._init_db()

    def _init_db(self) -> None:
        with self._lock:
            from pathlib import Path
            p = Path(self.db_path) if not isinstance(self.db_path, Path) else self.db_path
            p.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(str(p), check_same_thread=False)
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.executescript(_SCHEMA)
            self._conn.commit()

    def register_worker(
        self,
        name: str,
        endpoint: str = "",
        capabilities: Optional[List[str]] = None,
        auth_token: Optional[str] = None,
    ) -> Dict[str, Any]:
        worker_id = uuid.uuid4().hex[:12]
        token = auth_token or uuid.uuid4().hex[:24]
        with self._lock:
            self._conn.execute(
                """INSERT OR REPLACE INTO remote_workers
                   (worker_id, name, endpoint, auth_token, capabilities, status, registered_at)
                   VALUES (?, ?, ?, ?, ?, 'registered', ?)""",
                (worker_id, name, endpoint, token, json.dumps(capabilities or []), _now_iso()),
            )
            self._conn.commit()
        return {"worker_id": worker_id, "auth_token": token, "status": "registered"}

    def heartbeat(self, worker_id: str, status: str = "active") -> Dict[str, Any]:
        with self._lock:
            row = self._conn.execute(
                "SELECT worker_id FROM remote_workers WHERE worker_id = ?", (worker_id,)
            ).fetchone()
            if not row:
                return {"ok": False, "error": "Unknown worker"}
            self._conn.execute(
                "UPDATE remote_workers SET last_heartbeat = ?, status = ? WHERE worker_id = ?",
                (_now_iso(), status, worker_id),
            )
            self._conn.commit()
        return {"ok": True, "timestamp": _now_iso()}

    def assign_task(self, worker_id: str, task_id: str) -> Dict[str, Any]:
        with self._lock:
            row = self._conn.execute(
                "SELECT status FROM remote_workers WHERE worker_id = ?", (worker_id,)
            ).fetchone()
            if not row:
                return {"ok": False, "error": "Unknown worker"}
            if row[0] not in ("active", "registered"):
                return {"ok": False, "error": f"Worker not available (status={row[0]})"}
            self._conn.execute(
                """INSERT INTO worker_tasks (worker_id, task_id, assigned_at, status)
                   VALUES (?, ?, ?, 'assigned')""",
                (worker_id, task_id, _now_iso()),
            )
            self._conn.commit()
        return {"ok": True, "task_id": task_id, "worker_id": worker_id}

    def complete_task(self, worker_id: str, task_id: str, result: Any, success: bool = True) -> Dict[str, Any]:
        with self._lock:
            self._conn.execute(
                """UPDATE worker_tasks SET completed_at = ?, result = ?, status = ?
                   WHERE worker_id = ? AND task_id = ?""",
                (_now_iso(), json.dumps(result), "completed" if success else "failed", worker_id, task_id),
            )
            if success:
                self._conn.execute(
                    "UPDATE remote_workers SET tasks_completed = tasks_completed + 1 WHERE worker_id = ?",
                    (worker_id,),
                )
            else:
                self._conn.execute(
                    "UPDATE remote_workers SET tasks_failed = tasks_failed + 1 WHERE worker_id = ?",
                    (worker_id,),
                )
            self._conn.commit()
        return {"ok": True}

    def list_workers(self, status_filter: Optional[str] = None) -> List[Dict[str, Any]]:
        with self._lock:
            if status_filter:
                rows = self._conn.execute(
                    "SELECT * FROM remote_workers WHERE status = ? ORDER BY registered_at DESC",
                    (status_filter,),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT * FROM remote_workers ORDER BY registered_at DESC"
                ).fetchall()
        return [self._row_to_worker(r) for r in rows]

    def get_worker(self, worker_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM remote_workers WHERE worker_id = ?", (worker_id,)
            ).fetchone()
        return self._row_to_worker(row) if row else None

    def remove_worker(self, worker_id: str) -> bool:
        with self._lock:
            cur = self._conn.execute(
                "DELETE FROM remote_workers WHERE worker_id = ?", (worker_id,)
            )
            self._conn.execute(
                "DELETE FROM worker_tasks WHERE worker_id = ?", (worker_id,)
            )
            self._conn.commit()
            return cur.rowcount > 0

    def _row_to_worker(self, row) -> Dict[str, Any]:
        return {
            "worker_id": row[0],
            "name": row[1],
            "endpoint": row[2],
            "capabilities": json.loads(row[4]) if row[4] else [],
            "status": row[5],
            "last_heartbeat": row[6] or "",
            "tasks_completed": row[7],
            "tasks_failed": row[8],
            "registered_at": row[9] or "",
        }

    def status(self) -> Dict[str, Any]:
        with self._lock:
            total = self._conn.execute("SELECT COUNT(*) FROM remote_workers").fetchone()[0]
            active = self._conn.execute(
                "SELECT COUNT(*) FROM remote_workers WHERE status = 'active'"
            ).fetchone()[0]
            tasks_assigned = self._conn.execute(
                "SELECT COUNT(*) FROM worker_tasks WHERE status = 'assigned'"
            ).fetchone()[0]
            tasks_done = self._conn.execute(
                "SELECT COUNT(*) FROM worker_tasks WHERE status = 'completed'"
            ).fetchone()[0]
        return {
            "total_workers": total,
            "active_workers": active,
            "tasks_assigned": tasks_assigned,
            "tasks_completed": tasks_done,
        }

    def close(self) -> None:
        with self._lock:
            if self._conn:
                self._conn.close()
                self._conn = None
