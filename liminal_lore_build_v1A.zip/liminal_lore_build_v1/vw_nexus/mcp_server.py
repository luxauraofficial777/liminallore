"""MCP (Model Context Protocol) server module for VW Nexus.

Exposes Nexus capabilities as MCP tools so external clients (Claude Desktop,
Windsurf, Cascade, etc.) can query RAG, create/list tasks, read telemetry,
request file locks, and trigger builds.
"""

from __future__ import annotations

import json
import threading
import time
from typing import Any, Callable, Dict, List, Optional


# Tool registry: name -> {description, schema, handler, authority_required}
_TOOL_REGISTRY: Dict[str, Dict[str, Any]] = {}


def register_tool(
    name: str,
    description: str,
    schema: Dict[str, Any],
    handler: Callable[[Dict[str, Any]], Dict[str, Any]],
    authority_required: str = "read",
    rate_limit: int = 0,
) -> None:
    _TOOL_REGISTRY[name] = {
        "name": name,
        "description": description,
        "schema": schema,
        "handler": handler,
        "authority_required": authority_required,
        "rate_limit": rate_limit,
    }


def list_tools() -> List[Dict[str, Any]]:
    return [
        {
            "name": t["name"],
            "description": t["description"],
            "schema": t["schema"],
            "authority_required": t["authority_required"],
        }
        for t in _TOOL_REGISTRY.values()
    ]


def _validate_args(schema: Dict[str, Any], args: Dict[str, Any]) -> Optional[str]:
    """Validate args against tool schema. Returns error message or None if valid."""
    for param_name, param_spec in schema.items():
        if isinstance(param_spec, dict):
            is_required = param_spec.get("required", False)
            param_type = param_spec.get("type", "string")
            default = param_spec.get("default")
            if is_required and param_name not in args and default is None:
                return f"Missing required parameter: {param_name}"
            if param_name in args and args[param_name] is not None:
                val = args[param_name]
                type_map = {"string": str, "integer": int, "number": (int, float), "boolean": bool, "array": list, "object": dict}
                expected = type_map.get(param_type)
                if expected and not isinstance(val, expected):
                    return f"Parameter '{param_name}' must be {param_type}, got {type(val).__name__}"
    return None


def call_tool(name: str, args: Dict[str, Any], agent_id: str = "",
              authority: str = "read") -> Dict[str, Any]:
    tool = _TOOL_REGISTRY.get(name)
    if not tool:
        return {"ok": False, "error": f"Unknown tool: {name}"}
    auth_order = ["read", "suggest", "write", "execute", "deploy"]
    try:
        req_idx = auth_order.index(tool["authority_required"])
        have_idx = auth_order.index(authority)
    except ValueError:
        return {"ok": False, "error": f"Invalid authority level: {authority}"}
    if have_idx < req_idx:
        return {"ok": False, "error": f"Insufficient authority: requires {tool['authority_required']}, have {authority}"}
    validation_error = _validate_args(tool["schema"], args)
    if validation_error:
        return {"ok": False, "error": validation_error, "tool": name}
    try:
        result = tool["handler"](args)
        result.setdefault("ok", True)
        result.setdefault("tool", name)
        return result
    except Exception as e:
        return {"ok": False, "error": str(e), "tool": name}


class McpServer:
    """MCP server that manages tool registration and approval rules."""

    def __init__(self):
        self._lock = threading.RLock()
        self._auto_approve: List[Dict[str, Any]] = []
        self._pending_calls: List[Dict[str, Any]] = []
        self._call_log: List[Dict[str, Any]] = []
        self._rate_limits: Dict[str, List[float]] = {}  # tool_name -> [timestamps]

    def add_auto_approve_rule(self, tool_name: str, agent_id: str = "*",
                              path_pattern: str = "*") -> None:
        with self._lock:
            self._auto_approve.append({
                "tool": tool_name,
                "agent": agent_id,
                "path_pattern": path_pattern,
            })

    def _is_auto_approved(self, tool_name: str, agent_id: str) -> bool:
        for rule in self._auto_approve:
            if rule["tool"] == tool_name or rule["tool"] == "*":
                if rule["agent"] == agent_id or rule["agent"] == "*":
                    return True
        return False

    def _check_rate_limit(self, tool_name: str) -> bool:
        """Returns True if within rate limit, False if exceeded."""
        tool = _TOOL_REGISTRY.get(tool_name)
        if not tool or tool.get("rate_limit", 0) <= 0:
            return True
        limit = tool["rate_limit"]
        now = time.time()
        window = 60.0  # 1 minute window
        with self._lock:
            if tool_name not in self._rate_limits:
                self._rate_limits[tool_name] = []
            timestamps = self._rate_limits[tool_name]
            timestamps[:] = [t for t in timestamps if now - t < window]
            if len(timestamps) >= limit:
                return False
            timestamps.append(now)
            return True

    def request_call(self, tool_name: str, args: Dict[str, Any],
                     agent_id: str, authority: str = "read") -> Dict[str, Any]:
        if not self._check_rate_limit(tool_name):
            return {"ok": False, "error": f"Rate limit exceeded for tool: {tool_name}"}
        if self._is_auto_approved(tool_name, agent_id):
            result = call_tool(tool_name, args, agent_id, authority)
            self._log_call(tool_name, agent_id, args, result, approved=True, auto=True)
            return result
        with self._lock:
            call_id = f"MCPCALL_{len(self._pending_calls)}_{tool_name}"
            self._pending_calls.append({
                "call_id": call_id,
                "tool": tool_name,
                "args": args,
                "agent_id": agent_id,
                "authority": authority,
                "status": "pending",
            })
        return {"ok": False, "error": "Pending human approval", "call_id": call_id, "status": "pending"}

    def approve_call(self, call_id: str) -> Dict[str, Any]:
        with self._lock:
            for i, pc in enumerate(self._pending_calls):
                if pc["call_id"] == call_id:
                    result = call_tool(pc["tool"], pc["args"], pc["agent_id"], pc["authority"])
                    self._log_call(pc["tool"], pc["agent_id"], pc["args"], result, approved=True, auto=False)
                    self._pending_calls.pop(i)
                    return result
        return {"ok": False, "error": "Call not found"}

    def deny_call(self, call_id: str, reason: str = "") -> Dict[str, Any]:
        with self._lock:
            for i, pc in enumerate(self._pending_calls):
                if pc["call_id"] == call_id:
                    self._log_call(pc["tool"], pc["agent_id"], pc["args"],
                                   {"ok": False, "error": f"Denied: {reason}"}, approved=False, auto=False)
                    self._pending_calls.pop(i)
                    return {"ok": True, "denied": True}
        return {"ok": False, "error": "Call not found"}

    def pending_calls(self) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self._pending_calls)

    def call_log(self, limit: int = 100) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self._call_log[-limit:])

    def _log_call(self, tool: str, agent_id: str, args: Dict, result: Dict,
                  approved: bool, auto: bool) -> None:
        with self._lock:
            self._call_log.append({
                "tool": tool,
                "agent_id": agent_id,
                "args": args,
                "result": result,
                "approved": approved,
                "auto_approved": auto,
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            })
            if len(self._call_log) > 1000:
                self._call_log = self._call_log[-500:]

    def status(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "tools_registered": len(_TOOL_REGISTRY),
                "auto_approve_rules": len(self._auto_approve),
                "pending_calls": len(self._pending_calls),
                "total_calls_logged": len(self._call_log),
                "rate_limited_tools": sum(1 for t in _TOOL_REGISTRY.values() if t.get("rate_limit", 0) > 0),
            }


def register_default_tools(nexus: Any) -> None:
    """Register the standard set of Nexus MCP tools."""

    def _rag_query(args: Dict) -> Dict:
        result = nexus.rag_query(
            query=args.get("query", ""),
            max_chunks=args.get("max_chunks", 20),
            max_bytes=args.get("max_bytes", 200000),
            tags=args.get("tags"),
        )
        return result

    def _rag_index(args: Dict) -> Dict:
        return nexus.rag_index(force=args.get("force", False))

    def _rag_status(args: Dict) -> Dict:
        return nexus.rag_status()

    def _create_task(args: Dict) -> Dict:
        task = nexus.tasks.create(
            title=args.get("title", "Untitled"),
            description=args.get("description", ""),
            agent_id=args.get("agent_id"),
            dependencies=args.get("dependencies", []),
            priority=args.get("priority", 5),
            metadata=args.get("metadata", {}),
        )
        nexus.events.publish("task_created", task_id=task.task_id, payload={"title": task.title})
        return task.to_dict()

    def _list_tasks(args: Dict) -> Dict:
        tasks = nexus.tasks.list(status=args.get("status"))
        return {"tasks": [t.to_dict() for t in tasks]}

    def _list_agents(args: Dict) -> Dict:
        agents = nexus.agents.list(include_offline=args.get("include_offline", False))
        return {"agents": [a.to_dict() for a in agents]}

    def _request_lock(args: Dict) -> Dict:
        return nexus.locks.request(
            agent_id=args.get("agent_id", ""),
            path=args.get("path", ""),
            intent=args.get("intent", ""),
            ttl_seconds=args.get("ttl_seconds", 1800),
        )

    def _get_telemetry(args: Dict) -> Dict:
        return nexus.status()

    def _broadcast(args: Dict) -> Dict:
        event = nexus.events.publish(
            event_type=args.get("event_type", "broadcast"),
            agent_id=args.get("agent_id"),
            payload=args.get("payload", {}),
        )
        return event.to_dict()

    register_tool("rag_query", "Search the RAG index for relevant code/docs",
                  {"query": {"type": "string", "required": True},
                   "max_chunks": {"type": "integer", "default": 20}},
                  _rag_query, "read", rate_limit=30)

    register_tool("rag_index", "Trigger RAG re-indexing",
                  {"force": {"type": "boolean", "default": False}},
                  _rag_index, "execute", rate_limit=2)

    register_tool("rag_status", "Get RAG index status and stats",
                  {}, _rag_status, "read", rate_limit=60)

    register_tool("create_task", "Create a new task in the Nexus task queue",
                  {"title": {"type": "string", "required": True},
                   "description": {"type": "string"},
                   "agent_id": {"type": "string"},
                   "dependencies": {"type": "array", "items": {"type": "string"}},
                   "priority": {"type": "integer", "default": 5}},
                  _create_task, "write", rate_limit=20)

    register_tool("list_tasks", "List tasks, optionally filtered by status",
                  {"status": {"type": "string"}},
                  _list_tasks, "read", rate_limit=60)

    register_tool("list_agents", "List registered agents",
                  {"include_offline": {"type": "boolean", "default": False}},
                  _list_agents, "read", rate_limit=60)

    register_tool("request_lock", "Request a file lock",
                  {"agent_id": {"type": "string", "required": True},
                   "path": {"type": "string", "required": True},
                   "intent": {"type": "string"},
                   "ttl_seconds": {"type": "integer", "default": 1800}},
                  _request_lock, "write", rate_limit=20)

    register_tool("get_telemetry", "Get Nexus status and telemetry",
                  {}, _get_telemetry, "read", rate_limit=60)

    register_tool("broadcast", "Broadcast an event on the Nexus bus",
                  {"event_type": {"type": "string", "required": True},
                   "agent_id": {"type": "string"},
                   "payload": {"type": "object"}},
                  _broadcast, "write", rate_limit=30)
