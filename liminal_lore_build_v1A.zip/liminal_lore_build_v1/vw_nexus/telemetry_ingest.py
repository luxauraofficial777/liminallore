"""Real-time telemetry ingestion service for VW Nexus.

Watches telemetry output directories from testing harnesses
(CyberGrime PSX, VW64 X64 engine) and ingests telemetry JSON
files into the multi-corpus vector DB as searchable chunks.

Runs as a background thread inside the Nexus process. Polls
configured directories at a configurable interval (default 5s).
"""

from __future__ import annotations

import json
import os
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Callable


_HARNESS_SOURCES = {
    "dq_cybergrime": {
        "name": "CyberGrime PSX Harness",
        "telemetry_dirs": [
            "C:/LuxAura/VoidWalkers_Project/DQLOSTTRANSLATION/telemetry",
            "C:/LuxAura/VoidWalkers_Project/DQLOSTTRANSLATION",
        ],
        "patterns": ["telemetry_*.json", "telemetry*.json"],
        "corpus_id": "dq_cybergrime",
        "max_files": 500,
    },
    "dq_triage": {
        "name": "CyberGrime Triage Logs",
        "telemetry_dirs": [
            "C:/LuxAura/VoidWalkers_Project",
            "C:/LuxAura/VoidWalkers_Project/DQLOSTTRANSLATION",
        ],
        "patterns": ["emulator_triage_*.log", "emulator_triage_*.json"],
        "corpus_id": "dq_cybergrime",
        "max_files": 200,
    },
    "vw_x64": {
        "name": "VW64 X64 Engine Harness",
        "telemetry_dirs": [
            "C:/LuxAura/VoidWalkers_Project/Modern_X64/tools/simulation",
            "C:/LuxAura/VoidWalkers_Project/Modern_X64/tools/study",
            "C:/LuxAura/VoidWalkers_Project/Modern_X64/study",
        ],
        "patterns": ["*.json", "*.log", "*.txt"],
        "corpus_id": "vw_x64",
        "max_files": 200,
    },
}


class TelemetryIngestor:
    """Background service that ingests harness telemetry into the vector DB."""

    def __init__(self, multi_corpus: Any, poll_interval: float = 5.0,
                 sources: Optional[Dict[str, Dict]] = None):
        self.multi_corpus = multi_corpus
        self.poll_interval = poll_interval
        self.sources = sources or _HARNESS_SOURCES
        self._thread: Optional[threading.Thread] = None
        self._running = False
        self._processed_files: Dict[str, float] = {}
        self._max_processed = 5000
        self._stats = {
            "total_ingested": 0,
            "total_errors": 0,
            "last_ingest": None,
            "per_source": {},
        }
        self._lock = threading.RLock()
        self._on_ingest: Optional[Callable[[str, Dict], None]] = None

    def set_on_ingest_callback(self, callback: Callable[[str, Dict], None]) -> None:
        self._on_ingest = callback

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run, daemon=True, name="telemetry-ingest")
        self._thread.start()

    def stop(self) -> None:
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)
        self._thread = None

    def _run(self) -> None:
        while self._running:
            try:
                self._poll_once()
            except Exception as e:
                print(f"[telemetry_ingest] Poll error: {e}")
            time.sleep(self.poll_interval)

    def _poll_once(self) -> None:
        for source_id, source_cfg in self.sources.items():
            corpus_id = source_cfg.get("corpus_id", source_id)
            for dir_path_str in source_cfg.get("telemetry_dirs", []):
                dir_path = Path(dir_path_str)
                if not dir_path.exists():
                    continue
                for pattern in source_cfg.get("patterns", ["*.json"]):
                    max_files = source_cfg.get("max_files", 200)
                    count = 0
                    try:
                        matched = sorted(
                            dir_path.glob(pattern),
                            key=lambda p: p.stat().st_mtime if p.exists() else 0,
                            reverse=True,
                        )
                    except Exception:
                        continue
                    for f in matched:
                        if count >= max_files:
                            break
                        if not f.is_file():
                            continue
                        try:
                            mtime = f.stat().st_mtime
                        except Exception:
                            continue
                        file_key = str(f)
                        if file_key in self._processed_files and self._processed_files[file_key] >= mtime:
                            continue

                        result = self._ingest_file(source_id, corpus_id, f)
                        if result.get("ok"):
                            with self._lock:
                                self._processed_files[file_key] = mtime
                                self._stats["total_ingested"] += 1
                                self._stats["last_ingest"] = datetime.now(timezone.utc).isoformat()
                                per_src = self._stats["per_source"].setdefault(source_id, {"ingested": 0, "errors": 0})
                                per_src["ingested"] += 1
                                if len(self._processed_files) > self._max_processed:
                                    sorted_keys = sorted(self._processed_files, key=lambda k: self._processed_files[k])
                                    for k in sorted_keys[:self._max_processed // 2]:
                                        del self._processed_files[k]
                        else:
                            with self._lock:
                                self._stats["total_errors"] += 1
                                per_src = self._stats["per_source"].setdefault(source_id, {"ingested": 0, "errors": 0})
                                per_src["errors"] += 1
                        count += 1

    def _ingest_file(self, source_id: str, corpus_id: str, file_path: Path) -> Dict[str, Any]:
        try:
            text = file_path.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            return {"ok": False, "error": f"Read error: {e}"}

        if not text.strip():
            return {"ok": False, "error": "Empty file"}

        telemetry_data: Dict[str, Any]
        if file_path.suffix == ".json":
            try:
                telemetry_data = json.loads(text)
            except Exception:
                telemetry_data = {"raw_text": text[:8000], "source_file": str(file_path)}
        else:
            telemetry_data = {
                "raw_text": text[:8000],
                "source_file": str(file_path),
                "source_id": source_id,
                "file_size": len(text),
            }

        telemetry_data["_meta"] = {
            "source_id": source_id,
            "source_file": str(file_path),
            "ingested_at": datetime.now(timezone.utc).isoformat(),
        }

        result = self.multi_corpus.ingest_telemetry(corpus_id, telemetry_data)

        if self._on_ingest and result.get("ok"):
            self._on_ingest(corpus_id, telemetry_data)

        return result

    def ingest_manual(self, corpus_id: str, telemetry: Dict[str, Any]) -> Dict[str, Any]:
        result = self.multi_corpus.ingest_telemetry(corpus_id, telemetry)
        if result.get("ok"):
            with self._lock:
                self._stats["total_ingested"] += 1
                self._stats["last_ingest"] = datetime.now(timezone.utc).isoformat()
                self._stats["per_source"].setdefault("manual", {"ingested": 0, "errors": 0})["ingested"] += 1
        return result

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "running": self._running,
                "poll_interval": self.poll_interval,
                "processed_files": len(self._processed_files),
                **self._stats,
                "sources": {
                    sid: {
                        "name": s.get("name", sid),
                        "corpus_id": s.get("corpus_id", sid),
                        "dirs": s.get("telemetry_dirs", []),
                        "patterns": s.get("patterns", []),
                    }
                    for sid, s in self.sources.items()
                },
            }

    def add_source(self, source_id: str, config: Dict[str, Any]) -> Dict[str, Any]:
        self.sources[source_id] = config
        return {"ok": True, "source_id": source_id}

    def remove_source(self, source_id: str) -> Dict[str, Any]:
        self.sources.pop(source_id, None)
        return {"ok": True, "source_id": source_id}
