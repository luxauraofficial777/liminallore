"""Task queue with DAG dependency tracking and parallel scheduling."""

from __future__ import annotations

import threading
from typing import Dict, List, Optional, Set

from .models import Task, TaskStatus, _now_iso


class TaskQueue:
    """Thread-safe task queue with dependency resolution."""

    def __init__(self):
        self._tasks: Dict[str, Task] = {}
        self._lock = threading.RLock()
        self._counter = 0

    def create(self, title: str, description: str = "", agent_id: Optional[str] = None,
               dependencies: Optional[List[str]] = None, priority: int = 5,
               metadata: Optional[Dict] = None) -> Task:
        with self._lock:
            task = Task(
                title=title,
                description=description,
                agent_id=agent_id,
                dependencies=dependencies or [],
                priority=priority,
                metadata=metadata or {},
            )
            self._tasks[task.task_id] = task
            return task

    def get(self, task_id: str) -> Optional[Task]:
        with self._lock:
            return self._tasks.get(task_id)

    def list(self, status: Optional[str] = None) -> List[Task]:
        with self._lock:
            tasks = list(self._tasks.values())
        if status:
            tasks = [t for t in tasks if t.status == status]
        return sorted(tasks, key=lambda t: (-t.priority, t.created))

    def claim(self, task_id: str, agent_id: str) -> Optional[Task]:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return None
            if task.status != TaskStatus.PENDING.value:
                return None
            if not self._dependencies_satisfied(task):
                return None
            task.status = TaskStatus.CLAIMED.value
            task.agent_id = agent_id
            task.started = _now_iso()
            return task

    def start(self, task_id: str, agent_id: str) -> Optional[Task]:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task or task.agent_id != agent_id:
                return None
            if task.status in (TaskStatus.CLAIMED.value, TaskStatus.PENDING.value):
                task.status = TaskStatus.RUNNING.value
                return task
            return None

    def complete(self, task_id: str, agent_id: str, result: Optional[Dict] = None,
                 artifacts: Optional[List[str]] = None) -> Optional[Task]:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task or task.agent_id != agent_id:
                return None
            if task.status not in (TaskStatus.CLAIMED.value, TaskStatus.RUNNING.value):
                return None
            task.status = TaskStatus.DONE.value
            task.finished = _now_iso()
            task.result = result
            if artifacts:
                task.artifacts.extend(artifacts)
            return task

    def fail(self, task_id: str, agent_id: str, error: str) -> Optional[Task]:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task or task.agent_id != agent_id:
                return None
            task.status = TaskStatus.FAILED.value
            task.finished = _now_iso()
            task.result = {"error": error}
            return task

    def cancel(self, task_id: str) -> Optional[Task]:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return None
            if task.status == TaskStatus.DONE.value:
                return None
            task.status = TaskStatus.CANCELLED.value
            task.finished = _now_iso()
            return task

    def get_ready_tasks(self) -> List[Task]:
        with self._lock:
            tasks = [t for t in self._tasks.values()
                     if t.status == TaskStatus.PENDING.value and self._dependencies_satisfied(t)]
        return sorted(tasks, key=lambda t: (-t.priority, t.created))

    def get_next_for_agent(self, agent_id: str, capabilities: List[str]) -> Optional[Task]:
        ready = self.get_ready_tasks()
        for task in ready:
            if task.agent_id and task.agent_id != agent_id:
                continue
            if not self._agent_can_do(task, capabilities):
                continue
            return task
        return None

    def _dependencies_satisfied(self, task: Task) -> bool:
        for dep_id in task.dependencies:
            dep = self._tasks.get(dep_id)
            if not dep or dep.status != TaskStatus.DONE.value:
                return False
        return True

    def _agent_can_do(self, task: Task, capabilities: List[str]) -> bool:
        required = task.metadata.get("required_capabilities", [])
        if not required:
            return True
        return all(cap in capabilities for cap in required)

    def _tasks_blocking(self, task_id: str) -> List[str]:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return []
            return [tid for tid in task.dependencies
                    if self._tasks.get(tid) and self._tasks[tid].status != TaskStatus.DONE.value]
