"""OpenTelemetry-style span export for VW Nexus.

Provides distributed tracing spans for all Nexus operations —
MCP calls, RAG queries, committee sessions, governor actions,
task lifecycle, and agent interactions. Spans are stored in
SQLite and can be exported in OTLP-compatible JSON format.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from typing import Any, Dict, List, Optional


_SCHEMA = """
CREATE TABLE IF NOT EXISTS spans (
    span_id         TEXT PRIMARY KEY,
    trace_id        TEXT NOT NULL,
    parent_span_id  TEXT,
    name            TEXT NOT NULL,
    kind            TEXT NOT NULL DEFAULT 'internal',
    start_time_ns   INTEGER NOT NULL,
    end_time_ns     INTEGER,
    duration_ns     INTEGER,
    status          TEXT NOT NULL DEFAULT 'ok',
    status_message  TEXT DEFAULT '',
    attributes      TEXT DEFAULT '{}',
    events          TEXT DEFAULT '[]',
    resource        TEXT DEFAULT '{}',
    agent_id        TEXT DEFAULT '',
    created_at      TEXT DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_spans_trace ON spans(trace_id);
CREATE INDEX IF NOT EXISTS idx_spans_name ON spans(name);
CREATE INDEX IF NOT EXISTS idx_spans_agent ON spans(agent_id);
CREATE INDEX IF NOT EXISTS idx_spans_time ON spans(start_time_ns);

CREATE TABLE IF NOT EXISTS traces (
    trace_id        TEXT PRIMARY KEY,
    root_span_id    TEXT,
    span_count      INTEGER DEFAULT 0,
    created_at      TEXT DEFAULT '',
    description     TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS audit_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp       TEXT NOT NULL,
    actor           TEXT NOT NULL,
    action          TEXT NOT NULL,
    target          TEXT DEFAULT '',
    decision        TEXT NOT NULL DEFAULT 'allow',
    reason          TEXT DEFAULT '',
    context         TEXT DEFAULT '{}',
    span_id         TEXT DEFAULT '',
    immutable_hash  TEXT DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_audit_time ON audit_log(timestamp);
CREATE INDEX IF NOT EXISTS idx_audit_actor ON audit_log(actor);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_log(action);
"""


def _now_ns() -> int:
    return int(time.time_ns())


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _hash_entry(entry: str) -> str:
    import hashlib
    return hashlib.sha256(entry.encode()).hexdigest()[:16]


class Span:
    """A single tracing span."""

    def __init__(
        self,
        name: str,
        trace_id: Optional[str] = None,
        parent_span_id: Optional[str] = None,
        kind: str = "internal",
        agent_id: str = "",
        attributes: Optional[Dict[str, Any]] = None,
    ):
        self.span_id = uuid.uuid4().hex[:16]
        self.trace_id = trace_id or uuid.uuid4().hex[:32]
        self.parent_span_id = parent_span_id
        self.name = name
        self.kind = kind
        self.start_time_ns = _now_ns()
        self.end_time_ns: Optional[int] = None
        self.duration_ns: Optional[int] = None
        self.status = "ok"
        self.status_message = ""
        self.attributes = attributes or {}
        self.events: List[Dict[str, Any]] = []
        self.agent_id = agent_id
        self.resource: Dict[str, Any] = {}

    def set_attribute(self, key: str, value: Any) -> None:
        self.attributes[key] = value

    def add_event(self, name: str, attributes: Optional[Dict[str, Any]] = None) -> None:
        self.events.append({
            "name": name,
            "timestamp_ns": _now_ns(),
            "attributes": attributes or {},
        })

    def set_status(self, status: str, message: str = "") -> None:
        self.status = status
        self.status_message = message

    def end(self) -> None:
        self.end_time_ns = _now_ns()
        self.duration_ns = self.end_time_ns - self.start_time_ns

    def to_dict(self) -> Dict[str, Any]:
        return {
            "span_id": self.span_id,
            "trace_id": self.trace_id,
            "parent_span_id": self.parent_span_id,
            "name": self.name,
            "kind": self.kind,
            "start_time_ns": self.start_time_ns,
            "end_time_ns": self.end_time_ns,
            "duration_ns": self.duration_ns,
            "duration_ms": (self.duration_ns / 1e6) if self.duration_ns else None,
            "status": self.status,
            "status_message": self.status_message,
            "attributes": self.attributes,
            "events": self.events,
            "resource": self.resource,
            "agent_id": self.agent_id,
        }

    def to_otlp(self) -> Dict[str, Any]:
        """Convert to OTLP-compatible JSON format."""
        return {
            "traceId": self.trace_id,
            "spanId": self.span_id,
            "parentSpanId": self.parent_span_id,
            "name": self.name,
            "kind": f"SPAN_KIND_{self.kind.upper()}",
            "startTimeUnixNano": str(self.start_time_ns),
            "endTimeUnixNano": str(self.end_time_ns) if self.end_time_ns else "",
            "status": {
                "code": "STATUS_CODE_OK" if self.status == "ok" else "STATUS_CODE_ERROR",
                "message": self.status_message,
            },
            "attributes": [
                {"key": k, "value": {"stringValue": str(v)}}
                for k, v in self.attributes.items()
            ],
            "events": [
                {
                    "name": e["name"],
                    "timeUnixNano": str(e["timestamp_ns"]),
                    "attributes": [
                        {"key": k, "value": {"stringValue": str(v)}}
                        for k, v in e.get("attributes", {}).items()
                    ],
                }
                for e in self.events
            ],
        }


class TelemetryExporter:
    """Manages tracing spans and audit log entries with SQLite persistence."""

    def __init__(self, db_path: Any):
        self.db_path = db_path
        self._lock = threading.RLock()
        self._conn: Optional[sqlite3.Connection] = None
        self._active_spans: Dict[str, Span] = {}
        self._init_db()

    def _init_db(self) -> None:
        with self._lock:
            from pathlib import Path
            p = Path(self.db_path) if not isinstance(self.db_path, Path) else self.db_path
            p.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(str(p), check_same_thread=False)
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._conn.executescript(_SCHEMA)
            self._conn.commit()

    def start_span(
        self,
        name: str,
        trace_id: Optional[str] = None,
        parent_span_id: Optional[str] = None,
        kind: str = "internal",
        agent_id: str = "",
        attributes: Optional[Dict[str, Any]] = None,
    ) -> Span:
        span = Span(
            name=name,
            trace_id=trace_id,
            parent_span_id=parent_span_id,
            kind=kind,
            agent_id=agent_id,
            attributes=attributes,
        )
        span.resource = {"service.name": "vw-nexus", "service.version": "1.0"}
        with self._lock:
            self._active_spans[span.span_id] = span
        return span

    def end_span(self, span: Span, status: str = "ok", message: str = "") -> None:
        if status != "ok":
            span.set_status(status, message)
        span.end()
        with self._lock:
            self._store_span(span)
            self._active_spans.pop(span.span_id, None)

    def _store_span(self, span: Span) -> None:
        self._conn.execute(
            """INSERT OR REPLACE INTO spans
               (span_id, trace_id, parent_span_id, name, kind,
                start_time_ns, end_time_ns, duration_ns, status, status_message,
                attributes, events, resource, agent_id, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                span.span_id, span.trace_id, span.parent_span_id,
                span.name, span.kind,
                span.start_time_ns, span.end_time_ns, span.duration_ns,
                span.status, span.status_message,
                json.dumps(span.attributes), json.dumps(span.events),
                json.dumps(span.resource), span.agent_id, _now_iso(),
            ),
        )
        self._conn.execute(
            """INSERT OR IGNORE INTO traces (trace_id, root_span_id, created_at, description)
               VALUES (?, ?, ?, ?)""",
            (span.trace_id, span.span_id if not span.parent_span_id else "", _now_iso(), span.name),
        )
        self._conn.execute(
            "UPDATE traces SET span_count = span_count + 1 WHERE trace_id = ?",
            (span.trace_id,),
        )
        self._conn.commit()

    def get_span(self, span_id: str) -> Optional[Dict[str, Any]]:
        row = self._conn.execute(
            "SELECT * FROM spans WHERE span_id = ?", (span_id,)
        ).fetchone()
        if not row:
            return None
        return self._row_to_span_dict(row)

    def get_trace(self, trace_id: str) -> Dict[str, Any]:
        trace_row = self._conn.execute(
            "SELECT * FROM traces WHERE trace_id = ?", (trace_id,)
        ).fetchone()
        span_rows = self._conn.execute(
            "SELECT * FROM spans WHERE trace_id = ? ORDER BY start_time_ns", (trace_id,)
        ).fetchall()
        spans = [self._row_to_span_dict(r) for r in span_rows]
        return {
            "trace_id": trace_id,
            "root_span_id": trace_row[1] if trace_row else "",
            "span_count": trace_row[2] if trace_row else 0,
            "created_at": trace_row[3] if trace_row else "",
            "description": trace_row[4] if trace_row else "",
            "spans": spans,
        }

    def list_traces(self, limit: int = 50) -> List[Dict[str, Any]]:
        rows = self._conn.execute(
            "SELECT trace_id, root_span_id, span_count, created_at, description FROM traces ORDER BY created_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [
            {"trace_id": r[0], "root_span_id": r[1], "span_count": r[2], "created_at": r[3], "description": r[4]}
            for r in rows
        ]

    def list_spans(self, limit: int = 100, name_filter: Optional[str] = None,
                   agent_filter: Optional[str] = None) -> List[Dict[str, Any]]:
        sql = "SELECT * FROM spans"
        conditions = []
        params = []
        if name_filter:
            conditions.append("name LIKE ?")
            params.append(f"%{name_filter}%")
        if agent_filter:
            conditions.append("agent_id = ?")
            params.append(agent_filter)
        if conditions:
            sql += " WHERE " + " AND ".join(conditions)
        sql += " ORDER BY start_time_ns DESC LIMIT ?"
        params.append(limit)
        rows = self._conn.execute(sql, params).fetchall()
        return [self._row_to_span_dict(r) for r in rows]

    def export_otlp(self, trace_id: Optional[str] = None, limit: int = 100) -> Dict[str, Any]:
        """Export spans in OTLP-compatible JSON format."""
        if trace_id:
            spans = self.get_trace(trace_id)["spans"]
        else:
            spans = self.list_spans(limit=limit)
        return {
            "resourceSpans": [{
                "resource": {
                    "attributes": [{"key": "service.name", "value": {"stringValue": "vw-nexus"}}]
                },
                "scopeSpans": [{
                    "scope": {"name": "vw-nexus", "version": "1.0"},
                    "spans": [Span(
                        name=s["name"],
                        trace_id=s["trace_id"],
                        parent_span_id=s.get("parent_span_id"),
                    ).to_otlp() for s in spans],
                }],
            }],
        }

    def _row_to_span_dict(self, row) -> Dict[str, Any]:
        return {
            "span_id": row[0],
            "trace_id": row[1],
            "parent_span_id": row[2],
            "name": row[3],
            "kind": row[4],
            "start_time_ns": row[5],
            "end_time_ns": row[6],
            "duration_ns": row[7],
            "duration_ms": (row[7] / 1e6) if row[7] else None,
            "status": row[8],
            "status_message": row[9],
            "attributes": json.loads(row[10]) if row[10] else {},
            "events": json.loads(row[11]) if row[11] else [],
            "resource": json.loads(row[12]) if row[12] else {},
            "agent_id": row[13] or "",
            "created_at": row[14] or "",
        }

    # ── Audit Log ───────────────────────────────────────────────

    def audit(
        self,
        actor: str,
        action: str,
        target: str = "",
        decision: str = "allow",
        reason: str = "",
        context: Optional[Dict[str, Any]] = None,
        span_id: str = "",
    ) -> str:
        """Record an immutable audit log entry."""
        ts = _now_iso()
        ctx = json.dumps(context or {})
        entry_str = f"{ts}|{actor}|{action}|{target}|{decision}|{reason}|{span_id}"
        imm_hash = _hash_entry(entry_str)
        with self._lock:
            self._conn.execute(
                """INSERT INTO audit_log
                   (timestamp, actor, action, target, decision, reason, context, span_id, immutable_hash)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (ts, actor, action, target, decision, reason, ctx, span_id, imm_hash),
            )
            self._conn.commit()
        return imm_hash

    def query_audit(
        self,
        actor: Optional[str] = None,
        action: Optional[str] = None,
        limit: int = 100,
        since: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        sql = "SELECT * FROM audit_log"
        conditions = []
        params = []
        if actor:
            conditions.append("actor = ?")
            params.append(actor)
        if action:
            conditions.append("action = ?")
            params.append(action)
        if since:
            conditions.append("timestamp >= ?")
            params.append(since)
        if conditions:
            sql += " WHERE " + " AND ".join(conditions)
        sql += " ORDER BY id DESC LIMIT ?"
        params.append(limit)
        rows = self._conn.execute(sql, params).fetchall()
        return [
            {
                "id": r[0],
                "timestamp": r[1],
                "actor": r[2],
                "action": r[3],
                "target": r[4],
                "decision": r[5],
                "reason": r[6],
                "context": json.loads(r[7]) if r[7] else {},
                "span_id": r[8] or "",
                "hash": r[9] or "",
            }
            for r in rows
        ]

    def verify_audit_integrity(self) -> Dict[str, Any]:
        """Verify that no audit entries have been tampered with."""
        rows = self._conn.execute(
            "SELECT id, timestamp, actor, action, target, decision, reason, span_id, immutable_hash FROM audit_log"
        ).fetchall()
        verified = 0
        tampered = 0
        for r in rows:
            entry_str = f"{r[1]}|{r[2]}|{r[3]}|{r[4]}|{r[5]}|{r[6]}|{r[7]}"
            expected = _hash_entry(entry_str)
            if expected == r[8]:
                verified += 1
            else:
                tampered += 1
        return {"verified": verified, "tampered": tampered, "total": verified + tampered}

    def status(self) -> Dict[str, Any]:
        with self._lock:
            span_count = self._conn.execute("SELECT COUNT(*) FROM spans").fetchone()[0]
            trace_count = self._conn.execute("SELECT COUNT(*) FROM traces").fetchone()[0]
            audit_count = self._conn.execute("SELECT COUNT(*) FROM audit_log").fetchone()[0]
            active_spans = len(self._active_spans)
        return {
            "total_spans": span_count,
            "total_traces": trace_count,
            "active_spans": active_spans,
            "audit_entries": audit_count,
        }

    def close(self) -> None:
        with self._lock:
            if self._conn:
                self._conn.close()
                self._conn = None
