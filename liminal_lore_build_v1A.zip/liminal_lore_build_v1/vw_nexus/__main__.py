"""Entry point for the VW Nexus."""

from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

from .api import NexusAPI


def main():
    parser = argparse.ArgumentParser(description="VW Nexus — Universal Orchestration Layer")
    parser.add_argument("--port", type=int, default=8651)
    parser.add_argument("--ws-port", type=int, default=8652)
    parser.add_argument("--project-root", type=Path, default=None)
    parser.add_argument("--forward-url", type=str, default=None)
    args = parser.parse_args()

    root = args.project_root or Path(os.environ.get(
        "VW_ROOT", "C:/LuxAura/VoidWalkers_Project/Modern_X64"
    ))

    try:
        nexus = NexusAPI(
            project_root=root,
            port=args.port,
            ws_port=args.ws_port,
            forward_url=args.forward_url,
        )
    except ImportError as e:
        print(f"Import error: {e}")
        print("Install required packages with: pip install websockets>=12.0")
        sys.exit(1)

    nexus.start()
    print(f"VW Nexus HTTP  running on http://127.0.0.1:{args.port}")
    print(f"VW Nexus WebSocket running on ws://127.0.0.1:{args.ws_port}")
    print("Press Ctrl+C to stop")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping Nexus...")
        nexus.stop()
        sys.exit(0)


if __name__ == "__main__":
    main()
