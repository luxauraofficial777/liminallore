"""FUBBU telemetry and orchestration tracking layer.

Provides lightweight logging, step tracking, and state mirroring for the
Router-Worker-Verifier loop. Every Think→Route→Delegate→Execute→Verify
step is recorded as a structured event with timing, token counts, and
status. Events are optionally mirrored to the Nexus event bus via HTTP.

Telemetry outputs:
  - JSONL step log (fubbu_steps.jsonl) — one event per line
  - Telemetry log file (fubbu_telemetry.log) — human-readable
  - Metrics SQLite DB (fubbu_metrics.db) — queryable time-series
  - Nexus event bus mirror — batched HTTP POST to /events
"""

from __future__ import annotations

import enum
import json
import sqlite3
import threading
import time
from collections import deque
from pathlib import Path
from typing import Any, Dict, List, Optional


class StepType(enum.Enum):
    THINK = "think"           # Router analyzes task
    ROUTE = "route"           # Router decomposes + assigns
    DELEGATE = "delegate"     # Router sends to worker
    EXECUTE = "execute"       # Worker runs inference
    VERIFY = "verify"         # Verifier checks output
    FEEDBACK = "feedback"     # Verifier sends rejection back
    COMPLETE = "complete"     # Task completed successfully
    FAIL = "fail"             # Task failed
    CHECKPOINT = "checkpoint" # State checkpoint
    HEARTBEAT = "heartbeat"   # Heartbeat to Nexus


class StepStatus(enum.Enum):
    STARTED = "started"
    SUCCESS = "success"
    FAILED = "failed"
    TIMEOUT = "timeout"
    SKIPPED = "skipped"


_SCHEMA = """
CREATE TABLE IF NOT EXISTS fubbu_metrics (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp       TEXT NOT NULL,
    task_id         TEXT NOT NULL DEFAULT '',
    iteration_id    TEXT NOT NULL DEFAULT '',
    step_type       TEXT NOT NULL,
    step_status     TEXT NOT NULL,
    agent_role      TEXT NOT NULL DEFAULT '',
    model           TEXT NOT NULL DEFAULT '',
    tokens_in       INTEGER NOT NULL DEFAULT 0,
    tokens_out      INTEGER NOT NULL DEFAULT 0,
    latency_ms      REAL NOT NULL DEFAULT 0.0,
    metadata        TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_metrics_task ON fubbu_metrics(task_id);
CREATE INDEX IF NOT EXISTS idx_metrics_step ON fubbu_metrics(step_type);
CREATE INDEX IF NOT EXISTS idx_metrics_ts ON fubbu_metrics(timestamp);
"""


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


class FubbuTelemetry:
    """Telemetry and step tracking for the FUBBU sidecar.

    Records every step in the Router-Worker-Verifier pipeline with
    structured metadata. Optionally mirrors events to Nexus event bus.
    """

    def __init__(
        self,
        log_path: str | Path = "tools/fubbu/data/fubbu_telemetry.log",
        metrics_db_path: str | Path = "tools/fubbu/data/fubbu_metrics.db",
        step_log_path: str | Path = "tools/fubbu/data/fubbu_steps.jsonl",
        mirror_to_nexus: bool = True,
        mirror_interval_s: int = 10,
        log_level: str = "INFO",
    ):
        self.log_path = Path(log_path)
        self.metrics_db_path = Path(metrics_db_path)
        self.step_log_path = Path(step_log_path)
        self.mirror_to_nexus = mirror_to_nexus
        self.mirror_interval_s = mirror_interval_s
        self.log_level = log_level

        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.metrics_db_path.parent.mkdir(parents=True, exist_ok=True)

        self._lock = threading.RLock()
        self._conn: Optional[sqlite3.Connection] = None
        self._step_buffer: deque = deque(maxlen=10000)
        self._nexus_client = None  # Set by sidecar for event mirroring
        self._last_mirror = 0.0
        self._init_db()

    def _init_db(self) -> None:
        with self._lock:
            self._conn = sqlite3.connect(
                str(self.metrics_db_path), check_same_thread=False
            )
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.executescript(_SCHEMA)
            self._conn.commit()

    def set_nexus_client(self, client) -> None:
        """Set the Nexus client for event mirroring."""
        self._nexus_client = client

    # ── Step Recording ────────────────────────────────────────

    def record_step(
        self,
        step_type: StepType,
        step_status: StepStatus,
        task_id: str = "",
        iteration_id: str = "",
        agent_role: str = "",
        model: str = "",
        tokens_in: int = 0,
        tokens_out: int = 0,
        latency_ms: float = 0.0,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Record a single step in the Router-Worker-Verifier pipeline."""
        event = {
            "timestamp": _now_iso(),
            "task_id": task_id,
            "iteration_id": iteration_id,
            "step_type": step_type.value,
            "step_status": step_status.value,
            "agent_role": agent_role,
            "model": model,
            "tokens_in": tokens_in,
            "tokens_out": tokens_out,
            "latency_ms": round(latency_ms, 2),
            "metadata": metadata or {},
        }

        with self._lock:
            # Write to JSONL step log
            with open(self.step_log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(event, default=str) + "\n")

            # Write to metrics DB
            self._conn.execute(
                """INSERT INTO fubbu_metrics
                   (timestamp, task_id, iteration_id, step_type, step_status,
                    agent_role, model, tokens_in, tokens_out, latency_ms, metadata)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    event["timestamp"], task_id, iteration_id,
                    step_type.value, step_status.value,
                    agent_role, model,
                    tokens_in, tokens_out, latency_ms,
                    json.dumps(metadata or {}),
                ),
            )
            self._conn.commit()

            # Buffer for Nexus mirroring
            self._step_buffer.append(event)

            # Human-readable log
            self._log_write(event)

        # Try mirror if interval elapsed
        self._maybe_mirror()
        return event

    def _log_write(self, event: Dict[str, Any]) -> None:
        level_map = {"STARTED": "INFO", "SUCCESS": "INFO", "FAILED": "WARN",
                     "TIMEOUT": "WARN", "SKIPPED": "DEBUG"}
        level = level_map.get(event["step_status"].upper(), "INFO")
        if level == "DEBUG" and self.log_level != "DEBUG":
            return
        line = (
            f"[{event['timestamp']}] [{level}] "
            f"step={event['step_type']} status={event['step_status']} "
            f"task={event['task_id']} role={event['agent_role']} "
            f"model={event['model']} tokens={event['tokens_in']}→{event['tokens_out']} "
            f"latency={event['latency_ms']}ms"
        )
        try:
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            pass

    def _maybe_mirror(self) -> None:
        if not self.mirror_to_nexus or not self._nexus_client:
            return
        now = time.time()
        if now - self._last_mirror < self.mirror_interval_s:
            return
        self._last_mirror = now
        with self._lock:
            if not self._step_buffer:
                return
            batch = list(self._step_buffer)
            self._step_buffer.clear()
        # Mirror to Nexus event bus (best-effort, non-blocking)
        try:
            self._nexus_client.post_event("telemetry_batch", {
                "events": batch,
                "count": len(batch),
            })
        except Exception:
            pass

    # ── Querying ──────────────────────────────────────────────

    def get_steps_for_task(self, task_id: str) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM fubbu_metrics WHERE task_id = ? ORDER BY id ASC",
                (task_id,),
            ).fetchall()
        return [self._row_to_metric(r) for r in rows]

    def get_recent_steps(self, limit: int = 50) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM fubbu_metrics ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        return [self._row_to_metric(r) for r in reversed(rows)]

    def get_step_summary(self, hours: int = 1) -> Dict[str, Any]:
        cutoff = time.strftime("%Y-%m-%dT%H:%M:%SZ",
                               time.gmtime(time.time() - hours * 3600))
        with self._lock:
            rows = self._conn.execute(
                "SELECT step_type, step_status, COUNT(*) as cnt, "
                "SUM(tokens_in) as tin, SUM(tokens_out) as tout, "
                "AVG(latency_ms) as avg_lat "
                "FROM fubbu_metrics WHERE timestamp >= ? "
                "GROUP BY step_type, step_status",
                (cutoff,),
            ).fetchall()
        summary = {}
        for r in rows:
            key = f"{r[0]}:{r[1]}"
            summary[key] = {
                "count": r[2],
                "tokens_in": r[3] or 0,
                "tokens_out": r[4] or 0,
                "avg_latency_ms": round(r[5] or 0, 2),
            }
        return summary

    def _row_to_metric(self, row) -> Dict[str, Any]:
        return {
            "id": row[0],
            "timestamp": row[1],
            "task_id": row[2],
            "iteration_id": row[3],
            "step_type": row[4],
            "step_status": row[5],
            "agent_role": row[6],
            "model": row[7],
            "tokens_in": row[8],
            "tokens_out": row[9],
            "latency_ms": row[10],
            "metadata": json.loads(row[11]) if row[11] else {},
        }

    # ── Status ────────────────────────────────────────────────

    def status(self) -> Dict[str, Any]:
        with self._lock:
            total = self._conn.execute("SELECT COUNT(*) FROM fubbu_metrics").fetchone()[0]
            buffered = len(self._step_buffer)
        return {
            "total_steps": total,
            "buffered_events": buffered,
            "mirror_enabled": self.mirror_to_nexus,
            "mirror_interval_s": self.mirror_interval_s,
            "log_path": str(self.log_path),
            "metrics_db": str(self.metrics_db_path),
            "step_log": str(self.step_log_path),
        }

    def close(self) -> None:
        with self._lock:
            if self._conn:
                self._conn.close()
                self._conn = None
