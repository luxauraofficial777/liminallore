"""FUBBU Nexus HTTP client.

Thin HTTP client that wraps the VW Nexus REST API for all FUBBU-to-Nexus
communication. This is the ONLY channel through which FUBBU touches Nexus
state — never shared DB, never shared memory, never imported Nexus modules.

All methods return dicts with {"ok": bool, ...} convention matching Nexus API.
"""

from __future__ import annotations

import json
import urllib.request
import urllib.error
from typing import Any, Dict, List, Optional


class FubbuNexusClient:
    """HTTP-only client for FUBBU ↔ Nexus communication.

    This client implements the clean API boundary between FUBBU and the
    core Nexus engine. FUBBU never directly accesses Nexus internals.
    """

    def __init__(self, nexus_url: str = "http://127.0.0.1:8651",
                 agent_id: str = "fubbu_router",
                 agent_name: str = "FUBBU",
                 provider: str = "ollama",
                 model: str = "qwen2.5-coder:7b",
                 capabilities: Optional[List[str]] = None):
        self.nexus_url = nexus_url.rstrip("/")
        self.agent_id = agent_id
        self.agent_name = agent_name
        self.provider = provider
        self.model = model
        self.capabilities = capabilities or [
            "low_level_debug", "mips_analysis", "binary_diff",
            "psx_emulator_debug", "code_review", "architecture_analysis",
        ]
        self._registered = False

    # ── Low-level HTTP ────────────────────────────────────────

    def _request(self, method: str, path: str,
                 data: Optional[Dict] = None,
                 timeout: int = 15) -> Dict[str, Any]:
        url = f"{self.nexus_url}{path}"
        try:
            payload = json.dumps(data).encode("utf-8") if data else None
            req = urllib.request.Request(
                url, data=payload, method=method,
                headers={"Content-Type": "application/json"} if payload else {},
            )
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.URLError as e:
            return {"ok": False, "error": f"Nexus unreachable: {e}"}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _get(self, path: str, timeout: int = 10) -> Dict[str, Any]:
        return self._request("GET", path, timeout=timeout)

    def _post(self, path: str, data: Dict[str, Any], timeout: int = 15) -> Dict[str, Any]:
        return self._request("POST", path, data=data, timeout=timeout)

    def _delete(self, path: str, data: Optional[Dict] = None) -> Dict[str, Any]:
        return self._request("DELETE", path, data=data)

    # ── Agent Lifecycle ───────────────────────────────────────

    def register(self) -> Dict[str, Any]:
        result = self._post("/agents", {
            "agent_id": self.agent_id,
            "name": self.agent_name,
            "provider": self.provider,
            "model": self.model,
            "capabilities": self.capabilities,
            "session_id": "fubbu",
            "state": "idle",
            "metadata": {
                "type": "fubbu_sidecar",
                "version": "1.0.0",
                "isolated": True,
            },
        })
        if result.get("ok", False) or result.get("agent_id"):
            self._registered = True
        return result

    def heartbeat(self, state: str = "idle",
                  current_task: Optional[str] = None,
                  current_task_title: Optional[str] = None) -> Dict[str, Any]:
        data: Dict[str, Any] = {"state": state}
        if current_task is not None:
            data["current_task"] = current_task
        if current_task_title is not None:
            data["current_task_title"] = current_task_title
        return self._post(f"/agents/{self.agent_id}/heartbeat", data)

    def unregister(self) -> Dict[str, Any]:
        return self._delete(f"/agents/{self.agent_id}")

    # ── Task Management ───────────────────────────────────────

    def get_ready_tasks(self) -> Dict[str, Any]:
        return self._get("/tasks/ready")

    def claim_task(self, task_id: str) -> Dict[str, Any]:
        return self._post(f"/tasks/{task_id}/claim", {
            "agent_id": self.agent_id,
        })

    def complete_task(self, task_id: str,
                      result: Optional[Dict] = None,
                      artifacts: Optional[List[str]] = None) -> Dict[str, Any]:
        return self._post(f"/tasks/{task_id}/done", {
            "agent_id": self.agent_id,
            "result": result or {},
            "artifacts": artifacts or [],
        })

    def fail_task(self, task_id: str, error: str) -> Dict[str, Any]:
        return self._post(f"/tasks/{task_id}/fail", {
            "agent_id": self.agent_id,
            "error": error,
        })

    # ── File Locks ────────────────────────────────────────────

    def request_lock(self, path: str, intent: str = "", ttl: int = 1800) -> Dict[str, Any]:
        return self._post("/locks", {
            "agent_id": self.agent_id,
            "path": path,
            "intent": intent,
            "ttl_seconds": ttl,
        })

    def release_lock(self, path: str) -> Dict[str, Any]:
        import urllib.parse
        encoded = urllib.parse.quote(path, safe="")
        return self._delete(f"/locks/{encoded}", {"agent_id": self.agent_id})

    def get_locked_files(self) -> List[Dict[str, Any]]:
        result = self._get("/locks")
        return result.get("locks", [])

    # ── RAG Query ─────────────────────────────────────────────

    def rag_query(self, query: str, max_chunks: int = 15,
                  corpus: Optional[str] = None) -> Dict[str, Any]:
        data: Dict[str, Any] = {
            "query": query,
            "max_chunks": max_chunks,
            "agent_id": self.agent_id,
        }
        if corpus:
            data["corpus"] = corpus
        return self._post("/rag", data, timeout=30)

    # ── Event Bus (state mirroring) ───────────────────────────

    def post_event(self, event_type: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        return self._post("/events", {
            "event_type": f"fubbu_{event_type}",
            "agent_id": self.agent_id,
            "session_id": "fubbu",
            "payload": payload,
        })

    # ── Status ────────────────────────────────────────────────

    def get_nexus_status(self) -> Dict[str, Any]:
        return self._get("/status")

    def get_other_agents(self) -> List[Dict[str, Any]]:
        result = self._get("/agents")
        agents = result.get("agents", [])
        return [a for a in agents if a.get("agent_id") != self.agent_id]

    def is_nexus_alive(self) -> bool:
        result = self._get("/health", timeout=5)
        return result.get("ok", False)
