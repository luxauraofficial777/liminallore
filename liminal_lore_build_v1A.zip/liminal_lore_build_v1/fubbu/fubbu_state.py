"""FUBBU isolated state store.

Separate SQLite database for FUBBU's internal router-worker-verifier state.
NEVER writes to nexus_state.db. All Nexus interaction goes through HTTP API.

Tables:
  - fubbu_tasks: Decomposed sub-tasks and their status
  - fubbu_iterations: Router→Worker→Verify cycle history per task
  - fubbu_worker_outputs: Raw model outputs with metadata
  - fubbu_verdicts: Verifier structural + advisory results
  - fubbu_checkpoints: Periodic state snapshots for crash recovery
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional


_SCHEMA = """
CREATE TABLE IF NOT EXISTS fubbu_tasks (
    task_id         TEXT PRIMARY KEY,
    nexus_task_id   TEXT NOT NULL DEFAULT '',
    title           TEXT NOT NULL DEFAULT '',
    description     TEXT NOT NULL DEFAULT '',
    sub_tasks       TEXT NOT NULL DEFAULT '[]',
    status          TEXT NOT NULL DEFAULT 'pending',
    priority        INTEGER NOT NULL DEFAULT 5,
    created         TEXT NOT NULL,
    updated         TEXT NOT NULL,
    completed       TEXT
);

CREATE INDEX IF NOT EXISTS idx_ftasks_status ON fubbu_tasks(status);
CREATE INDEX IF NOT EXISTS idx_ftasks_nexus ON fubbu_tasks(nexus_task_id);

CREATE TABLE IF NOT EXISTS fubbu_iterations (
    iteration_id    TEXT PRIMARY KEY,
    task_id         TEXT NOT NULL,
    iteration_num   INTEGER NOT NULL DEFAULT 0,
    router_prompt   TEXT NOT NULL DEFAULT '',
    router_output   TEXT NOT NULL DEFAULT '',
    worker_prompt   TEXT NOT NULL DEFAULT '',
    worker_output   TEXT NOT NULL DEFAULT '',
    verifier_input  TEXT NOT NULL DEFAULT '',
    verifier_output TEXT NOT NULL DEFAULT '',
    structural_pass INTEGER NOT NULL DEFAULT 0,
    advisory_score  REAL NOT NULL DEFAULT 0.0,
    verdict         TEXT NOT NULL DEFAULT 'pending',
    tokens_in       INTEGER NOT NULL DEFAULT 0,
    tokens_out      INTEGER NOT NULL DEFAULT 0,
    latency_ms      REAL NOT NULL DEFAULT 0.0,
    created         TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_fiter_task ON fubbu_iterations(task_id);

CREATE TABLE IF NOT EXISTS fubbu_worker_outputs (
    output_id       TEXT PRIMARY KEY,
    task_id         TEXT NOT NULL,
    iteration_id    TEXT NOT NULL,
    model           TEXT NOT NULL DEFAULT '',
    raw_output      TEXT NOT NULL DEFAULT '',
    parsed_output   TEXT NOT NULL DEFAULT '{}',
    tokens_in       INTEGER NOT NULL DEFAULT 0,
    tokens_out      INTEGER NOT NULL DEFAULT 0,
    latency_ms      REAL NOT NULL DEFAULT 0.0,
    created         TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_fwout_task ON fubbu_worker_outputs(task_id);

CREATE TABLE IF NOT EXISTS fubbu_verdicts (
    verdict_id      TEXT PRIMARY KEY,
    task_id         TEXT NOT NULL,
    iteration_id    TEXT NOT NULL,
    structural_results TEXT NOT NULL DEFAULT '{}',
    advisory_output TEXT NOT NULL DEFAULT '',
    advisory_score  REAL NOT NULL DEFAULT 0.0,
    passed          INTEGER NOT NULL DEFAULT 0,
    rejection_reason TEXT NOT NULL DEFAULT '',
    created         TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_fverdict_task ON fubbu_verdicts(task_id);

CREATE TABLE IF NOT EXISTS fubbu_checkpoints (
    checkpoint_id   TEXT PRIMARY KEY,
    snapshot        TEXT NOT NULL DEFAULT '{}',
    created         TEXT NOT NULL
);
"""


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


class FubbuState:
    """Isolated state store for FUBBU sidecar.

    Uses a completely separate SQLite database from VW Nexus.
    All Nexus communication goes through HTTP API, never shared DB state.
    """

    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn: Optional[sqlite3.Connection] = None
        self._init_db()

    def _init_db(self) -> None:
        with self._lock:
            self._conn = sqlite3.connect(
                str(self.db_path), check_same_thread=False
            )
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._conn.executescript(_SCHEMA)
            self._conn.commit()

    # ── Task Management ───────────────────────────────────────

    def create_task(
        self,
        nexus_task_id: str,
        title: str,
        description: str,
        sub_tasks: List[Dict[str, Any]],
        priority: int = 5,
    ) -> str:
        task_id = f"fubbu_{uuid.uuid4().hex[:10]}"
        with self._lock:
            self._conn.execute(
                """INSERT INTO fubbu_tasks
                   (task_id, nexus_task_id, title, description, sub_tasks,
                    status, priority, created, updated)
                   VALUES (?, ?, ?, ?, ?, 'pending', ?, ?, ?)""",
                (
                    task_id, nexus_task_id, title, description,
                    json.dumps(sub_tasks), priority, _now_iso(), _now_iso(),
                ),
            )
            self._conn.commit()
        return task_id

    def update_task_status(self, task_id: str, status: str) -> None:
        with self._lock:
            self._conn.execute(
                "UPDATE fubbu_tasks SET status = ?, updated = ? WHERE task_id = ?",
                (status, _now_iso(), task_id),
            )
            self._conn.commit()

    def complete_task(self, task_id: str) -> None:
        with self._lock:
            self._conn.execute(
                "UPDATE fubbu_tasks SET status = 'completed', completed = ?, updated = ? WHERE task_id = ?",
                (_now_iso(), _now_iso(), task_id),
            )
            self._conn.commit()

    def get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM fubbu_tasks WHERE task_id = ?", (task_id,)
            ).fetchone()
        if not row:
            return None
        return self._row_to_task(row)

    def get_active_tasks(self) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM fubbu_tasks WHERE status IN ('pending', 'routing', 'working', 'verifying') ORDER BY priority ASC"
            ).fetchall()
        return [self._row_to_task(r) for r in rows]

    def _row_to_task(self, row) -> Dict[str, Any]:
        return {
            "task_id": row[0],
            "nexus_task_id": row[1],
            "title": row[2],
            "description": row[3],
            "sub_tasks": json.loads(row[4]) if row[4] else [],
            "status": row[5],
            "priority": row[6],
            "created": row[7],
            "updated": row[8],
            "completed": row[9],
        }

    # ── Iteration Tracking ────────────────────────────────────

    def record_iteration(
        self,
        task_id: str,
        iteration_num: int,
        router_prompt: str = "",
        router_output: str = "",
        worker_prompt: str = "",
        worker_output: str = "",
        verifier_input: str = "",
        verifier_output: str = "",
        structural_pass: bool = False,
        advisory_score: float = 0.0,
        verdict: str = "pending",
        tokens_in: int = 0,
        tokens_out: int = 0,
        latency_ms: float = 0.0,
    ) -> str:
        iteration_id = f"iter_{uuid.uuid4().hex[:10]}"
        with self._lock:
            self._conn.execute(
                """INSERT INTO fubbu_iterations
                   (iteration_id, task_id, iteration_num,
                    router_prompt, router_output,
                    worker_prompt, worker_output,
                    verifier_input, verifier_output,
                    structural_pass, advisory_score, verdict,
                    tokens_in, tokens_out, latency_ms, created)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    iteration_id, task_id, iteration_num,
                    router_prompt, router_output,
                    worker_prompt, worker_output,
                    verifier_input, verifier_output,
                    1 if structural_pass else 0, advisory_score, verdict,
                    tokens_in, tokens_out, latency_ms, _now_iso(),
                ),
            )
            self._conn.commit()
        return iteration_id

    def get_iterations(self, task_id: str) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM fubbu_iterations WHERE task_id = ? ORDER BY iteration_num ASC",
                (task_id,),
            ).fetchall()
        return [
            {
                "iteration_id": r[0],
                "task_id": r[1],
                "iteration_num": r[2],
                "router_prompt": r[3],
                "router_output": r[4],
                "worker_prompt": r[5],
                "worker_output": r[6],
                "verifier_input": r[7],
                "verifier_output": r[8],
                "structural_pass": bool(r[9]),
                "advisory_score": r[10],
                "verdict": r[11],
                "tokens_in": r[12],
                "tokens_out": r[13],
                "latency_ms": r[14],
                "created": r[15],
            }
            for r in rows
        ]

    # ── Worker Output Storage ─────────────────────────────────

    def record_worker_output(
        self,
        task_id: str,
        iteration_id: str,
        model: str,
        raw_output: str,
        parsed_output: Dict[str, Any],
        tokens_in: int = 0,
        tokens_out: int = 0,
        latency_ms: float = 0.0,
    ) -> str:
        output_id = f"wout_{uuid.uuid4().hex[:10]}"
        with self._lock:
            self._conn.execute(
                """INSERT INTO fubbu_worker_outputs
                   (output_id, task_id, iteration_id, model,
                    raw_output, parsed_output,
                    tokens_in, tokens_out, latency_ms, created)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    output_id, task_id, iteration_id, model,
                    raw_output, json.dumps(parsed_output),
                    tokens_in, tokens_out, latency_ms, _now_iso(),
                ),
            )
            self._conn.commit()
        return output_id

    # ── Verdict Storage ───────────────────────────────────────

    def record_verdict(
        self,
        task_id: str,
        iteration_id: str,
        structural_results: Dict[str, Any],
        advisory_output: str,
        advisory_score: float,
        passed: bool,
        rejection_reason: str = "",
    ) -> str:
        verdict_id = f"vrd_{uuid.uuid4().hex[:10]}"
        with self._lock:
            self._conn.execute(
                """INSERT INTO fubbu_verdicts
                   (verdict_id, task_id, iteration_id,
                    structural_results, advisory_output, advisory_score,
                    passed, rejection_reason, created)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    verdict_id, task_id, iteration_id,
                    json.dumps(structural_results), advisory_output, advisory_score,
                    1 if passed else 0, rejection_reason, _now_iso(),
                ),
            )
            self._conn.commit()
        return verdict_id

    def get_verdicts(self, task_id: str) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM fubbu_verdicts WHERE task_id = ? ORDER BY created ASC",
                (task_id,),
            ).fetchall()
        return [
            {
                "verdict_id": r[0],
                "task_id": r[1],
                "iteration_id": r[2],
                "structural_results": json.loads(r[3]) if r[3] else {},
                "advisory_output": r[4],
                "advisory_score": r[5],
                "passed": bool(r[6]),
                "rejection_reason": r[7],
                "created": r[8],
            }
            for r in rows
        ]

    # ── Checkpoint / Recovery ─────────────────────────────────

    def checkpoint(self) -> str:
        snapshot = {
            "active_tasks": [t for t in self.get_active_tasks()],
            "timestamp": _now_iso(),
        }
        checkpoint_id = f"ckpt_{uuid.uuid4().hex[:10]}"
        with self._lock:
            self._conn.execute(
                "INSERT INTO fubbu_checkpoints (checkpoint_id, snapshot, created) VALUES (?, ?, ?)",
                (checkpoint_id, json.dumps(snapshot, default=str), _now_iso()),
            )
            self._conn.commit()
        return checkpoint_id

    def get_latest_checkpoint(self) -> Optional[Dict[str, Any]]:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM fubbu_checkpoints ORDER BY created DESC LIMIT 1"
            ).fetchone()
        if not row:
            return None
        return {
            "checkpoint_id": row[0],
            "snapshot": json.loads(row[1]) if row[1] else {},
            "created": row[2],
        }

    # ── Status Summary ────────────────────────────────────────

    def status(self) -> Dict[str, Any]:
        with self._lock:
            total = self._conn.execute("SELECT COUNT(*) FROM fubbu_tasks").fetchone()[0]
            pending = self._conn.execute(
                "SELECT COUNT(*) FROM fubbu_tasks WHERE status = 'pending'"
            ).fetchone()[0]
            active = self._conn.execute(
                "SELECT COUNT(*) FROM fubbu_tasks WHERE status IN ('routing', 'working', 'verifying')"
            ).fetchone()[0]
            completed = self._conn.execute(
                "SELECT COUNT(*) FROM fubbu_tasks WHERE status = 'completed'"
            ).fetchone()[0]
            failed = self._conn.execute(
                "SELECT COUNT(*) FROM fubbu_tasks WHERE status = 'failed'"
            ).fetchone()[0]
            iterations = self._conn.execute(
                "SELECT COUNT(*) FROM fubbu_iterations"
            ).fetchone()[0]
            verdicts = self._conn.execute(
                "SELECT COUNT(*) FROM fubbu_verdicts WHERE passed = 1"
            ).fetchone()[0]
            total_verdicts = self._conn.execute(
                "SELECT COUNT(*) FROM fubbu_verdicts"
            ).fetchone()[0]
        return {
            "tasks_total": total,
            "tasks_pending": pending,
            "tasks_active": active,
            "tasks_completed": completed,
            "tasks_failed": failed,
            "iterations_total": iterations,
            "verdicts_passed": verdicts,
            "verdicts_total": total_verdicts,
            "pass_rate": round(verdicts / total_verdicts, 3) if total_verdicts else 0.0,
        }

    def close(self) -> None:
        with self._lock:
            if self._conn:
                self._conn.close()
                self._conn = None
