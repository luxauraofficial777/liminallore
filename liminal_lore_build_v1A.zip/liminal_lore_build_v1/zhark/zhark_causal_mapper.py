"""ZHARK — Causal Mapper.

Extracts causal relationships from gathered evidence and builds a causal DAG
(Directed Acyclic Graph). Unlike correlation-based analysis, the causal mapper
uses structural cues from the LLM's reasoning to identify:

  - Direct causes: A → B (A causes B)
  - Mediators: A → M → B (A causes B through M)
  - Confounders: C → A, C → B (C causes both, creating spurious correlation)
  - Feedback loops: A → B → A (detected and flagged, not cyclic in DAG)

The causal map feeds directly into the Strategy Synthesizer to identify
leverage points — variables that, if changed, have the largest downstream
impact on the strategic outcome.
"""

from __future__ import annotations

import json
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple


class CausalType(str, Enum):
    DIRECT = "direct"           # A → B
    MEDIATED = "mediated"       # A → M → B
    CONFOUNDED = "confounded"   # C → A, C → B
    FEEDBACK = "feedback"       # A → B → A (flagged)
    INHIBITOR = "inhibitor"     # A ⊣ B (A prevents/reduces B)


@dataclass
class CausalNode:
    """A variable or factor in the causal graph."""
    node_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    name: str = ""
    description: str = ""
    category: str = ""  # e.g., "market", "technology", "regulatory", "financial"
    leverage_score: float = 0.0  # [0, 1] — how much control/influence over this node
    centrality: float = 0.0  # Computed: how many paths pass through this node
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_id": self.node_id,
            "name": self.name,
            "description": self.description,
            "category": self.category,
            "leverage_score": round(self.leverage_score, 3),
            "centrality": round(self.centrality, 3),
            "metadata": self.metadata,
        }


@dataclass
class CausalEdge:
    """A causal relationship between two nodes."""
    edge_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    source_id: str = ""  # Cause
    target_id: str = ""  # Effect
    causal_type: str = CausalType.DIRECT.value
    strength: float = 0.5  # [0, 1] — confidence in the causal link
    mediator_id: Optional[str] = None  # For mediated relationships
    evidence_ref: str = ""  # Reference to evidence in hypothesis graph
    description: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "edge_id": self.edge_id,
            "source_id": self.source_id,
            "target_id": self.target_id,
            "causal_type": self.causal_type,
            "strength": round(self.strength, 3),
            "mediator_id": self.mediator_id,
            "evidence_ref": self.evidence_ref,
            "description": self.description,
            "metadata": self.metadata,
        }


class CausalMapper:
    """Builds and queries causal DAGs from research evidence.

    Workflow:
      1. LLM extracts causal claims from evidence text
      2. Claims are parsed into nodes and edges
      3. DAG consistency is validated (no cycles except feedback)
      4. Centrality and leverage scores are computed
      5. Leverage points identified for strategy synthesis
    """

    def __init__(self):
        self._nodes: Dict[str, CausalNode] = {}
        self._edges: Dict[str, CausalEdge] = {}
        self._adjacency: Dict[str, List[str]] = {}  # node_id → [edge_ids]
        self._reverse: Dict[str, List[str]] = {}    # target_id → [edge_ids]
        self._lock = threading.RLock()

    def add_node(
        self,
        name: str,
        description: str = "",
        category: str = "",
        leverage_score: float = 0.0,
        metadata: Optional[Dict] = None,
    ) -> CausalNode:
        """Add a causal node (variable/factor)."""
        with self._lock:
            # Check if node with same name exists
            for node in self._nodes.values():
                if node.name.lower() == name.lower():
                    return node

            node = CausalNode(
                name=name,
                description=description,
                category=category,
                leverage_score=leverage_score,
                metadata=metadata or {},
            )
            self._nodes[node.node_id] = node
            self._adjacency[node.node_id] = []
            self._reverse[node.node_id] = []
            return node

    def add_edge(
        self,
        source_name: str,
        target_name: str,
        causal_type: str = CausalType.DIRECT.value,
        strength: float = 0.5,
        description: str = "",
        evidence_ref: str = "",
        mediator_name: Optional[str] = None,
    ) -> Optional[CausalEdge]:
        """Add a causal edge between two nodes (by name)."""
        with self._lock:
            source = self.add_node(source_name)
            target = self.add_node(target_name)
            mediator = None
            if mediator_name:
                mediator = self.add_node(mediator_name)

            edge = CausalEdge(
                source_id=source.node_id,
                target_id=target.node_id,
                causal_type=causal_type,
                strength=strength,
                mediator_id=mediator.node_id if mediator else None,
                description=description,
                evidence_ref=evidence_ref,
            )
            self._edges[edge.edge_id] = edge
            self._adjacency.setdefault(source.node_id, []).append(edge.edge_id)
            self._reverse.setdefault(target.node_id, []).append(edge.edge_id)

            # Check for feedback loops
            if self._would_create_cycle(source.node_id, target.node_id):
                edge.causal_type = CausalType.FEEDBACK.value

            return edge

    def _would_create_cycle(self, source_id: str, target_id: str) -> bool:
        """Check if adding source→target would create a cycle (DFS)."""
        visited: Set[str] = set()

        def _dfs(node_id: str) -> bool:
            if node_id == source_id:
                return True
            if node_id in visited:
                return False
            visited.add(node_id)
            for edge_id in self._adjacency.get(node_id, []):
                edge = self._edges.get(edge_id)
                if edge and edge.causal_type != CausalType.FEEDBACK.value:
                    if _dfs(edge.target_id):
                        return True
            return False

        return _dfs(target_id)

    def compute_centrality(self) -> None:
        """Compute betweenness centrality for all nodes (simplified)."""
        with self._lock:
            for node_id in self._nodes:
                # Count paths passing through this node
                in_count = len(self._reverse.get(node_id, []))
                out_count = len(self._adjacency.get(node_id, []))
                self._nodes[node_id].centrality = (in_count + out_count) / max(
                    len(self._nodes), 1
                )

    def get_leverage_points(self, top_n: int = 5) -> List[CausalNode]:
        """Identify top leverage points — nodes with high centrality and controllability."""
        with self._lock:
            self.compute_centrality()
            scored = [
                (n, n.centrality * n.leverage_score)
                for n in self._nodes.values()
            ]
            scored.sort(key=lambda x: x[1], reverse=True)
            return [n for n, _ in scored[:top_n]]

    def get_causes_of(self, node_name: str) -> List[CausalNode]:
        """Get all direct causes of a node."""
        with self._lock:
            node = self._find_by_name(node_name)
            if not node:
                return []
            causes = []
            for edge_id in self._reverse.get(node.node_id, []):
                edge = self._edges.get(edge_id)
                if edge:
                    cause = self._nodes.get(edge.source_id)
                    if cause:
                        causes.append(cause)
            return causes

    def get_effects_of(self, node_name: str) -> List[CausalNode]:
        """Get all direct effects of a node."""
        with self._lock:
            node = self._find_by_name(node_name)
            if not node:
                return []
            effects = []
            for edge_id in self._adjacency.get(node.node_id, []):
                edge = self._edges.get(edge_id)
                if edge:
                    effect = self._nodes.get(edge.target_id)
                    if effect:
                        effects.append(effect)
            return effects

    def _find_by_name(self, name: str) -> Optional[CausalNode]:
        for node in self._nodes.values():
            if node.name.lower() == name.lower():
                return node
        return None

    def to_dict(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "nodes": {nid: n.to_dict() for nid, n in self._nodes.items()},
                "edges": {eid: e.to_dict() for eid, e in self._edges.items()},
            }

    def summary(self) -> Dict[str, Any]:
        with self._lock:
            categories: Dict[str, int] = {}
            for node in self._nodes.values():
                cat = node.category or "uncategorized"
                categories[cat] = categories.get(cat, 0) + 1

            edge_types: Dict[str, int] = {}
            for edge in self._edges.values():
                edge_types[edge.causal_type] = edge_types.get(edge.causal_type, 0) + 1

            return {
                "total_nodes": len(self._nodes),
                "total_edges": len(self._edges),
                "categories": categories,
                "edge_types": edge_types,
                "leverage_points": [n.name for n in self.get_leverage_points(5)],
            }

    def save(self, path: str | Path) -> str:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.to_dict(), indent=2, default=str), encoding="utf-8")
        return str(path)

    def load(self, path: str | Path) -> bool:
        path = Path(path)
        if not path.exists():
            return False
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            with self._lock:
                self._nodes = {}
                self._edges = {}
                self._adjacency = {}
                self._reverse = {}
                for nid, ndata in data.get("nodes", {}).items():
                    node = CausalNode(
                        node_id=ndata["node_id"],
                        name=ndata["name"],
                        description=ndata.get("description", ""),
                        category=ndata.get("category", ""),
                        leverage_score=ndata.get("leverage_score", 0.0),
                        centrality=ndata.get("centrality", 0.0),
                        metadata=ndata.get("metadata", {}),
                    )
                    self._nodes[nid] = node
                    self._adjacency[nid] = []
                    self._reverse[nid] = []
                for eid, edata in data.get("edges", {}).items():
                    edge = CausalEdge(
                        edge_id=edata["edge_id"],
                        source_id=edata["source_id"],
                        target_id=edata["target_id"],
                        causal_type=edata.get("causal_type", CausalType.DIRECT.value),
                        strength=edata.get("strength", 0.5),
                        mediator_id=edata.get("mediator_id"),
                        evidence_ref=edata.get("evidence_ref", ""),
                        description=edata.get("description", ""),
                        metadata=edata.get("metadata", {}),
                    )
                    self._edges[eid] = edge
                    self._adjacency.setdefault(edge.source_id, []).append(eid)
                    self._reverse.setdefault(edge.target_id, []).append(eid)
            return True
        except Exception:
            return False
