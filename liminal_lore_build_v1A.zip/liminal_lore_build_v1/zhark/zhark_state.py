"""ZHARK — State Management & Verification Buffer.

Provides:
  - Persistent state via SQLite (checkpoint/resume across multi-hour cycles)
  - Verification buffer for inference-time compute scaling
  - Self-correction tracking (revision history per hypothesis)
  - Cycle state machine (hypothesis → gather → analyze → verify → refine)
  - Telemetry export for audit trail

The verification buffer implements test-time compute scaling by:
  1. Buffering multiple LLM outputs for the same query
  2. Scoring each output for consistency and evidence alignment
  3. Selecting the best output or requesting refinement
  4. Tracking revision history to measure convergence
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


class CyclePhase(str, Enum):
    IDLE = "idle"
    HYPOTHESIS = "hypothesis"
    GATHERING = "gathering"
    ANALYZING = "analyzing"
    VERIFYING = "verifying"
    REFINING = "refining"
    SYNTHESIZING = "synthesizing"
    COMPLETE = "complete"
    ERROR = "error"


class VerificationStatus(str, Enum):
    PENDING = "pending"
    CONSISTENT = "consistent"
    CONTRADICTORY = "contradictory"
    REFUTED = "refuted"
    NEEDS_REVISION = "needs_revision"
    ACCEPTED = "accepted"


@dataclass
class VerificationEntry:
    """A single verification attempt in the buffer."""
    entry_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    query: str = ""
    output: str = ""
    score: float = 0.0  # [0, 1] — quality score
    consistency: float = 0.0  # [0, 1] — agreement with other outputs
    evidence_alignment: float = 0.0  # [0, 1] — alignment with known evidence
    status: str = VerificationStatus.PENDING.value
    revision: int = 0  # Which revision this is (0 = first attempt)
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "entry_id": self.entry_id,
            "query": self.query[:200],
            "output": self.output[:500],
            "score": round(self.score, 3),
            "consistency": round(self.consistency, 3),
            "evidence_alignment": round(self.evidence_alignment, 3),
            "status": self.status,
            "revision": self.revision,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }


class VerifyBuffer:
    """Inference-time compute scaling via buffered verification.

    Implements test-time compute scaling by:
      1. Generating multiple candidate outputs for the same query
      2. Scoring each for quality, consistency, and evidence alignment
      3. Selecting the best or requesting refinement
      4. Tracking convergence across revisions

    This is the core of ZHARK's ability to "think longer" on hard problems.
    """

    def __init__(self, max_candidates: int = 3, convergence_threshold: float = 0.8):
        self._buffer: Dict[str, List[VerificationEntry]] = {}  # query_hash → entries
        self._max_candidates = max_candidates
        self._convergence_threshold = convergence_threshold
        self._lock = threading.RLock()
        self._revision_history: Dict[str, List[int]] = {}  # query_hash → revision numbers

    def submit(
        self,
        query: str,
        output: str,
        evidence_context: str = "",
        revision: int = 0,
    ) -> VerificationEntry:
        """Submit a candidate output for verification."""
        with self._lock:
            query_hash = self._hash_query(query)
            entry = VerificationEntry(
                query=query,
                output=output,
                revision=revision,
                metadata={"evidence_context": evidence_context[:500]},
            )

            self._buffer.setdefault(query_hash, []).append(entry)
            self._revision_history.setdefault(query_hash, []).append(revision)

            return entry

    def evaluate(self, query: str) -> Dict[str, Any]:
        """Evaluate all candidates for a query and select the best.

        Returns:
          - best_entry: The highest-scoring entry
          - status: consistent/contradictory/needs_revision
          - consensus_score: Agreement between candidates
          - should_refine: Whether another revision is needed
        """
        with self._lock:
            query_hash = self._hash_query(query)
            entries = self._buffer.get(query_hash, [])

            if not entries:
                return {"status": "empty", "should_refine": False}

            if len(entries) == 1:
                entries[0].status = VerificationStatus.PENDING.value
                entries[0].consistency = 1.0
                return {
                    "best_entry": entries[0].to_dict(),
                    "status": VerificationStatus.PENDING.value,
                    "consensus_score": 1.0,
                    "should_refine": True,  # Need more candidates
                }

            # Score consistency: pairwise text similarity (simplified)
            for i, entry in enumerate(entries):
                others = entries[:i] + entries[i + 1:]
                entry.consistency = self._text_similarity(entry.output, [o.output for o in others])
                entry.score = (entry.consistency + entry.evidence_alignment) / 2

            # Check for consensus
            scores = [e.score for e in entries]
            avg_score = sum(scores) / len(scores)
            max_score = max(scores)
            min_score = min(scores)
            spread = max_score - min_score

            best = max(entries, key=lambda e: e.score)

            if avg_score >= self._convergence_threshold and spread < 0.2:
                best.status = VerificationStatus.CONSISTENT.value
                should_refine = False
            elif spread > 0.4:
                best.status = VerificationStatus.CONTRADICTORY.value
                should_refine = True
            elif max_score < 0.5:
                best.status = VerificationStatus.NEEDS_REVISION.value
                should_refine = True
            else:
                best.status = VerificationStatus.ACCEPTED.value
                should_refine = False

            return {
                "best_entry": best.to_dict(),
                "status": best.status,
                "consensus_score": round(avg_score, 3),
                "spread": round(spread, 3),
                "should_refine": should_refine,
                "candidate_count": len(entries),
            }

    def get_convergence(self, query: str) -> Dict[str, Any]:
        """Track convergence across revisions for a query."""
        with self._lock:
            query_hash = self._hash_query(query)
            entries = self._buffer.get(query_hash, [])
            revisions = self._revision_history.get(query_hash, [])

            if not entries:
                return {"converged": False, "revisions": 0}

            # Track score improvement across revisions
            by_revision: Dict[int, List[float]] = {}
            for entry in entries:
                by_revision.setdefault(entry.revision, []).append(entry.score)

            avg_by_revision = {
                rev: sum(scores) / len(scores)
                for rev, scores in sorted(by_revision.items())
            }

            latest = max(avg_by_revision.keys()) if avg_by_revision else 0
            latest_score = avg_by_revision.get(latest, 0)
            converged = latest_score >= self._convergence_threshold and latest >= 2

            return {
                "converged": converged,
                "revisions": len(avg_by_revision),
                "score_by_revision": {str(k): round(v, 3) for k, v in avg_by_revision.items()},
                "latest_score": round(latest_score, 3),
                "trend": "improving" if len(avg_by_revision) >= 2 and
                         list(avg_by_revision.values())[-1] > list(avg_by_revision.values())[-2]
                         else "stable" if len(avg_by_revision) >= 2 else "insufficient",
            }

    @staticmethod
    def _hash_query(query: str) -> str:
        import hashlib
        return hashlib.sha256(query.encode()).hexdigest()[:16]

    @staticmethod
    def _text_similarity(text: str, others: List[str]) -> float:
        """Simplified text similarity using word overlap (Jaccard)."""
        if not others:
            return 1.0
        words_a = set(text.lower().split())
        total = 0.0
        for other in others:
            words_b = set(other.lower().split())
            if not words_a and not words_b:
                total += 1.0
            elif not words_a or not words_b:
                total += 0.0
            else:
                total += len(words_a & words_b) / len(words_a | words_b)
        return total / len(others)

    def clear(self, query: Optional[str] = None) -> None:
        with self._lock:
            if query:
                query_hash = self._hash_query(query)
                self._buffer.pop(query_hash, None)
                self._revision_history.pop(query_hash, None)
            else:
                self._buffer.clear()
                self._revision_history.clear()


class ZharkState:
    """Persistent state management for ZHARK orchestration cycles.

    SQLite-backed for checkpoint/resume across multi-hour runs.
    Stores:
      - Cycle state (current phase, iteration count, start time)
      - Verification buffer entries
      - Hypothesis graph checkpoints
      - Causal map checkpoints
      - Strategy outputs
      - Telemetry/audit trail
    """

    SCHEMA = """
    CREATE TABLE IF NOT EXISTS zhark_cycles (
        cycle_id TEXT PRIMARY KEY,
        research_question TEXT NOT NULL,
        phase TEXT NOT NULL,
        iteration INTEGER DEFAULT 0,
        started TEXT NOT NULL,
        last_checkpoint TEXT,
        config_json TEXT,
        status TEXT DEFAULT 'active'
    );

    CREATE TABLE IF NOT EXISTS zhark_verification (
        entry_id TEXT PRIMARY KEY,
        cycle_id TEXT NOT NULL,
        query TEXT,
        output TEXT,
        score REAL DEFAULT 0,
        consistency REAL DEFAULT 0,
        evidence_alignment REAL DEFAULT 0,
        status TEXT DEFAULT 'pending',
        revision INTEGER DEFAULT 0,
        timestamp TEXT NOT NULL,
        metadata_json TEXT,
        FOREIGN KEY (cycle_id) REFERENCES zhark_cycles(cycle_id)
    );

    CREATE TABLE IF NOT EXISTS zhark_checkpoints (
        checkpoint_id TEXT PRIMARY KEY,
        cycle_id TEXT NOT NULL,
        phase TEXT NOT NULL,
        iteration INTEGER,
        hypothesis_graph_json TEXT,
        causal_map_json TEXT,
        strategy_json TEXT,
        timestamp TEXT NOT NULL,
        FOREIGN KEY (cycle_id) REFERENCES zhark_cycles(cycle_id)
    );

    CREATE TABLE IF NOT EXISTS zhark_telemetry (
        event_id TEXT PRIMARY KEY,
        cycle_id TEXT NOT NULL,
        event_type TEXT NOT NULL,
        payload_json TEXT,
        timestamp TEXT NOT NULL,
        FOREIGN KEY (cycle_id) REFERENCES zhark_cycles(cycle_id)
    );
    """

    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._init_db()

    def _init_db(self) -> None:
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            conn.executescript(self.SCHEMA)
            conn.commit()
            conn.close()

    def start_cycle(self, research_question: str, config: Optional[Dict] = None) -> str:
        """Start a new research cycle and return cycle_id."""
        cycle_id = uuid.uuid4().hex[:16]
        now = datetime.now(timezone.utc).isoformat()
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            conn.execute(
                "INSERT INTO zhark_cycles (cycle_id, research_question, phase, started, config_json, status) "
                "VALUES (?, ?, ?, ?, ?, 'active')",
                (cycle_id, research_question, CyclePhase.HYPOTHESIS.value, now,
                 json.dumps(config or {}), ),
            )
            conn.commit()
            conn.close()
        self.log_event(cycle_id, "cycle_started", {"question": research_question})
        return cycle_id

    def update_phase(self, cycle_id: str, phase: str, iteration: int) -> None:
        """Update current phase and iteration."""
        now = datetime.now(timezone.utc).isoformat()
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            conn.execute(
                "UPDATE zhark_cycles SET phase = ?, iteration = ?, last_checkpoint = ? WHERE cycle_id = ?",
                (phase, iteration, now, cycle_id),
            )
            conn.commit()
            conn.close()

    def checkpoint(
        self,
        cycle_id: str,
        phase: str,
        iteration: int,
        hypothesis_graph_json: str = "",
        causal_map_json: str = "",
        strategy_json: str = "",
    ) -> str:
        """Save a checkpoint for resume capability."""
        checkpoint_id = uuid.uuid4().hex[:12]
        now = datetime.now(timezone.utc).isoformat()
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            conn.execute(
                "INSERT INTO zhark_checkpoints "
                "(checkpoint_id, cycle_id, phase, iteration, hypothesis_graph_json, "
                "causal_map_json, strategy_json, timestamp) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (checkpoint_id, cycle_id, phase, iteration,
                 hypothesis_graph_json, causal_map_json, strategy_json, now),
            )
            conn.commit()
            conn.close()
        return checkpoint_id

    def load_latest_checkpoint(self, cycle_id: str) -> Optional[Dict[str, Any]]:
        """Load the most recent checkpoint for a cycle."""
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            conn.row_factory = sqlite3.Row
            row = conn.execute(
                "SELECT * FROM zhark_checkpoints WHERE cycle_id = ? ORDER BY timestamp DESC LIMIT 1",
                (cycle_id,),
            ).fetchone()
            conn.close()
            if not row:
                return None
            return {
                "checkpoint_id": row["checkpoint_id"],
                "phase": row["phase"],
                "iteration": row["iteration"],
                "hypothesis_graph": json.loads(row["hypothesis_graph_json"]) if row["hypothesis_graph_json"] else None,
                "causal_map": json.loads(row["causal_map_json"]) if row["causal_map_json"] else None,
                "strategy": json.loads(row["strategy_json"]) if row["strategy_json"] else None,
                "timestamp": row["timestamp"],
            }

    def log_event(self, cycle_id: str, event_type: str, payload: Dict) -> None:
        """Log a telemetry event."""
        event_id = uuid.uuid4().hex[:12]
        now = datetime.now(timezone.utc).isoformat()
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            conn.execute(
                "INSERT INTO zhark_telemetry (event_id, cycle_id, event_type, payload_json, timestamp) "
                "VALUES (?, ?, ?, ?, ?)",
                (event_id, cycle_id, event_type, json.dumps(payload, default=str), now),
            )
            conn.commit()
            conn.close()

    def get_cycle(self, cycle_id: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            conn.row_factory = sqlite3.Row
            row = conn.execute(
                "SELECT * FROM zhark_cycles WHERE cycle_id = ?", (cycle_id,),
            ).fetchone()
            conn.close()
            if not row:
                return None
            return dict(row)

    def list_cycles(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            conn.row_factory = sqlite3.Row
            if status:
                rows = conn.execute(
                    "SELECT * FROM zhark_cycles WHERE status = ? ORDER BY started DESC",
                    (status,),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM zhark_cycles ORDER BY started DESC"
                ).fetchall()
            conn.close()
            return [dict(r) for r in rows]

    def complete_cycle(self, cycle_id: str) -> None:
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            conn.execute(
                "UPDATE zhark_cycles SET status = 'completed', phase = ? WHERE cycle_id = ?",
                (CyclePhase.COMPLETE.value, cycle_id),
            )
            conn.commit()
            conn.close()
        self.log_event(cycle_id, "cycle_completed", {})

    def get_telemetry(self, cycle_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM zhark_telemetry WHERE cycle_id = ? ORDER BY timestamp DESC LIMIT ?",
                (cycle_id, limit),
            ).fetchall()
            conn.close()
            return [dict(r) for r in rows]
