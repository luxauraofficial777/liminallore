# Liminal Lore Build v1

Autonomous agentic research and development suite — source-only build package.

## Contents

```
liminal_lore_build_v1/
├── pyproject.toml                 # Python project config (pip install -e .)
├── tool_manifest.yaml             # Tool registry manifest
├── BUILD_INSTALL.md               # This file
│
├── zhark/                         # ZHARK Virtual CSO
│   ├── __init__.py
│   ├── __main__.py                # CLI: run, status, resume, cycles, report
│   ├── zhark_orchestrator.py      # Autonomous research loop
│   ├── zhark_hypothesis_graph.py  # Hypothesis DAG + evidence tracking
│   ├── zhark_causal_mapper.py     # Causal relationship mapping
│   ├── zhark_strategy_synthesizer.py
│   ├── zhark_state.py             # SQLite state + verification buffer
│   ├── zhark_web_gatherer.py      # DuckDuckGo search + extraction
│   ├── zhark_verify.py
│   └── ARCHITECTURE.md
│
├── vw_nexus/                      # Universal orchestration layer
│   ├── __init__.py
│   ├── __main__.py                # CLI entry point
│   ├── api.py                     # HTTP API server
│   ├── agent_registry.py          # Agent tracking + heartbeats
│   ├── task_queue.py              # DAG dependency task scheduling
│   ├── mcp_server.py              # MCP tool protocol
│   ├── event_bus.py               # Inter-agent event bus
│   ├── state_store.py             # Persistent state
│   ├── ... (30+ Python modules)
│   └── data/
│       ├── agent_manifest.json    # Agent definitions
│       └── corpus_config.json     # RAG corpus config
│
├── vw_rag/                        # RAG engine (FTS5 + optional vectors)
│   ├── __init__.py
│   ├── __main__.py                # CLI: index, query, status
│   ├── chunker.py
│   ├── embedder.py
│   ├── graph_index.py
│   ├── indexer.py
│   ├── models.py
│   ├── multi_corpus.py
│   └── retriever.py
│
├── fubbu/                         # FUBBU sidecar (Router-Worker-Verifier)
│   ├── __init__.py
│   ├── __main__.py                # CLI: start, status, topology
│   ├── nexus_router_bridge.py     # Main sidecar loop
│   ├── fubbu_router.py
│   ├── fubbu_worker.py
│   ├── fubbu_verifier.py
│   ├── fubbu_state.py
│   ├── fubbu_nexus_client.py
│   ├── fubbu_telemetry.py
│   ├── fubbu_topography.py
│   ├── fubbu_config.yaml
│   └── README.md
│
├── liminal_lore_vw_deck/          # GUI + bridge + config
│   ├── VoidWalkers_Chat_GUI.html  # Main chat + deck UI
│   ├── VoidWalkers_Suite.html     # Suite launcher page
│   ├── hermes-bridge.js           # HTTP bridge server (Node.js)
│   ├── voidwalkers-fs-service.js  # File system service
│   ├── vw_deck.cpp                # Native deck (C++ source)
│   ├── vw_deck.config.json        # Deck config (${project_root} vars)
│   ├── liminal_settings.json      # FS service settings
│   ├── colibri_bridge.py          # Colibri integration bridge
│   ├── runpod-bridge.py           # RunPod cloud bridge
│   ├── turboquant-liminal.py      # TurboQuant module
│   ├── vw-vpn-monitor.py          # VPN monitor
│   ├── vw_nexus_service.py        # Nexus service wrapper
│   ├── hardware_probe.js          # Hardware detection
│   ├── build-deck.bat             # Build script for native deck
│   ├── build-master.bat           # Master build script
│   ├── SETUP_GUIDE.md             # Full setup documentation
│   ├── DIAGNOSTIC_BLUEPRINT.md
│   ├── pipeline_manifest.json
│   ├── workspaces.json
│   ├── vpn-diagnose-fix.ps1
│   ├── watchdog-vpn.ps1
│   │
│   ├── config/                    # Configuration system
│   │   ├── __init__.py
│   │   ├── config_loader.py       # Layered config: .env → YAML → defaults
│   │   ├── provider_abstraction.py # Dynamic LLM provider
│   │   └── setup_wizard.py        # Interactive setup + shipping check
│   │
│   ├── electron/                  # Electron app wrapper
│   │   ├── main.js
│   │   ├── preload.js
│   │   ├── package.json
│   │   ├── package-lock.json
│   │   ├── hermes-bridge.js
│   │   ├── voidwalkers-fs-service.js
│   │   ├── hardware_probe.js
│   │   ├── VoidWalkers_Suite.html
│   │   ├── vw_deck.config.json
│   │   ├── liminal_settings.json
│   │   ├── committee_manifest.json
│   │   ├── pipeline_manifest.json
│   │   ├── workspaces.json
│   │   └── README.md
│   │
│   └── scripts/
│       └── fetch-and-import-vpngate.ps1
│
└── mcp_server/tools/              # MCP YAML tool definitions
    ├── _schema.yaml
    ├── nexus_agent_list.yaml
    ├── nexus_agent_register.yaml
    ├── nexus_agent_self_model.yaml
    ├── nexus_lock_request.yaml
    ├── nexus_task_create.yaml
    ├── rag_index.yaml
    ├── rag_query.yaml
    ├── rag_status.yaml
    ├── fs_read_file.yaml
    ├── fs_write_file.yaml
    ├── fs_list_dir.yaml
    ├── fs_delete_file.yaml
    ├── fs_exec_command.yaml
    ├── ai_list_workspaces.yaml
    └── ai_rag_context.yaml
```

## Build & Install

### Prerequisites

- **Python** >= 3.11
- **Node.js** >= 18 (for Hermes bridge + Electron)
- **C++ compiler** (MSVC or MinGW) — for native `vw_deck.cpp`
- **Ollama** (recommended, for local LLM inference)

### Step 1: Python Install

```powershell
cd liminal_lore_build_v1
pip install -e .
```

This installs all Python dependencies from `pyproject.toml` and registers CLI entry points:
- `vw_nexus` → `vw_nexus.__main__:main`
- `vw_rag` → `vw_rag.__main__:main`

### Step 2: Configuration

```powershell
cd liminal_lore_vw_deck
python -m config.setup_wizard               # Interactive setup
# OR
python -m config.setup_wizard --generate    # Generate templates only
```

This creates:
- `.env` — API keys and environment settings
- `liminal_lore.yaml` — Provider and tool configuration

### Step 3: Validate

```powershell
python -m config.setup_wizard --check       # Validate config
python -m config.setup_wizard --ship        # Full shipping check
```

### Step 4: Build Native Deck (optional)

```powershell
cd liminal_lore_vw_deck
.\build-deck.bat                            # Compiles vw_deck.cpp
```

### Step 5: Electron App (optional)

```powershell
cd liminal_lore_vw_deck\electron
npm install
npm start
```

### Step 6: Start Services

```powershell
# Terminal 1: VW Nexus
python -m vw_nexus --port 8651

# Terminal 2: FUBBU sidecar (optional)
python -m fubbu start

# Terminal 3: ZHARK research cycle
python -m zhark run "Your research question"

# Terminal 4: Hermes bridge (for GUI)
node liminal_lore_vw_deck\hermes-bridge.js
```

### Step 7: Open GUI

Open `liminal_lore_vw_deck\VoidWalkers_Chat_GUI.html` in a browser, or launch via Electron.

## What's NOT Included (build artifacts)

- Compiled binaries (`.exe`, `.obj`, `.dll`)
- SQLite databases (`.db`, `.db-shm`, `.db-wal`) — created at runtime
- Node.js `node_modules/` — install via `npm install`
- Python `__pycache__/` — created at runtime
- Log files (`.log`)
- Colibri submodule (has its own `.git`)

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PROJECT_ROOT` | (required) | Absolute path to project root |
| `LIMINAL_LORE_ACTIVE_PROVIDER` | `ollama` | LLM provider: ollama, openai_compatible, openrouter, custom |
| `OLLAMA_BASE_URL` | `http://127.0.0.1:11434` | Ollama API URL |
| `NEXUS_API_KEY` | (optional) | VW Nexus auth key |
| `ZHARK_MAX_ITERATIONS` | `50` | ZHARK max research cycles |
| `ZHARK_CONVERGENCE_THRESHOLD` | `0.75` | ZHARK stop threshold |
