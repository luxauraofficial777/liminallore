@echo off
echo ==========================================
echo   VoidWalkers MASTER // Build .exe
echo ==========================================
echo.

cd /d "%~dp0"

:: Check Node.js
node --version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Node.js not installed. Download from https://nodejs.org/
    pause
    exit /b 1
)

:: Check npm
npm --version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [ERROR] npm not found.
    pause
    exit /b 1
)

:: Install pkg if needed
echo Checking pkg...
npm list -g pkg >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo Installing pkg globally...
    npm install -g pkg
    if %ERRORLEVEL% neq 0 (
        echo [ERROR] Failed to install pkg.
        pause
        exit /b 1
    )
)

:: Build
echo.
echo Building vw-master.exe...
echo.
node -e "const {execSync}=require('child_process'); execSync('npx pkg . --targets node18-win-x64 --output vw-master.exe',{stdio:'inherit',cwd:'C:\\LuxAura\\VoidWalkers_Project\\Modern_X64\\tools\\liminal_link_vw_deck'})"

if %ERRORLEVEL% neq 0 (
    echo.
    echo [BUILD FAILED] See output above.
    pause
    exit /b 1
)

echo.
echo [BUILD OK] vw-master.exe created in tools\liminal_link_vw_deck folder.
echo.
echo Launching vw-master.exe...
echo.
start vw-master.exe
pause
