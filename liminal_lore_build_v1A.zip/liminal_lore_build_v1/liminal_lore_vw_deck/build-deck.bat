@echo off
echo ==========================================
echo   VoidWalkers Command Deck // Build
echo ==========================================
echo.

cd /d "%~dp0"

:: ─── Try MinGW-W64 first ───
where gcc.exe >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo [COMPILER] MinGW-W64 detected.
    echo.
    echo Compiling with g++...
    g++ -O2 -std=c++17 vw_deck.cpp -o vw_deck.exe -luser32 -lgdi32 -lshell32 -lcomctl32 -lwininet -lole32 -loleaut32 -luuid -lgdiplus -lws2_32 -mwindows -static-libgcc -static-libstdc++
    if %ERRORLEVEL% equ 0 goto :BUILD_OK
    echo [WARN] gcc build failed, trying MSVC fallback...
)

:: ─── MSVC Fallback ───
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if exist "%VSWHERE%" (
    for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -property installationPath`) do set "VS_PATH=%%i"
)
if not exist "%VS_PATH%" (
    set "VS_PATH=C:\Program Files\Microsoft Visual Studio\2022\Community"
    if not exist "%VS_PATH%" set "VS_PATH=C:\Program Files\Microsoft Visual Studio\2022\BuildTools"
)
if not exist "%VS_PATH%" (
    echo [ERROR] No compiler found. Install MinGW-W64 or MSVC Build Tools.
    pause
    exit /b 1
)
call "%VS_PATH%\VC\Auxiliary\Build\vcvars64.bat"

:: ─── Try CMake + Ninja first ───
where cmake.exe >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo [BUILD] Configuring CMake for vw_deck...
    cmake -B "%~dp0..\build_deck" -S "%~dp0.." -G Ninja -DCMAKE_BUILD_TYPE=Release 2>nul
    if %ERRORLEVEL% equ 0 (
        echo [BUILD] Building vw_deck with Ninja...
        cmake --build "%~dp0..\build_deck" --target vw_deck --config Release
        if %ERRORLEVEL% equ 0 (
            copy /Y "%~dp0..\build_deck\vw_deck.exe" "%~dp0vw_deck.exe" >nul
            goto :BUILD_OK
        )
    )
    echo [BUILD] CMake/Ninja failed, falling back to direct compile...
)

:: ─── Direct cl.exe fallback ───
echo.
echo Compiling with MSVC (direct)...
cl /O2 /EHsc /Fe:vw_deck.exe vw_deck.cpp user32.lib gdi32.lib shell32.lib comctl32.lib wininet.lib ole32.lib oleaut32.lib uuid.lib gdiplus.lib ws2_32.lib /link /SUBSYSTEM:WINDOWS
if %ERRORLEVEL% neq 0 (
    echo [BUILD FAILED]
    pause
    exit /b 1
)

:BUILD_OK
echo.
echo [BUILD OK] vw_deck.exe created.
echo.
echo Launching...
start vw_deck.exe
pause
