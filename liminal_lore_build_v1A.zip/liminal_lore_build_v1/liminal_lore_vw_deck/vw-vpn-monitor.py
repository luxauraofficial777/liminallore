#!/usr/bin/env python3
"""
VoidWalkers VPN Monitor — Port 8645
Auto-reconnect, health checks, relay failover.
Replaces legacy liminal-link.py.
"""
import argparse
import json
import os
import sys
import threading
import time
import urllib.request
from http.server import HTTPServer, BaseHTTPRequestHandler

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_DIR = os.path.join(SCRIPT_DIR, "logs")
VPN_LOG = os.path.join(LOG_DIR, "vpn_monitor.log")
os.makedirs(LOG_DIR, exist_ok=True)

# ─── CONFIG LOADER ───
def load_vpn_config():
    """Load VPN config from deck config or standalone vpn_config.json."""
    cfg = {
        "enabled": True,
        "provider": "vpngate",
        "client_type": "softether",
        "client_path": None,
        "nic_name": "VPN",
        "account_prefix": "VW_",
        "ip_check_url": "https://checkip.amazonaws.com",
        "providers": {
            "vpngate": {
                "api_url": "https://www.vpngate.net/api/iphone/",
                "filters": {"countries": ["JP", "KR"], "min_score": 200000, "min_speed": 1500000, "min_uptime": 1800},
                "ports": [443, 992, 5555],
                "hub_default": "VPNGATE",
                "username": "anonymous"
            },
            "custom": {"relays": []},
            "wireguard": {"config_dir": ".", "interface_name": "wg0", "command": "wireguard.exe"}
        }
    }
    # Try master deck config first
    for path in [os.path.join(SCRIPT_DIR, "vw_deck.config.json"), os.path.join(SCRIPT_DIR, "vpn_config.json")]:
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if "vpn" in data:
                    deep_update(cfg, data["vpn"])
                else:
                    deep_update(cfg, data)
                break
            except Exception as e:
                log(f"[CONFIG] Load warning from {path}: {e}")
    return cfg

def deep_update(base, overlay):
    for k, v in overlay.items():
        if isinstance(v, dict) and k in base and isinstance(base[k], dict):
            deep_update(base[k], v)
        else:
            base[k] = v

VPN_CONFIG = load_vpn_config()

VPINGATE_API = VPN_CONFIG.get("providers", {}).get("vpngate", {}).get("api_url", "https://www.vpngate.net/api/iphone/")
IP_CHECK = VPN_CONFIG.get("ip_check_url", "https://checkip.amazonaws.com")
ACCT_PREFIX = VPN_CONFIG.get("account_prefix", "VW_")
NIC_NAME = VPN_CONFIG.get("nic_name", "VPN")
CLIENT_PATH = VPN_CONFIG.get("client_path", None)
PROVIDER = VPN_CONFIG.get("provider", "vpngate")

_state = {
    "connected": False,
    "exit_ip": None,
    "last_check": 0,
    "current_account": None,
    "failures": 0,
    "relays": []
}
_state_lock = threading.Lock()


def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    with open(VPN_LOG, "a", encoding="utf-8") as f:
        f.write(line + "\n")


def _find_vpncmd():
    if CLIENT_PATH and os.path.exists(CLIENT_PATH):
        return CLIENT_PATH
    for path in [
        r"C:\Program Files\SoftEther VPN Client\vpncmd.exe",
        r"C:\Program Files (x86)\SoftEther VPN Client\vpncmd.exe",
    ]:
        if os.path.exists(path):
            return path
    return None


def _ensure_nic():
    """Ensure SoftEther virtual NIC exists before creating accounts."""
    lines = vpncmd("NicList")
    has_vpn = any(NIC_NAME in line for line in lines)
    if not has_vpn:
        log(f"[NIC] Virtual NIC '{NIC_NAME}' not found. Creating...")
        out = vpncmd("NicCreate", NIC_NAME)
        log(f"[NIC] NicCreate output: {out}")
    else:
        log(f"[NIC] Virtual NIC '{NIC_NAME}' OK.")


def vpncmd(*args):
    exe = _find_vpncmd()
    if not exe:
        return []
    import subprocess
    cmd = [exe, "localhost", "/CLIENT", "/CMD"] + list(args)
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        return out.stdout.splitlines()
    except Exception as e:
        log(f"[ERROR] vpncmd failed: {e}")
        return []


def check_ip():
    try:
        with urllib.request.urlopen(IP_CHECK, timeout=5) as r:
            return r.read().decode().strip()
    except Exception:
        return None


def get_accounts():
    lines = vpncmd("AccountList")
    accounts = []
    for line in lines:
        line = line.strip()
        if line.startswith(ACCT_PREFIX):
            name = line.split()[0]
            accounts.append(name)
    return accounts


def is_connected():
    lines = vpncmd("AccountList")
    for line in lines:
        if "Connection" in line and "Established" in line:
            return True
    return False


def disconnect_all():
    for acct in get_accounts():
        vpncmd("AccountDisconnect", acct)


def get_vpn_interface_name():
    """Get exact Windows interface name for SoftEther VPN adapter."""
    try:
        import subprocess
        out = subprocess.run(["netsh", "interface", "show", "interface"], capture_output=True, text=True, timeout=10)
        for line in out.stdout.splitlines():
            l = line.strip()
            if "VPN" in l:
                # netsh format: AdminState  State  Type  InterfaceName
                # Split on 2+ spaces to preserve names with spaces
                parts = [p.strip() for p in l.split("  ") if p.strip()]
                if len(parts) >= 4:
                    # name is everything after Type (3rd column, 0-indexed)
                    # Reconstruct by finding where Type column ends
                    type_col = parts[2]  # e.g. "Dedicated"
                    idx = l.find(type_col) + len(type_col)
                    name = l[idx:].strip()
                    if name:
                        return name
    except Exception:
        pass
    return None


def get_vpn_adapter_ip():
    """Check if the SoftEther virtual adapter has received a DHCP IP."""
    try:
        import subprocess
        out = subprocess.run(["ipconfig"], capture_output=True, text=True, timeout=10)
        lines = out.stdout.splitlines()
        in_vpn = False
        for line in lines:
            # Match "VPN Client Adapter", "VPN - VPN Client", "Virtual Ethernet", etc.
            if "VPN" in line or "Virtual" in line or "Tunnel" in line:
                in_vpn = True
            if in_vpn and "IPv4" in line:
                ip = line.split(":")[-1].strip()
                if ip and not ip.startswith("169.254"):
                    return ip
            if in_vpn and line.strip() == "":
                in_vpn = False
    except Exception:
        pass
    return None


def reset_vpn_adapter():
    """Disable/enable adapter cycle + DHCP renewal for stubborn adapters."""
    try:
        import subprocess
        iface = get_vpn_interface_name()
        if iface:
            subprocess.run(f'netsh interface set interface name="{iface}" admin=disabled', shell=True, capture_output=True, timeout=10)
            time.sleep(2)
            subprocess.run(f'netsh interface set interface name="{iface}" admin=enabled', shell=True, capture_output=True, timeout=10)
            time.sleep(3)
            subprocess.run(f'netsh interface ip set address name="{iface}" source=dhcp', shell=True, capture_output=True, timeout=10)
            subprocess.run(f'netsh interface ip set dns name="{iface}" source=dhcp', shell=True, capture_output=True, timeout=10)
        subprocess.run(["ipconfig", "/release", "*VPN*"], capture_output=True, timeout=10)
        time.sleep(1)
        subprocess.run(["ipconfig", "/renew", "*VPN*"], capture_output=True, timeout=15)
        time.sleep(3)
    except Exception:
        pass


def renew_vpn_adapter():
    """Force DHCP renewal on VPN adapters using exact interface name."""
    try:
        import subprocess
        iface = get_vpn_interface_name()
        if iface:
            subprocess.run(f'netsh interface ip set address name="{iface}" source=dhcp', shell=True, capture_output=True, timeout=10)
            subprocess.run(f'netsh interface ip set dns name="{iface}" source=dhcp', shell=True, capture_output=True, timeout=10)
        subprocess.run(["ipconfig", "/release", "*VPN*"], capture_output=True, timeout=10)
        time.sleep(1)
        subprocess.run(["ipconfig", "/renew", "*VPN*"], capture_output=True, timeout=15)
        time.sleep(3)
    except Exception:
        pass


def connect_account(name):
    log(f"[TRY] Connecting {name} ...")
    vpncmd("AccountDisconnect", name)
    time.sleep(1)
    vpncmd("AccountConnect", name)
    # Wait for SoftEther handshake + Windows DHCP
    for attempt in range(15):
        time.sleep(2)
        adapter_ip = get_vpn_adapter_ip()
        if adapter_ip:
            break
    if not adapter_ip:
        # Hard reset: disable/enable adapter cycle + DHCP renew
        log("[DHCP] No adapter IP, hard resetting adapter...")
        reset_vpn_adapter()
        adapter_ip = get_vpn_adapter_ip()
    if adapter_ip:
        exit_ip = check_ip()
        with _state_lock:
            _state["connected"] = True
            _state["exit_ip"] = exit_ip
            _state["current_account"] = name
            _state["failures"] = 0
        log(f"[OK] Connected {name} — adapter IP: {adapter_ip}, exit IP: {exit_ip}")
        return True
    log(f"[FAIL] {name} connected but no adapter IP assigned. Disconnecting.")
    vpncmd("AccountDisconnect", name)
    return False


def fetch_relays():
    _ensure_nic()
    if PROVIDER == "custom":
        return _fetch_custom_relays()
    if PROVIDER == "wireguard":
        return _fetch_wireguard_relays()
    log("[FETCH] Pulling fresh VPN Gate relays...")
    vpg = VPN_CONFIG.get("providers", {}).get("vpngate", {})
    filt = vpg.get("filters", {})
    countries = filt.get("countries", ["JP", "KR"])
    min_score = filt.get("min_score", 200000)
    min_speed = filt.get("min_speed", 1500000)
    min_uptime = filt.get("min_uptime", 1800)
    ports = vpg.get("ports", [443, 992, 5555])
    hub_default = vpg.get("hub_default", "VPNGATE")
    username = vpg.get("username", "anonymous")
    try:
        with urllib.request.urlopen(VPINGATE_API, timeout=20) as r:
            data = r.read().decode()
        lines = data.splitlines()[2:-2]
        relays = []
        for line in lines:
            cols = line.split(",")
            if len(cols) < 15:
                continue
            country = cols[6]
            score = int(cols[2]) if cols[2].isdigit() else 0
            speed = int(cols[4]) if cols[4].isdigit() else 0
            uptime = int(cols[8]) if cols[8].isdigit() else 0
            hostname = cols[0]
            ip = cols[1]
            hub = cols[13] if cols[13] and cols[13] != "*" else hub_default
            if country in countries and score > min_score and speed > min_speed and uptime > min_uptime:
                relays.append({
                    "name": f"{ACCT_PREFIX}{country}_{ip}",
                    "host": hostname if hostname and hostname != "*" else ip,
                    "hub": hub,
                    "score": score,
                    "country": country
                })
        relays.sort(key=lambda x: x["score"], reverse=True)
        top = relays[:10]
        for r in top:
            vpncmd("AccountDelete", r["name"])
            created = False
            for port in ports:
                out = vpncmd("AccountCreate", r["name"], f"/SERVER:{r['host']}:{port}", f"/HUB:{r['hub']}", f"/USERNAME:{username}", f"/NICNAME:{NIC_NAME}")
                if any("completed" in line.lower() or "ok" in line.lower() for line in out):
                    vpncmd("AccountDetailSet", r["name"], "/UDPEnabled:yes")
                    created = True
                    break
                vpncmd("AccountDelete", r["name"])
            if not created:
                log(f"[WARN] Failed to create account for {r['name']} on any port")
        with _state_lock:
            _state["relays"] = top
        log(f"[FETCH] Imported {len(top)} fresh relays.")
        return [r["name"] for r in top]
    except Exception as e:
        log(f"[ERROR] Fetch failed: {e}")
        return []


def _fetch_custom_relays():
    _ensure_nic()
    custom = VPN_CONFIG.get("providers", {}).get("custom", {})
    relays = custom.get("relays", [])
    names = []
    for r in relays:
        name = r.get("name", "CustomVPN")
        vpncmd("AccountDelete", name)
        out = vpncmd("AccountCreate", name, f"/SERVER:{r['host']}:{r.get('port', 443)}", f"/HUB:{r.get('hub', 'DEFAULT')}", f"/USERNAME:{r.get('username', 'user')}", f"/NICNAME:{r.get('nic_name', NIC_NAME)}")
        if any("completed" in line.lower() or "ok" in line.lower() for line in out):
            vpncmd("AccountDetailSet", name, "/UDPEnabled:yes")
            names.append(name)
        else:
            log(f"[WARN] Failed to create custom account {name}")
    with _state_lock:
        _state["relays"] = relays
    log(f"[FETCH] Loaded {len(names)} custom relays.")
    return names


def _fetch_wireguard_relays():
    wg = VPN_CONFIG.get("providers", {}).get("wireguard", {})
    log(f"[FETCH] WireGuard provider: interface={wg.get('interface_name', 'wg0')} (not yet auto-managed)")
    with _state_lock:
        _state["relays"] = []
    return []


def monitor_loop():
    _ensure_nic()
    accounts = get_accounts()
    if not accounts:
        log(f"[WARN] No {ACCT_PREFIX} accounts found. Fetching fresh relays...")
        accounts = fetch_relays()

    while True:
        if not is_connected():
            with _state_lock:
                _state["failures"] += 1
                failures = _state["failures"]
            log(f"[WARN] VPN disconnected (failure {failures}/3).")
            if failures >= 3:
                log("[FAILOVER] Exhausted known relays. Fetching new ones...")
                accounts = fetch_relays()
                with _state_lock:
                    _state["failures"] = 0
            connected = False
            for acct in accounts:
                if connect_account(acct):
                    connected = True
                    break
                time.sleep(2)
            if not connected:
                log("[CRITICAL] All relays failed. Waiting 60s...")
                time.sleep(60)
                continue
        else:
            ip = check_ip()
            with _state_lock:
                if _state["failures"] > 0:
                    log("[RECOVER] VPN tunnel restored.")
                _state["failures"] = 0
                _state["connected"] = True
                _state["exit_ip"] = ip
                _state["last_check"] = time.time()
        time.sleep(30)


def start_http(port):
    class H(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path == "/health":
                with _state_lock:
                    payload = json.dumps({
                        "ok": True,
                        "provider": PROVIDER,
                        "connected": _state["connected"],
                        "exit_ip": _state["exit_ip"],
                        "current_account": _state["current_account"],
                        "failures": _state["failures"],
                        "relay_count": len(_state["relays"]),
                        "nic_name": NIC_NAME,
                        "client_type": VPN_CONFIG.get("client_type", "softether")
                    })
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(payload.encode())
            elif self.path == "/config":
                # Return non-sensitive config (no credentials)
                safe_cfg = {
                    "enabled": VPN_CONFIG.get("enabled", True),
                    "provider": PROVIDER,
                    "client_type": VPN_CONFIG.get("client_type", "softether"),
                    "nic_name": NIC_NAME,
                    "account_prefix": ACCT_PREFIX,
                    "ip_check_url": IP_CHECK,
                }
                if PROVIDER == "vpngate":
                    vpg = VPN_CONFIG.get("providers", {}).get("vpngate", {})
                    safe_cfg["filters"] = vpg.get("filters", {})
                    safe_cfg["ports"] = vpg.get("ports", [443, 992, 5555])
                elif PROVIDER == "custom":
                    custom = VPN_CONFIG.get("providers", {}).get("custom", {})
                    safe_cfg["relay_count"] = len(custom.get("relays", []))
                    safe_cfg["relay_names"] = [r.get("name", "?") for r in custom.get("relays", [])]
                elif PROVIDER == "wireguard":
                    wg = VPN_CONFIG.get("providers", {}).get("wireguard", {})
                    safe_cfg["interface_name"] = wg.get("interface_name", "wg0")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(safe_cfg).encode())
            elif self.path == "/force-reconnect":
                threading.Thread(target=monitor_loop, daemon=True).start()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"ok":true,"action":"reconnect_triggered"}')
            else:
                self.send_response(404)
                self.end_headers()

        def log_message(self, fmt, *args):
            pass

    srv = HTTPServer(("127.0.0.1", port), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    log(f"[HTTP] VPN Monitor on http://127.0.0.1:{port}/health")
    return srv


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8645)
    args = ap.parse_args()

    start_http(args.port)
    monitor_loop()
