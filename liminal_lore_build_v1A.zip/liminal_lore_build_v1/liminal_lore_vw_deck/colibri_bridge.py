#!/usr/bin/env python3
"""
Colibri Bridge — Expert streaming service for the VoidWalkers distilled agent MoE.

Adapts Colibri's disk-streaming expert architecture (LFRU cache, heat tracking,
SSD-to-RAM swap) to work with Ollama-hosted distilled agents, fused with:
  - HBE (Heart Beat Engine) cadence for cache clearing and tier-swapping
  - TurboQuant for dynamic RAM pressure monitoring and KV-cache scaling
  - VW Nexus for agent registration and task routing

The 4 distilled agents are treated as "experts" in the MoE sense:
  - Only `max_hot` agents are "hot" (loaded in Ollama RAM) at any time
  - Cold agents live on SSD and are swapped in on demand
  - LFRU (Frequency + Recency) algorithm decides which expert to evict
  - HBE heartbeat controls decay cadence and prefetch timing
  - TurboQuant RAM pressure can force emergency eviction

HTTP API on port 8648:
  GET  /colibri/status         — current expert cache state
  GET  /colibri/experts        — list all experts with hot/cold status
  POST /colibri/activate       — activate (swap in) an expert by name
  POST /colibri/deactivate     — deactivate (swap out) an expert
  POST /colibri/heartbeat      — HBE pulse: decay heat, check RAM, maybe swap
  GET  /colibri/health         — simple health check
"""

import argparse
import json
import os
import sys
import sqlite3
import time
import threading
import urllib.request
import urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# ─── Configuration ───
EXPERTS = [
    {"name": "lux-architect", "disk_mb": 2048, "spec": "C++/DX11/ASM rendering"},
    {"name": "nex",           "disk_mb": 2048, "spec": "PSX emulator dev, MIPS/HBD"},
    {"name": "nexx",          "disk_mb": 1300, "spec": "Build systems, audits, SOPs"},
    {"name": "n3x",           "disk_mb": 2048, "spec": "Asset pipelines, RigForge, quant"},
]

OLLAMA_URL = "http://127.0.0.1:11434"
TURBOQUANT_URL = "http://127.0.0.1:8646"
NEXUS_URL = "http://127.0.0.1:8651"
HERMES_URL = "http://127.0.0.1:8643"

DEFAULT_RAM_BUDGET_MB = 10240  # 10 GB cap (16 GB system, 6 GB for OS + HD620 + KV cache)
DEFAULT_MAX_HOT = 2            # 2 active + 2 cold per README
HEARTBEAT_INTERVAL_S = 30      # HBE cadence
DECAY_FACTOR = 0.9             # gentle decay: ~5 min half-life instead of 30s
MIN_HEAT = 1                   # floor: accessed experts stay above never-accessed
SWAP_HYSTERESIS = 0.25         # 25% + 4 freq margin from tier.h
RECENT_WINDOW = 64             # 64 ticks @ 30s = ~32 min recency window
EMERGENCY_RAM_PCT = 65         # early eviction threshold (was 70)
HALT_RAM_PCT = 70              # hard halt threshold

# ─── Expert State (adapted from Colibri tier.h) ───
class ExpertState:
    def __init__(self, name, disk_mb, spec):
        self.name = name
        self.disk_mb = disk_mb
        self.spec = spec
        self.heat = 0          # access frequency count (tier.h: uint32_t heat)
        self.last_access = 0   # clock tick of last access (tier.h: uint32_t last)
        self.hot = False       # resident in RAM (loaded in Ollama)
        self.load_time = 0     # timestamp when loaded
        self.access_count = 0  # total accesses
        self.swap_count = 0    # times swapped in/out

    def lfru_score(self, clock):
        """LFRU score from tier.h: frequency primary, recency breaks ties."""
        age = clock - self.last_access
        recent = RECENT_WINDOW - age if age < RECENT_WINDOW else 0
        return (self.heat << 8) | recent

    def access(self, clock):
        self.heat += 1
        self.last_access = clock
        self.access_count += 1

    def decay(self):
        """Heat decay: fractional decay with MIN_HEAT floor.
        0.9 per heartbeat gives ~5 min half-life instead of 30s."""
        self.heat = max(MIN_HEAT, int(self.heat * DECAY_FACTOR)) if self.heat > 0 else 0


class ColibriBridge:
    def __init__(self, ram_budget_mb=DEFAULT_RAM_BUDGET_MB, max_hot=DEFAULT_MAX_HOT, db_path=None):
        self.experts = {e["name"]: ExpertState(e["name"], e["disk_mb"], e["spec"]) for e in EXPERTS}
        self.ram_budget_mb = ram_budget_mb
        self.max_hot = max_hot
        self.clock = 0  # monotonic tick counter (incremented each heartbeat)
        self.cache_hits = 0
        self.cache_misses = 0
        self.swap_events = 0
        self.ram_used_mb = 0
        self.lock = threading.Lock()
        self.last_heartbeat = 0
        self.tq_alive = False
        self.ollama_alive = False
        self._stop = False
        self._hb_thread = None
        self._db_path = db_path
        self._db = None
        if db_path:
            self._init_db()
            self._load_state()

    def _init_db(self):
        """Initialize SQLite persistence database."""
        os.makedirs(os.path.dirname(self._db_path), exist_ok=True)
        self._db = sqlite3.connect(self._db_path, check_same_thread=False)
        self._db.execute("""
            CREATE TABLE IF NOT EXISTS expert_state (
                name TEXT PRIMARY KEY,
                heat INTEGER DEFAULT 0,
                access_count INTEGER DEFAULT 0,
                swap_count INTEGER DEFAULT 0,
                hot INTEGER DEFAULT 0,
                last_access INTEGER DEFAULT 0
            )
        """)
        self._db.execute("""
            CREATE TABLE IF NOT EXISTS bridge_meta (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        self._db.commit()

    def _load_state(self):
        """Load expert state from SQLite on startup."""
        try:
            cur = self._db.execute("SELECT name, heat, access_count, swap_count, hot, last_access FROM expert_state")
            for row in cur.fetchall():
                name, heat, access_count, swap_count, hot, last_access = row
                if name in self.experts:
                    e = self.experts[name]
                    e.heat = heat
                    e.access_count = access_count
                    e.swap_count = swap_count
                    e.hot = bool(hot)
                    e.last_access = last_access
            cur = self._db.execute("SELECT value FROM bridge_meta WHERE key='clock'")
            row = cur.fetchone()
            if row:
                self.clock = int(row[0])
            cur = self._db.execute("SELECT value FROM bridge_meta WHERE key='cache_hits'")
            row = cur.fetchone()
            if row:
                self.cache_hits = int(row[0])
            cur = self._db.execute("SELECT value FROM bridge_meta WHERE key='cache_misses'")
            row = cur.fetchone()
            if row:
                self.cache_misses = int(row[0])
            cur = self._db.execute("SELECT value FROM bridge_meta WHERE key='swap_events'")
            row = cur.fetchone()
            if row:
                self.swap_events = int(row[0])
            self._log(f"State loaded from {self._db_path} (clock={self.clock})")
        except Exception as e:
            self._log(f"Failed to load state: {e}")

    def _save_state(self):
        """Persist expert state to SQLite."""
        if not self._db:
            return
        try:
            for name, e in self.experts.items():
                self._db.execute(
                    "INSERT OR REPLACE INTO expert_state (name, heat, access_count, swap_count, hot, last_access) VALUES (?, ?, ?, ?, ?, ?)",
                    (name, e.heat, e.access_count, e.swap_count, int(e.hot), e.last_access)
                )
            self._db.execute("INSERT OR REPLACE INTO bridge_meta (key, value) VALUES ('clock', ?)", (str(self.clock),))
            self._db.execute("INSERT OR REPLACE INTO bridge_meta (key, value) VALUES ('cache_hits', ?)", (str(self.cache_hits),))
            self._db.execute("INSERT OR REPLACE INTO bridge_meta (key, value) VALUES ('cache_misses', ?)", (str(self.cache_misses),))
            self._db.execute("INSERT OR REPLACE INTO bridge_meta (key, value) VALUES ('swap_events', ?)", (str(self.swap_events),))
            self._db.commit()
        except Exception as e:
            self._log(f"Failed to save state: {e}")

    def _ram_used(self):
        """Calculate current RAM usage from hot experts."""
        return sum(e.disk_mb for e in self.experts.values() if e.hot)

    def _check_turboquant(self):
        """Check TurboQuant status for RAM pressure."""
        try:
            req = urllib.request.Request(f"{TURBOQUANT_URL}/tq/status", method="GET")
            with urllib.request.urlopen(req, timeout=2) as resp:
                data = json.loads(resp.read())
                self.tq_alive = True
                return data
        except Exception:
            self.tq_alive = False
            return None

    def _check_ollama(self):
        """Check if Ollama is running and which models are loaded."""
        try:
            req = urllib.request.Request(f"{OLLAMA_URL}/api/tags", method="GET")
            with urllib.request.urlopen(req, timeout=2) as resp:
                data = json.loads(resp.read())
                self.ollama_alive = True
                return data
        except Exception:
            self.ollama_alive = False
            return None

    def _pick_swap_candidate(self):
        """LFRU swap algorithm from Colibri tier.h.
        Find the coldest hot expert and the hottest cold expert.
        If hot > cold + hysteresis, swap them."""
        hot_experts = [e for e in self.experts.values() if e.hot]
        cold_experts = [e for e in self.experts.values() if not e.hot]

        if not hot_experts or not cold_experts:
            return None, None

        # Find coldest hot expert (lowest LFRU score)
        coldest_hot = min(hot_experts, key=lambda e: e.lfru_score(self.clock))
        # Find hottest cold expert (highest LFRU score)
        hottest_cold = max(cold_experts, key=lambda e: e.lfru_score(self.clock))

        # Hysteresis check from tier.h: hs <= cs + cs>>2 + (4<<8)
        cs = coldest_hot.lfru_score(self.clock)
        hs = hottest_cold.lfru_score(self.clock)
        threshold = cs + (cs >> 2) + (4 << 8)

        if hs <= threshold:
            return None, None  # No swap needed

        return coldest_hot, hottest_cold

    def _force_evict_coldest(self):
        """Emergency eviction when RAM pressure is critical."""
        hot_experts = [e for e in self.experts.values() if e.hot]
        if not hot_experts:
            return None
        coldest = min(hot_experts, key=lambda e: e.lfru_score(self.clock))
        coldest.hot = False
        coldest.swap_count += 1
        self.swap_events += 1
        self.ram_used_mb = self._ram_used()
        return coldest.name

    def _can_fit_expert(self, expert):
        """Check if an expert can fit in RAM, gating on live TurboQuant pressure."""
        tq = self._check_turboquant()
        if tq:
            ram_pct = tq.get("ram_pct", 0)
            if ram_pct >= EMERGENCY_RAM_PCT:
                return False, f"RAM pressure {ram_pct:.0f}% >= {EMERGENCY_RAM_PCT}% early eviction"
        projected = self._ram_used() + expert.disk_mb
        if projected > self.ram_budget_mb:
            return False, f"RAM budget exceeded ({projected}MB > {self.ram_budget_mb}MB)"
        return True, ""

    def activate(self, name):
        """Activate (swap in) an expert. Returns True if successful.
        Strict LFRU admission: only admit if LFRU hysteresis passes or RAM has room."""
        with self.lock:
            if name not in self.experts:
                return False, f"Unknown expert: {name}"

            expert = self.experts[name]
            self.clock += 1
            expert.access(self.clock)

            if expert.hot:
                self.cache_hits += 1
                return True, f"Expert {name} already hot (cache hit)"

            self.cache_misses += 1

            hot_count = sum(1 for e in self.experts.values() if e.hot)

            # Case A: room under max_hot — just load if RAM allows
            if hot_count < self.max_hot:
                ok, msg = self._can_fit_expert(expert)
                if not ok:
                    return False, msg
                expert.hot = True
                expert.load_time = time.time()
                expert.swap_count += 1
                self.swap_events += 1
                self.ram_used_mb = self._ram_used()
                return True, f"Expert {name} loaded"

            # Case B: at max_hot — only admit if LFRU says this cold expert outranks a hot one
            coldest, hottest = self._pick_swap_candidate()
            if hottest and hottest.name == name:
                # Verify RAM fits after swap
                ok, msg = self._can_fit_expert(expert)
                if not ok:
                    return False, msg
                coldest.hot = False
                coldest.swap_count += 1
                hottest.hot = True
                hottest.load_time = time.time()
                hottest.swap_count += 1
                self.swap_events += 1
                self.ram_used_mb = self._ram_used()
                return True, f"Expert {name} swapped in via LFRU (evicted {coldest.name})"

            # Case C: deny — cold expert not hot enough to displace current hot experts
            return False, f"LFRU hysteresis blocked {name}: not hot enough to displace current hot experts"

    def deactivate(self, name):
        """Deactivate (swap out) an expert."""
        with self.lock:
            if name not in self.experts:
                return False, f"Unknown expert: {name}"
            expert = self.experts[name]
            if not expert.hot:
                return True, f"Expert {name} already cold"
            expert.hot = False
            expert.swap_count += 1
            self.swap_events += 1
            self.ram_used_mb = self._ram_used()
            return True, f"Expert {name} deactivated (swap out)"

    def heartbeat(self):
        """HBE pulse: decay heat, check RAM pressure, maybe swap experts."""
        with self.lock:
            self.clock += 1
            self.last_heartbeat = time.time()

            # Decay all expert heat (tier.h: tier_decay)
            for expert in self.experts.values():
                expert.decay()

            # Check TurboQuant for RAM pressure
            tq_data = self._check_turboquant()
            if tq_data:
                ram_pct = tq_data.get("ram_pct", 0)
                # Emergency eviction at 65% RAM (early eviction to protect HD620 shared memory)
                if ram_pct >= EMERGENCY_RAM_PCT:
                    hot_count = sum(1 for e in self.experts.values() if e.hot)
                    if hot_count > 1:
                        evicted = self._force_evict_coldest()
                        if evicted:
                            self._log(f"[HBE] Emergency eviction: {evicted} (RAM {ram_pct:.0f}%)")

            # Check Ollama model status
            ollama_data = self._check_ollama()
            if ollama_data:
                loaded_models = set()
                for m in ollama_data.get("models", []):
                    loaded_models.add(m.get("name", "").split(":")[0])
                # Sync expert hot state with Ollama loaded models
                for name, expert in self.experts.items():
                    if expert.hot and name not in loaded_models:
                        expert.hot = False
                        self.swap_events += 1
                        self._log(f"[SYNC] {name} unloaded by Ollama (detected via /api/tags)")

            # Try LFRU swap if we have room
            coldest, hottest = self._pick_swap_candidate()
            if coldest and hottest:
                # Only swap if we're not at max_hot or can evict
                hot_count = sum(1 for e in self.experts.values() if e.hot)
                if hot_count <= self.max_hot:
                    coldest.hot = False
                    hottest.hot = True
                    hottest.load_time = time.time()
                    coldest.swap_count += 1
                    hottest.swap_count += 1
                    self.swap_events += 1
                    self.ram_used_mb = self._ram_used()
                    self._log(f"[LFRU] Swap: {coldest.name} -> {hottest.name}")

            self.ram_used_mb = self._ram_used()
            self._save_state()
            return True

    def status(self):
        """Get current bridge status for telemetry."""
        with self.lock:
            hot_experts = [e for e in self.experts.values() if e.hot]
            cold_experts = [e for e in self.experts.values() if not e.hot]
            hot_names = [e.name for e in hot_experts]
            # Pick the most recently loaded as "hot_expert_name"
            hot_name = max(hot_experts, key=lambda e: e.load_time).name if hot_experts else "--"

            return {
                "alive": True,
                "hot_expert": len(hot_experts),
                "cold_experts": len(cold_experts),
                "hot_expert_name": hot_name,
                "hot_experts": hot_names,
                "cache_hits": self.cache_hits,
                "cache_misses": self.cache_misses,
                "swap_events": self.swap_events,
                "ram_budget_mb": self.ram_budget_mb,
                "ram_used_mb": self.ram_used_mb,
                "max_hot": self.max_hot,
                "clock": self.clock,
                "ollama_alive": self.ollama_alive,
                "tq_alive": self.tq_alive,
                "experts": [
                    {
                        "name": e.name,
                        "hot": e.hot,
                        "heat": e.heat,
                        "access_count": e.access_count,
                        "swap_count": e.swap_count,
                        "disk_mb": e.disk_mb,
                        "spec": e.spec,
                    }
                    for e in self.experts.values()
                ],
            }

    def _log(self, msg):
        print(f"[Colibri] {msg}", flush=True)

    def start_heartbeat_loop(self):
        """Start background HBE heartbeat thread."""
        def _loop():
            while not self._stop:
                try:
                    self.heartbeat()
                except Exception as e:
                    self._log(f"Heartbeat error: {e}")
                time.sleep(HEARTBEAT_INTERVAL_S)

        self._hb_thread = threading.Thread(target=_loop, daemon=True)
        self._hb_thread.start()
        self._log(f"Heartbeat loop started (interval={HEARTBEAT_INTERVAL_S}s)")

    def stop(self):
        self._stop = True
        if self._db:
            self._save_state()
            self._db.close()


# ─── HTTP Server ───
bridge = None  # Global bridge instance


class ColibriHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass  # Suppress default logging

    def _json_response(self, code, data):
        body = json.dumps(data).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self):
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        try:
            return json.loads(self.rfile.read(length))
        except Exception:
            return {}

    def do_GET(self):
        if self.path == "/colibri/status":
            self._json_response(200, bridge.status())
        elif self.path == "/colibri/experts":
            self._json_response(200, {"experts": bridge.status()["experts"]})
        elif self.path == "/colibri/health":
            self._json_response(200, {"ok": True, "service": "colibri-bridge"})
        else:
            self._json_response(404, {"error": "Not found"})

    def do_POST(self):
        body = self._read_body()

        if self.path == "/colibri/activate":
            name = body.get("name", "")
            ok, msg = bridge.activate(name)
            self._json_response(200 if ok else 400, {"ok": ok, "message": msg})

        elif self.path == "/colibri/deactivate":
            name = body.get("name", "")
            ok, msg = bridge.deactivate(name)
            self._json_response(200 if ok else 400, {"ok": ok, "message": msg})

        elif self.path == "/colibri/heartbeat":
            ok = bridge.heartbeat()
            self._json_response(200, {"ok": ok, "status": bridge.status()})

        else:
            self._json_response(404, {"error": "Not found"})


def main():
    global bridge
    parser = argparse.ArgumentParser(description="Colibri Bridge — Expert streaming for VW distilled agents")
    parser.add_argument("--port", type=int, default=8648, help="HTTP port (default: 8648)")
    parser.add_argument("--ram", type=int, default=DEFAULT_RAM_BUDGET_MB, help="RAM budget in MB")
    parser.add_argument("--max-hot", type=int, default=DEFAULT_MAX_HOT, help="Max concurrent hot experts")
    parser.add_argument("--db", type=str, default=os.path.join(os.path.dirname(__file__), "data", "colibri_state.db"), help="SQLite state DB path")
    parser.add_argument("--no-heartbeat", action="store_true", help="Disable automatic heartbeat loop")
    args = parser.parse_args()

    bridge = ColibriBridge(ram_budget_mb=args.ram, max_hot=args.max_hot, db_path=args.db)

    # Pre-activate first 2 experts (lux-architect + nex) as default hot set
    bridge.activate("lux-architect")
    bridge.activate("nex")

    if not args.no_heartbeat:
        bridge.start_heartbeat_loop()

    server = ThreadingHTTPServer(("127.0.0.1", args.port), ColibriHandler)
    print(f"[Colibri] Bridge listening on 127.0.0.1:{args.port}")
    print(f"[Colibri] RAM budget: {args.ram}MB, max hot: {args.max_hot}")
    print(f"[Colibri] Experts: {[e['name'] for e in EXPERTS]}")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[Colibri] Shutting down...")
        bridge.stop()
        server.shutdown()


if __name__ == "__main__":
    main()
