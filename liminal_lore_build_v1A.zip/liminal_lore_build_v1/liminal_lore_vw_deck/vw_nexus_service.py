"""Service wrapper that launches the VW Nexus from the deck directory.

This script is used by the C++ vw_deck.exe to start the Nexus with the
correct PYTHONPATH without requiring a global package install.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path


def main():
    # Add the parent tools directory to the import path
    deck_dir = Path(__file__).resolve().parent
    tools_dir = deck_dir.parent
    if str(tools_dir) not in sys.path:
        sys.path.insert(0, str(tools_dir))

    # Default to the Modern_X64 project root
    project_root = deck_dir.parent.parent
    os.environ.setdefault("VW_ROOT", str(project_root))

    from vw_nexus.__main__ import main as nexus_main
    nexus_main()


if __name__ == "__main__":
    main()
