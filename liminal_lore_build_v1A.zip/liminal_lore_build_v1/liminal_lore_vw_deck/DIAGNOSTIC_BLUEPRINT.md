# VW Deck Total Integration Blueprint
## Diagnostic Telemetry, Nexus Control, and Process Monitoring

### Service Architecture (Current)

| Service    | Port  | Tech      | Role                                          |
|------------|-------|-----------|-----------------------------------------------|
| Hermes Bridge | 8643 | Node.js   | Middleware: web portal ↔ all backend services |
| Provider Harness | 8647 | Python | Unified model discovery (Ollama + KoboldCpp)  |
| Ollama     | 11434 | Go        | LLM inference engine                          |
| VW Nexus   | 8651  | Python    | Orchestration: agents, tasks, sessions, locks |
| Nexus WS   | 8652  | Python    | Real-time agent communication bus             |
| TurboQuant | 8646  | Python    | KV-cache scaling, memory pressure management  |
| Heartbeat  | —     | Python    | Background pulse monitor → resonance.json     |

### Phase 1: Backend — Telemetry Aggregation (hermes-bridge.js)

#### 1A. GET /nexus/telemetry
Single endpoint that aggregates all service health into one JSON blob:

```
{
  "timestamp": "ISO-8601",
  "nexus": {                    // from :8651/status + /agents
    "alive": true,
    "agents": [{id, name, state, last_heartbeat}],
    "tasks": {pending, claimed, running, done, failed},
    "sessions": N,
    "bus_stats": {...},
    "clock": {...}
  },
  "turboquant": {               // from :8646/tq/status
    "alive": true,
    "ram_pct": 62.3,
    "ram_used_gb": 9.8,
    "mode": "normal|scale|queue|halt",
    "is_safe": true,
    "should_scale": false,
    "kv_bits": 2
  },
  "heartbeat": {                // from resonance.json
    "ram_pressure": 0.62,
    "cpu_percent": 15.2,
    "ollama_alive": true,
    "active_agents": 4,
    "void_benevolence": true,
    "notes": "",
    "last_pulse": "ISO-8601"
  },
  "ollama": {                   // from :11434/api/tags
    "alive": true,
    "models": ["lux-architect:latest", "nex:latest", ...]
  },
  "committee": {                // from committee_manifest.json + transcript
    "members": N,
    "sessions": N,
    "mode": "lazy_sync|serial_consensus|parallel_debate",
    "last_variance": 0.12
  },
  "tier": {                     // from vw_deck.config.json
    "current": "potato",
    "label": "Potato (Intel HD620)",
    "max_concurrent": 1,
    "tq_strategy": "aggressive",
    "kv_bits": 2
  },
  "pipeline": {                 // from pipeline_manifest.json
    "active": "dx11",
    "label": "DirectX 11",
    "category": "modern"
  },
  "alerts": [                   // computed warning gates
    {"level": "amber|red", "source": "turboquant|nexus|heartbeat", "message": "..."}
  ]
}
```

#### 1B. GET /nexus/hbe-stats
HBE efficiency metrics from heartbeat logs + request counters:

```
{
  "total_pulses": 450,
  "llm_invocations": 22,
  "efficiency_rate": "95.1%",
  "deterministic_bypass": 428,
  "trigger_frequency_per_min": 2.5,
  "task_queue_depth": 3,
  "recent_pulses": [...]       // last 20 entries from heartbeat.jsonl
}
```

#### 1C. Telemetry Polling Loop
- 5-second interval background poll
- Caches results in memory for instant /nexus/telemetry responses
- Logs every snapshot to `AGENT/distilled_agents/logs/nexus_telemetry.log`
- Graceful degradation: if a service is down, mark it `alive: false` and continue

#### 1D. Request Counters
- Track total chat requests, committee triggers, pipeline switches
- Track per-model invocation count + cumulative latency
- Exposed via /nexus/hbe-stats

### Phase 2: Frontend — System Diagnostics Panel (VoidWalkers_Suite.html)

#### 2A. Layout
New collapsible right sidebar (`#diagPanel`), 300px wide, containing:

1. **Nexus Health Section**
   - Green/Yellow/Red pulse indicator based on agent response latency
   - Per-agent status grid: name, state, last heartbeat age
   - Task queue depth: pending/running/done/failed counts
   - Consensus variance gauge (drift meter)

2. **KV-Cache Section**
   - Bit-depth indicator: "KV-Cache: 2-bit [COMPRESSED]" or "Native [FULL]"
   - Memory pressure bar (0-100% with color gradient)
   - Mode badge: NORMAL / SCALE / QUEUE / HALT
   - Context utilization: tokens vs max window

3. **HBE Pulsar Section**
   - Pulse counter (total pulses / min)
   - Efficiency ratio: "95.1% bypass" with color coding
   - LLM invocations vs deterministic filters
   - Mini pulse graph (last 20 heartbeats as bar chart)

4. **Service Status Grid**
   - 6 service indicators: Bridge, Harness, Ollama, Nexus, TurboQuant, Heartbeat
   - Each shows green (up) / red (down) with latency ms

5. **Alert Banner**
   - Shows active alerts from telemetry
   - Amber for warnings, red for critical
   - Auto-dismiss when condition clears

#### 2B. Warning Gates
- **KV-Cache Overflow**: RAM > 70% → red alert
- **KV-Cache Pressure**: RAM > 65% → amber alert  
- **Nexus Arrhythmia**: Agent latency > 30s or Ollama down → red
- **Nexus Warning**: Agent latency > 10s → amber
- **Heartbeat Stale**: No pulse in 60s → amber

#### 2C. Auto-Refresh
- Polls `/nexus/telemetry` every 5 seconds
- Updates all panels in-place
- Toggle button to pause/resume polling
- Manual "REFRESH" button

### Phase 3: Implementation Order

1. Add telemetry state + polling loop to hermes-bridge.js
2. Add `/nexus/telemetry` endpoint
3. Add `/nexus/hbe-stats` endpoint  
4. Add request counter middleware
5. Add telemetry logging to nexus_telemetry.log
6. Add diagnostic sidebar HTML + CSS to VoidWalkers_Suite.html
7. Add diagnostic JS (fetch + render + auto-refresh)
8. Add warning gate logic
9. Add DIAGNOSTICS toggle button to toolbar
10. Rebuild Electron app

### Files Modified
- `hermes-bridge.js` — telemetry aggregation, polling, endpoints, logging
- `VoidWalkers_Suite.html` — diagnostic sidebar, auto-refresh, warning gates
- `electron/package.json` — version bump
