// ============================================================================
// preload.js — Electron Preload Script
// ============================================================================
// Exposes a safe IPC bridge to the renderer process for native menu events
// and file dialog results.
// ============================================================================

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('voidwalkersNative', {
  onMenuAction: (callback) => ipcRenderer.on('menu-action', (_, action) => callback(action)),
  onSwitchTool: (callback) => ipcRenderer.on('switch-tool', (_, tool) => callback(tool)),
  onFileOpened: (callback) => ipcRenderer.on('file-opened', (_, path) => callback(path)),
  onFileSaved: (callback) => ipcRenderer.on('file-saved', (_, path) => callback(path)),
  onFileImported: (callback) => ipcRenderer.on('file-imported', (_, path) => callback(path)),
  onFileExported: (callback) => ipcRenderer.on('file-exported', (_, path) => callback(path)),
  isElectron: true
});
