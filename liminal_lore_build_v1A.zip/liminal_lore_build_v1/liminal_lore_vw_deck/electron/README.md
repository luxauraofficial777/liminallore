# VoidWalkers Production Suite — Electron Wrapper (Layer C)

Native desktop distribution of the VoidWalkers Suite with OS-level menus,
file dialogs, and built-in CLI bridge server.

## Quick Start

```bash
cd tools/liminal_link_vw_deck/electron
npm install
npm start
```

## Build Installer

```bash
npm run build
```

Produces an NSIS installer in `dist/`.

## Architecture

- **main.js** — Electron main process: creates window, builds native menu bar
  (File/Edit/View/Select/Tools/Help), runs CLI bridge HTTP server on port 8643
- **preload.js** — Secure IPC bridge exposing native menu events to the renderer
- **VoidWalkers_Suite.html** — Loaded as the renderer (Layer A web suite)

## Menu Structure

| Menu    | Items                                                        |
|---------|-------------------------------------------------------------|
| File    | New, Open, Save, Save As, Import, Export, Preferences, Quit |
| Edit    | Undo, Redo, Cut, Copy, Paste, Select All/None/Invert        |
| View    | Zoom In/Out, Fit, Toggle Grid, Toggle Console, DevTools     |
| Select  | All, None, Invert, By Region, By Alpha Threshold            |
| Tools   | Switch to AtlasArchitect/SpriteSlicer/FidelityForge/RigForge|
| Help    | About, CLI Reference, Documentation                          |

## CLI Bridge

The Electron main process runs an HTTP server on `127.0.0.1:8643` that
accepts `POST /exec` with `{command, cwd}` and returns `{stdout, stderr, exitCode}`.
This is the same interface the web suite uses, so the HTML works identically
in browser and desktop contexts.
