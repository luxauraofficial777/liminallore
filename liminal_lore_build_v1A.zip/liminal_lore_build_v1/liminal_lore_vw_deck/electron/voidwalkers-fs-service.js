/**
 * VoidWalkers File System Service
 * Persistent local filesystem + shell execution API
 * Port: 8644
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

const PORT = 8644;
const SETTINGS_PATH = path.join(__dirname, 'liminal_settings.json');

let settings = {};
let PROJECT_ROOT = 'C:\\LuxAura\\VoidWalkers_Project';
let ALLOWED_ROOTS = [path.resolve(PROJECT_ROOT), path.resolve('C:\\LuxAura'), 'C:\\', 'D:\\'];
let STUDY_DIR = path.join(PROJECT_ROOT, 'Modern_X64', 'study');
let MAX_STUDY_SCAN_DEPTH = 3;
let MAX_STUDY_FILE_BYTES = 512 * 1024;

function resolvePlaceholders(str, root) {
  if (typeof str !== 'string') return str;
  return str.replace(/\$\{project_root\}/g, root);
}

function loadSettings() {
  try {
    const raw = fs.readFileSync(SETTINGS_PATH, 'utf8');
    settings = JSON.parse(raw);
    const fsCfg = settings.fs_service || {};
    PROJECT_ROOT = fsCfg.project_root || PROJECT_ROOT;
    STUDY_DIR = path.resolve(resolvePlaceholders(fsCfg.study_dir || path.join(PROJECT_ROOT, 'Modern_X64', 'study'), PROJECT_ROOT));
    MAX_STUDY_SCAN_DEPTH = fsCfg.max_study_scan_depth ?? MAX_STUDY_SCAN_DEPTH;
    MAX_STUDY_FILE_BYTES = fsCfg.max_study_file_bytes ?? MAX_STUDY_FILE_BYTES;
    ALLOWED_ROOTS = (fsCfg.allowed_roots || [PROJECT_ROOT, 'C:\\LuxAura', 'C:\\', 'D:\\']).map(r => path.resolve(resolvePlaceholders(r, PROJECT_ROOT)));
    log('Settings loaded from', SETTINGS_PATH);
    log('PROJECT_ROOT:', PROJECT_ROOT);
    log('ALLOWED_ROOTS:', ALLOWED_ROOTS.map(r => normalizePath(r)));
    log('STUDY_DIR:', STUDY_DIR);
  } catch (e) {
    log('Failed to load settings:', e.message, '- using defaults');
    settings = {
      fs_service: {
        project_root: PROJECT_ROOT,
        allowed_roots: ALLOWED_ROOTS.map(r => normalizePath(r)),
        study_dir: STUDY_DIR,
        max_study_scan_depth: MAX_STUDY_SCAN_DEPTH,
        max_study_file_bytes: MAX_STUDY_FILE_BYTES
      }
    };
  }
}

function saveSettings(newSettings) {
  try {
    fs.writeFileSync(SETTINGS_PATH, JSON.stringify(newSettings, null, 2), 'utf8');
    settings = newSettings;
    loadSettings();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

function log(...args) {
  const ts = new Date().toISOString().replace('T', ' ').slice(0, 19);
  console.log(`[${ts}]`, ...args);
}

loadSettings();

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

function normalizePath(p) {
  try {
    // Resolve to absolute path, handle Windows backslashes
    return path.resolve(p).replace(/\\/g, '/');
  } catch (e) {
    return '';
  }
}

function isAllowed(targetPath) {
  const resolved = normalizePath(targetPath).toLowerCase();
  if (!resolved) return false;
  return ALLOWED_ROOTS.some(base => {
    const b = path.resolve(base).replace(/\\/g, '/').toLowerCase();
    const bFolder = b.endsWith('/') ? b : b + '/';
    return resolved === b || resolved.startsWith(bFolder);
  });
}

function buildStudyIndex(dir = STUDY_DIR, base = STUDY_DIR, depth = 0) {
  if (depth > MAX_STUDY_SCAN_DEPTH) return [];
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const items = [];
  for (const e of entries) {
    const full = path.join(dir, e.name);
    const rel = path.relative(base, full);
    if (rel.startsWith('.')) continue;
    if (e.isDirectory()) {
      items.push({ path: full, rel, isDir: true, items: buildStudyIndex(full, base, depth + 1) });
    } else {
      const st = fs.statSync(full);
      items.push({ path: full, rel, isDir: false, size: st.size, modified: st.mtime.toISOString() });
    }
  }
  return items;
}

function searchStudy(query, maxResults = 20) {
  const results = [];
  const q = query.toLowerCase();
  function walk(dir, depth) {
    if (depth > MAX_STUDY_SCAN_DEPTH || results.length >= maxResults) return;
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (e.isDirectory()) { walk(full, depth + 1); continue; }
      if (e.name.toLowerCase().includes(q)) {
        results.push({ path: full, rel: path.relative(STUDY_DIR, full), match: 'filename', score: 10 });
        if (results.length >= maxResults) return;
      }
      try {
        const st = fs.statSync(full);
        if (st.size > MAX_STUDY_FILE_BYTES) continue;
        const content = fs.readFileSync(full, 'utf8');
        const idx = content.toLowerCase().indexOf(q);
        if (idx !== -1) {
          const excerpt = content.slice(Math.max(0, idx - 80), idx + 200).replace(/\s+/g, ' ').trim();
          results.push({ path: full, rel: path.relative(STUDY_DIR, full), match: 'content', excerpt, score: 5 });
          if (results.length >= maxResults) return;
        }
      } catch (err) { /* skip unreadable */ }
    }
  }
  walk(STUDY_DIR, 0);
  return results.sort((a, b) => b.score - a.score);
}

function jsonResponse(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', c => data += c);
    req.on('end', () => { try { resolve(JSON.parse(data)); } catch { resolve({}); } });
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  cors(res);
  if (req.method === 'OPTIONS') { res.writeHead(200); res.end(); return; }

  const url = req.url;

  // Health
  if (url === '/health') { res.writeHead(200); res.end('ok'); return; }

  // Diagnostic: list active allowed roots
  if (url === '/roots') {
    jsonResponse(res, 200, {
      ok: true,
      project_root: PROJECT_ROOT,
      allowed_roots: ALLOWED_ROOTS.map(r => normalizePath(r))
    });
    return;
  }

  // Settings: read current FS service configuration
  if (url === '/settings' && req.method === 'GET') {
    jsonResponse(res, 200, {
      ok: true,
      settings_path: SETTINGS_PATH,
      fs_service: {
        project_root: PROJECT_ROOT,
        allowed_roots: ALLOWED_ROOTS.map(r => normalizePath(r)),
        study_dir: STUDY_DIR,
        max_study_scan_depth: MAX_STUDY_SCAN_DEPTH,
        max_study_file_bytes: MAX_STUDY_FILE_BYTES
      }
    });
    return;
  }

  // Settings: update FS service configuration (persist to disk and reload)
  if (url === '/settings' && req.method === 'POST') {
    const body = await readBody(req);
    const newFs = body.fs_service || {};
    if (!newFs.project_root || typeof newFs.project_root !== 'string') {
      return jsonResponse(res, 400, { ok: false, error: 'Missing or invalid fs_service.project_root' });
    }
    const newAllowed = Array.isArray(newFs.allowed_roots) ? newFs.allowed_roots : settings.fs_service?.allowed_roots || [newFs.project_root, 'C:\\', 'D:\\'];
    const newStudy = newFs.study_dir || settings.fs_service?.study_dir || '${project_root}\\Modern_X64\\study';
    const newDepth = typeof newFs.max_study_scan_depth === 'number' ? newFs.max_study_scan_depth : (settings.fs_service?.max_study_scan_depth ?? 3);
    const newMaxBytes = typeof newFs.max_study_file_bytes === 'number' ? newFs.max_study_file_bytes : (settings.fs_service?.max_study_file_bytes ?? 512 * 1024);
    settings.fs_service = {
      project_root: newFs.project_root,
      allowed_roots: newAllowed,
      study_dir: newStudy,
      max_study_scan_depth: newDepth,
      max_study_file_bytes: newMaxBytes
    };
    const result = saveSettings(settings);
    if (!result.ok) return jsonResponse(res, 500, { ok: false, error: result.error });
    log('SETTINGS UPDATED', 'project_root:', PROJECT_ROOT);
    jsonResponse(res, 200, {
      ok: true,
      fs_service: {
        project_root: PROJECT_ROOT,
        allowed_roots: ALLOWED_ROOTS.map(r => normalizePath(r)),
        study_dir: STUDY_DIR,
        max_study_scan_depth: MAX_STUDY_SCAN_DEPTH,
        max_study_file_bytes: MAX_STUDY_FILE_BYTES
      }
    });
    return;
  }

  // RAG: live study index / manifest
  if (url === '/study/index' && req.method === 'GET') {
    try {
      const index = buildStudyIndex();
      let countFiles = 0;
      function count(items) { for (const i of items) { if (i.isDir) count(i.items); else countFiles++; } }
      count(index);
      log('STUDY INDEX', countFiles, 'files');
      jsonResponse(res, 200, { ok: true, study_dir: STUDY_DIR, count: countFiles, index });
    } catch (e) {
      jsonResponse(res, 500, { ok: false, error: e.message });
    }
    return;
  }

  // RAG: keyword search over study corpus
  if (url === '/study/search' && req.method === 'POST') {
    const body = await readBody(req);
    const query = body.query || '';
    const maxResults = Math.min(50, parseInt(body.max || 20, 10));
    if (!query) return jsonResponse(res, 400, { ok: false, error: 'Missing query' });
    try {
      const results = searchStudy(query, maxResults);
      log('STUDY SEARCH', query, `=> ${results.length} results`);
      jsonResponse(res, 200, { ok: true, query, count: results.length, results });
    } catch (e) {
      jsonResponse(res, 500, { ok: false, error: e.message });
    }
    return;
  }

  // ─── READ FILE ───
  if (url === '/read-file' && req.method === 'POST') {
    const body = await readBody(req);
    const filePath = body.path;
    if (!filePath) return jsonResponse(res, 400, { ok: false, error: 'Missing path' });
    if (!isAllowed(filePath)) return jsonResponse(res, 403, { ok: false, error: 'Path outside allowed directories' });
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      log('READ', filePath, `(${content.length} bytes)`);
      jsonResponse(res, 200, { ok: true, path: filePath, content, bytes: content.length });
    } catch (e) {
      jsonResponse(res, 500, { ok: false, error: e.message });
    }
    return;
  }

  // ─── READ FILE BINARY (base64) ───
  if (url === '/read-file-binary' && req.method === 'POST') {
    const body = await readBody(req);
    const filePath = body.path;
    if (!filePath) return jsonResponse(res, 400, { ok: false, error: 'Missing path' });
    if (!isAllowed(filePath)) return jsonResponse(res, 403, { ok: false, error: 'Path outside allowed directories' });
    try {
      const content = fs.readFileSync(filePath);
      log('READ-BINARY', filePath, `(${content.length} bytes)`);
      jsonResponse(res, 200, { ok: true, path: filePath, base64: content.toString('base64'), bytes: content.length });
    } catch (e) {
      jsonResponse(res, 500, { ok: false, error: e.message });
    }
    return;
  }

  // ─── WRITE FILE ───
  if (url === '/write-file' && req.method === 'POST') {
    const body = await readBody(req);
    const filePath = body.path;
    const content = body.content;
    log('WRITE REQUEST', filePath, `(${content?.length || 0} bytes)`);
    if (!filePath || typeof content !== 'string') {
      log('WRITE FAILED: Missing path or content');
      return jsonResponse(res, 400, { ok: false, error: 'Missing path or content' });
    }
    if (!isAllowed(filePath)) {
      log('WRITE FAILED: Path not allowed', filePath);
      return jsonResponse(res, 403, { ok: false, error: 'Path outside allowed directories' });
    }
    try {
      const resolvedPath = path.resolve(filePath);
      fs.mkdirSync(path.dirname(resolvedPath), { recursive: true });
      fs.writeFileSync(resolvedPath, content, 'utf8');
      log('WRITE SUCCESS', resolvedPath, `(${content.length} bytes)`);
      jsonResponse(res, 200, { ok: true, path: resolvedPath, bytes: content.length });
    } catch (e) {
      log('WRITE ERROR', e.message);
      jsonResponse(res, 500, { ok: false, error: e.message });
    }
    return;
  }

  // ─── LIST DIRECTORY ───
  if (url === '/list-dir' && req.method === 'POST') {
    const body = await readBody(req);
    const dirPath = body.path || '.';
    if (!isAllowed(dirPath)) return jsonResponse(res, 403, { ok: false, error: 'Path outside allowed directories' });
    try {
      const entries = fs.readdirSync(dirPath, { withFileTypes: true });
      const items = entries.map(e => ({ name: e.name, isDir: e.isDirectory(), size: e.isFile() ? fs.statSync(path.join(dirPath, e.name)).size : null }));
      log('LIST', dirPath, `(${items.length} items)`);
      jsonResponse(res, 200, { ok: true, path: dirPath, items });
    } catch (e) {
      jsonResponse(res, 500, { ok: false, error: e.message });
    }
    return;
  }

  // ─── FILE STATS ───
  if (url === '/stat' && req.method === 'POST') {
    const body = await readBody(req);
    const targetPath = body.path;
    if (!targetPath) return jsonResponse(res, 400, { ok: false, error: 'Missing path' });
    if (!isAllowed(targetPath)) return jsonResponse(res, 403, { ok: false, error: 'Path outside allowed directories' });
    try {
      const st = fs.statSync(targetPath);
      jsonResponse(res, 200, {
        ok: true, path: targetPath,
        isFile: st.isFile(), isDir: st.isDirectory(),
        size: st.size, modified: st.mtime, created: st.birthtime
      });
    } catch (e) {
      jsonResponse(res, 500, { ok: false, error: e.message });
    }
    return;
  }

  // ─── SEARCH FILES ───
  if (url === '/search' && req.method === 'POST') {
    const body = await readBody(req);
    const dirPath = body.path || '.';
    const query = body.query || '';
    const max = body.max || 50;
    if (!isAllowed(dirPath)) return jsonResponse(res, 403, { ok: false, error: 'Path outside allowed directories' });
    try {
      const results = [];
      function walk(dir, depth) {
        if (depth > 5 || results.length >= max) return;
        const entries = fs.readdirSync(dir, { withFileTypes: true });
        for (const e of entries) {
          const full = path.join(dir, e.name);
          if (e.isDirectory()) { walk(full, depth + 1); }
          else if (e.isFile() && e.name.toLowerCase().includes(query.toLowerCase())) {
            results.push(full);
            if (results.length >= max) break;
          }
        }
      }
      walk(dirPath, 0);
      log('SEARCH', dirPath, `query:"${query}" => ${results.length} results`);
      jsonResponse(res, 200, { ok: true, path: dirPath, query, results });
    } catch (e) {
      jsonResponse(res, 500, { ok: false, error: e.message });
    }
    return;
  }

  // ─── EXECUTE SHELL COMMAND ───
  if (url === '/exec' && req.method === 'POST') {
    const body = await readBody(req);
    const cmd = body.command;
    const cwd = body.cwd || process.cwd();
    if (!cmd) return jsonResponse(res, 400, { ok: false, error: 'Missing command' });
    if (!isAllowed(cwd)) return jsonResponse(res, 403, { ok: false, error: 'CWD outside allowed directories' });
    log('EXEC', cwd, '>', cmd);
    exec(cmd, { cwd, timeout: 60000, maxBuffer: 2 * 1024 * 1024, shell: true }, (err, stdout, stderr) => {
      jsonResponse(res, 200, {
        ok: true,
        exitCode: err ? err.code : 0,
        stdout: stdout.slice(0, 10000),
        stderr: stderr.slice(0, 5000),
      });
    });
    return;
  }

  // ─── DELETE FILE ───
  if (url === '/delete' && req.method === 'POST') {
    const body = await readBody(req);
    const filePath = body.path;
    if (!filePath) return jsonResponse(res, 400, { ok: false, error: 'Missing path' });
    if (!isAllowed(filePath)) return jsonResponse(res, 403, { ok: false, error: 'Path outside allowed directories' });
    try {
      fs.rmSync(filePath, { recursive: body.recursive || false });
      log('DELETE', filePath);
      jsonResponse(res, 200, { ok: true, path: filePath });
    } catch (e) {
      jsonResponse(res, 500, { ok: false, error: e.message });
    }
    return;
  }

  jsonResponse(res, 404, { ok: false, error: 'Not found' });
});

server.listen(PORT, '127.0.0.1', () => {
  log('VoidWalkers FS Service on http://127.0.0.1:' + PORT);
  log('Allowed roots:', ALLOWED_ROOTS.map(r => normalizePath(r)));
  log('Project root:', PROJECT_ROOT);
});
