// ============================================================================
// main.js — VoidWalkers Production Suite Electron Main Process
// ============================================================================
// Creates a native desktop window with OS menu bar, loads the VoidWalkers_Suite
// HTML, and provides IPC for file dialogs and CLI execution.
// ============================================================================

const { app, BrowserWindow, Menu, dialog, ipcMain } = require('electron');
const path = require('path');
const { spawn } = require('child_process');

let mainWindow = null;
let bridgeProcess = null;

// ─── Default root path ───
const DEFAULT_ROOT = 'C:\\LuxAura\\VoidWalkers_Project\\Modern_X64';

// ─── Tool binary paths ───
function getToolPath(tool, root) {
  const r = root || DEFAULT_ROOT;
  const paths = {
    atlas: `${r}\\tools\\atlas_architect_cpp\\bin\\AtlasArchitect.exe`,
    slicer: `${r}\\tools\\sprite_slicer\\bin\\SpriteSlicer.exe`,
    fidelity: `${r}\\tools\\atlas_forge_cpp\\bin\\FidelityForge.exe`,
    rigforge: `${r}\\tools\\RigForge\\bin\\rigforge.exe`
  };
  return paths[tool] || '';
}

// ─── Hermes Bridge Server (full nexus/committee/pipeline support) ───
function startBridgeServer() {
  const bridgePath = path.join(__dirname, 'hermes-bridge.js');
  bridgeProcess = spawn('node', [bridgePath], {
    cwd: path.dirname(bridgePath),
    env: { ...process.env },
    shell: false,
    windowsHide: true,
  });

  bridgeProcess.stdout.on('data', (d) => {
    const msg = d.toString().trim();
    if (msg) console.log(`[bridge] ${msg}`);
  });

  bridgeProcess.stderr.on('data', (d) => {
    const msg = d.toString().trim();
    if (msg) console.error(`[bridge-err] ${msg}`);
  });

  bridgeProcess.on('error', (err) => {
    console.error('Failed to start hermes-bridge:', err.message);
  });

  console.log(`[main] Hermes bridge spawned (PID ${bridgeProcess.pid}) on port 8643`);
}

// ─── Menu Template ───
function buildMenu() {
  return Menu.buildFromTemplate([
    {
      label: 'File',
      submenu: [
        {
          label: 'New Project',
          accelerator: 'Ctrl+N',
          click: () => mainWindow.webContents.send('menu-action', 'fileNew')
        },
        {
          label: 'Open...',
          accelerator: 'Ctrl+O',
          click: async () => {
            const result = await dialog.showOpenDialog(mainWindow, {
              filters: [
                { name: 'All Files', extensions: ['*'] },
                { name: 'PNG Images', extensions: ['png'] },
                { name: 'JSON', extensions: ['json'] }
              ],
              properties: ['openFile']
            });
            if (!result.canceled && result.filePaths.length > 0) {
              mainWindow.webContents.send('file-opened', result.filePaths[0]);
            }
          }
        },
        { type: 'separator' },
        { label: 'Save', accelerator: 'Ctrl+S', click: () => mainWindow.webContents.send('menu-action', 'fileSave') },
        { label: 'Save As...', accelerator: 'Ctrl+Shift+S', click: async () => {
            const result = await dialog.showSaveDialog(mainWindow, {
              filters: [{ name: 'JSON', extensions: ['json'] }, { name: 'PNG', extensions: ['png'] }]
            });
            if (!result.canceled && result.filePath) {
              mainWindow.webContents.send('file-saved', result.filePath);
            }
          }
        },
        { type: 'separator' },
        { label: 'Import Asset...', accelerator: 'Ctrl+I', click: async () => {
            const result = await dialog.showOpenDialog(mainWindow, {
              filters: [{ name: 'Images', extensions: ['png', 'bmp', 'jpg'] }],
              properties: ['openFile']
            });
            if (!result.canceled && result.filePaths.length > 0) {
              mainWindow.webContents.send('file-imported', result.filePaths[0]);
            }
          }
        },
        { label: 'Export...', accelerator: 'Ctrl+E', click: async () => {
            const result = await dialog.showSaveDialog(mainWindow, {
              filters: [{ name: 'PNG', extensions: ['png'] }, { name: 'JSON', extensions: ['json'] }]
            });
            if (!result.canceled && result.filePath) {
              mainWindow.webContents.send('file-exported', result.filePath);
            }
          }
        },
        { type: 'separator' },
        { label: 'Preferences...', click: () => mainWindow.webContents.send('menu-action', 'openPrefs') },
        { type: 'separator' },
        { role: 'quit' }
      ]
    },
    {
      label: 'Edit',
      submenu: [
        { label: 'Undo', accelerator: 'Ctrl+Z', click: () => mainWindow.webContents.send('menu-action', 'editUndo') },
        { label: 'Redo', accelerator: 'Ctrl+Y', click: () => mainWindow.webContents.send('menu-action', 'editRedo') },
        { type: 'separator' },
        { label: 'Cut', accelerator: 'Ctrl+X', role: 'cut' },
        { label: 'Copy', accelerator: 'Ctrl+C', role: 'copy' },
        { label: 'Paste', accelerator: 'Ctrl+V', role: 'paste' },
        { type: 'separator' },
        { label: 'Select All', accelerator: 'Ctrl+A', click: () => mainWindow.webContents.send('menu-action', 'selectAll') },
        { label: 'Select None', accelerator: 'Ctrl+Shift+A', click: () => mainWindow.webContents.send('menu-action', 'selectNone') },
        { label: 'Invert Selection', accelerator: 'Ctrl+Shift+I', click: () => mainWindow.webContents.send('menu-action', 'selectInvert') }
      ]
    },
    {
      label: 'View',
      submenu: [
        { label: 'Zoom In', accelerator: 'Ctrl++', click: () => mainWindow.webContents.send('menu-action', 'viewZoomIn') },
        { label: 'Zoom Out', accelerator: 'Ctrl+-', click: () => mainWindow.webContents.send('menu-action', 'viewZoomOut') },
        { label: 'Fit to Screen', accelerator: 'Ctrl+0', click: () => mainWindow.webContents.send('menu-action', 'viewFit') },
        { type: 'separator' },
        { label: 'Toggle Grid', accelerator: 'Ctrl+G', click: () => mainWindow.webContents.send('menu-action', 'viewToggleGrid') },
        { label: 'Toggle Console', accelerator: 'Ctrl+`', click: () => mainWindow.webContents.send('menu-action', 'viewToggleConsole') },
        { type: 'separator' },
        { role: 'toggleDevTools' },
        { role: 'reload' }
      ]
    },
    {
      label: 'Select',
      submenu: [
        { label: 'Select All', click: () => mainWindow.webContents.send('menu-action', 'selectAll') },
        { label: 'Select None', click: () => mainWindow.webContents.send('menu-action', 'selectNone') },
        { label: 'Invert Selection', click: () => mainWindow.webContents.send('menu-action', 'selectInvert') },
        { type: 'separator' },
        { label: 'Select by Region...', click: () => mainWindow.webContents.send('menu-action', 'selectByRegion') },
        { label: 'Select by Alpha Threshold...', click: () => mainWindow.webContents.send('menu-action', 'selectByAlpha') }
      ]
    },
    {
      label: 'Tools',
      submenu: [
        { label: 'AtlasArchitect', click: () => mainWindow.webContents.send('switch-tool', 'atlas') },
        { label: 'SpriteSlicer', click: () => mainWindow.webContents.send('switch-tool', 'slicer') },
        { label: 'FidelityForge', click: () => mainWindow.webContents.send('switch-tool', 'fidelity') },
        { label: 'RigForge', click: () => mainWindow.webContents.send('switch-tool', 'rigforge') }
      ]
    },
    {
      label: 'Help',
      submenu: [
        { label: 'About VoidWalkers Suite', click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'About',
              message: 'VoidWalkers Production Suite v1.0.0',
              detail: 'Liminal Lore Agentic Game Development\n\nAtlasArchitect | SpriteSlicer | FidelityForge | RigForge\n\nFord Automation for Game Dev'
            });
          }
        },
        { label: 'CLI Reference', click: () => mainWindow.webContents.send('menu-action', 'helpCLI') },
        { label: 'Documentation', click: () => mainWindow.webContents.send('menu-action', 'helpDocs') }
      ]
    }
  ]);
}

// ─── Create Window ───
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 800,
    minHeight: 500,
    title: 'VoidWalkers Production Suite',
    backgroundColor: '#020204',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  Menu.setApplicationMenu(buildMenu());

  mainWindow.loadFile(path.join(__dirname, 'VoidWalkers_Suite.html'));

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// ─── App Lifecycle ───
app.whenReady().then(() => {
  startBridgeServer();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (bridgeProcess) {
    bridgeProcess.kill();
    bridgeProcess = null;
  }
  if (process.platform !== 'darwin') app.quit();
});
