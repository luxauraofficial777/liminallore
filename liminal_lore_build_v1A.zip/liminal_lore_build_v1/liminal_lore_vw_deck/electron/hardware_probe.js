#!/usr/bin/env node
/**
 * hardware_probe.js — Auto-detect system RAM/VRAM and inject the appropriate
 * hardware_tier into vw_deck.config.json.
 *
 * Tier logic:
 *   potato:    <= 16 GB RAM  OR  no dedicated GPU (integrated only)
 *   mid_range: 16-32 GB RAM  AND  basic dedicated GPU (<= 8 GB VRAM)
 *   high_end:  >= 64 GB RAM  AND  dedicated GPU with >= 12 GB VRAM
 *
 * Usage:
 *   node hardware_probe.js           # Detect and write to config
 *   node hardware_probe.js --dry     # Detect only, print result
 *   node hardware_probe.js --force potato  # Override tier manually
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const CONFIG_PATH = path.join(__dirname, 'vw_deck.config.json');

function log(...args) {
  const ts = new Date().toISOString().replace('T', ' ').slice(0, 19);
  console.log(`[${ts}] [HW-PROBE]`, ...args);
}

function detectRAM() {
  try {
    const output = execSync('wmic computersystem get TotalPhysicalMemory /value', { encoding: 'utf-8', timeout: 5000 });
    const match = output.match(/TotalPhysicalMemory=(\d+)/);
    if (match) return Math.round(parseInt(match[1]) / (1024 * 1024 * 1024)); // GB
  } catch {}
  try {
    const output = execSync('powershell -Command "(Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory"', { encoding: 'utf-8', timeout: 5000 });
    const val = parseInt(output.trim());
    if (val > 0) return Math.round(val / (1024 * 1024 * 1024));
  } catch {}
  return 0;
}

function detectVRAM() {
  let vramMB = 0;
  let gpuName = 'Unknown';
  let isIntegrated = false;

  try {
    const output = execSync('wmic path win32_VideoController get Name,AdapterRAM /value', { encoding: 'utf-8', timeout: 5000 });
    const lines = output.split('\n');
    let currentName = '';
    for (const line of lines) {
      const nameMatch = line.match(/Name=(.+)/);
      if (nameMatch) currentName = nameMatch[1].trim();
      const ramMatch = line.match(/AdapterRAM=(\d+)/);
      if (ramMatch && currentName) {
        const ram = parseInt(ramMatch[1]);
        // AdapterRAM is uint32, wraps at 4GB — cap at 4GB
        if (ram > vramMB) vramMB = Math.min(ram, 4 * 1024 * 1024 * 1024) / (1024 * 1024);
        gpuName = currentName;
        if (/Intel|Integrated|HD Graphics|UHD|Iris/i.test(currentName)) isIntegrated = true;
        currentName = '';
      }
    }
  } catch {}

  // Try PowerShell for more accurate VRAM on dedicated GPUs
  if (!isIntegrated) {
    try {
      const output = execSync('powershell -Command "Get-CimInstance Win32_VideoController | Select-Object Name, AdapterRAM, VideoProcessor | Format-List"', { encoding: 'utf-8', timeout: 5000 });
      const gpuBlocks = output.split(/\n\s*\n/);
      for (const block of gpuBlocks) {
        const nameMatch = block.match(/Name\s*:\s*(.+)/);
        const ramMatch = block.match(/AdapterRAM\s*:\s*(\d+)/);
        if (nameMatch) {
          const name = nameMatch[1].trim();
          if (/NVIDIA|GeForce|RTX|GTX|AMD|Radeon|RX /i.test(name)) {
            isIntegrated = false;
            gpuName = name;
            if (ramMatch) {
              const ram = parseInt(ramMatch[1]);
              if (ram > vramMB * 1024 * 1024) vramMB = Math.min(ram, 16 * 1024 * 1024 * 1024) / (1024 * 1024);
            }
          }
        }
      }
    } catch {}
  }

  return {
    vram_mb: Math.round(vramMB),
    vram_gb: Math.round(vramMB / 1024 * 10) / 10,
    gpu_name: gpuName,
    is_integrated: isIntegrated,
  };
}

function detectTier(forceTier) {
  if (forceTier && ['potato', 'mid_range', 'high_end'].includes(forceTier)) {
    log(`Forced tier: ${forceTier}`);
    return forceTier;
  }

  const ramGB = detectRAM();
  const gpu = detectVRAM();

  log(`Detected: RAM=${ramGB}GB, GPU="${gpu.gpu_name}", VRAM=${gpu.vram_gb}GB, Integrated=${gpu.is_integrated}`);

  let tier;
  if (ramGB >= 64 && !gpu.is_integrated && gpu.vram_gb >= 12) {
    tier = 'high_end';
  } else if (ramGB > 16 && !gpu.is_integrated) {
    tier = 'mid_range';
  } else {
    tier = 'potato';
  }

  log(`Auto-detected tier: ${tier}`);
  return tier;
}

function updateConfig(tier, dryRun) {
  const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));

  if (!config.hardware_tier) {
    log('ERROR: hardware_tier section missing from config');
    process.exit(1);
  }

  const profile = config.hardware_tier.profiles[tier];
  if (!profile) {
    log(`ERROR: Unknown tier "${tier}"`);
    process.exit(1);
  }

  log(`Applying tier "${tier}": ${profile.label}`);
  log(`  max_concurrent_experts: ${profile.max_concurrent_experts}`);
  log(`  turboquant_strategy: ${profile.turboquant_strategy} (kv_bits=${profile.turboquant_kv_bits}, flush=${profile.turboquant_flush_threshold_pct}%)`);
  log(`  refresh_strategy: ${profile.refresh_strategy} (interval=${profile.refresh_interval_ms}ms)`);
  log(`  nexus_heartbeat: ${profile.nexus_heartbeat_interval_s}s`);
  log(`  gpu_offload: ${profile.gpu_offload_flag}`);
  log(`  cpu_only: ${profile.cpu_only}, hbe_streaming: ${profile.hbe_streaming}`);

  if (dryRun) {
    log('Dry run — config not modified');
    return;
  }

  config.hardware_tier.current = tier;
  config.hardware_tier.auto_detect = true;

  // Sync nexus_settings to tier profile
  config.nexus_settings.auto_refresh_enabled = profile.refresh_strategy === 'auto';
  config.nexus_settings.refresh_interval_ms = profile.refresh_interval_ms || 30000;
  config.nexus_settings.pulse_mode = profile.refresh_strategy;

  fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
  log(`Config updated: ${CONFIG_PATH}`);
  log(`  nexus_settings.auto_refresh_enabled = ${config.nexus_settings.auto_refresh_enabled}`);
  log(`  nexus_settings.refresh_interval_ms = ${config.nexus_settings.refresh_interval_ms}`);
  log(`  nexus_settings.pulse_mode = ${config.nexus_settings.pulse_mode}`);
}

// Main
const args = process.argv.slice(2);
const dryRun = args.includes('--dry');
const forceIdx = args.indexOf('--force');
const forceTier = forceIdx >= 0 && args[forceIdx + 1] ? args[forceIdx + 1] : null;

log('Starting hardware probe...');
const tier = detectTier(forceTier);
updateConfig(tier, dryRun);
log('Done.');
