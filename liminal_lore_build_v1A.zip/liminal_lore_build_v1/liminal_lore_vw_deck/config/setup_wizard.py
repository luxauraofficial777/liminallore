"""Liminal Lore — Setup Wizard & Initialization Flow.

Interactive setup that:
  1. Checks for required environment parameters
  2. Prompts user for missing configurations
  3. Generates .env template and liminal_lore.yaml config file
  4. Tests connectivity to configured providers
  5. Reports readiness status

Usage:
  python -m config.setup_wizard           # Interactive
  python -m config.setup_wizard --check   # Non-interactive validation only
  python -m config.setup_wizard --generate # Generate template files only
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from .config_loader import ConfigLoader


ENV_TEMPLATE = """\
# ────────────────────────────────────────────────────────────────
# Liminal Lore — Environment Configuration
# Copy this file to .env and fill in your values.
# NEVER commit your .env file to version control.
# ────────────────────────────────────────────────────────────────

# ── Project Root ────────────────────────────────────────────────
# Absolute path to your project root directory
PROJECT_ROOT=

# ── LLM Provider Settings ───────────────────────────────────────
# Active provider: ollama, openai_compatible, openrouter, custom
LIMINAL_LORE_ACTIVE_PROVIDER=ollama
LIMINAL_LORE_ACTIVE_MODEL=

# ── Ollama (local, no API key needed) ───────────────────────────
OLLAMA_BASE_URL=http://127.0.0.1:11434

# ── OpenAI-Compatible API (LM Studio, vLLM, etc.) ───────────────
# LLM_BASE_URL=http://127.0.0.1:1234/v1
# LLM_API_KEY=

# ── OpenRouter ──────────────────────────────────────────────────
# OPENROUTER_API_KEY=
# (Base URL is predefined: https://openrouter.ai/api/v1)

# ── Custom LLM Provider ─────────────────────────────────────────
# CUSTOM_LLM_BASE_URL=
# CUSTOM_LLM_API_KEY=

# ── VW Nexus (optional) ─────────────────────────────────────────
# NEXUS_API_KEY=
# LIMINAL_LORE_NEXUS_URL=http://127.0.0.1:8651

# ── Bridge Ports (optional overrides) ───────────────────────────
# LIMINAL_LORE_BRIDGE_PORT=8643
# LIMINAL_LORE_FS_PORT=8644
# LIMINAL_LORE_THEME=void
# LIMINAL_LORE_HARDWARE_TIER=mid_range

# ── ZHARK Virtual CSO (optional) ────────────────────────────────
# ZHARK_MAX_ITERATIONS=50
# ZHARK_CONVERGENCE_THRESHOLD=0.75
# ZHARK_MAX_DEPTH=5
# ZHARK_CYCLE_DELAY=5
# ZHARK_VERIFY_CANDIDATES=3
"""

YAML_TEMPLATE = """\
# ────────────────────────────────────────────────────────────────
# Liminal Lore — User Configuration
# API keys go in .env, NOT in this file.
# ────────────────────────────────────────────────────────────────

tool_name: "Liminal Lore"
version: "1.0.0"
schema_version: "1.0"

# ── Bridge Server ───────────────────────────────────────────────
bridge:
  host: "0.0.0.0"
  port: 8643
  fs_service_port: 8644
  memory_monitor_port: 8645
  turboquant_port: 8646
  runpod_bridge_port: 8647

# ── Nexus ───────────────────────────────────────────────────────
nexus:
  url: "http://127.0.0.1:8651"
  api_key_env: "NEXUS_API_KEY"  # Name of env var, not the key itself

# ── Model Providers ─────────────────────────────────────────────
# Enable the providers you want to use. Credentials go in .env.
providers:
  ollama:
    enabled: true
    base_url_env: "OLLAMA_BASE_URL"
    default_base_url: "http://127.0.0.1:11434"
    default_model: "qwen2.5-coder:7b"

  openai_compatible:
    enabled: false
    base_url_env: "LLM_BASE_URL"
    api_key_env: "LLM_API_KEY"
    default_base_url: ""
    default_model: ""

  openrouter:
    enabled: false
    api_key_env: "OPENROUTER_API_KEY"
    default_base_url: "https://openrouter.ai/api/v1"
    default_model: ""

  custom:
    enabled: false
    base_url_env: "CUSTOM_LLM_BASE_URL"
    api_key_env: "CUSTOM_LLM_API_KEY"
    default_base_url: ""
    default_model: ""

# ── Active Provider ─────────────────────────────────────────────
# Which provider to use by default
active_provider: "ollama"
active_model: ""  # Empty = use provider default

# ── Committee / Agent Settings ──────────────────────────────────
committee:
  default_mode: "lazy_sync"
  max_concurrent: 2
  consensus_threshold: 0.7

# ── Hardware Tier ───────────────────────────────────────────────
hardware_tier:
  auto_detect: true
  default: "mid_range"  # potato, mid_range, high_end, custom

# ── Security ────────────────────────────────────────────────────
security:
  allowed_exec_prefixes: ["python", "powershell", "cmd", "cmake", "ninja", "pip", "node", "npm"]
  blocked_patterns: ["rm -rf", "del /f /s /q", "format", "rd /s /q"]

# ── File Access ─────────────────────────────────────────────────
file_access:
  enabled: true
  mode: "allowlist"
  allowed_prefixes_env: "PROJECT_ROOT"
  denied_patterns: ["\\.ssh", "\\.git\\\\hooks", "\\\\secrets\\\\.", "\\\\keys\\\\."]

# ── UI ──────────────────────────────────────────────────────────
ui:
  default_theme: "void"  # void, ice, ember
  settings_menu_enabled: true
  backdrop_interval_ms: 20000

# ── VPN (optional, disabled by default) ─────────────────────────
vpn:
  enabled: false
  provider: ""
  monitor_port: 8645

# ── Paths (relative to PROJECT_ROOT) ────────────────────────────
paths:
  project_root_env: "PROJECT_ROOT"
  study_dir: "${project_root}/study"
  tools_dir: "${project_root}/tools"
  assets_dir: "${project_root}/assets"
  build_dir: "${project_root}/build"
  data_dir: "${project_root}/data"
"""


class SetupWizard:
    """Interactive setup wizard for Liminal Lore.

    Modes:
      - interactive: Prompt user for missing values, generate config
      - check: Non-interactive validation, report issues
      - generate: Create template .env and config files without prompting
    """

    def __init__(self, project_root: Optional[str | Path] = None):
        self.project_root = Path(project_root or os.getcwd()).resolve()
        self.env_path = self.project_root / ".env"
        self.config_path = self.project_root / "liminal_lore.yaml"

    # ── Interactive Prompt Helpers ────────────────────────────

    @staticmethod
    def _prompt(label: str, default: str = "", required: bool = False) -> str:
        suffix = f" [{default}]" if default else ""
        while True:
            value = input(f"  {label}{suffix}: ").strip()
            if not value and default:
                return default
            if not value and required:
                print("    ⚠ This field is required. Please enter a value.")
                continue
            return value

    @staticmethod
    def _prompt_yes_no(label: str, default: bool = True) -> bool:
        default_str = "Y/n" if default else "y/N"
        value = input(f"  {label} [{default_str}]: ").strip().lower()
        if not value:
            return default
        return value in ("y", "yes", "1", "true")

    @staticmethod
    def _prompt_choice(label: str, choices: List[str], default: str = "") -> str:
        choices_str = "/".join(choices)
        while True:
            value = input(f"  {label} [{choices_str}] ({default}): ").strip().lower()
            if not value and default:
                return default
            if value in choices:
                return value
            print(f"    ⚠ Please choose from: {choices_str}")

    # ── File Generation ───────────────────────────────────────

    def generate_env_template(self) -> str:
        """Generate .env template file."""
        if self.env_path.exists():
            print(f"  ✓ .env already exists at {self.env_path}")
            return str(self.env_path)
        self.env_path.write_text(ENV_TEMPLATE, encoding="utf-8")
        print(f"  ✓ Created .env template at {self.env_path}")
        print(f"    → Edit it to add your API keys and settings")
        return str(self.env_path)

    def generate_config_template(self) -> str:
        """Generate liminal_lore.yaml template file."""
        if self.config_path.exists():
            print(f"  ✓ liminal_lore.yaml already exists at {self.config_path}")
            return str(self.config_path)
        self.config_path.write_text(YAML_TEMPLATE, encoding="utf-8")
        print(f"  ✓ Created liminal_lore.yaml at {self.config_path}")
        print(f"    → Customize providers, models, and settings here")
        return str(self.config_path)

    # ── Validation ────────────────────────────────────────────

    def validate(self) -> Dict[str, Any]:
        """Validate current configuration state."""
        loader = ConfigLoader(project_root=self.project_root)
        return loader.validate()

    # ── Interactive Flow ──────────────────────────────────────

    def run_interactive(self) -> Dict[str, Any]:
        """Run the full interactive setup wizard."""
        print()
        print("╔══════════════════════════════════════════════════════════════╗")
        print("║         Liminal Lore — Setup Wizard                         ║")
        print("║         Self-hosted agentic game development suite          ║")
        print("╚══════════════════════════════════════════════════════════════╝")
        print()

        # Step 1: Project root
        print("─ Step 1: Project Root ─")
        detected = self._detect_project_root()
        project_root = self._prompt("Project root path", default=str(detected), required=True)
        self.project_root = Path(project_root).resolve()
        self.env_path = self.project_root / ".env"
        self.config_path = self.project_root / "liminal_lore.yaml"
        print()

        # Step 2: Generate template files
        print("─ Step 2: Generate Config Files ─")
        self.generate_env_template()
        self.generate_config_template()
        print()

        # Step 3: Provider selection
        print("─ Step 3: LLM Provider ─")
        provider = self._prompt_choice(
            "Which LLM provider do you want to use?",
            ["ollama", "openai_compatible", "openrouter", "custom"],
            default="ollama",
        )
        print()

        # Provider-specific prompts
        if provider == "ollama":
            print("─ Ollama Configuration ─")
            ollama_url = self._prompt("Ollama base URL", default="http://127.0.0.1:11434")
            ollama_model = self._prompt("Default model", default="qwen2.5-coder:7b")
            self._write_env_value("OLLAMA_BASE_URL", ollama_url)
            self._write_env_value("LIMINAL_LORE_ACTIVE_PROVIDER", "ollama")
            self._write_env_value("LIMINAL_LORE_ACTIVE_MODEL", ollama_model)
            print()

        elif provider == "openai_compatible":
            print("─ OpenAI-Compatible Configuration ─")
            api_url = self._prompt("API base URL (e.g., http://127.0.0.1:1234/v1)", required=True)
            api_key = self._prompt("API key (leave empty if none needed)")
            api_model = self._prompt("Model name", required=True)
            self._write_env_value("LLM_BASE_URL", api_url)
            if api_key:
                self._write_env_value("LLM_API_KEY", api_key)
            self._write_env_value("LIMINAL_LORE_ACTIVE_PROVIDER", "openai_compatible")
            self._write_env_value("LIMINAL_LORE_ACTIVE_MODEL", api_model)
            print()

        elif provider == "openrouter":
            print("─ OpenRouter Configuration ─")
            or_key = self._prompt("OpenRouter API key", required=True)
            or_model = self._prompt("Model ID (e.g., anthropic/claude-3.5-sonnet)", required=True)
            self._write_env_value("OPENROUTER_API_KEY", or_key)
            self._write_env_value("LIMINAL_LORE_ACTIVE_PROVIDER", "openrouter")
            self._write_env_value("LIMINAL_LORE_ACTIVE_MODEL", or_model)
            print()

        elif provider == "custom":
            print("─ Custom Provider Configuration ─")
            custom_url = self._prompt("Custom base URL", required=True)
            custom_key = self._prompt("API key (leave empty if none needed)")
            custom_model = self._prompt("Model name", required=True)
            self._write_env_value("CUSTOM_LLM_BASE_URL", custom_url)
            if custom_key:
                self._write_env_value("CUSTOM_LLM_API_KEY", custom_key)
            self._write_env_value("LIMINAL_LORE_ACTIVE_PROVIDER", "custom")
            self._write_env_value("LIMINAL_LORE_ACTIVE_MODEL", custom_model)
            print()

        # Step 4: Nexus (optional)
        print("─ Step 4: VW Nexus (optional) ─")
        use_nexus = self._prompt_yes_no("Connect to VW Nexus orchestration layer?", default=False)
        if use_nexus:
            nexus_url = self._prompt("Nexus URL", default="http://127.0.0.1:8651")
            self._write_env_value("LIMINAL_LORE_NEXUS_URL", nexus_url)
        print()

        # Step 5: Hardware tier
        print("─ Step 5: Hardware Tier ─")
        tier = self._prompt_choice(
            "What's your hardware tier?",
            ["potato", "mid_range", "high_end", "custom"],
            default="mid_range",
        )
        self._write_env_value("LIMINAL_LORE_HARDWARE_TIER", tier)
        print()

        # Step 6: Validate
        print("─ Step 6: Validation ─")
        result = self.validate()
        if result["ok"]:
            print("  ✓ Configuration is valid!")
        else:
            print("  ✗ Configuration issues found:")
            for issue in result["issues"]:
                print(f"    ✗ {issue}")

        for warning in result["warnings"]:
            print(f"    ⚠ {warning}")

        for ready in result["ready"]:
            print(f"    ✓ {ready}")

        print()
        print("─ Setup Complete ─")
        print(f"  .env: {self.env_path}")
        print(f"  Config: {self.config_path}")
        print()
        print("  Next steps:")
        print("    1. Review and edit your .env file for any remaining secrets")
        print("    2. Start Ollama: ollama serve")
        print("    3. Pull models: ollama pull <model_name>")
        print("    4. Start Liminal Lore: npm start (in electron/ directory)")
        print()

        return result

    def run_check(self) -> Dict[str, Any]:
        """Non-interactive validation only."""
        print("Liminal Lore — Configuration Check")
        print()
        result = self.validate()
        if result["ok"]:
            print("✓ Configuration is valid")
        else:
            print("✗ Configuration issues found:")
            for issue in result["issues"]:
                print(f"  ✗ {issue}")

        for warning in result["warnings"]:
            print(f"  ⚠ {warning}")

        for ready in result["ready"]:
            print(f"  ✓ {ready}")

        print()
        # Check for template files
        if not self.env_path.exists():
            print(f"  ⚠ No .env file found at {self.env_path}")
            print(f"    Run: python -m config.setup_wizard --generate")
        if not self.config_path.exists():
            print(f"  ⚠ No config file found at {self.config_path}")
            print(f"    Run: python -m config.setup_wizard --generate")

        return result

    def run_generate(self) -> Dict[str, str]:
        """Generate template files only, no prompting."""
        print("Liminal Lore — Generating Template Files")
        print()
        env_path = self.generate_env_template()
        config_path = self.generate_config_template()
        print()
        print("  Next steps:")
        print(f"    1. Edit {env_path} — add your API keys and settings")
        print(f"    2. Edit {config_path} — customize providers and models")
        print(f"    3. Run: python -m config.setup_wizard --check")
        return {"env": env_path, "config": config_path}

    def run_ship(self) -> Dict[str, Any]:
        """Prepare Liminal Lore suite for shipping — validate all components."""
        print()
        print("╔══════════════════════════════════════════════════════════════╗")
        print("║     Liminal Lore — Shipping Finalization                    ║")
        print("║     VW Nexus + VW Deck + ZHARK Virtual CSO                 ║")
        print("╚══════════════════════════════════════════════════════════════╝")
        print()

        manifest = {
            "suite": "Liminal Lore",
            "version": "1.0.0",
            "components": {},
            "ready": True,
            "issues": [],
        }

        # 1. Config system
        print("─ Component 1: Config System ─")
        config_dir = Path(__file__).parent
        required_files = ["__init__.py", "config_loader.py", "provider_abstraction.py", "setup_wizard.py"]
        all_present = all((config_dir / f).exists() for f in required_files)
        if all_present:
            print("  ✓ Config package complete (4 modules)")
            manifest["components"]["config"] = {"status": "ready", "modules": len(required_files)}
        else:
            missing = [f for f in required_files if not (config_dir / f).exists()]
            print(f"  ✗ Missing config modules: {missing}")
            manifest["components"]["config"] = {"status": "incomplete", "missing": missing}
            manifest["ready"] = False
            manifest["issues"].append(f"Missing config modules: {missing}")
        print()

        # 2. VW Nexus
        print("─ Component 2: VW Nexus ─")
        nexus_dir = self.project_root / "tools" / "vw_nexus"
        nexus_files = ["__init__.py", "__main__.py", "api.py", "agent_registry.py", "task_queue.py",
                       "mcp_server.py", "event_bus.py", "models.py", "state_store.py"]
        nexus_present = sum(1 for f in nexus_files if (nexus_dir / f).exists())
        if nexus_present >= 7:
            print(f"  ✓ VW Nexus present ({nexus_present}/{len(nexus_files)} core modules)")
            manifest["components"]["vw_nexus"] = {"status": "ready", "modules": nexus_present}
        else:
            print(f"  ✗ VW Nexus incomplete ({nexus_present}/{len(nexus_files)} modules)")
            manifest["components"]["vw_nexus"] = {"status": "incomplete", "modules": nexus_present}
            manifest["ready"] = False
            manifest["issues"].append("VW Nexus incomplete")
        print()

        # 3. VW Deck (Electron + Bridge + GUI)
        print("─ Component 3: VW Deck ─")
        deck_dir = self.project_root / "tools" / "liminal_link_vw_deck"
        deck_files = ["VoidWalkers_Chat_GUI.html", "hermes-bridge.js", "vw_deck.config.json",
                      "liminal_settings.json", "SETUP_GUIDE.md"]
        deck_present = sum(1 for f in deck_files if (deck_dir / f).exists())
        electron_dir = deck_dir / "electron"
        electron_files = ["main.js", "hermes-bridge.js", "package.json", "vw_deck.config.json"]
        electron_present = sum(1 for f in electron_files if (electron_dir / f).exists())
        if deck_present >= 4 and electron_present >= 3:
            print(f"  ✓ VW Deck present ({deck_present}/{len(deck_files)} root, {electron_present}/{len(electron_files)} electron)")
            manifest["components"]["vw_deck"] = {"status": "ready", "root_files": deck_present, "electron_files": electron_present}
        else:
            print(f"  ✗ VW Deck incomplete (root: {deck_present}/{len(deck_files)}, electron: {electron_present}/{len(electron_files)})")
            manifest["components"]["vw_deck"] = {"status": "incomplete"}
            manifest["ready"] = False
            manifest["issues"].append("VW Deck incomplete")
        print()

        # 4. ZHARK Virtual CSO
        print("─ Component 4: ZHARK Virtual CSO ─")
        zhark_dir = self.project_root / "tools" / "zhark"
        zhark_files = ["__init__.py", "__main__.py", "zhark_orchestrator.py",
                       "zhark_hypothesis_graph.py", "zhark_causal_mapper.py",
                       "zhark_strategy_synthesizer.py", "zhark_state.py",
                       "zhark_web_gatherer.py", "zhark_verify.py"]
        zhark_present = sum(1 for f in zhark_files if (zhark_dir / f).exists())
        if zhark_present >= 8:
            print(f"  ✓ ZHARK present ({zhark_present}/{len(zhark_files)} modules)")
            manifest["components"]["zhark"] = {"status": "ready", "modules": zhark_present}
        else:
            print(f"  ✗ ZHARK incomplete ({zhark_present}/{len(zhark_files)} modules)")
            manifest["components"]["zhark"] = {"status": "incomplete", "modules": zhark_present}
            manifest["ready"] = False
            manifest["issues"].append("ZHARK incomplete")
        print()

        # 5. Check for hardcoded paths (shipping hygiene)
        print("─ Shipping Hygiene: Hardcoded Path Check ─")
        import re
        hardcoded_pattern = re.compile(r"C:\\LuxAura", re.IGNORECASE)
        checked_files = []
        for f_path in [deck_dir / "vw_deck.config.json", deck_dir / "liminal_settings.json",
                       deck_dir / "electron" / "vw_deck.config.json"]:
            if f_path.exists():
                content = f_path.read_text(encoding="utf-8")
                matches = hardcoded_pattern.findall(content)
                if matches:
                    print(f"  ✗ {f_path.name}: {len(matches)} hardcoded paths found")
                    manifest["issues"].append(f"Hardcoded paths in {f_path.name}")
                    manifest["ready"] = False
                else:
                    print(f"  ✓ {f_path.name}: clean")
                    checked_files.append(str(f_path))
        manifest["components"]["shipping_hygiene"] = {"status": "clean" if manifest["ready"] else "issues",
                                                       "checked_files": len(checked_files)}
        print()

        # 6. Config validation
        print("─ Configuration Validation ─")
        result = self.validate()
        if result["ok"]:
            print("  ✓ Configuration valid")
        else:
            for issue in result["issues"]:
                print(f"  ✗ {issue}")
                manifest["issues"].append(issue)
            manifest["ready"] = False
        for warning in result["warnings"]:
            print(f"  ⚠ {warning}")
        print()

        # Summary
        print("─ Shipping Manifest ─")
        if manifest["ready"]:
            print("  ✓ ALL COMPONENTS READY FOR SHIPPING")
        else:
            print(f"  ✗ {len(manifest["issues"])} issues must be resolved before shipping")
            for issue in manifest["issues"]:
                print(f"    ✗ {issue}")

        print()
        print("  Suite Components:")
        for comp, info in manifest["components"].items():
            status_icon = "✓" if info.get("status") == "ready" else "✗"
            print(f"    {status_icon} {comp}: {info.get("status", "unknown")}")

        print()
        print("  Shipping Package Contents:")
        print("    1. Liminal Lore Config System (config/)")
        print("    2. VW Nexus (tools/vw_nexus/)")
        print("    3. VW Deck (tools/liminal_link_vw_deck/)")
        print("    4. ZHARK Virtual CSO (tools/zhark/)")
        print("    5. SETUP_GUIDE.md")
        print("    6. .env template (user-generated)")
        print("    7. liminal_lore.yaml template (user-generated)")
        print()

        # Save manifest
        manifest_path = self.project_root / "SHIPPING_MANIFEST.json"
        manifest_path.write_text(json.dumps(manifest, indent=2, default=str), encoding="utf-8")
        print(f"  Manifest saved: {manifest_path}")

        return manifest

    # ── Helpers ───────────────────────────────────────────────

    def _detect_project_root(self) -> Path:
        env_root = os.environ.get("PROJECT_ROOT")
        if env_root:
            return Path(env_root).resolve()
        current = Path(__file__).resolve().parent
        for _ in range(10):
            if (current / ".git").exists() or (current / "tools").exists():
                return current
            parent = current.parent
            if parent == current:
                break
            current = parent
        return Path.cwd()

    def _write_env_value(self, key: str, value: str) -> None:
        """Write or update a key=value in the .env file."""
        if not self.env_path.exists():
            return

        lines = self.env_path.read_text(encoding="utf-8").splitlines()
        found = False
        new_lines = []
        for line in lines:
            if line.strip().startswith(f"{key}=") and not line.strip().startswith("#"):
                new_lines.append(f"{key}={value}")
                found = True
            elif line.strip() == f"#{key}=":
                new_lines.append(f"{key}={value}")
                found = True
            else:
                new_lines.append(line)

        if not found:
            # Find the commented template line and uncomment it
            for i, line in enumerate(new_lines):
                if f"#{key}=" in line:
                    new_lines[i] = f"{key}={value}"
                    found = True
                    break

        if not found:
            new_lines.append(f"{key}={value}")

        self.env_path.write_text("\n".join(new_lines) + "\n", encoding="utf-8")


def main(argv: Optional[list] = None) -> int:
    args = argv or sys.argv[1:]
    wizard = SetupWizard()

    if not args or args[0] == "--interactive":
        wizard.run_interactive()
    elif args[0] == "--check":
        result = wizard.run_check()
        return 0 if result["ok"] else 1
    elif args[0] == "--generate":
        wizard.run_generate()
    elif args[0] == "--ship":
        manifest = wizard.run_ship()
        return 0 if manifest.get("ready") else 1
    elif args[0] in ("-h", "--help"):
        print("Liminal Lore Setup Wizard")
        print()
        print("Usage:")
        print("  python -m config.setup_wizard               Interactive setup")
        print("  python -m config.setup_wizard --check       Validate config only")
        print("  python -m config.setup_wizard --generate    Generate template files")
        print("  python -m config.setup_wizard --ship        Shipping finalization check")
    else:
        print(f"Unknown argument: {args[0]}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
