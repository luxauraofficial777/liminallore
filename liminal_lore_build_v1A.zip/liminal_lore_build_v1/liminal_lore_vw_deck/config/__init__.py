"""Liminal Lore — Configuration package.

Exports:
  ConfigLoader   — Layered config loader (.env → YAML/JSON → defaults)
  LLMProvider    — Dynamic LLM provider abstraction
  SetupWizard    — Interactive setup and initialization wizard
"""

from .config_loader import ConfigLoader
from .provider_abstraction import LLMProvider, ProviderInfo
from .setup_wizard import SetupWizard

__all__ = ["ConfigLoader", "LLMProvider", "ProviderInfo", "SetupWizard"]
