"""Liminal Lore — Decoupled Configuration Loader.

Replaces all hardcoded URLs, credentials, and paths with a layered
configuration system:

  1. Environment variables (.env) — highest priority, never committed
  2. User config file (liminal_lore.yaml or liminal_lore.json) — user settings
  3. Built-in defaults — safe fallbacks, no secrets

No API keys, tokens, or machine-specific paths are hardcoded anywhere.
Users provide their own via .env or config file.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional


# ── Defaults (no secrets, no machine-specific paths) ───────────

_DEFAULTS: Dict[str, Any] = {
    "tool_name": "Liminal Lore",
    "version": "1.0.0",
    "schema_version": "1.0",

    # Bridge server
    "bridge": {
        "host": "0.0.0.0",
        "port": 8643,
        "fs_service_port": 8644,
        "memory_monitor_port": 8645,
        "turboquant_port": 8646,
        "runpod_bridge_port": 8647,
    },

    # Nexus
    "nexus": {
        "url": "http://127.0.0.1:8651",
        "api_key_env": "NEXUS_API_KEY",
    },

    # Model providers — all via env vars or config file
    "providers": {
        "ollama": {
            "enabled": True,
            "base_url_env": "OLLAMA_BASE_URL",
            "default_base_url": "http://127.0.0.1:11434",
            "default_model": "qwen2.5-coder:7b",
        },
        "openai_compatible": {
            "enabled": False,
            "base_url_env": "LLM_BASE_URL",
            "api_key_env": "LLM_API_KEY",
            "default_base_url": "",
            "default_model": "",
        },
        "openrouter": {
            "enabled": False,
            "api_key_env": "OPENROUTER_API_KEY",
            "default_base_url": "https://openrouter.ai/api/v1",
            "default_model": "",
        },
        "custom": {
            "enabled": False,
            "base_url_env": "CUSTOM_LLM_BASE_URL",
            "api_key_env": "CUSTOM_LLM_API_KEY",
            "default_base_url": "",
            "default_model": "",
        },
    },

    # Active provider selection
    "active_provider": "ollama",
    "active_model": "",

    # Committee / agent settings
    "committee": {
        "default_mode": "lazy_sync",
        "max_concurrent": 2,
        "consensus_threshold": 0.7,
    },

    # Hardware tier
    "hardware_tier": {
        "auto_detect": True,
        "default": "mid_range",
    },

    # Security
    "security": {
        "allowed_exec_prefixes": ["python", "powershell", "cmd", "cmake", "ninja", "pip", "node", "npm"],
        "blocked_patterns": ["rm -rf", "del /f /s /q", "format", "rd /s /q"],
    },

    # File access — uses env var for project root, no hardcoded paths
    "file_access": {
        "enabled": True,
        "mode": "allowlist",
        "allowed_prefixes_env": "PROJECT_ROOT",
        "denied_patterns": ["\\.ssh", "\\.git\\hooks", "\\secrets\\.", "\\keys\\."],
    },

    # UI
    "ui": {
        "default_theme": "void",
        "settings_menu_enabled": True,
        "backdrop_interval_ms": 20000,
    },

    # VPN (optional, disabled by default for public release)
    "vpn": {
        "enabled": False,
        "provider": "",
        "monitor_port": 8645,
    },

    # Paths — all relative to project root, no hardcoded absolute paths
    "paths": {
        "project_root_env": "PROJECT_ROOT",
        "study_dir": "${project_root}/study",
        "tools_dir": "${project_root}/tools",
        "assets_dir": "${project_root}/assets",
        "build_dir": "${project_root}/build",
        "data_dir": "${project_root}/data",
    },
}


class ConfigLoader:
    """Layered configuration loader: .env → user config → defaults.

    Resolution order (highest priority first):
      1. Environment variables
      2. .env file in project root
      3. User config file (liminal_lore.yaml or liminal_lore.json)
      4. Built-in defaults

    No secrets are ever stored in the config file. API keys are always
    read from environment variables at runtime.
    """

    def __init__(
        self,
        project_root: Optional[str | Path] = None,
        config_file: Optional[str | Path] = None,
        env_file: Optional[str | Path] = None,
    ):
        self.project_root = self._detect_project_root(project_root)
        self._env_loaded = False
        self._config: Dict[str, Any] = {}

        # Load .env file
        env_path = env_file or (self.project_root / ".env")
        self._load_env(env_path)

        # Load user config
        config_path = config_file or self._find_config_file()
        user_config = self._load_config_file(config_path)

        # Merge: defaults < user_config < env overrides
        self._config = self._deep_merge(_DEFAULTS, user_config)
        self._apply_env_overrides()

        # Resolve path variables
        self._resolve_paths()

    # ── Project Root Detection ────────────────────────────────

    @staticmethod
    def _detect_project_root(explicit: Optional[str | Path]) -> Path:
        if explicit:
            return Path(explicit).resolve()
        env_root = os.environ.get("PROJECT_ROOT")
        if env_root:
            return Path(env_root).resolve()
        current = Path(__file__).resolve().parent
        for _ in range(10):
            if (current / ".env").exists() or (current / "liminal_lore.yaml").exists():
                return current
            if (current / "tools").exists() and (current / "study").exists():
                return current
            parent = current.parent
            if parent == current:
                break
            current = parent
        return Path.cwd()

    # ── .env Loading ──────────────────────────────────────────

    def _load_env(self, env_path: Path) -> None:
        if not env_path.exists():
            return
        try:
            with open(env_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    if "=" not in line:
                        continue
                    key, _, value = line.partition("=")
                    key = key.strip()
                    value = value.strip().strip('"').strip("'")
                    if key and key not in os.environ:
                        os.environ[key] = value
            self._env_loaded = True
        except Exception:
            pass

    # ── Config File Loading ───────────────────────────────────

    def _find_config_file(self) -> Optional[Path]:
        candidates = [
            self.project_root / "liminal_lore.yaml",
            self.project_root / "liminal_lore.yml",
            self.project_root / "liminal_lore.json",
            self.project_root / "tools" / "liminal_link_vw_deck" / "liminal_lore.yaml",
            self.project_root / "tools" / "liminal_link_vw_deck" / "liminal_lore.json",
        ]
        for c in candidates:
            if c.exists():
                return c
        return None

    @staticmethod
    def _load_config_file(path: Optional[Path]) -> Dict[str, Any]:
        if not path or not path.exists():
            return {}
        try:
            text = path.read_text(encoding="utf-8")
            if path.suffix in (".yaml", ".yml"):
                try:
                    import yaml
                    return yaml.safe_load(text) or {}
                except ImportError:
                    return {}
            elif path.suffix == ".json":
                return json.loads(text)
        except Exception:
            pass
        return {}

    # ── Merging ───────────────────────────────────────────────

    @staticmethod
    def _deep_merge(base: Dict, override: Dict) -> Dict:
        result = dict(base)
        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = ConfigLoader._deep_merge(result[key], value)
            else:
                result[key] = value
        return result

    # ── Environment Overrides ─────────────────────────────────

    def _apply_env_overrides(self) -> None:
        env_map = {
            "LIMINAL_LORE_BRIDGE_PORT": ("bridge", "port"),
            "LIMINAL_LORE_FS_PORT": ("bridge", "fs_service_port"),
            "LIMINAL_LORE_NEXUS_URL": ("nexus", "url"),
            "LIMINAL_LORE_ACTIVE_PROVIDER": ("active_provider",),
            "LIMINAL_LORE_ACTIVE_MODEL": ("active_model",),
            "LIMINAL_LORE_HARDWARE_TIER": ("hardware_tier", "default"),
            "LIMINAL_LORE_THEME": ("ui", "default_theme"),
        }
        for env_key, config_path in env_map.items():
            env_val = os.environ.get(env_key)
            if env_val is None:
                continue
            d = self._config
            for k in config_path[:-1]:
                if k not in d or not isinstance(d[k], dict):
                    d[k] = {}
                d = d[k]
            final_key = config_path[-1]
            if isinstance(d.get(final_key), int):
                try:
                    d[final_key] = int(env_val)
                except ValueError:
                    d[final_key] = env_val
            elif isinstance(d.get(final_key), bool):
                d[final_key] = env_val.lower() in ("true", "1", "yes")
            else:
                d[final_key] = env_val

    # ── Path Resolution ───────────────────────────────────────

    def _resolve_paths(self) -> None:
        project_root_str = str(self.project_root)

        def _resolve_str(s: str) -> str:
            if not isinstance(s, str):
                return s
            return s.replace("${project_root}", project_root_str)

        def _deep_resolve(obj: Any) -> Any:
            if isinstance(obj, str):
                return _resolve_str(obj)
            if isinstance(obj, list):
                return [_deep_resolve(item) for item in obj]
            if isinstance(obj, dict):
                return {k: _deep_resolve(v) for k, v in obj.items()}
            return obj

        self._config = _deep_resolve(self._config)

    # ── Provider Credential Resolution ────────────────────────

    def get_provider_config(self, provider_id: Optional[str] = None) -> Dict[str, Any]:
        provider_id = provider_id or self._config.get("active_provider", "ollama")
        providers = self._config.get("providers", {})
        provider = providers.get(provider_id, {})

        base_url_env = provider.get("base_url_env", "")
        base_url = os.environ.get(base_url_env, "") if base_url_env else ""
        if not base_url:
            base_url = provider.get("default_base_url", "")

        api_key_env = provider.get("api_key_env", "")
        api_key = os.environ.get(api_key_env, "") if api_key_env else ""

        model = self._config.get("active_model", "") or provider.get("default_model", "")

        return {
            "id": provider_id,
            "base_url": base_url,
            "api_key": api_key,
            "api_key_present": bool(api_key),
            "model": model,
            "enabled": provider.get("enabled", False),
        }

    def get_nexus_config(self) -> Dict[str, Any]:
        nexus = self._config.get("nexus", {})
        api_key_env = nexus.get("api_key_env", "NEXUS_API_KEY")
        return {
            "url": nexus.get("url", "http://127.0.0.1:8651"),
            "api_key": os.environ.get(api_key_env, ""),
            "api_key_present": bool(os.environ.get(api_key_env, "")),
        }

    # ── Access ────────────────────────────────────────────────

    def get(self, key: str, default: Any = None) -> Any:
        return self._config.get(key, default)

    def get_nested(self, *keys: str, default: Any = None) -> Any:
        d = self._config
        for k in keys:
            if not isinstance(d, dict) or k not in d:
                return default
            d = d[k]
        return d

    @property
    def config(self) -> Dict[str, Any]:
        return self._redact(self._config)

    @staticmethod
    def _redact(obj: Any) -> Any:
        if isinstance(obj, str):
            return obj
        if isinstance(obj, dict):
            result = {}
            for k, v in obj.items():
                if k in ("api_key", "token", "secret", "password", "auth_token"):
                    result[k] = "***" if v else ""
                else:
                    result[k] = ConfigLoader._redact(v)
            return result
        if isinstance(obj, list):
            return [ConfigLoader._redact(item) for item in obj]
        return obj

    # ── Validation ────────────────────────────────────────────

    def validate(self) -> Dict[str, Any]:
        issues: List[str] = []
        warnings: List[str] = []
        ready: List[str] = []

        if not self.project_root.exists():
            issues.append(f"Project root does not exist: {self.project_root}")
        else:
            ready.append(f"Project root: {self.project_root}")

        provider = self.get_provider_config()
        if not provider["enabled"]:
            warnings.append(f"Active provider '{provider['id']}' is not enabled")
        elif not provider["base_url"]:
            issues.append(f"Provider '{provider['id']}' has no base_url configured")
        else:
            ready.append(f"Provider: {provider['id']} at {provider['base_url']}")

        if not provider["model"]:
            warnings.append("No model specified — will use provider default")

        if provider["id"] != "ollama" and not provider["api_key_present"]:
            warnings.append(
                f"Provider '{provider['id']}' may require an API key. "
                f"Set it via the environment variable."
            )

        nexus = self.get_nexus_config()
        if nexus["url"]:
            ready.append(f"Nexus URL: {nexus['url']}")

        return {
            "ok": len(issues) == 0,
            "issues": issues,
            "warnings": warnings,
            "ready": ready,
            "tool_name": self._config.get("tool_name", "Liminal Lore"),
            "version": self._config.get("version", "1.0.0"),
        }

    # ── Export ────────────────────────────────────────────────

    def export_template(self, path: str | Path, fmt: str = "yaml") -> str:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        template = {
            "tool_name": "Liminal Lore",
            "version": "1.0.0",
            "schema_version": "1.0",
            "_comment": "Copy this file and customize. API keys go in .env, never here.",
            "bridge": _DEFAULTS["bridge"],
            "nexus": _DEFAULTS["nexus"],
            "providers": _DEFAULTS["providers"],
            "active_provider": "ollama",
            "active_model": "",
            "committee": _DEFAULTS["committee"],
            "hardware_tier": _DEFAULTS["hardware_tier"],
            "security": _DEFAULTS["security"],
            "file_access": _DEFAULTS["file_access"],
            "ui": _DEFAULTS["ui"],
            "vpn": _DEFAULTS["vpn"],
            "paths": _DEFAULTS["paths"],
        }

        if fmt == "yaml":
            try:
                import yaml
                with open(path, "w", encoding="utf-8") as f:
                    yaml.dump(template, f, default_flow_style=False, sort_keys=False)
            except ImportError:
                fmt = "json"

        if fmt == "json":
            with open(path, "w", encoding="utf-8") as f:
                json.dump(template, f, indent=2, default=str)

        return str(path)
