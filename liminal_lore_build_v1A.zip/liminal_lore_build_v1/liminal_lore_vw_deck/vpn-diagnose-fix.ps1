# VoidWalkers // VPN Diagnose & Fix
# Run as Administrator. Creates virtual NIC, fixes adapter DHCP, connects fastest relay.

# ─── CONFIG LOADER ───
$ConfigPath = Join-Path $PSScriptRoot "vw_deck.config.json"
$VpnConfig = @{}
if (Test-Path $ConfigPath) {
    try {
        $raw = Get-Content $ConfigPath -Raw -Encoding UTF8
        $cfg = $raw | ConvertFrom-Json
        if ($cfg.vpn) { $VpnConfig = $cfg.vpn }
    } catch { Write-Host "[CONFIG] Warning: could not parse vw_deck.config.json" -ForegroundColor Yellow }
}
$clientPath = if ($VpnConfig.client_path) { $VpnConfig.client_path } else { $null }
$nicName    = if ($VpnConfig.nic_name) { $VpnConfig.nic_name } else { "VPN" }
$provider   = if ($VpnConfig.provider) { $VpnConfig.provider } else { "vpngate" }

$vpncmd = $clientPath
if (-not $vpncmd -or -not (Test-Path $vpncmd)) { $vpncmd = "C:\Program Files\SoftEther VPN Client\vpncmd.exe" }
if (-not (Test-Path $vpncmd)) { $vpncmd = "C:\Program Files (x86)\SoftEther VPN Client\vpncmd.exe" }
if (-not (Test-Path $vpncmd)) { Write-Error "vpncmd.exe not found. Install SoftEther VPN Client first or set client_path in config."; exit 1 }

function Out($msg) { Write-Host $msg -ForegroundColor Cyan }
function Ok($msg) { Write-Host $msg -ForegroundColor Green }
function Warn($msg) { Write-Host $msg -ForegroundColor Yellow }
function Err($msg) { Write-Host $msg -ForegroundColor Red }

# ─── 1. Check SoftEther Client Service ───
Out "=== 1. SoftEther Client Service ==="
$svc = Get-Service -Name "sevpnclient" -ErrorAction SilentlyContinue
if (-not $svc) { $svc = Get-Service -Name "SoftEtherVPNClient" -ErrorAction SilentlyContinue }
if (-not $svc) { $svc = Get-Service -Name "vpnclient" -ErrorAction SilentlyContinue }
if ($svc) {
    Ok "Service found: $($svc.Name) — Status: $($svc.Status)"
    if ($svc.Status -ne 'Running') {
        Warn "Starting service..."
        Start-Service $svc.Name -ErrorAction SilentlyContinue
    }
} else {
    Warn "Could not detect SoftEther service name. Assuming it's running."
}

# ─── 2. Virtual NIC ───
Out "`n=== 2. Virtual NIC Check ==="
$nicList = & $vpncmd localhost /CLIENT /CMD NicList 2>&1
$hasVpn = $nicList | Where-Object { $_ -match $nicName }
if (-not $hasVpn) {
    Warn "No '$nicName' virtual NIC found. Creating..."
    $create = & $vpncmd localhost /CLIENT /CMD NicCreate $nicName 2>&1
    Ok "NicCreate output: $create"
} else {
    Ok "Virtual NIC '$nicName' exists."
}

# ─── 3. Windows Adapter State ───
Out "`n=== 3. Windows Adapter State ==="
$allIfaces = netsh interface show interface | Out-String
$vpnIface = $null
foreach ($line in $allIfaces -split "`r?`n") {
    if ($line -match $nicName) {
        Write-Host "  $line"
        if ($line -match "Connected|Enabled") {
            $parts = $line -split "\s{2,}"
            if ($parts.Length -ge 4) { $vpnIface = $parts[3].Trim() }
        }
    }
}
if ($vpnIface) {
    Ok "Detected adapter: '$vpnIface'"
    # Make sure it's enabled
    netsh interface set interface name="$vpnIface" admin=enabled | Out-Null
    Ok "Ensured adapter is enabled."
} else {
    Err "No VPN adapter found in Windows. Check SoftEther Client is installed."
}

# ─── 4. ipconfig Before Fix ───
Out "`n=== 4. Current IP Configuration ==="
$before = ipconfig | Out-String
$inBlock = $false
foreach ($line in ($before -split "`r?`n")) {
    if ($line -match "VPN|Virtual|Tunnel|10\.211|192\.168\.30") { $inBlock = $true }
    if ($inBlock) { Write-Host "  $line" }
    if ($inBlock -and $line -match "^\s*$") { $inBlock = $false }
}

# ─── 5. Force Adapter Reset + DHCP ───
Out "`n=== 5. Resetting Adapter + Forcing DHCP ==="
if ($vpnIface) {
    Warn "Disabling adapter '$vpnIface'..."
    netsh interface set interface name="$vpnIface" admin=disabled | Out-Null
    Start-Sleep -Seconds 2
    Warn "Re-enabling..."
    netsh interface set interface name="$vpnIface" admin=enabled | Out-Null
    Start-Sleep -Seconds 3
}

# Use exact interface name for DHCP renewal if available
if ($vpnIface) {
    netsh interface ip set address name="$vpnIface" source=dhcp | Out-Null
    netsh interface ip set dns name="$vpnIface" source=dhcp | Out-Null
    Start-Sleep -Seconds 2
} else {
    ipconfig /release "*VPN*" | Out-Null
    Start-Sleep -Seconds 1
    ipconfig /renew "*VPN*" | Out-Null
    Start-Sleep -Seconds 3
}

# ─── 6. Check IP After ───
Out "`n=== 6. IP After Fix ==="
$after = ipconfig | Out-String
$gotIP = $false
$inBlock = $false
foreach ($line in ($after -split "`r?`n")) {
    if ($line -match "VPN|Virtual|Tunnel|10\.211|192\.168\.30") { $inBlock = $true }
    if ($inBlock) {
        Write-Host "  $line"
        if ($line -match "IPv4.*:\s+(\d+\.\d+\.\d+\.\d+)") { $gotIP = $true }
    }
    if ($inBlock -and $line -match "^\s*$") { $inBlock = $false }
}
if ($gotIP) {
    Ok "Adapter now has an IP."
} else {
    Warn "Still no IP. Will attempt static fallback after connection."
}

# ─── 7. Import & Connect Best Relay ───
Out "`n=== 7. Fetching + Connecting Best Relay ==="

if ($provider -eq "custom") {
    $customRelays = $VpnConfig.providers.custom.relays
    if (-not $customRelays) { Err "No custom relays configured."; exit 1 }
    $best = @()
    foreach ($r in $customRelays) {
        $best += [PSCustomObject]@{
            Name = $r.name
            Host = $r.host
            Hub  = if ($r.hub) { $r.hub } else { "DEFAULT" }
            Port = if ($r.port) { $r.port } else { 443 }
            Username = if ($r.username) { $r.username } else { "user" }
        }
    }
} else {
    $vpg = $VpnConfig.providers.vpngate
    $filt = if ($vpg.filters) { $vpg.filters } else { @{ countries=@("JP","KR"); min_score=150000; min_speed=1000000 } }
    $portsCfg = if ($vpg.ports) { $vpg.ports } else { @(443,992,5555) }
    $hubDefault = if ($vpg.hub_default) { $vpg.hub_default } else { "VPNGATE" }
    $username = if ($vpg.username) { $vpg.username } else { "anonymous" }
    $apiUrl = if ($vpg.api_url) { $vpg.api_url } else { "https://www.vpngate.net/api/iphone/" }

    $api = Invoke-RestMethod -Uri $apiUrl -TimeoutSec 20
    $lines = $api -split "`n"
    $relays = @()
    foreach ($line in $lines[2..($lines.Length-3)]) {
        $c = $line -split ","
        if ($c.Length -lt 15) { continue }
        $country = $c[6]
        $score = [long]$c[2]
        $speed = [long]$c[4]
        if ($country -in $filt.countries -and $score -gt $filt.min_score -and $speed -gt $filt.min_speed) {
            $relays += [PSCustomObject]@{
                Name = "$($VpnConfig.account_prefix)$($country)_$($c[1])"
                Host = if ($c[0] -and $c[0] -ne "*") { $c[0] } else { $c[1] }
                Hub  = if ($c[13] -and $c[13] -ne "*") { $c[13] } else { $hubDefault }
                Score = $score
                Username = $username
                Ports = $portsCfg
            }
        }
    }
    $best = $relays | Sort-Object Score -Descending | Select-Object -First 5
}

$connected = $false
foreach ($r in $best) {
    & $vpncmd localhost /CLIENT /CMD AccountDelete $r.Name 2>$null | Out-Null
    $ports = if ($r.Ports) { $r.Ports } else { @($r.Port) }
    foreach ($port in $ports) {
        $user = if ($r.Username) { $r.Username } else { "anonymous" }
        $out = & $vpncmd localhost /CLIENT /CMD AccountCreate $r.Name /SERVER:$($r.Host):$port /HUB:$($r.Hub) /USERNAME:$user /NICNAME:$nicName 2>&1
        if ($out -join "" -match "completed|ok|success|already") {
            & $vpncmd localhost /CLIENT /CMD AccountDetailSet $r.Name /UDPEnabled:yes 2>$null | Out-Null
            & $vpncmd localhost /CLIENT /CMD AccountDisconnect $r.Name 2>$null | Out-Null
            Start-Sleep -Milliseconds 500
            $conn = & $vpncmd localhost /CLIENT /CMD AccountConnect $r.Name 2>&1
            Ok "Created + connecting: $($r.Name) on port $port ..."
            Start-Sleep -Seconds 3

            # Wait for adapter IP
            for ($i=0; $i -lt 15; $i++) {
                Start-Sleep -Seconds 2
                $cfg = ipconfig | Out-String
                if ($cfg -match "IPv4.*(10\.211\.\d+\.\d+|192\.168\.30\.\d+)") {
                    $adapterIP = $matches[1]
                    try { $exitIP = (Invoke-RestMethod -Uri "https://checkip.amazonaws.com" -TimeoutSec 5).Trim() } catch { $exitIP = "?" }
                    Ok "SUCCESS! Relay: $($r.Name) | Adapter: $adapterIP | Exit: $exitIP"
                    $connected = $true
                    break
                }
            }
            if ($connected) { break }
        }
        & $vpncmd localhost /CLIENT /CMD AccountDelete $r.Name 2>$null | Out-Null
    }
    if ($connected) { break }
}

if (-not $connected) {
    Err "All relays failed to assign adapter IP. Try rebooting or reinstalling SoftEther Client."
} else {
    Ok "`n=== VPN Tunnel ESTABLISHED ==="
}

# ─── 8. Save Account Names for Deck ───
$best | ForEach-Object { $_.Name } | Out-File "$PSScriptRoot\last_relay_accounts.txt" -Encoding utf8
Out "`nSaved relay list to last_relay_accounts.txt"

pause
