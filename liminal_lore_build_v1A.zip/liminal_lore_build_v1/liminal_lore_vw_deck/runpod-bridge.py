#!/usr/bin/env python3
"""
Runpod Remote Provider Bridge v2.0
Persistent SSH/SFTP service with slash-command processing for Portal Studio.
HTTP Service Port: 8647
"""

import argparse
import json
import hashlib
import os
import sys
import time
import socket
import threading
import uuid
import shutil
import zipfile
from pathlib import Path
from typing import Callable, Optional, Dict
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
from urllib.parse import urlparse

# Soft dependency: paramiko
try:
    import paramiko
except ImportError:
    sys.stderr.write("[ERROR] paramiko required. Run: pip install paramiko\n")
    sys.exit(1)

# ─── Global State ───
BRIDGE_INSTANCE: Optional["RunpodBridge"] = None
JOBS: Dict[str, dict] = {}
JOBS_LOCK = threading.Lock()
PORT = 8647

# ─── Helpers ───
def file_digest(path: str) -> str:
    h = hashlib.md5()
    try:
        st = os.stat(path)
        h.update(str(st.st_mtime).encode())
        h.update(str(st.st_size).encode())
        with open(path, "rb") as f:
            while chunk := f.read(65536):
                h.update(chunk)
    except OSError:
        return ""
    return h.hexdigest()

class SyncState:
    def __init__(self, state_path: str):
        self.state_path = Path(state_path)
        self.state = {}
        if self.state_path.exists():
            try:
                with open(self.state_path, "r", encoding="utf-8") as f:
                    self.state = json.load(f)
            except Exception:
                self.state = {}

    def get(self, path: str) -> Optional[str]:
        return self.state.get(Path(path).as_posix())

    def set(self, path: str, digest: str):
        self.state[Path(path).as_posix()] = digest

    def save(self):
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.state_path, "w", encoding="utf-8") as f:
            json.dump(self.state, f, indent=2)

# ─── Core Bridge ───
class RunpodBridge:
    def __init__(self, config_path: str = "runpod_config.json"):
        self.config_path = Path(config_path)
        self.config = {}
        self.ssh: Optional[paramiko.SSHClient] = None
        self.sftp: Optional[paramiko.SFTPClient] = None
        self.connected = False
        self._lock = threading.Lock()
        self._load_config()
        self.sync_state = SyncState(self.config.get("sync_state_path", "sync_state.json"))
        self.model_state = self._load_model_state()
        self._keepalive_thread: Optional[threading.Thread] = None
        self._stop_keepalive = threading.Event()

    def _load_config(self):
        if not self.config_path.exists():
            default_config = {
                "host": "ssh.runpod.io",
                "port": 22,
                "username": "root",
                "key_path": "~/.ssh/runpod_key",
                "timeout": 20,
                "workspace_dir": "C:/LuxAura/VoidWalkers_Project/Modern_X64",
                "sync_state_path": "runpod_sync_state.json",
                "dir_map": {
                    "default": {
                        "local": "C:/LuxAura/VoidWalkers_Project/Modern_X64",
                        "remote": "/workspace/voidwalkers"
                    }
                }
            }
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(default_config, f, indent=2)
            self.config = default_config
            print(f"[INFO] Created default config: {self.config_path}")
        else:
            with open(self.config_path, "r", encoding="utf-8") as f:
                self.config = json.load(f)
        required = ["host", "port", "username", "key_path", "dir_map"]
        for k in required:
            if k not in self.config:
                raise ValueError(f"Missing config key: {k}")

    def _load_model_state(self) -> dict:
        p = Path("runpod_model_state.json")
        if p.exists():
            try:
                with open(p, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {"provider": "hermes", "model": "kimi-k2.6"}

    def check_vpn(self) -> dict:
        vpn_cfg = self.config.get("vpn", {})
        if not vpn_cfg.get("enabled", False):
            return {"enabled": False}
        try:
            import urllib.request
            url = vpn_cfg.get("health_check_url", "https://checkip.amazonaws.com")
            with urllib.request.urlopen(url, timeout=5) as r:
                ip = r.read().decode().strip()
            return {"enabled": True, "connected": True, "exit_ip": ip}
        except Exception as e:
            return {"enabled": True, "connected": False, "error": str(e)}

    def _save_model_state(self):
        with open("runpod_model_state.json", "w", encoding="utf-8") as f:
            json.dump(self.model_state, f, indent=2)

    def connect(self) -> bool:
        with self._lock:
            if self.connected and self.ssh and self.ssh.get_transport() and self.ssh.get_transport().is_active():
                return True
            self._disconnect()
            host = self.config["host"]
            port = int(self.config.get("port", 22))
            username = self.config["username"]
            key_path = Path(self.config["key_path"]).expanduser()
            timeout = int(self.config.get("timeout", 15))

            if not key_path.exists():
                raise FileNotFoundError(f"SSH key not found: {key_path}")

            # Detect key type
            pkey = None
            for key_cls in (paramiko.RSAKey, paramiko.Ed25519Key, paramiko.ECDSAKey):
                try:
                    pkey = key_cls.from_private_key_file(str(key_path))
                    break
                except Exception:
                    continue
            if not pkey:
                raise ValueError(f"Unable to parse SSH key: {key_path}")

            self.ssh = paramiko.SSHClient()
            self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            try:
                self.ssh.connect(
                    hostname=host, port=port, username=username, pkey=pkey,
                    timeout=timeout, banner_timeout=timeout, auth_timeout=timeout,
                )
                self.sftp = self.ssh.open_sftp()
                self.connected = True
                self._start_keepalive()
                return True
            except paramiko.AuthenticationException as e:
                raise ConnectionError(f"SSH auth failed: {e}") from e
            except socket.timeout as e:
                raise ConnectionError(f"SSH timeout: {e}") from e
            except socket.error as e:
                errno_str = f" errno={e.errno}" if hasattr(e, "errno") else ""
                raise ConnectionError(f"SSH socket error{errno_str}: {e}") from e

    def _disconnect(self):
        self._stop_keepalive.set()
        if self._keepalive_thread:
            self._keepalive_thread.join(timeout=2)
        if self.sftp:
            try:
                self.sftp.close()
            except Exception:
                pass
            self.sftp = None
        if self.ssh:
            try:
                self.ssh.close()
            except Exception:
                pass
            self.ssh = None
        self.connected = False

    def _start_keepalive(self):
        self._stop_keepalive.clear()
        def loop():
            while not self._stop_keepalive.is_set():
                try:
                    if self.ssh and self.ssh.get_transport():
                        self.ssh.get_transport().send_ignore()
                except Exception:
                    pass
                self._stop_keepalive.wait(30)
        self._keepalive_thread = threading.Thread(target=loop, daemon=True)
        self._keepalive_thread.start()

    def close(self):
        with self._lock:
            self._disconnect()

    def _ensure_remote_dir(self, remote_dir: str):
        parts = remote_dir.strip("/").split("/")
        path = ""
        for part in parts:
            path += "/" + part
            try:
                self.sftp.stat(path)
            except FileNotFoundError:
                self.sftp.mkdir(path)

    def sync_up(self, local_dir: str, remote_dir: str, job_id: str) -> dict:
        if not self.sftp:
            raise RuntimeError("SFTP not connected")
        self._ensure_remote_dir(remote_dir)
        stats = {"uploaded": 0, "skipped": 0, "errors": 0, "bytes": 0}
        local_root = Path(local_dir)

        for root, _, files in os.walk(local_dir):
            for fname in files:
                local_path = Path(root) / fname
                rel = local_path.relative_to(local_root).as_posix()
                remote_path = (Path(remote_dir) / rel).as_posix()
                remote_parent = str(Path(remote_path).parent).replace("\\", "/")
                self._ensure_remote_dir(remote_parent)
                digest = file_digest(str(local_path))
                if self.sync_state.get(str(local_path)) == digest:
                    stats["skipped"] += 1
                    _job_append(job_id, f"SKIP {rel}")
                    continue
                try:
                    self.sftp.put(str(local_path), remote_path)
                    self.sync_state.set(str(local_path), digest)
                    stats["uploaded"] += 1
                    stats["bytes"] += local_path.stat().st_size
                    _job_append(job_id, f"UP {rel}")
                except Exception as e:
                    stats["errors"] += 1
                    _job_append(job_id, f"ERR {rel}: {e}")
        self.sync_state.save()
        return stats

    def sync_down(self, remote_dir: str, local_dir: str, job_id: str) -> dict:
        if not self.sftp:
            raise RuntimeError("SFTP not connected")
        stats = {"downloaded": 0, "skipped": 0, "errors": 0, "bytes": 0}
        local_root = Path(local_dir)
        local_root.mkdir(parents=True, exist_ok=True)

        def walk(remote_path: str, rel_prefix: str = ""):
            try:
                entries = self.sftp.listdir_attr(remote_path)
            except Exception as e:
                stats["errors"] += 1
                _job_append(job_id, f"ERR list {remote_path}: {e}")
                return
            for entry in entries:
                name = entry.filename
                full_remote = f"{remote_path}/{name}"
                rel = f"{rel_prefix}/{name}" if rel_prefix else name
                local_path = local_root / rel
                if paramiko.S_ISDIR(entry.st_mode):
                    local_path.mkdir(parents=True, exist_ok=True)
                    walk(full_remote, rel)
                else:
                    try:
                        digest = file_digest(str(local_path))
                        local_mtime = local_path.stat().st_mtime if local_path.exists() else 0
                        if local_mtime >= entry.st_mtime:
                            stats["skipped"] += 1
                            _job_append(job_id, f"SKIP {rel}")
                            continue
                        self.sftp.get(full_remote, str(local_path))
                        stats["downloaded"] += 1
                        stats["bytes"] += entry.st_size
                        _job_append(job_id, f"DOWN {rel}")
                    except Exception as e:
                        stats["errors"] += 1
                        _job_append(job_id, f"ERR {rel}: {e}")
        walk(remote_dir)
        return stats

    def remote_exec(self, command: str, job_id: str) -> int:
        if not self.ssh:
            raise RuntimeError("SSH not connected")
        transport = self.ssh.get_transport()
        if not transport or not transport.is_active():
            raise ConnectionError("SSH transport disconnected")
        channel = transport.open_session()
        channel.get_pty()
        channel.exec_command(command)
        while not channel.exit_status_ready():
            if channel.recv_ready():
                data = channel.recv(4096).decode("utf-8", errors="replace")
                for line in data.splitlines():
                    _job_append(job_id, line)
            if channel.recv_stderr_ready():
                data = channel.recv_stderr(4096).decode("utf-8", errors="replace")
                for line in data.splitlines():
                    _job_append(job_id, f"[STDERR] {line}")
            time.sleep(0.01)
        while channel.recv_ready():
            data = channel.recv(4096).decode("utf-8", errors="replace")
            for line in data.splitlines():
                _job_append(job_id, line)
        exit_code = channel.recv_exit_status()
        channel.close()
        return exit_code

    def run_agent_block(self, code_block: str, job_id: str, remote_python: str = "python3") -> int:
        remote_script = f"/tmp/vw_agent_{int(time.time())}.py"
        with self.sftp.file(remote_script, "w") as f:
            f.write(code_block)
        cmd = f"{remote_python} {remote_script}"
        return self.remote_exec(cmd, job_id)

    def compress_local(self, target_dir: str, output_path: str) -> str:
        target = Path(target_dir)
        if not target.exists():
            raise FileNotFoundError(f"Target directory not found: {target_dir}")
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
            for root, _, files in os.walk(target):
                for fname in files:
                    fp = Path(root) / fname
                    arcname = fp.relative_to(target).as_posix()
                    zf.write(fp, arcname)
        return str(out)

    def save_snapshot(self, name: str, job_id: str) -> dict:
        ts = time.strftime("%Y%m%d_%H%M%S")
        snap_name = f"{name}_{ts}"
        local_snap = Path("snapshots") / snap_name
        local_snap.mkdir(parents=True, exist_ok=True)
        # Archive workspace
        zip_path = local_snap / f"{snap_name}.zip"
        workspace = Path(self.config.get("workspace_dir", "."))
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for root, _, files in os.walk(workspace):
                for fname in files:
                    fp = Path(root) / fname
                    arcname = fp.relative_to(workspace).as_posix()
                    zf.write(fp, arcname)
        _job_append(job_id, f"Local snapshot: {zip_path}")
        # Sync to remote
        remote_dir = f"/workspace/snapshots/{snap_name}"
        stats = self.sync_up(str(local_snap), remote_dir, job_id)
        meta = {"snapshot": snap_name, "local": str(local_snap), "remote": remote_dir, "stats": stats}
        with open(local_snap / "meta.json", "w", encoding="utf-8") as f:
            json.dump(meta, f, indent=2)
        return meta

    def switch_model(self, provider: str, model: str) -> dict:
        self.model_state["provider"] = provider
        self.model_state["model"] = model
        self._save_model_state()
        # Optionally signal remote pod to reload context
        return {"provider": provider, "model": model, "status": "ok"}

# ─── Job Manager ───
def _job_create() -> str:
    jid = str(uuid.uuid4())[:8]
    with JOBS_LOCK:
        JOBS[jid] = {"lines": [], "done": False, "exit_code": None, "error": None}
    return jid

def _job_append(jid: str, line: str):
    with JOBS_LOCK:
        if jid in JOBS:
            JOBS[jid]["lines"].append(line)
            if len(JOBS[jid]["lines"]) > 2000:
                JOBS[jid]["lines"] = JOBS[jid]["lines"][-1500:]

def _job_done(jid: str, exit_code: int = 0, error: Optional[str] = None):
    with JOBS_LOCK:
        if jid in JOBS:
            JOBS[jid]["done"] = True
            JOBS[jid]["exit_code"] = exit_code
            JOBS[jid]["error"] = error

def _job_get(jid: str, since: int = 0) -> dict:
    with JOBS_LOCK:
        job = JOBS.get(jid, {"lines": [], "done": True, "exit_code": -1, "error": "unknown job"})
        return {
            "lines": job["lines"][since:],
            "done": job["done"],
            "exit_code": job["exit_code"],
            "error": job["error"],
            "total": len(job["lines"]),
        }

# ─── HTTP Server ───
class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # Silent

    def _json(self, status: int, data: dict):
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        if length:
            return json.loads(self.rfile.read(length).decode("utf-8"))
        return {}

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def _route_path(self) -> str:
        return urlparse(self.path).path

    def do_GET(self):
        route = self._route_path()
        if route == "/runpod/status":
            if not BRIDGE_INSTANCE:
                return self._json(503, {"connected": False, "error": "bridge not initialized"})
            try:
                ok = BRIDGE_INSTANCE.connect()
                return self._json(200, {
                    "connected": ok,
                    "host": BRIDGE_INSTANCE.config.get("host"),
                    "model": BRIDGE_INSTANCE.model_state,
                })
            except Exception as e:
                return self._json(200, {"connected": False, "error": str(e)})

        elif route.startswith("/runpod/stream/"):
            jid = route.split("/")[-1]
            since = int(self.headers.get("X-Since", 0))
            return self._json(200, _job_get(jid, since))

        elif route == "/runpod/vpn":
            if not BRIDGE_INSTANCE:
                return self._json(503, {"error": "bridge not initialized"})
            return self._json(200, BRIDGE_INSTANCE.check_vpn())

        elif route == "/runpod/help":
            help_text = """
[ PORTAL DESIGN STUDIO // CORES & UTILITIES COMMAND MATRIX ]
-----------------------------------------------------------------
/help                             - Display this system command map and utility manifesto.
/model [provider] [model]         - Hot-swap the active LLM router core (e.g., Hermes KIMI-K2.6) dynamically.
/compress [dir]                   - Pack and optimize targeted assets/code into high-speed transit blocks.
/save [snapshot]                  - Secure a persistent state checkpoint to local cache and Runpod disk.
/remote [command]                 - Pipe a direct, non-blocking bash command straight to the connected cloud shell.
/sync                             - Force a manual hash-check and bi-directional update of local/remote paths.
/clear                            - Wipe the active local terminal stream and interface buffer.
-----------------------------------------------------------------
""".strip()
            return self._json(200, {"help": help_text})

        else:
            self._json(404, {"error": "not found"})

    def do_POST(self):
        body = self._read_body()
        route = self._route_path()

        if route == "/runpod/command":
            # Slash command router from chat node
            raw = body.get("command", "").strip()
            if not raw:
                return self._json(400, {"error": "empty command"})

            jid = _job_create()
            _job_append(jid, f">>> {raw}")

            def run_cmd():
                try:
                    if not BRIDGE_INSTANCE:
                        raise RuntimeError("Bridge not initialized")
                    BRIDGE_INSTANCE.connect()
                    result = self._process_slash(raw, jid)
                    _job_done(jid, exit_code=0)
                except Exception as e:
                    _job_append(jid, f"[FATAL] {e}")
                    _job_done(jid, exit_code=1, error=str(e))

            threading.Thread(target=run_cmd, daemon=True).start()
            return self._json(202, {"job_id": jid, "status": "accepted"})

        elif route == "/runpod/sync-up":
            jid = _job_create()
            dir_key = body.get("dir_key", "default")
            mapping = BRIDGE_INSTANCE.config.get("dir_map", {}).get(dir_key, {})
            def run():
                try:
                    BRIDGE_INSTANCE.connect()
                    stats = BRIDGE_INSTANCE.sync_up(mapping.get("local", "."), mapping.get("remote", "/workspace"), jid)
                    _job_append(jid, f"Sync-up complete: {stats}")
                    _job_done(jid, 0)
                except Exception as e:
                    _job_done(jid, 1, str(e))
            threading.Thread(target=run, daemon=True).start()
            return self._json(202, {"job_id": jid})

        elif route == "/runpod/sync-down":
            jid = _job_create()
            dir_key = body.get("dir_key", "default")
            mapping = BRIDGE_INSTANCE.config.get("dir_map", {}).get(dir_key, {})
            def run():
                try:
                    BRIDGE_INSTANCE.connect()
                    stats = BRIDGE_INSTANCE.sync_down(mapping.get("remote", "/workspace"), mapping.get("local", "."), jid)
                    _job_append(jid, f"Sync-down complete: {stats}")
                    _job_done(jid, 0)
                except Exception as e:
                    _job_done(jid, 1, str(e))
            threading.Thread(target=run, daemon=True).start()
            return self._json(202, {"job_id": jid})

        elif route == "/runpod/remote-exec":
            jid = _job_create()
            cmd = body.get("command", "")
            def run():
                try:
                    BRIDGE_INSTANCE.connect()
                    rc = BRIDGE_INSTANCE.remote_exec(cmd, jid)
                    _job_done(jid, rc)
                except Exception as e:
                    _job_done(jid, 1, str(e))
            threading.Thread(target=run, daemon=True).start()
            return self._json(202, {"job_id": jid})

        elif route == "/runpod/model":
            provider = body.get("provider", "hermes")
            model = body.get("model", "kimi-k2.6")
            result = BRIDGE_INSTANCE.switch_model(provider, model)
            return self._json(200, result)

        else:
            self._json(404, {"error": "not found"})

    def _process_slash(self, raw: str, jid: str) -> str:
        if not raw.startswith("/"):
            _job_append(jid, f"[WARN] Not a slash command: {raw}")
            return "ignored"
        parts = raw.split()
        cmd = parts[0].lower()
        args = parts[1:]

        if cmd == "/help":
            _job_append(jid, "[ PORTAL DESIGN STUDIO // CORES & UTILITIES COMMAND MATRIX ]")
            _job_append(jid, "-----------------------------------------------------------------")
            _job_append(jid, "/help                             - Display this system command map and utility manifesto.")
            _job_append(jid, "/model [provider] [model]         - Hot-swap the active LLM router core dynamically.")
            _job_append(jid, "/compress [dir]                   - Pack and optimize targeted assets/code into high-speed transit blocks.")
            _job_append(jid, "/save [snapshot]                  - Secure a persistent state checkpoint to local cache and Runpod disk.")
            _job_append(jid, "/remote [command]                 - Pipe a direct, non-blocking bash command straight to the connected cloud shell.")
            _job_append(jid, "/sync                             - Force a manual hash-check and bi-directional update of local/remote paths.")
            _job_append(jid, "/clear                            - Wipe the active local terminal stream and interface buffer.")
            _job_append(jid, "-----------------------------------------------------------------")
            return "ok"

        elif cmd == "/model":
            provider = args[0] if len(args) > 0 else "hermes"
            model = args[1] if len(args) > 1 else "kimi-k2.6"
            result = BRIDGE_INSTANCE.switch_model(provider, model)
            _job_append(jid, f"Model switched: {result}")
            # Optionally re-init remote context
            if len(args) > 2 and args[2] == "--remote-init":
                init_cmd = f"echo 'Re-initializing context for {provider}/{model}'"
                BRIDGE_INSTANCE.remote_exec(init_cmd, jid)
            return "ok"

        elif cmd == "/compress":
            target = args[0] if args else "."
            out = f"compressed_{int(time.time())}.zip"
            _job_append(jid, f"Compressing {target} -> {out} ...")
            path = BRIDGE_INSTANCE.compress_local(target, out)
            _job_append(jid, f"Compressed: {path}")
            # Auto-sync compressed archive up
            mapping = BRIDGE_INSTANCE.config.get("dir_map", {}).get("default", {})
            remote_path = f"{mapping.get('remote', '/workspace')}/{out}"
            BRIDGE_INSTANCE._ensure_remote_dir(str(Path(remote_path).parent).replace("\\", "/"))
            BRIDGE_INSTANCE.sftp.put(path, remote_path)
            _job_append(jid, f"Uploaded archive to {remote_path}")
            return "ok"

        elif cmd == "/save":
            name = args[0] if args else "checkpoint"
            _job_append(jid, f"Saving snapshot: {name} ...")
            meta = BRIDGE_INSTANCE.save_snapshot(name, jid)
            _job_append(jid, f"Snapshot complete: {meta['snapshot']}")
            return "ok"

        elif cmd == "/remote":
            bash_cmd = " ".join(args)
            if not bash_cmd:
                _job_append(jid, "[ERR] /remote requires a command argument")
                return "error"
            _job_append(jid, f"Executing remote: {bash_cmd}")
            rc = BRIDGE_INSTANCE.remote_exec(bash_cmd, jid)
            _job_append(jid, f"Remote exec finished with code {rc}")
            return "ok"

        elif cmd == "/sync":
            mapping = BRIDGE_INSTANCE.config.get("dir_map", {}).get("default", {})
            _job_append(jid, "Starting bi-directional sync ...")
            up_stats = BRIDGE_INSTANCE.sync_up(mapping.get("local", "."), mapping.get("remote", "/workspace"), jid)
            _job_append(jid, f"Up-sync: {up_stats}")
            down_stats = BRIDGE_INSTANCE.sync_down(mapping.get("remote", "/workspace"), mapping.get("local", "."), jid)
            _job_append(jid, f"Down-sync: {down_stats}")
            return "ok"

        elif cmd == "/clear":
            _job_append(jid, "[CLEAR] Terminal buffer reset signal emitted.")
            return "ok"

        else:
            _job_append(jid, f"[ERR] Unknown slash command: {cmd}")
            return "error"

# ─── Main ───
def main():
    parser = argparse.ArgumentParser(description="Runpod Remote Provider Bridge v2.0")
    parser.add_argument("--config", default="runpod_config.json")
    parser.add_argument("--port", type=int, default=PORT)
    parser.add_argument("--service", action="store_true", help="Run HTTP service")
    parser.add_argument("--command", type=str, help="Single CLI command (non-service)")
    args = parser.parse_args()

    global BRIDGE_INSTANCE
    BRIDGE_INSTANCE = RunpodBridge(args.config)

    if args.service:
        server = ThreadedHTTPServer(("127.0.0.1", args.port), Handler)
        print(json.dumps({"event": "service_start", "port": args.port}))
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            BRIDGE_INSTANCE.close()
            print(json.dumps({"event": "service_stop"}))
    elif args.command:
        try:
            BRIDGE_INSTANCE.connect()
            jid = _job_create()
            h = Handler
            h._process_slash(h, args.command, jid)
            time.sleep(0.5)
            print(json.dumps({"result": _job_get(jid)}))
        except Exception as e:
            print(json.dumps({"error": str(e)}))
        finally:
            BRIDGE_INSTANCE.close()
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
