# VoidWalkers // VPN Gate Relay Auto-Fetch & Import
# Run as Administrator in PowerShell
# Requires: SoftEther VPN Client installed with vpncmd.exe

$vpncmd = "C:\Program Files\SoftEther VPN Client\vpncmd.exe"
if (-not (Test-Path $vpncmd)) {
    $vpncmd = "C:\Program Files (x86)\SoftEther VPN Client\vpncmd.exe"
}
if (-not (Test-Path $vpncmd)) {
    Write-Error "vpncmd.exe not found. Ensure SoftEther VPN Client is installed."
    exit 1
}

$vpnNic = "VPN"
Write-Host "[INFO] Fetching VPN Gate relay list..." -ForegroundColor Cyan

try {
    $response = Invoke-RestMethod -Uri "https://www.vpngate.net/api/iphone/" -Method Get -TimeoutSec 30
} catch {
    Write-Error "Failed to fetch VPN Gate list. Check internet connection."
    exit 1
}

$lines = $response -split "`n"
$relays = @()
foreach ($line in $lines[2..($lines.Length - 3)]) {
    $cols = $line -split ","
    if ($cols.Length -lt 15) { continue }
    $country = $cols[6]
    $score = [long]$cols[2]
    $speed = [long]$cols[4]
    $uptime = [long]$cols[8]
    $hostname = $cols[0]
    $ip = $cols[1]
    $hub = $cols[13]

    if ($country -in @("JP", "KR") -and $score -gt 300000 -and $speed -gt 2000000 -and $uptime -gt 1800) {
        $relays += [PSCustomObject]@{
            SettingName = "VW_$($country)_$($ip)"
            Hostname = if ($hostname -and $hostname -ne "*") { $hostname } else { $ip }
            IP = $ip
            Hub = if ($hub -and $hub -ne "*") { $hub } else { "VPNGATE" }
            Score = $score
            Speed = $speed
            Country = $country
            Uptime = $uptime
        }
    }
}

if ($relays.Count -eq 0) {
    Write-Error "No JP/KR relays matched the criteria."
    exit 1
}

$topRelays = $relays | Sort-Object Score -Descending | Select-Object -First 10
Write-Host "`n[INFO] Top relays selected:" -ForegroundColor Cyan
$topRelays | Format-Table SettingName, Hostname, Country, @{N="Speed(Mbps)";E={[math]::Round($_.Speed / 1048576, 1)}}, Score -AutoSize

# Save JSON reference
$outDir = Split-Path -Parent $PSScriptRoot
$topRelays | ConvertTo-Json | Out-File "$outDir\vpngate_top_relays.json" -Encoding utf8
Write-Host "`n[INFO] Saved relay details to vpngate_top_relays.json" -ForegroundColor Green

function Import-RelayWithPorts {
    param($relay)
    $name = $relay.SettingName
    $srvHost = $relay.Hostname
    $hub = $relay.Hub
    $ports = @(443, 992, 5555)

    foreach ($port in $ports) {
        & $vpncmd localhost /CLIENT /CMD AccountDelete $name 2>$null | Out-Null
        $create = & $vpncmd localhost /CLIENT /CMD AccountCreate $name /SERVER:$srvHost`:$port /HUB:$hub /USERNAME:anonymous /NICNAME:$vpnNic 2>&1
        if ($LASTEXITCODE -eq 0 -or ($create -join "") -match "command completed") {
            # Enable UDP acceleration (preferred)
            & $vpncmd localhost /CLIENT /CMD AccountDetailSet $name /UDPEnabled:yes 2>$null | Out-Null
            # Test connect
            & $vpncmd localhost /CLIENT /CMD AccountConnect $name 2>&1 | Out-Null
            Start-Sleep -Seconds 5
            $status = & $vpncmd localhost /CLIENT /CMD AccountStatusGet $name 2>&1
            if ($status -match "Connection.*Established" -or $status -match "Connected") {
                Write-Host "  [OK] Connected: $name on port $port (UDP preferred)" -ForegroundColor Green
                & $vpncmd localhost /CLIENT /CMD AccountDisconnect $name 2>$null | Out-Null
                return $true
            } else {
                & $vpncmd localhost /CLIENT /CMD AccountDisconnect $name 2>$null | Out-Null
                Write-Host "  [TRY] $name port $port created but no connect. Next port..." -ForegroundColor DarkYellow
            }
        }
    }
    return $false
}

Write-Host "`n[INFO] Importing into SoftEther VPN Client (trying UDP/TCP on ports 443, 992, 5555)..." -ForegroundColor Cyan
$imported = 0
foreach ($relay in $topRelays) {
    if (Import-RelayWithPorts -relay $relay) {
        $imported++
    } else {
        Write-Host "  [FAIL] All ports failed for $($relay.SettingName)" -ForegroundColor Red
    }
}

Write-Host "`n[SUCCESS] Imported $imported/$($topRelays.Count) relays with working ports." -ForegroundColor Green
Write-Host "[NEXT] Open SoftEther Client Manager and double-click a relay to connect."
Write-Host "[VERIFY] After connecting, visit: https://checkip.amazonaws.com"
