# VoidWalkers // VPN Watchdog — Auto-reconnect + Relay Failover
# Run as Administrator via Task Scheduler or manually while toolchain is active.

# ─── CONFIG LOADER ───
$ConfigPath = Join-Path $PSScriptRoot "vw_deck.config.json"
$VpnConfig = @{}
if (Test-Path $ConfigPath) {
    try {
        $raw = Get-Content $ConfigPath -Raw -Encoding UTF8
        $cfg = $raw | ConvertFrom-Json
        if ($cfg.vpn) { $VpnConfig = $cfg.vpn }
    } catch { Write-Host "[CONFIG] Warning: could not parse vw_deck.config.json" -ForegroundColor Yellow }
}
$clientPath = if ($VpnConfig.client_path) { $VpnConfig.client_path } else { $null }
$nicName    = if ($VpnConfig.nic_name) { $VpnConfig.nic_name } else { "VPN" }
$provider   = if ($VpnConfig.provider) { $VpnConfig.provider } else { "vpngate" }
$acctPrefix = if ($VpnConfig.account_prefix) { $VpnConfig.account_prefix } else { "VW_" }

$vpncmd = $clientPath
if (-not $vpncmd -or -not (Test-Path $vpncmd)) { $vpncmd = "C:\Program Files\SoftEther VPN Client\vpncmd.exe" }
if (-not (Test-Path $vpncmd)) { $vpncmd = "C:\Program Files (x86)\SoftEther VPN Client\vpncmd.exe" }
if (-not (Test-Path $vpncmd)) {
    Write-Error "[FATAL] vpncmd.exe not found. Aborting."
    exit 1
}

$LOG = "$PSScriptRoot\logs\vpn_watchdog.log"
function Log($msg) {
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts] $msg"
    Write-Host $line
    $dir = Split-Path -Parent $LOG
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    Add-Content -Path $LOG -Value $line
}

function Initialize-Nic {
    $nicList = & $vpncmd localhost /CLIENT /CMD NicList 2>&1
    $hasVpn = $nicList | Where-Object { $_ -match $nicName }
    if (-not $hasVpn) {
        Log "[NIC] Virtual NIC '$nicName' not found. Creating..."
        $out = & $vpncmd localhost /CLIENT /CMD NicCreate $nicName 2>&1
        Log "[NIC] NicCreate: $out"
    } else {
        Log "[NIC] Virtual NIC '$nicName' OK."
    }
}

function Get-VpnAccounts {
    $raw = & $vpncmd localhost /CLIENT /CMD AccountList 2>&1
    $accounts = @()
    $pattern = "(" + [regex]::Escape($acctPrefix) + "[A-Z]{2}_[\d\.]+)"
    foreach ($line in $raw) {
        if ($line -match $pattern) {
            $name = $matches[1].Trim()
            if ($name -notin $accounts) { $accounts += $name }
        }
    }
    return $accounts
}

function Get-ConnectedAccount {
    $raw = & $vpncmd localhost /CLIENT /CMD AccountList 2>&1
    foreach ($line in $raw) {
        if ($line -match "Connection\s+Established") {
            return $true
        }
    }
    return $false
}

function Get-VpnInterfaceName {
    $out = netsh interface show interface | Out-String
    foreach ($line in ($out -split "`r?`n")) {
        $l = $line.Trim()
        if ($l -match $nicName) {
            # netsh: AdminState  State  Type  InterfaceName
            $parts = [regex]::Split($l, "\s{2,}") | Where-Object { $_ }
            if ($parts.Length -ge 4) {
                $typeCol = $parts[2]
                $idx = $l.IndexOf($typeCol) + $typeCol.Length
                $name = $l.Substring($idx).Trim()
                if ($name) { return $name }
            }
        }
    }
    return $null
}

function Get-VpnAdapterIP {
    $cfg = ipconfig | Out-String
    $lines = $cfg -split "`r?`n"
    $inVpn = $false
    foreach ($line in $lines) {
        if ($line -match $nicName) { $inVpn = $true }
        if ($inVpn -and $line -match "IPv4.*:\s+(\d+\.\d+\.\d+\.\d+)") {
            $ip = $matches[1]
            if ($ip -notmatch "^169\.254") { return $ip }
        }
        if ($inVpn -and $line -match "^\s*$") { $inVpn = $false }
    }
    return $null
}

function Update-VpnAdapterIP {
    $iface = Get-VpnInterfaceName
    if ($iface) {
        netsh interface ip set address name="$iface" source=dhcp | Out-Null
        netsh interface ip set dns name="$iface" source=dhcp | Out-Null
        netsh interface ip set address name="$iface" source=dhcp | Out-Null
        netsh interface ip set dns name="$iface" source=dhcp | Out-Null
    } else {
        ipconfig /release "*VPN*" | Out-Null
        Start-Sleep -Seconds 1
        ipconfig /renew "*VPN*" | Out-Null
        Start-Sleep -Seconds 3
    }
}

function Reset-VpnAdapter {
    $iface = Get-VpnInterfaceName
    if ($iface) {
        Log "[ADAPTER] Hard reset: disabling '$iface'..."
        netsh interface set interface name="$iface" admin=disabled | Out-Null
        Start-Sleep -Seconds 2
        Log "[ADAPTER] Re-enabling '$iface'..."
        netsh interface set interface name="$iface" admin=enabled | Out-Null
        Start-Sleep -Seconds 3
        netsh interface ip set address name="$iface" source=dhcp | Out-Null
        netsh interface ip set dns name="$iface" source=dhcp | Out-Null
    } else {
        ipconfig /release "*VPN*" | Out-Null
        Start-Sleep -Seconds 1
        ipconfig /renew "*VPN*" | Out-Null
        Start-Sleep -Seconds 3
    }
}

function Connect-BestRelay {
    param([string[]]$Accounts)
    foreach ($acct in $Accounts) {
        Log "[TRY] Connecting $acct ..."
        & $vpncmd localhost /CLIENT /CMD AccountDisconnect $acct 2>$null | Out-Null
        Start-Sleep -Seconds 1
        $res = & $vpncmd localhost /CLIENT /CMD AccountConnect $acct 2>&1
        if ($res -match "error|failed") {
            Log "[DETAIL] $acct connect output: $res"
        }
        # Wait for SoftEther handshake + Windows DHCP (up to 30s)
        $adapterIP = $null
        for ($i = 0; $i -lt 15; $i++) {
            Start-Sleep -Seconds 2
            $adapterIP = Get-VpnAdapterIP
            if ($adapterIP) { break }
        }
        if (-not $adapterIP) {
            Log "[DHCP] No adapter IP for $acct, hard resetting adapter..."
            Reset-VpnAdapter
            $adapterIP = Get-VpnAdapterIP
        }
        if ($adapterIP) {
            try {
                $exitIP = (Invoke-RestMethod -Uri "https://checkip.amazonaws.com" -TimeoutSec 5).Trim()
            } catch { $exitIP = "unknown" }
            Log "[OK] Connected: $acct — adapter IP: $adapterIP, exit IP: $exitIP"
            return $acct
        } else {
            Log "[FAIL] $acct tunnel up but no adapter IP. Disconnecting..."
            & $vpncmd localhost /CLIENT /CMD AccountDisconnect $acct 2>$null | Out-Null
        }
    }
    return $null
}

function Import-VpnRelays {
    Initialize-Nic
    if ($provider -eq "custom") {
        $customRelays = $VpnConfig.providers.custom.relays
        if (-not $customRelays) { Log "[WARN] No custom relays configured."; return @() }
        $names = @()
        foreach ($r in $customRelays) {
            $name = $r.name
            & $vpncmd localhost /CLIENT /CMD AccountDelete $name 2>$null | Out-Null
            $port = if ($r.port) { $r.port } else { 443 }
            $hub = if ($r.hub) { $r.hub } else { "DEFAULT" }
            $user = if ($r.username) { $r.username } else { "user" }
            $out = & $vpncmd localhost /CLIENT /CMD AccountCreate $name /SERVER:$($r.host):$port /HUB:$hub /USERNAME:$user /NICNAME:$nicName 2>&1
            if ($out -join "" -match "completed|ok") {
                & $vpncmd localhost /CLIENT /CMD AccountDetailSet $name /UDPEnabled:yes 2>$null | Out-Null
                $names += $name
            } else {
                Log "[WARN] Failed to create custom account $name"
            }
        }
        Log "[FETCH] Loaded $($names.Count) custom relays."
        return $names
    }
    $vpg = $VpnConfig.providers.vpngate
    $filt = if ($vpg.filters) { $vpg.filters } else { @{ countries=@("JP","KR"); min_score=200000; min_speed=1500000; min_uptime=1800 } }
    $portsCfg = if ($vpg.ports) { $vpg.ports } else { @(443,992,5555) }
    $hubDefault = if ($vpg.hub_default) { $vpg.hub_default } else { "VPNGATE" }
    $username = if ($vpg.username) { $vpg.username } else { "anonymous" }
    $apiUrl = if ($vpg.api_url) { $vpg.api_url } else { "https://www.vpngate.net/api/iphone/" }
    Log "[FETCH] Pulling fresh relays from $provider..."
    try {
        $response = Invoke-RestMethod -Uri $apiUrl -Method Get -TimeoutSec 20
        $lines = $response -split "`n"
        $relays = @()
        foreach ($line in $lines[2..($lines.Length - 3)]) {
            $cols = $line -split ","
            if ($cols.Length -lt 15) { continue }
            $country = $cols[6]
            $score = [long]$cols[2]
            $speed = [long]$cols[4]
            $uptime = [long]$cols[8]
            $hostname = $cols[0]
            $ip = $cols[1]
            $hub = if ($cols[13] -and $cols[13] -ne "*") { $cols[13] } else { $hubDefault }
            if ($country -in $filt.countries -and $score -gt $filt.min_score -and $speed -gt $filt.min_speed -and $uptime -gt $filt.min_uptime) {
                $relays += [PSCustomObject]@{
                    Name = "$($acctPrefix)$($country)_$($ip)"
                    Host = if ($hostname -and $hostname -ne "*") { $hostname } else { $ip }
                    Hub = $hub
                    Score = $score
                }
            }
        }
        $top = $relays | Sort-Object Score -Descending | Select-Object -First 10
        foreach ($r in $top) {
            & $vpncmd localhost /CLIENT /CMD AccountDelete $r.Name 2>$null | Out-Null
            $created = $false
            foreach ($port in $portsCfg) {
                $out = & $vpncmd localhost /CLIENT /CMD AccountCreate $r.Name /SERVER:$($r.Host):$port /HUB:$($r.Hub) /USERNAME:$username /NICNAME:$nicName 2>&1
                if ($out -join "" -match "completed|ok") {
                    & $vpncmd localhost /CLIENT /CMD AccountDetailSet $r.Name /UDPEnabled:yes 2>$null | Out-Null
                    $created = $true
                    break
                }
                & $vpncmd localhost /CLIENT /CMD AccountDelete $r.Name 2>$null | Out-Null
            }
            if (-not $created) {
                Log "[WARN] Failed to create $($r.Name) on any port"
            }
        }
        Log "[FETCH] Imported $($top.Count) fresh relays."
        return $top | ForEach-Object { $_.Name }
    } catch {
        Log "[ERROR] Fetch failed: $_"
        return @()
    }
}

# ─── Main Loop ───
Log "[INIT] VoidWalkers VPN Watchdog started."
Initialize-Nic
$accounts = Get-VpnAccounts
if ($accounts.Count -eq 0) {
    Log "[WARN] No $($acctPrefix) accounts found. Fetching fresh relays..."
    $accounts = Import-VpnRelays
}

$failures = 0
$maxFailures = 3

while ($true) {
    $connected = Get-ConnectedAccount
    if (-not $connected) {
        $failures++
        Log "[WARN] VPN disconnected (failure $failures/$maxFailures)."
        if ($failures -ge $maxFailures) {
            Log "[FAILOVER] Exhausted known relays. Fetching new ones..."
            $accounts = Import-VpnRelays
            $failures = 0
        }
        $winner = Connect-BestRelay -Accounts $accounts
        if (-not $winner) {
            Log "[CRITICAL] All relays failed. Waiting 60s before retry..."
            Start-Sleep -Seconds 60
            continue
        }
    } else {
        if ($failures -gt 0) {
            Log "[RECOVER] VPN tunnel restored."
            $failures = 0
        }
    }
    Start-Sleep -Seconds 30
}
