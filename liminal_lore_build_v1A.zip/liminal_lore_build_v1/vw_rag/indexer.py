"""Indexer for the RAG engine.

Uses SQLite FTS5 for full-text keyword search (BM25 ranking) and
optionally sqlite-vec for vector similarity search. The index is
stored as a single .db file in the project's tools/vw_rag/ directory.
"""

from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .chunker import chunk_file
from .embedder import Embedder
from .models import Chunk, IndexStats, now_iso


_SCHEMA = """
CREATE TABLE IF NOT EXISTS chunks (
    chunk_id TEXT PRIMARY KEY,
    file_path TEXT NOT NULL,
    relative_path TEXT NOT NULL,
    position INTEGER DEFAULT 0,
    text TEXT NOT NULL,
    token_count INTEGER DEFAULT 0,
    tags TEXT DEFAULT '[]',
    modified TEXT DEFAULT '',
    file_size INTEGER DEFAULT 0,
    indexed_at TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS files (
    relative_path TEXT PRIMARY KEY,
    file_path TEXT NOT NULL,
    chunk_count INTEGER DEFAULT 0,
    modified TEXT DEFAULT '',
    indexed_at TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS index_meta (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
    chunk_id UNINDEXED,
    relative_path,
    text,
    tags,
    tokenize = 'porter unicode61'
);
"""

_VECTOR_SCHEMA = """
CREATE TABLE IF NOT EXISTS chunk_vectors (
    chunk_id TEXT PRIMARY KEY,
    embedding TEXT NOT NULL,
    model TEXT NOT NULL
);
"""


class Indexer:
    """Manages the SQLite FTS5 + optional vector index."""

    def __init__(self, db_path: Path, study_root: Path, embedder: Optional[Embedder] = None):
        self.db_path = db_path
        self.study_root = study_root
        self.embedder = embedder or Embedder()
        self._lock = threading.RLock()
        self._conn: Optional[sqlite3.Connection] = None
        self._init_db()

    def _init_db(self) -> None:
        with self._lock:
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
            # WAL mode for much faster writes
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._conn.execute("PRAGMA cache_size=-64000")  # 64MB cache
            self._conn.executescript(_SCHEMA)
            if self.embedder.available:
                try:
                    self._conn.executescript(_VECTOR_SCHEMA)
                except Exception:
                    pass
            self._conn.commit()

    def index_directory(self, force: bool = False) -> IndexStats:
        """Index all supported files in the study directory."""
        extensions = {".md", ".txt", ".json", ".py", ".cpp", ".h", ".hpp", ".c",
                      ".js", ".ts", ".ps1", ".bat", ".java", ".cs", ".yaml", ".yml"}
        files = [
            f for f in self.study_root.rglob("*")
            if f.is_file() and f.suffix.lower() in extensions
        ]

        total_chunks = 0
        indexed_files = 0

        with self._lock:
            for f in files:
                relative = str(f.relative_to(self.study_root)).replace("\\", "/")
                if not force and self._is_fresh(relative, f):
                    continue

                self._remove_file_chunks(relative)
                chunks = chunk_file(f, self.study_root)
                if not chunks:
                    continue

                self._store_chunks_batch(chunks)
                self._store_file_record(relative, str(f), len(chunks), f)
                indexed_files += 1
                total_chunks += len(chunks)
                # Commit per-file to avoid massive transaction
                self._conn.commit()

            self._set_meta("index_version", now_iso())
            self._set_meta("index_time", now_iso())
            self._set_meta("has_embeddings", str(self.embedder.available))
            self._set_meta("embedding_model", self.embedder.model_name if self.embedder.available else "none")
            self._conn.commit()

        return self.get_stats()

    def _is_fresh(self, relative: str, file_path: Path) -> bool:
        """Check if a file's chunks are already up-to-date."""
        try:
            row = self._conn.execute(
                "SELECT modified FROM files WHERE relative_path = ?", (relative,)
            ).fetchone()
            if not row:
                return False
            stored = row[0] or ""
            current = str(file_path.stat().st_mtime)
            return stored == current
        except Exception:
            return False

    def _store_chunk(self, chunk: Chunk) -> None:
        self._store_chunks_batch([chunk])

    def _store_chunks_batch(self, chunks: list) -> None:
        """Batch-insert chunks for better performance."""
        ts = now_iso()
        chunk_rows = []
        fts_rows = []
        vec_rows = []

        for chunk in chunks:
            chunk_rows.append((
                chunk.chunk_id, chunk.file_path, chunk.relative_path,
                chunk.position, chunk.text, chunk.token_count,
                json.dumps(chunk.tags), chunk.modified, chunk.file_size, ts,
            ))
            fts_rows.append((
                chunk.chunk_id, chunk.relative_path, chunk.text, " ".join(chunk.tags),
            ))
            if self.embedder.available:
                embedding = self.embedder.embed(chunk.text)
                if embedding:
                    vec_rows.append((
                        chunk.chunk_id, json.dumps(embedding), self.embedder.model_name,
                    ))
                    chunk.embedding = embedding

        self._conn.executemany(
            """INSERT OR REPLACE INTO chunks
               (chunk_id, file_path, relative_path, position, text, token_count, tags, modified, file_size, indexed_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            chunk_rows,
        )
        self._conn.executemany(
            """INSERT OR REPLACE INTO chunks_fts
               (chunk_id, relative_path, text, tags)
               VALUES (?, ?, ?, ?)""",
            fts_rows,
        )
        if vec_rows:
            self._conn.executemany(
                """INSERT OR REPLACE INTO chunk_vectors
                   (chunk_id, embedding, model) VALUES (?, ?, ?)""",
                vec_rows,
            )

    def _store_file_record(self, relative: str, full_path: str, chunk_count: int, file_path: Path) -> None:
        try:
            modified = str(file_path.stat().st_mtime)
        except Exception:
            modified = ""
        self._conn.execute(
            """INSERT OR REPLACE INTO files
               (relative_path, file_path, chunk_count, modified, indexed_at)
               VALUES (?, ?, ?, ?, ?)""",
            (relative, full_path, chunk_count, modified, now_iso()),
        )

    def _remove_file_chunks(self, relative: str) -> None:
        chunk_ids = self._conn.execute(
            "SELECT chunk_id FROM chunks WHERE relative_path = ?", (relative,)
        ).fetchall()
        for (chunk_id,) in chunk_ids:
            self._conn.execute("DELETE FROM chunks WHERE chunk_id = ?", (chunk_id,))
            self._conn.execute("DELETE FROM chunks_fts WHERE chunk_id = ?", (chunk_id,))
            if self.embedder.available:
                self._conn.execute("DELETE FROM chunk_vectors WHERE chunk_id = ?", (chunk_id,))

    def _set_meta(self, key: str, value: str) -> None:
        self._conn.execute(
            "INSERT OR REPLACE INTO index_meta (key, value) VALUES (?, ?)",
            (key, value),
        )

    def get_meta(self, key: str) -> Optional[str]:
        row = self._conn.execute(
            "SELECT value FROM index_meta WHERE key = ?", (key,)
        ).fetchone()
        return row[0] if row else None

    def get_stats(self) -> IndexStats:
        total_chunks = self._conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
        total_files = self._conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
        has_emb = self.get_meta("has_embeddings") == "True"
        emb_model = self.get_meta("embedding_model") or "none"

        file_types: Dict[str, int] = {}
        rows = self._conn.execute(
            "SELECT relative_path FROM files"
        ).fetchall()
        for (rel,) in rows:
            ext = Path(rel).suffix.lower().lstrip(".") or "unknown"
            file_types[ext] = file_types.get(ext, 0) + 1

        return IndexStats(
            total_chunks=total_chunks,
            total_files=total_files,
            index_version=self.get_meta("index_version") or "",
            index_time=self.get_meta("index_time") or "",
            db_path=str(self.db_path),
            has_embeddings=has_emb,
            embedding_model=emb_model,
            file_types=file_types,
        )

    def search_fts(self, query: str, limit: int = 20) -> List[tuple]:
        """BM25 keyword search via FTS5. Returns (chunk_id, bm25_score) tuples."""
        escaped = _escape_fts_query(query)
        if not escaped:
            return []
        sql = """
            SELECT chunks_fts.chunk_id, bm25(chunks_fts) as score
            FROM chunks_fts
            WHERE chunks_fts MATCH ?
            ORDER BY score
            LIMIT ?
        """
        try:
            return self._conn.execute(sql, (escaped, limit)).fetchall()
        except Exception:
            return []

    def get_chunk(self, chunk_id: str) -> Optional[Chunk]:
        row = self._conn.execute(
            """SELECT chunk_id, file_path, relative_path, position, text,
                      token_count, tags, modified, file_size
               FROM chunks WHERE chunk_id = ?""",
            (chunk_id,),
        ).fetchone()
        if not row:
            return None
        return Chunk(
            chunk_id=row[0], file_path=row[1], relative_path=row[2],
            position=row[3], text=row[4], token_count=row[5],
            tags=json.loads(row[6]) if row[6] else [],
            modified=row[7], file_size=row[8],
        )

    def get_vector(self, chunk_id: str) -> Optional[List[float]]:
        if not self.embedder.available:
            return None
        row = self._conn.execute(
            "SELECT embedding FROM chunk_vectors WHERE chunk_id = ?", (chunk_id,)
        ).fetchone()
        if not row:
            return None
        try:
            return json.loads(row[0])
        except Exception:
            return None

    def search_vector(self, query_vec: List[float], limit: int = 20) -> List[tuple]:
        """Cosine similarity search over stored vectors. Returns (chunk_id, score) tuples."""
        if not self.embedder.available:
            return []
        rows = self._conn.execute(
            "SELECT chunk_id, embedding FROM chunk_vectors"
        ).fetchall()
        scored = []
        for chunk_id, emb_json in rows:
            try:
                vec = json.loads(emb_json)
                score = _cosine_similarity(query_vec, vec)
                scored.append((chunk_id, score))
            except Exception:
                continue
        scored.sort(key=lambda x: -x[1])
        return scored[:limit]

    def close(self) -> None:
        with self._lock:
            if self._conn:
                self._conn.close()
                self._conn = None


def _escape_fts_query(query: str) -> str:
    """Escape a query for FTS5 MATCH."""
    # Split into terms and quote each one
    terms = query.strip().split()
    if not terms:
        return ""
    escaped = []
    for term in terms:
        clean = term.strip('"').strip()
        if clean:
            escaped.append(f'"{clean}"')
    return " AND ".join(escaped)


def _cosine_similarity(a: List[float], b: List[float]) -> float:
    """Compute cosine similarity between two vectors."""
    if len(a) != len(b) or not a:
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    mag_a = sum(x * x for x in a) ** 0.5
    mag_b = sum(y * y for y in b) ** 0.5
    if mag_a == 0 or mag_b == 0:
        return 0.0
    return dot / (mag_a * mag_b)
