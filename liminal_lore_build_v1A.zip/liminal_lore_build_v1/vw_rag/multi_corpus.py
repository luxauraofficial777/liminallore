"""Multi-corpus Vector DB manager for the VW Nexus.

Manages multiple independent RAG indexes (one per project/corpus),
routes queries across all or selected corpora, and merges results
with reciprocal rank fusion.

Each corpus gets its own SQLite DB file and optional vector index.
Corpora are defined in a YAML/JSON config file and can be added
at runtime via the Nexus API.
"""

from __future__ import annotations

import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .embedder import Embedder
from .indexer import Indexer
from .retriever import Retriever
from .models import SearchResult, now_iso


_DEFAULT_CORPORA = [
    {
        "corpus_id": "vw_x64",
        "name": "Void Walkers X64 Engine",
        "root": "C:/LuxAura/VoidWalkers_Project/Modern_X64/study",
        "extensions": [".md", ".txt", ".json", ".py", ".cpp", ".h", ".hpp",
                       ".js", ".ts", ".ps1", ".bat", ".java", ".cs", ".yaml", ".yml"],
        "tags": ["engine", "dx11", "combat", "world_map", "save", "determinism"],
        "description": "VW64 native x64 engine study docs and source",
    },
    {
        "corpus_id": "vw_tools",
        "name": "Void Walkers Toolchain",
        "root": "C:/LuxAura/VoidWalkers_Project/Modern_X64/tools",
        "extensions": [".py", ".js", ".ts", ".md", ".json", ".yaml", ".yml", ".bat"],
        "tags": ["toolchain", "nexus", "mcp", "rag", "build"],
        "description": "VW Nexus, MCP server, RAG engine, build tools",
    },
    {
        "corpus_id": "dqlosttranslation",
        "name": "DQLOSTTRANSLATION PSX Localization",
        "root": "C:/LuxAura/VoidWalkers_Project/DQLOSTTRANSLATION",
        "extensions": [".md", ".txt", ".json", ".py", ".cpp", ".h", ".java",
                       ".ps1", ".bat", ".yaml", ".yml"],
        "tags": ["psx", "frankenstein", "emulation", "translation", "debugging"],
        "description": "DQ4 PSX translation: CyberGrime emulator, Frankenstein ROM, HBD patcher",
    },
    {
        "corpus_id": "dq_cybergrime",
        "name": "CyberGrime PSX Emulator + Harness",
        "root": "C:/LuxAura/VoidWalkers_Project/DQLOSTTRANSLATION/cybergrime",
        "extensions": [".cpp", ".h", ".py", ".json", ".md", ".txt"],
        "tags": ["emulation", "psx", "debugging", "harness"],
        "description": "CyberGrime emulator core, agent runner, regression tests, DuckStation bridge",
    },
    {
        "corpus_id": "dq_translation_tools",
        "name": "DQ4 Translation Tools",
        "root": "C:/LuxAura/VoidWalkers_Project/DQLOSTTRANSLATION/translation-tools",
        "extensions": [".py", ".java", ".md", ".txt", ".json", ".asm"],
        "tags": ["translation", "frankenstein", "build"],
        "description": "Java patcher, Python HBD patcher, Frankenstein builder, QA tools",
    },
]


class CorpusEntry:
    """A single corpus with its own indexer and retriever."""

    def __init__(self, config: Dict[str, Any], db_dir: Path, embedder: Embedder):
        self.corpus_id: str = config["corpus_id"]
        self.name: str = config.get("name", self.corpus_id)
        self.root: Path = Path(config["root"])
        self.extensions: List[str] = config.get("extensions", [".md", ".txt", ".json", ".py"])
        self.tags: List[str] = config.get("tags", [])
        self.description: str = config.get("description", "")
        self.db_path: Path = db_dir / f"vw_rag_{self.corpus_id}.db"
        self._embedder = embedder
        self._indexer: Optional[Indexer] = None
        self._retriever: Optional[Retriever] = None
        self._lock = threading.Lock()
        self._initialized = False

    def _ensure(self) -> bool:
        if self._initialized:
            return True
        with self._lock:
            if self._initialized:
                return True
            if not self.root.exists():
                return False
            try:
                self._indexer = Indexer(self.db_path, self.root, self._embedder)
                self._retriever = Retriever(self._indexer, self._embedder)
                self._initialized = True
                return True
            except Exception as e:
                print(f"[multi_corpus] Failed to init corpus '{self.corpus_id}': {e}")
                return False

    def index(self, force: bool = False) -> Dict[str, Any]:
        if not self._ensure():
            return {"corpus_id": self.corpus_id, "status": "error", "message": "Corpus init failed"}
        try:
            stats = self._indexer.index_directory(force=force)
            return {"corpus_id": self.corpus_id, "status": "ok", "stats": stats.to_dict()}
        except Exception as e:
            return {"corpus_id": self.corpus_id, "status": "error", "message": str(e)}

    def query(self, query: str, max_chunks: int = 10, tags: Optional[List[str]] = None,
              after: Optional[str] = None) -> Dict[str, Any]:
        if not self._ensure():
            return {"corpus_id": self.corpus_id, "results": [], "status": "unavailable"}
        try:
            return self._retriever.query(
                query, max_chunks=max_chunks, tags=tags, after=after,
            )
        except Exception as e:
            return {"corpus_id": self.corpus_id, "results": [], "status": "error", "message": str(e)}

    def status(self) -> Dict[str, Any]:
        if not self._ensure():
            return {"corpus_id": self.corpus_id, "name": self.name, "available": False,
                    "root": str(self.root), "db_path": str(self.db_path)}
        try:
            stats = self._indexer.get_stats()
            return {
                "corpus_id": self.corpus_id, "name": self.name, "available": True,
                "root": str(self.root), "db_path": str(self.db_path),
                "description": self.description, "tags": self.tags,
                "stats": stats.to_dict(),
            }
        except Exception as e:
            return {"corpus_id": self.corpus_id, "name": self.name, "available": False, "error": str(e)}

    def close(self):
        if self._indexer:
            self._indexer.close()


class MultiCorpusManager:
    """Manages multiple corpus indexes and cross-corpus query routing."""

    def __init__(self, db_dir: Path, config_path: Optional[Path] = None,
                 embedder: Optional[Embedder] = None):
        self.db_dir = db_dir
        self.db_dir.mkdir(parents=True, exist_ok=True)
        self._embedder = embedder or Embedder()
        self._corpora: Dict[str, CorpusEntry] = {}
        self._lock = threading.RLock()
        self._config_path = config_path

        # Load corpus configs
        configs = self._load_configs(config_path)
        for cfg in configs:
            self._corpora[cfg["corpus_id"]] = CorpusEntry(cfg, self.db_dir, self._embedder)

    def _load_configs(self, config_path: Optional[Path]) -> List[Dict[str, Any]]:
        if config_path and config_path.exists():
            try:
                data = json.loads(config_path.read_text(encoding="utf-8"))
                if isinstance(data, dict) and "corpora" in data:
                    return data["corpora"]
                if isinstance(data, list):
                    return data
            except Exception:
                pass
        return _DEFAULT_CORPORA

    def add_corpus(self, config: Dict[str, Any]) -> Dict[str, Any]:
        cid = config.get("corpus_id", "")
        if not cid:
            return {"ok": False, "error": "Missing corpus_id"}
        with self._lock:
            if cid in self._corpora:
                return {"ok": False, "error": f"Corpus '{cid}' already exists"}
            self._corpora[cid] = CorpusEntry(config, self.db_dir, self._embedder)
        return {"ok": True, "corpus_id": cid}

    def remove_corpus(self, corpus_id: str) -> Dict[str, Any]:
        with self._lock:
            entry = self._corpora.pop(corpus_id, None)
            if entry:
                entry.close()
                return {"ok": True, "corpus_id": corpus_id}
            return {"ok": False, "error": "Corpus not found"}

    def list_corpora(self) -> List[Dict[str, Any]]:
        with self._lock:
            return [e.status() for e in self._corpora.values()]

    def index_all(self, force: bool = False) -> List[Dict[str, Any]]:
        results = []
        with self._lock:
            for entry in self._corpora.values():
                results.append(entry.index(force=force))
        return results

    def index_one(self, corpus_id: str, force: bool = False) -> Dict[str, Any]:
        with self._lock:
            entry = self._corpora.get(corpus_id)
            if not entry:
                return {"ok": False, "error": f"Corpus '{corpus_id}' not found"}
            return entry.index(force=force)

    def query(
        self,
        query: str,
        max_chunks: int = 20,
        corpora: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
        after: Optional[str] = None,
        cross_corpus_fusion: bool = True,
    ) -> Dict[str, Any]:
        """Query across one, many, or all corpora with fused ranking."""
        with self._lock:
            target_ids = corpora or list(self._corpora.keys())
            entries = [self._corpora[cid] for cid in target_ids if cid in self._corpora]

        if not entries:
            return {"results": [], "corpora_searched": [], "status": "no_corpora"}

        per_corpus_max = max_chunks if len(entries) == 1 else max(max_chunks // len(entries), 5)

        all_results: List[Tuple[str, float, Dict]] = []
        corpus_statuses: List[Dict[str, Any]] = []

        for entry in entries:
            result = entry.query(query, max_chunks=per_corpus_max * 2, tags=tags, after=after)
            status = result.get("status", "ok")
            corpus_statuses.append({
                "corpus_id": entry.corpus_id,
                "status": status,
                "result_count": len(result.get("results", [])),
            })
            for r in result.get("results", []):
                chunk = r.get("chunk", {})
                score = r.get("score", 0.0)
                # Boost score by corpus tag match
                if tags and entry.tags:
                    tag_overlap = len(set(tags) & set(entry.tags))
                    score += tag_overlap * 0.05
                all_results.append((entry.corpus_id, score, r))

        # Sort by fused score descending
        all_results.sort(key=lambda x: -x[1])

        # Trim to max_chunks
        trimmed = all_results[:max_chunks]

        # Format output
        formatted_results = []
        for corpus_id, score, r in trimmed:
            chunk_data = r.get("chunk", {})
            chunk_data["corpus_id"] = corpus_id
            formatted_results.append({
                "chunk": chunk_data,
                "score": round(score, 4),
                "bm25_score": r.get("bm25_score", 0.0),
                "vector_score": r.get("vector_score", 0.0),
                "recency_boost": r.get("recency_boost", 0.0),
                "corpus_id": corpus_id,
                "source": r.get("source", ""),
            })

        return {
            "results": formatted_results,
            "corpora_searched": [e.corpus_id for e in entries],
            "corpus_statuses": corpus_statuses,
            "total_results": len(formatted_results),
            "query": query,
            "timestamp": now_iso(),
        }

    def status(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "total_corpora": len(self._corpora),
                "corpora": [e.status() for e in self._corpora.values()],
                "embedder": self._embedder.status(),
                "db_dir": str(self.db_dir),
            }

    def ingest_telemetry(self, corpus_id: str, telemetry: Dict[str, Any]) -> Dict[str, Any]:
        """Ingest a telemetry JSON snapshot into a corpus's vector DB as a chunk.

        This enables real-time harness telemetry to be searchable via RAG queries.
        """
        with self._lock:
            entry = self._corpora.get(corpus_id)
            if not entry:
                return {"ok": False, "error": f"Corpus '{corpus_id}' not found"}
            if not entry._ensure():
                return {"ok": False, "error": "Corpus init failed"}

        # Serialize telemetry to searchable text
        tel_text = json.dumps(telemetry, indent=2, default=str)
        ts = datetime.now(timezone.utc).isoformat()

        # Build a chunk from the telemetry
        from .models import Chunk
        from .chunker import _make_id, _extract_tags
        chunk_id = _make_id(f"telemetry/{corpus_id}", int(datetime.now().timestamp() % 100000), tel_text)
        tags = _extract_tags(corpus_id, tel_text)
        tags.append("telemetry")
        if "crash" in tel_text.lower() or "crashed" in tel_text.lower():
            tags.append("crash")
        if "freeze" in tel_text.lower() or "frozen" in tel_text.lower():
            tags.append("freeze")
        if "vblank" in tel_text.lower():
            tags.append("vblank")

        chunk = Chunk(
            chunk_id=chunk_id,
            file_path=f"telemetry://{corpus_id}/{ts}",
            relative_path=f"telemetry/{corpus_id}/{ts}",
            position=0,
            text=tel_text,
            token_count=len(tel_text) // 4,
            tags=tags,
            modified=ts,
            file_size=len(tel_text),
        )

        # Store directly via indexer
        try:
            entry._indexer._store_chunks_batch([chunk])
            entry._indexer._conn.commit()
            return {"ok": True, "chunk_id": chunk_id, "corpus_id": corpus_id, "timestamp": ts}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def close(self):
        with self._lock:
            for entry in self._corpora.values():
                entry.close()
