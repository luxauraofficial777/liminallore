"""CLI entry point for the VW RAG engine.

Usage:
    python -m vw_rag index [--force]         # Build/rebuild the index
    python -m vw_rag query "search terms"    # Query the index
    python -m vw_rag status                  # Show index statistics
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .embedder import Embedder
from .indexer import Indexer
from .retriever import Retriever


def _get_default_db() -> Path:
    return Path(__file__).parent / "vw_rag_index.db"


def _get_study_root() -> Path:
    return Path(__file__).parent.parent.parent / "study"


def main():
    parser = argparse.ArgumentParser(description="VW RAG — Semantic retrieval for /study")
    sub = parser.add_subparsers(dest="command")

    p_index = sub.add_parser("index", help="Build or update the index")
    p_index.add_argument("--force", action="store_true", help="Force full re-index")
    p_index.add_argument("--db", type=Path, default=None, help="Database path")

    p_query = sub.add_parser("query", help="Query the index")
    p_query.add_argument("text", type=str, help="Search query")
    p_query.add_argument("--max", type=int, default=20, help="Max results")
    p_query.add_argument("--tags", type=str, nargs="*", default=None)
    p_query.add_argument("--after", type=str, default=None, help="ISO date filter")
    p_query.add_argument("--db", type=Path, default=None, help="Database path")

    sub.add_parser("status", help="Show index statistics")

    args = parser.parse_args()
    db_path = getattr(args, "db", None) or _get_default_db()
    study_root = _get_study_root()

    if args.command == "index":
        embedder = Embedder()
        indexer = Indexer(db_path, study_root, embedder)
        print(f"Indexing {study_root} ...")
        if embedder.available:
            print(f"Embedding model: {embedder.model_name} (dim={embedder.dimension})")
        else:
            print("No embedding model available — keyword-only (BM25) mode")
        stats = indexer.index_directory(force=args.force)
        print(json.dumps(stats.to_dict(), indent=2))
        indexer.close()

    elif args.command == "query":
        embedder = Embedder()
        indexer = Indexer(db_path, study_root, embedder)
        retriever = Retriever(indexer, embedder)
        result = retriever.query(
            args.text,
            max_chunks=args.max,
            tags=args.tags,
            after=args.after,
        )
        print(json.dumps(result, indent=2, default=str))
        indexer.close()

    elif args.command == "status":
        embedder = Embedder()
        indexer = Indexer(db_path, study_root, embedder)
        stats = indexer.get_stats()
        print(json.dumps(stats.to_dict(), indent=2))
        indexer.close()

    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
