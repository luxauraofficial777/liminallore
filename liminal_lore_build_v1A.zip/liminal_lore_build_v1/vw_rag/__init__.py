"""VW RAG — Semantic retrieval engine for the /study corpus.

Provides hybrid BM25 + optional vector similarity search over the
900+ file Void Walkers study directory. Works with zero external
dependencies (pure SQLite FTS5) and upgrades gracefully when
sentence-transformers and sqlite-vec are installed.
"""

__version__ = "0.1.0"
