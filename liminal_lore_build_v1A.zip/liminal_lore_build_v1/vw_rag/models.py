"""Data models for the RAG engine."""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


@dataclass
class Chunk:
    """A semantic chunk of a document."""
    chunk_id: str = ""
    file_path: str = ""
    relative_path: str = ""
    position: int = 0
    text: str = ""
    token_count: int = 0
    tags: List[str] = field(default_factory=list)
    modified: str = ""
    file_size: int = 0
    embedding: Optional[List[float]] = field(default=None, repr=False)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d.pop("embedding", None)
        return d


@dataclass
class SearchResult:
    """A single retrieval result."""
    chunk: Chunk
    score: float = 0.0
    bm25_score: float = 0.0
    vector_score: float = 0.0
    recency_boost: float = 0.0
    source: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "chunk": self.chunk.to_dict(),
            "score": round(self.score, 4),
            "bm25_score": round(self.bm25_score, 4),
            "vector_score": round(self.vector_score, 4),
            "recency_boost": round(self.recency_boost, 4),
            "source": self.source,
        }


@dataclass
class IndexStats:
    """Statistics about the current index state."""
    total_chunks: int = 0
    total_files: int = 0
    index_version: str = ""
    index_time: str = ""
    db_path: str = ""
    has_embeddings: bool = False
    embedding_model: str = ""
    file_types: Dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
