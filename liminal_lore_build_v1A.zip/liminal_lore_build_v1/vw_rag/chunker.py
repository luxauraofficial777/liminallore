"""Document chunker for the RAG engine.

Splits .md, .txt, and .json files into semantic chunks of <=512 tokens
with 64-token overlap. Uses markdown header boundaries as natural split
points when possible.
"""

from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import List, Optional

from .models import Chunk


_MAX_CHUNK_CHARS = 2000  # ~500 tokens at ~4 chars/token
_OVERLAP_CHARS = 256     # ~64 tokens
_MIN_CHUNK_CHARS = 100   # Don't create tiny chunks


def chunk_file(file_path: Path, study_root: Path) -> List[Chunk]:
    """Read a file and split it into chunks."""
    try:
        text = file_path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return []

    if not text.strip():
        return []

    relative = str(file_path.relative_to(study_root)).replace("\\", "/")
    try:
        stat = file_path.stat()
        modified = ""
        file_size = stat.st_size
    except Exception:
        modified = ""
        file_size = 0

    suffix = file_path.suffix.lower()
    if suffix == ".md":
        chunks = _chunk_markdown(text)
    elif suffix == ".json":
        chunks = _chunk_json(text)
    elif suffix in (".py", ".cpp", ".h", ".hpp", ".c", ".js", ".ts", ".ps1", ".bat", ".java", ".cs"):
        chunks = _chunk_code(text, suffix)
    else:
        chunks = _chunk_plain(text)

    result = []
    for i, chunk_text in enumerate(chunks):
        if len(chunk_text.strip()) < _MIN_CHUNK_CHARS:
            continue
        chunk_id = _make_id(relative, i, chunk_text)
        tags = _extract_tags(relative, chunk_text)
        result.append(Chunk(
            chunk_id=chunk_id,
            file_path=str(file_path),
            relative_path=relative,
            position=i,
            text=chunk_text.strip(),
            token_count=len(chunk_text) // 4,
            tags=tags,
            modified=modified,
            file_size=file_size,
        ))
    return result


def _chunk_markdown(text: str) -> List[str]:
    """Split markdown by headers, then by size."""
    sections = re.split(r"(^#{1,6}\s+.+$)", text, flags=re.MULTILINE)
    chunks = []
    current = ""
    for part in sections:
        if re.match(r"^#{1,6}\s+.+$", part, re.MULTILINE):
            if current.strip():
                chunks.extend(_split_by_size(current))
            current = part
        else:
            current += part
    if current.strip():
        chunks.extend(_split_by_size(current))
    return chunks


def _chunk_json(text: str) -> List[str]:
    """For JSON, chunk by top-level keys if it's an object, else by size."""
    try:
        import json
        data = json.loads(text)
        if isinstance(data, dict):
            chunks = []
            for key, value in data.items():
                chunk_text = f'"{key}": {json.dumps(value, indent=2, ensure_ascii=False)}'
                chunks.extend(_split_by_size(chunk_text))
            return chunks if chunks else _chunk_plain(text)
    except Exception:
        pass
    return _chunk_plain(text)


def _chunk_plain(text: str) -> List[str]:
    """Split plain text by paragraphs, then by size."""
    paragraphs = re.split(r"\n\s*\n", text)
    chunks = []
    for para in paragraphs:
        chunks.extend(_split_by_size(para))
    return chunks


def _split_by_size(text: str) -> List[str]:
    """Split text into chunks of at most _MAX_CHUNK_CHARS with overlap."""
    text = text.strip()
    if len(text) <= _MAX_CHUNK_CHARS:
        return [text] if text else []

    chunks = []
    start = 0
    while start < len(text):
        end = start + _MAX_CHUNK_CHARS
        if end >= len(text):
            end = len(text)
        else:
            # Try to break at a sentence or newline boundary
            boundary = _find_boundary(text, start, end)
            if boundary > start + _MIN_CHUNK_CHARS:
                end = boundary
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end >= len(text):
            break
        # Ensure we always advance — never go backwards
        next_start = end - _OVERLAP_CHARS
        if next_start <= start:
            next_start = start + max(_MIN_CHUNK_CHARS, end - start)
        start = next_start
    return chunks


def _find_boundary(text: str, start: int, end: int) -> int:
    """Find a good split point near `end`."""
    # Look for newline first, then sentence end, then space
    for pattern in ["\n\n", "\n", ". ", "! ", "? ", "; ", ", ", " "]:
        pos = text.rfind(pattern, start + _MIN_CHUNK_CHARS, end)
        if pos > start + _MIN_CHUNK_CHARS:
            return pos + len(pattern)
    return end


def _make_id(relative: str, position: int, text: str) -> str:
    """Generate a stable chunk ID from path + position + content hash."""
    h = hashlib.md5(f"{relative}:{position}:{text[:100]}".encode()).hexdigest()[:12]
    return f"chunk_{h}"


_TAG_PATTERNS = {
    "combat": ["combat", "battle", "enemy", "damage", "attack", "vfx"],
    "dx11": ["dx11", "d3d11", "directx", "shader", "render", "pipeline"],
    "world_map": ["world_map", "worldmap", "map", "zone", "tile", "quad"],
    "npc": ["npc", "dialogue", "interaction", "shop", "vista"],
    "asset": ["asset", "atlas", "sprite", "texture", "sanitiz", "uua"],
    "audio": ["audio", "sfx", "music", "flac", "wav", "mci"],
    "quest": ["quest", "story", "narrative", "progression", "flag"],
    "save": ["save", "load", "voidsave", "crc", "checkpoint"],
    "build": ["build", "cmake", "compile", "linker", "msvc"],
    "toolchain": ["toolchain", "vwforge", "mcp", "nexus", "liminal", "agent"],
    "rigforge": ["rigforge", "rig", "bone", "skeleton", "animation"],
    "engine": ["engine", "iiris", "core", "loop", "tick", "state"],
    "memory": ["memory", "vram", "page", "alloc", "heap"],
    "ui": ["ui", "hud", "menu", "cybergrime", "interface"],
    "determinism": ["deterministic", "determinism", "rng", "lcg", "seed"],
    # DQLOSTTRANSLATION / PSX tags
    "psx": ["psx", "ps1", "playstation", "mips", "r3000a", "bios", "cdrom", "vblank"],
    "frankenstein": ["frankenstein", "hbd", "huffman", "dw7", "dq4", "exe", "bootstrap"],
    "emulation": ["emulator", "emulation", "duckstation", "cybergrime", "telemetry", "harness"],
    "translation": ["translation", "patcher", "text", "dialog", "shiftjis", "xdelta", "edc", "ecc"],
    "rag": ["rag", "vector", "embedding", "retrieval", "bm25", "corpus", "index"],
    "mcp": ["mcp", "model context protocol", "tool", "agent_id", "authority"],
    "nexus": ["nexus", "orchestrat", "committee", "governor", "provider", "websocket"],
    "debugging": ["debug", "crash", "freeze", "breakpoint", "watchpoint", "stall", "trace"],
}


def _chunk_code(text: str, suffix: str) -> List[str]:
    """Split source code by function/class/section boundaries."""
    # Common patterns for code section boundaries
    if suffix in (".py",):
        # Python: split on def/class decorators and top-level assignments
        sections = re.split(r'(?=^(?:def |class |async def |@|\S+\s*=\s*))', text, flags=re.MULTILINE)
    elif suffix in (".cpp", ".h", ".hpp", ".c", ".cs", ".java"):
        # C/C++/C#/Java: split on function/class/struct definitions
        sections = re.split(r'(?=^(?:[\w:]+\s+)+[\w:]+\s*\()', text, flags=re.MULTILINE)
    elif suffix == ".js":
        # JavaScript: split on function/class/const/export
        sections = re.split(r'(?=^(?:function |class |const |export |async function |=>))', text, flags=re.MULTILINE)
    elif suffix == ".ps1":
        # PowerShell: split on function definitions
        sections = re.split(r'(?=^(?:function |\$\w+\s*=|#region))', text, flags=re.MULTILINE)
    else:
        sections = [text]

    chunks = []
    for section in sections:
        section = section.strip()
        if not section:
            continue
        chunks.extend(_split_by_size(section))
    return chunks if chunks else _chunk_plain(text)


def _extract_tags(relative: str, text: str) -> List[str]:
    """Extract topic tags from file path and content."""
    combined = (relative + " " + text[:500]).lower()
    tags = []
    for tag, keywords in _TAG_PATTERNS.items():
        if any(kw in combined for kw in keywords):
            tags.append(tag)
    return tags
