"""Pluggable embedder for the RAG engine.

Provides three backends:
1. None (default) — no embeddings, BM25 keyword-only
2. sentence-transformers — local MiniLM model when available
3. External API — pluggable for future OpenAI/Anthropic embeddings
"""

from __future__ import annotations

import hashlib
from typing import Any, Dict, List, Optional, Tuple

# Optional imports — gracefully degrade if not installed
try:
    from sentence_transformers import SentenceTransformer
    _ST_AVAILABLE = True
except ImportError:
    _ST_AVAILABLE = False

_DEFAULT_MODEL = "all-MiniLM-L6-v2"


class Embedder:
    """Pluggable text embedder with graceful fallback."""

    def __init__(self, model_name: Optional[str] = None, cache_dir: Optional[str] = None):
        self.model_name = model_name or _DEFAULT_MODEL
        self._model: Any = None
        self._available = False
        self._cache: Dict[str, List[float]] = {}
        self._cache_dir = cache_dir

        if _ST_AVAILABLE:
            try:
                self._model = SentenceTransformer(
                    self.model_name,
                    cache_folder=cache_dir,
                )
                self._available = True
            except Exception:
                self._available = False

    @property
    def available(self) -> bool:
        return self._available

    @property
    def dimension(self) -> int:
        if not self._available:
            return 0
        try:
            return self._model.get_sentence_embedding_dimension()
        except Exception:
            return 384  # MiniLM default

    def embed(self, text: str) -> Optional[List[float]]:
        if not self._available:
            return None
        key = hashlib.md5(text.encode()).hexdigest()
        if key in self._cache:
            return self._cache[key]
        try:
            vec = self._model.encode(text, normalize_embeddings=True)
            result = vec.tolist()
            self._cache[key] = result
            return result
        except Exception:
            return None

    def embed_batch(self, texts: List[str]) -> List[Optional[List[float]]]:
        if not self._available:
            return [None] * len(texts)
        results = []
        for text in texts:
            results.append(self.embed(text))
        return results

    def status(self) -> Dict[str, Any]:
        return {
            "available": self._available,
            "model": self.model_name if self._available else "none",
            "dimension": self.dimension,
            "cache_size": len(self._cache),
        }
