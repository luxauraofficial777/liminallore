"""Graph traversal layer for the RAG engine.

Builds a file-level reference graph from include/import/commit references
extracted during indexing, enabling multi-hop traversal from initial
search results to related files.
"""

from __future__ import annotations

import json
import re
import sqlite3
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

_GRAPH_SCHEMA = """
CREATE TABLE IF NOT EXISTS file_edges (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    source_path TEXT NOT NULL,
    target_path TEXT NOT NULL,
    edge_type   TEXT NOT NULL DEFAULT 'reference',
    weight      REAL NOT NULL DEFAULT 1.0,
    UNIQUE(source_path, target_path, edge_type)
);

CREATE INDEX IF NOT EXISTS idx_edges_source ON file_edges(source_path);
CREATE INDEX IF NOT EXISTS idx_edges_target ON file_edges(target_path);

CREATE TABLE IF NOT EXISTS agent_slices (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id    TEXT NOT NULL,
    relative_path TEXT NOT NULL,
    priority    REAL NOT NULL DEFAULT 1.0,
    tags        TEXT NOT NULL DEFAULT '[]',
    UNIQUE(agent_id, relative_path)
);

CREATE INDEX IF NOT EXISTS idx_slices_agent ON agent_slices(agent_id);
"""

_INCLUDE_PATTERNS = [
    re.compile(r'#include\s+[<"]([^>"]+)[>"]'),
    re.compile(r'from\s+([\w.]+)\s+import'),
    re.compile(r'import\s+([\w.]+)'),
    re.compile(r'require\([\'"]([^\'"]+)[\'"]\)'),
    re.compile(r'import\s+[\'"]([^\'"]+)[\'"]'),
    re.compile(r'\[\[([^\]]+)\]\]'),
    re.compile(r'\[([^\]]+)\]\([^\)]+\)'),
]

_REFERENCE_PATTERNS = [
    re.compile(r'(?:see|ref|reference|see also|related)\s*:?\s*([^\n]{3,80})', re.IGNORECASE),
    re.compile(r'(?:depends on|requires|uses|calls)\s*:?\s*([^\n]{3,80})', re.IGNORECASE),
]


def _extract_references(text: str, relative_path: str) -> List[Tuple[str, str]]:
    """Extract references from chunk text. Returns (target_hint, edge_type) pairs."""
    refs: List[Tuple[str, str]] = []
    for pattern in _INCLUDE_PATTERNS:
        for m in pattern.finditer(text):
            target = m.group(1).strip()
            if target and not target.startswith("http"):
                refs.append((target, "include"))
    for pattern in _REFERENCE_PATTERNS:
        for m in pattern.finditer(text):
            target = m.group(1).strip().rstrip(".")
            if target and len(target) > 2:
                refs.append((target, "reference"))
    return refs


def _resolve_reference(target_hint: str, known_files: Set[str]) -> Optional[str]:
    """Resolve a reference hint to an actual file path."""
    target_hint = target_hint.replace("\\", "/").strip()
    candidates = [
        target_hint,
        target_hint + ".py",
        target_hint + ".js",
        target_hint + ".cpp",
        target_hint + ".h",
        target_hint + ".md",
        target_hint + ".json",
        target_hint + ".ts",
        target_hint + ".tsx",
        target_hint + ".jsx",
    ]
    for c in candidates:
        if c in known_files:
            return c
        for kf in known_files:
            if kf.endswith("/" + c) or kf.endswith("\\" + c):
                return kf
            if kf.endswith(c):
                return kf
    return None


class GraphIndex:
    """File-level reference graph with multi-hop traversal."""

    def __init__(self, db_path: Path):
        self.db_path = db_path
        self._lock = threading.RLock()
        self._conn: Optional[sqlite3.Connection] = None
        self._init_db()

    def _init_db(self) -> None:
        with self._lock:
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._conn.executescript(_GRAPH_SCHEMA)
            self._conn.commit()

    def build_from_indexer(self, indexer: Any) -> Dict[str, Any]:
        """Build the edge graph from an Indexer's chunk database."""
        with self._lock:
            self._conn.execute("DELETE FROM file_edges")

        known_files: Set[str] = set()
        rows = indexer._conn.execute("SELECT relative_path FROM files").fetchall()
        for (rp,) in rows:
            known_files.add(rp)

        edges_built = 0
        chunk_rows = indexer._conn.execute(
            "SELECT relative_path, text FROM chunks"
        ).fetchall()

        for rp, text in chunk_rows:
            refs = _extract_references(text, rp)
            for target_hint, edge_type in refs:
                resolved = _resolve_reference(target_hint, known_files)
                if resolved and resolved != rp:
                    with self._lock:
                        self._conn.execute(
                            """INSERT OR IGNORE INTO file_edges
                               (source_path, target_path, edge_type, weight)
                               VALUES (?, ?, ?, ?)""",
                            (rp, resolved, edge_type, 1.0),
                        )
                        edges_built += 1

        with self._lock:
            self._conn.commit()

        return {
            "status": "ok",
            "known_files": len(known_files),
            "edges_built": edges_built,
        }

    def traverse(
        self,
        seed_paths: List[str],
        max_hops: int = 2,
        max_results: int = 30,
        edge_types: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """Multi-hop BFS traversal from seed paths."""
        visited: Dict[str, int] = {}
        queue: List[Tuple[str, int]] = [(p, 0) for p in seed_paths]
        results: List[Dict[str, Any]] = []

        while queue and len(results) < max_results:
            current, hops = queue.pop(0)
            if current in visited:
                continue
            visited[current] = hops

            results.append({
                "path": current,
                "hops": hops,
                "seed": hops == 0,
            })

            if hops >= max_hops:
                continue

            neighbors = self.get_neighbors(current, edge_types)
            for neighbor, edge_type, weight in neighbors:
                if neighbor not in visited:
                    queue.append((neighbor, hops + 1))

        return results

    def get_neighbors(
        self, path: str, edge_types: Optional[List[str]] = None
    ) -> List[Tuple[str, str, float]]:
        """Get direct neighbors of a file in the graph."""
        with self._lock:
            if edge_types:
                placeholders = ",".join("?" * len(edge_types))
                rows = self._conn.execute(
                    f"""SELECT target_path, edge_type, weight FROM file_edges
                        WHERE source_path = ? AND edge_type IN ({placeholders})
                        ORDER BY weight DESC""",
                    (path, *edge_types),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    """SELECT target_path, edge_type, weight FROM file_edges
                        WHERE source_path = ? ORDER BY weight DESC""",
                    (path,),
                ).fetchall()
        return [(r[0], r[1], r[2]) for r in rows]

    def get_reverse_neighbors(
        self, path: str, edge_types: Optional[List[str]] = None
    ) -> List[Tuple[str, str, float]]:
        """Get files that reference the given path."""
        with self._lock:
            if edge_types:
                placeholders = ",".join("?" * len(edge_types))
                rows = self._conn.execute(
                    f"""SELECT source_path, edge_type, weight FROM file_edges
                        WHERE target_path = ? AND edge_type IN ({placeholders})
                        ORDER BY weight DESC""",
                    (path, *edge_types),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    """SELECT source_path, edge_type, weight FROM file_edges
                        WHERE target_path = ? ORDER BY weight DESC""",
                    (path,),
                ).fetchall()
        return [(r[0], r[1], r[2]) for r in rows]

    def status(self) -> Dict[str, Any]:
        with self._lock:
            edge_count = self._conn.execute("SELECT COUNT(*) FROM file_edges").fetchone()[0]
            source_count = self._conn.execute(
                "SELECT COUNT(DISTINCT source_path) FROM file_edges"
            ).fetchone()[0]
            target_count = self._conn.execute(
                "SELECT COUNT(DISTINCT target_path) FROM file_edges"
            ).fetchone()[0]
            slice_count = self._conn.execute("SELECT COUNT(*) FROM agent_slices").fetchone()[0]
        return {
            "edges": edge_count,
            "source_files": source_count,
            "target_files": target_count,
            "agent_slices": slice_count,
        }

    # ── Agent-specific slices ────────────────────────────────────

    def set_agent_slice(
        self,
        agent_id: str,
        relative_path: str,
        priority: float = 1.0,
        tags: Optional[List[str]] = None,
    ) -> None:
        with self._lock:
            self._conn.execute(
                """INSERT OR REPLACE INTO agent_slices
                   (agent_id, relative_path, priority, tags)
                   VALUES (?, ?, ?, ?)""",
                (agent_id, relative_path, priority, json.dumps(tags or [])),
            )
            self._conn.commit()

    def remove_agent_slice(self, agent_id: str, relative_path: str) -> None:
        with self._lock:
            self._conn.execute(
                "DELETE FROM agent_slices WHERE agent_id=? AND relative_path=?",
                (agent_id, relative_path),
            )
            self._conn.commit()

    def get_agent_slice(self, agent_id: str) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                """SELECT relative_path, priority, tags FROM agent_slices
                   WHERE agent_id=? ORDER BY priority DESC""",
                (agent_id,),
            ).fetchall()
        return [
            {"path": r[0], "priority": r[1], "tags": json.loads(r[2]) if r[2] else []}
            for r in rows
        ]

    def clear_agent_slice(self, agent_id: str) -> int:
        with self._lock:
            cur = self._conn.execute(
                "DELETE FROM agent_slices WHERE agent_id=?", (agent_id,)
            )
            self._conn.commit()
            return cur.rowcount

    def filter_paths_for_agent(
        self, agent_id: str, paths: List[str]
    ) -> List[Tuple[str, float]]:
        """Filter and boost paths based on agent slice priorities."""
        slices = self.get_agent_slice(agent_id)
        if not slices:
            return [(p, 1.0) for p in paths]
        slice_map = {s["path"]: s["priority"] for s in slices}
        result = []
        for p in paths:
            priority = slice_map.get(p, 0.0)
            if priority > 0:
                result.append((p, priority))
            else:
                for sp, spri in slice_map.items():
                    if p.startswith(sp) or sp.startswith(p):
                        result.append((p, spri * 0.5))
                        break
                else:
                    result.append((p, 0.1))
        return result

    def close(self) -> None:
        with self._lock:
            if self._conn:
                self._conn.close()
                self._conn = None
