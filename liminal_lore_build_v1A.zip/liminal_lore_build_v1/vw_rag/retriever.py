"""Hybrid retrieval engine for the RAG system.

Combines BM25 keyword search with optional vector similarity,
applies reciprocal rank fusion, and adds a recency boost for
recently modified files.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from .embedder import Embedder
from .indexer import Indexer
from .models import Chunk, SearchResult
from .graph_index import GraphIndex


class Retriever:
    """Hybrid retrieval: BM25 + vector + recency boost + graph traversal."""

    def __init__(self, indexer: Indexer, embedder: Optional[Embedder] = None,
                 graph: Optional[GraphIndex] = None):
        self.indexer = indexer
        self.embedder = embedder or indexer.embedder
        self.graph = graph

    def query(
        self,
        query: str,
        max_chunks: int = 20,
        max_bytes: int = 200000,
        tags: Optional[List[str]] = None,
        after: Optional[str] = None,
        recency_days: int = 7,
        agent_id: Optional[str] = None,
        graph_hops: int = 0,
        graph_max_extra: int = 10,
    ) -> Dict[str, Any]:
        """Run a hybrid retrieval query with optional graph traversal and agent filtering."""
        # 1. BM25 keyword search
        bm25_results = self.indexer.search_fts(query, limit=max_chunks * 2)
        bm25_ranked = self._rank_to_dict(bm25_results)

        # 2. Vector similarity search (if available)
        vector_ranked: Dict[str, float] = {}
        if self.embedder.available:
            query_vec = self.embedder.embed(query)
            if query_vec:
                vec_results = self.indexer.search_vector(query_vec, limit=max_chunks * 2)
                vector_ranked = self._rank_to_dict(vec_results)

        # 3. Reciprocal rank fusion
        fused = self._reciprocal_rank_fusion(bm25_ranked, vector_ranked)

        # 4. Build results with recency boost
        results: List[SearchResult] = []
        total_bytes = 0
        cutoff_date = None
        if after:
            try:
                cutoff_date = datetime.fromisoformat(after)
                if cutoff_date.tzinfo is None:
                    cutoff_date = cutoff_date.replace(tzinfo=timezone.utc)
            except Exception:
                cutoff_date = None

        recency_cutoff = datetime.now(timezone.utc) - timedelta(days=recency_days)

        for chunk_id, fused_score in fused.items():
            chunk = self.indexer.get_chunk(chunk_id)
            if not chunk:
                continue

            # Tag filter
            if tags and not any(t in chunk.tags for t in tags):
                continue

            # Date filter
            if cutoff_date and chunk.modified:
                try:
                    mod_date = datetime.fromisoformat(chunk.modified)
                    if mod_date.tzinfo is None:
                        mod_date = mod_date.replace(tzinfo=timezone.utc)
                    if mod_date < cutoff_date:
                        continue
                except Exception:
                    pass

            # Recency boost
            recency_boost = 0.0
            if chunk.modified:
                try:
                    mod_date = datetime.fromisoformat(chunk.modified)
                    if mod_date.tzinfo is None:
                        mod_date = mod_date.replace(tzinfo=timezone.utc)
                    if mod_date >= recency_cutoff:
                        recency_boost = 0.1
                except Exception:
                    pass

            bm25_score = bm25_ranked.get(chunk_id, 0.0)
            vec_score = vector_ranked.get(chunk_id, 0.0)
            final_score = fused_score + recency_boost

            source = "hybrid" if bm25_score and vec_score else ("vector" if vec_score else "keyword")

            result = SearchResult(
                chunk=chunk,
                score=final_score,
                bm25_score=bm25_score,
                vector_score=vec_score,
                recency_boost=recency_boost,
                source=source,
            )
            results.append(result)

            total_bytes += len(chunk.text)
            if len(results) >= max_chunks or total_bytes >= max_bytes:
                break

        # 5. Graph traversal expansion
        graph_results: List[Dict[str, Any]] = []
        if graph_hops > 0 and self.graph:
            seed_paths = list({r.chunk.relative_path for r in results})
            if seed_paths:
                traversed = self.graph.traverse(
                    seed_paths,
                    max_hops=graph_hops,
                    max_results=graph_max_extra + len(seed_paths),
                )
                existing_paths = {r.chunk.relative_path for r in results}
                for entry in traversed:
                    if entry["path"] not in existing_paths and not entry["seed"]:
                        graph_results.append(entry)
                        # Try to fetch first chunk of this file
                        file_chunks = self.indexer._conn.execute(
                            "SELECT chunk_id FROM chunks WHERE relative_path=? ORDER BY position LIMIT 1",
                            (entry["path"],),
                        ).fetchall()
                        if file_chunks:
                            chunk = self.indexer.get_chunk(file_chunks[0][0])
                            if chunk:
                                agent_boost = 0.0
                                if agent_id and self.graph:
                                    priorities = self.graph.filter_paths_for_agent(
                                        agent_id, [entry["path"]]
                                    )
                                    if priorities:
                                        agent_boost = (priorities[0][1] - 0.1) * 0.2

                                result = SearchResult(
                                    chunk=chunk,
                                    score=0.3 - (entry["hops"] * 0.1) + agent_boost,
                                    bm25_score=0.0,
                                    vector_score=0.0,
                                    recency_boost=0.0,
                                    source=f"graph_hop_{entry['hops']}",
                                )
                                results.append(result)
                                total_bytes += len(chunk.text)
                                if len(results) >= max_chunks + graph_max_extra or total_bytes >= max_bytes:
                                    break

        # 6. Agent-slice priority boosting
        if agent_id and self.graph:
            for r in results:
                priorities = self.graph.filter_paths_for_agent(
                    agent_id, [r.chunk.relative_path]
                )
                if priorities and priorities[0][1] > 1.0:
                    r.score += (priorities[0][1] - 1.0) * 0.15

        return {
            "status": "ok",
            "query": query,
            "total_chunks": len(results),
            "returned_bytes": total_bytes,
            "has_embeddings": self.embedder.available,
            "agent_id": agent_id,
            "graph_traversed": len(graph_results),
            "results": [r.to_dict() for r in results],
        }

    def _rank_to_dict(self, ranked: List[tuple]) -> Dict[str, float]:
        """Convert (chunk_id, score) list to normalized dict."""
        if not ranked:
            return {}
        scores = [s for _, s in ranked]
        min_s = min(scores)
        max_s = max(scores)
        range_s = max_s - min_s if max_s != min_s else 1.0
        return {cid: (s - min_s) / range_s for cid, s in ranked}

    def _reciprocal_rank_fusion(
        self, bm25: Dict[str, float], vector: Dict[str, float], k: int = 60
    ) -> Dict[str, float]:
        """Fuse BM25 and vector rankings using reciprocal rank fusion."""
        all_ids = set(bm25.keys()) | set(vector.keys())
        bm25_ranked = sorted(bm25.keys(), key=lambda x: -bm25[x])
        vector_ranked = sorted(vector.keys(), key=lambda x: -vector[x])

        bm25_pos = {cid: i + 1 for i, cid in enumerate(bm25_ranked)}
        vector_pos = {cid: i + 1 for i, cid in enumerate(vector_ranked)}

        fused: Dict[str, float] = {}
        for cid in all_ids:
            score = 0.0
            if cid in bm25_pos:
                score += 1.0 / (k + bm25_pos[cid])
            if cid in vector_pos:
                score += 1.0 / (k + vector_pos[cid])
            fused[cid] = score
        return dict(sorted(fused.items(), key=lambda x: -x[1]))
